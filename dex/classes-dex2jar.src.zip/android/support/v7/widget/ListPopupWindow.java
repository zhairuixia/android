package android.support.v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v4.a.a.a;
import android.support.v4.c.d;
import android.support.v4.view.ah;
import android.support.v4.view.n;
import android.support.v4.view.y;
import android.support.v4.widget.k;
import android.support.v4.widget.m;
import android.support.v7.a.a.a;
import android.support.v7.a.a.k;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnTouchListener;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import java.lang.reflect.Method;

public class ListPopupWindow
{
  private static Method Jf;
  private static Method Jg;
  public int ED = 0;
  int Ij = -2;
  private final e JA = new e((byte)0);
  private final c JB = new c((byte)0);
  private Runnable JC;
  private boolean JD;
  private int JE;
  public PopupWindow Jh;
  public a Ji;
  private int Jj = -2;
  int Jk;
  int Jl;
  private int Jm = 1002;
  boolean Jn;
  private boolean Jo = false;
  private boolean Jp = false;
  int Jq = 2147483647;
  private View Jr;
  int Js = 0;
  private DataSetObserver Jt;
  public View Ju;
  private Drawable Jv;
  public AdapterView.OnItemClickListener Jw;
  private AdapterView.OnItemSelectedListener Jx;
  private final g Jy = new g((byte)0);
  private final f Jz = new f((byte)0);
  private Rect kh = new Rect();
  private Context mContext;
  private final Handler mHandler;
  private ListAdapter sz;

  static
  {
    try
    {
      Jf = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", new Class[] { Boolean.TYPE });
      try
      {
        label20: Jg = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[] { View.class, Integer.TYPE, Boolean.TYPE });
        return;
      }
      catch (NoSuchMethodException localNoSuchMethodException1)
      {
      }
    }
    catch (NoSuchMethodException localNoSuchMethodException2)
    {
      break label20;
    }
  }

  public ListPopupWindow(Context paramContext)
  {
    this(paramContext, null, a.a.listPopupWindowStyle);
  }

  public ListPopupWindow(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, a.a.listPopupWindowStyle);
  }

  public ListPopupWindow(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }

  public ListPopupWindow(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2)
  {
    this.mContext = paramContext;
    this.mHandler = new Handler(paramContext.getMainLooper());
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, a.k.zA, paramInt1, paramInt2);
    this.Jk = localTypedArray.getDimensionPixelOffset(a.k.zB, 0);
    this.Jl = localTypedArray.getDimensionPixelOffset(a.k.zC, 0);
    if (this.Jl != 0)
      this.Jn = true;
    localTypedArray.recycle();
    this.Jh = new AppCompatPopupWindow(paramContext, paramAttributeSet, paramInt1);
    this.Jh.setInputMethodMode(1);
    this.JE = d.getLayoutDirectionFromLocale(this.mContext.getResources().getConfiguration().locale);
  }

  private int a(View paramView, int paramInt, boolean paramBoolean)
  {
    if (Jg != null)
      try
      {
        int i = ((Integer)Jg.invoke(this.Jh, new Object[] { paramView, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) })).intValue();
        return i;
      }
      catch (Exception localException)
      {
      }
    return this.Jh.getMaxAvailableHeight(paramView, paramInt);
  }

  public final void clearListSelection()
  {
    a locala = this.Ji;
    if (locala != null)
    {
      a.a(locala, true);
      locala.requestLayout();
    }
  }

  public final void dismiss()
  {
    this.Jh.dismiss();
    if (this.Jr != null)
    {
      ViewParent localViewParent = this.Jr.getParent();
      if ((localViewParent instanceof ViewGroup))
        ((ViewGroup)localViewParent).removeView(this.Jr);
    }
    this.Jh.setContentView(null);
    this.Ji = null;
    this.mHandler.removeCallbacks(this.Jy);
  }

  public final void dv()
  {
    this.JD = true;
    this.Jh.setFocusable(true);
  }

  public final void dw()
  {
    this.Jh.setInputMethodMode(2);
  }

  public final boolean isInputMethodNotNeeded()
  {
    return this.Jh.getInputMethodMode() == 2;
  }

  public void setAdapter(ListAdapter paramListAdapter)
  {
    if (this.Jt == null)
      this.Jt = new d((byte)0);
    while (true)
    {
      this.sz = paramListAdapter;
      if (this.sz != null)
        paramListAdapter.registerDataSetObserver(this.Jt);
      if (this.Ji != null)
        this.Ji.setAdapter(this.sz);
      return;
      if (this.sz != null)
        this.sz.unregisterDataSetObserver(this.Jt);
    }
  }

  public final void setBackgroundDrawable(Drawable paramDrawable)
  {
    this.Jh.setBackgroundDrawable(paramDrawable);
  }

  public final void setContentWidth(int paramInt)
  {
    Drawable localDrawable = this.Jh.getBackground();
    if (localDrawable != null)
    {
      localDrawable.getPadding(this.kh);
      this.Ij = (this.kh.left + this.kh.right + paramInt);
      return;
    }
    this.Ij = paramInt;
  }

  public final void setOnDismissListener(PopupWindow.OnDismissListener paramOnDismissListener)
  {
    this.Jh.setOnDismissListener(paramOnDismissListener);
  }

  public void show()
  {
    boolean bool3 = true;
    boolean bool2 = true;
    Object localObject2;
    boolean bool1;
    Object localObject1;
    View localView;
    LinearLayout.LayoutParams localLayoutParams;
    label246: int j;
    int i;
    if (this.Ji == null)
    {
      localObject2 = this.mContext;
      this.JC = new Runnable()
      {
        public final void run()
        {
          View localView = ListPopupWindow.this.Ju;
          if ((localView != null) && (localView.getWindowToken() != null))
            ListPopupWindow.this.show();
        }
      };
      if (!this.JD)
      {
        bool1 = true;
        this.Ji = new a((Context)localObject2, bool1);
        if (this.Jv != null)
          this.Ji.setSelector(this.Jv);
        this.Ji.setAdapter(this.sz);
        this.Ji.setOnItemClickListener(this.Jw);
        this.Ji.setFocusable(true);
        this.Ji.setFocusableInTouchMode(true);
        this.Ji.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
          public final void onItemSelected(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong)
          {
            if (paramAnonymousInt != -1)
            {
              paramAnonymousAdapterView = ListPopupWindow.a(ListPopupWindow.this);
              if (paramAnonymousAdapterView != null)
                ListPopupWindow.a.a(paramAnonymousAdapterView, false);
            }
          }

          public final void onNothingSelected(AdapterView<?> paramAnonymousAdapterView)
          {
          }
        });
        this.Ji.setOnScrollListener(this.JA);
        if (this.Jx != null)
          this.Ji.setOnItemSelectedListener(this.Jx);
        localObject1 = this.Ji;
        localView = this.Jr;
        if (localView == null)
          break label1215;
        localObject2 = new LinearLayout((Context)localObject2);
        ((LinearLayout)localObject2).setOrientation(1);
        localLayoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0F);
        switch (this.Js)
        {
        default:
          new StringBuilder("Invalid hint position ").append(this.Js);
          if (this.Ij >= 0)
          {
            j = this.Ij;
            i = -2147483648;
            label262: localView.measure(View.MeasureSpec.makeMeasureSpec(j, i), 0);
            localObject1 = (LinearLayout.LayoutParams)localView.getLayoutParams();
            i = localView.getMeasuredHeight();
            j = ((LinearLayout.LayoutParams)localObject1).topMargin;
            i = ((LinearLayout.LayoutParams)localObject1).bottomMargin + (i + j);
            localObject1 = localObject2;
          }
          break;
        case 1:
        case 0:
        }
      }
    }
    while (true)
    {
      this.Jh.setContentView((View)localObject1);
      while (true)
      {
        label318: localObject1 = this.Jh.getBackground();
        int k;
        label381: int m;
        if (localObject1 != null)
        {
          ((Drawable)localObject1).getPadding(this.kh);
          j = this.kh.top + this.kh.bottom;
          k = j;
          if (!this.Jn)
          {
            this.Jl = (-this.kh.top);
            k = j;
          }
          if (this.Jh.getInputMethodMode() != 2)
            break label718;
          bool1 = true;
          label395: m = a(this.Ju, this.Jl, bool1);
          if ((!this.Jo) && (this.Jj != -1))
            break label724;
          i = m + k;
          bool1 = isInputMethodNotNeeded();
          m.a(this.Jh, this.Jm);
          if (!this.Jh.isShowing())
            break label976;
          if (this.Ij != -1)
            break label874;
          j = -1;
          label468: if (this.Jj != -1)
            break label950;
          if (!bool1)
            break label902;
          label481: if (!bool1)
            break label912;
          localObject1 = this.Jh;
          if (this.Ij != -1)
            break label907;
          k = -1;
          label502: ((PopupWindow)localObject1).setWidth(k);
          this.Jh.setHeight(0);
          label516: localObject1 = this.Jh;
          if ((this.Jp) || (this.Jo))
            break label970;
          bool1 = bool2;
          label540: ((PopupWindow)localObject1).setOutsideTouchable(bool1);
          localObject1 = this.Jh;
          localObject2 = this.Ju;
          m = this.Jk;
          int n = this.Jl;
          k = j;
          if (j < 0)
            k = -1;
          j = i;
          if (i < 0)
            j = -1;
          ((PopupWindow)localObject1).update((View)localObject2, m, n, k, j);
        }
        while (true)
        {
          return;
          bool1 = false;
          break;
          ((LinearLayout)localObject2).addView((View)localObject1, localLayoutParams);
          ((LinearLayout)localObject2).addView(localView);
          break label246;
          ((LinearLayout)localObject2).addView(localView);
          ((LinearLayout)localObject2).addView((View)localObject1, localLayoutParams);
          break label246;
          i = 0;
          j = 0;
          break label262;
          this.Jh.getContentView();
          localObject1 = this.Jr;
          if (localObject1 != null)
          {
            localObject2 = (LinearLayout.LayoutParams)((View)localObject1).getLayoutParams();
            i = ((View)localObject1).getMeasuredHeight();
            j = ((LinearLayout.LayoutParams)localObject2).topMargin;
            i = ((LinearLayout.LayoutParams)localObject2).bottomMargin + (i + j);
            break label318;
            this.kh.setEmpty();
            k = 0;
            break label381;
            label718: bool1 = false;
            break label395;
            label724: switch (this.Ij)
            {
            default:
              j = View.MeasureSpec.makeMeasureSpec(this.Ij, 1073741824);
            case -2:
            case -1:
            }
            while (true)
            {
              m = this.Ji.q(j, m - i);
              j = i;
              if (m > 0)
                j = i + k;
              i = j + m;
              break;
              j = View.MeasureSpec.makeMeasureSpec(this.mContext.getResources().getDisplayMetrics().widthPixels - (this.kh.left + this.kh.right), -2147483648);
              continue;
              j = View.MeasureSpec.makeMeasureSpec(this.mContext.getResources().getDisplayMetrics().widthPixels - (this.kh.left + this.kh.right), 1073741824);
            }
            label874: if (this.Ij == -2)
            {
              j = this.Ju.getWidth();
              break label468;
            }
            j = this.Ij;
            break label468;
            label902: i = -1;
            break label481;
            label907: k = 0;
            break label502;
            label912: localObject1 = this.Jh;
            if (this.Ij == -1);
            for (k = -1; ; k = 0)
            {
              ((PopupWindow)localObject1).setWidth(k);
              this.Jh.setHeight(-1);
              break;
            }
            label950: if (this.Jj == -2)
              break label516;
            i = this.Jj;
            break label516;
            label970: bool1 = false;
            break label540;
            label976: if (this.Ij == -1)
            {
              j = -1;
              label986: if (this.Jj != -1)
                break label1182;
              i = -1;
              label996: this.Jh.setWidth(j);
              this.Jh.setHeight(i);
              if (Jf == null);
            }
            try
            {
              Jf.invoke(this.Jh, new Object[] { Boolean.valueOf(true) });
              label1040: localObject1 = this.Jh;
              if ((!this.Jp) && (!this.Jo));
              for (bool1 = bool3; ; bool1 = false)
              {
                ((PopupWindow)localObject1).setOutsideTouchable(bool1);
                this.Jh.setTouchInterceptor(this.Jz);
                m.a(this.Jh, this.Ju, this.Jk, this.Jl, this.ED);
                this.Ji.setSelection(-1);
                if ((!this.JD) || (this.Ji.isInTouchMode()))
                  clearListSelection();
                if (this.JD)
                  break;
                this.mHandler.post(this.JB);
                return;
                if (this.Ij == -2)
                {
                  j = this.Ju.getWidth();
                  break label986;
                }
                j = this.Ij;
                break label986;
                label1182: if (this.Jj == -2)
                  break label996;
                i = this.Jj;
                break label996;
              }
            }
            catch (Exception localException)
            {
              break label1040;
            }
          }
        }
        i = 0;
      }
      label1215: i = 0;
    }
  }

  private static final class a extends ListViewCompat
  {
    private boolean JG;
    private boolean JH;
    private boolean JI;
    private ah JJ;
    private k JK;

    public a(Context paramContext, boolean paramBoolean)
    {
      super(null, a.a.dropDownListViewStyle);
      this.JH = paramBoolean;
      setCacheColorHint(0);
    }

    protected final boolean dx()
    {
      return (this.JI) || (super.dx());
    }

    public final boolean g(MotionEvent paramMotionEvent, int paramInt)
    {
      int i = n.d(paramMotionEvent);
      label41: View localView;
      switch (i)
      {
      default:
        paramInt = 0;
      case 3:
        for (bool = true; ; bool = false)
        {
          if ((!bool) || (paramInt != 0))
          {
            this.JI = false;
            setPressed(false);
            drawableStateChanged();
            localView = getChildAt(this.Kb - getFirstVisiblePosition());
            if (localView != null)
              localView.setPressed(false);
            if (this.JJ != null)
            {
              this.JJ.cancel();
              this.JJ = null;
            }
          }
          if (!bool)
            break;
          if (this.JK == null)
            this.JK = new k(this);
          this.JK.l(true);
          this.JK.onTouch(this, paramMotionEvent);
          label152: return bool;
          paramInt = 0;
        }
      case 1:
      case 2:
      }
      for (boolean bool = false; ; bool = true)
      {
        int j = paramMotionEvent.findPointerIndex(paramInt);
        if (j < 0)
        {
          paramInt = 0;
          bool = false;
          break label41;
        }
        paramInt = (int)paramMotionEvent.getX(j);
        int k = (int)paramMotionEvent.getY(j);
        j = pointToPosition(paramInt, k);
        if (j == -1)
        {
          paramInt = 1;
          break label41;
        }
        localView = getChildAt(j - getFirstVisiblePosition());
        float f1 = paramInt;
        float f2 = k;
        this.JI = true;
        if (Build.VERSION.SDK_INT >= 21)
          drawableHotspotChanged(f1, f2);
        if (!isPressed())
          setPressed(true);
        layoutChildren();
        if (this.Kb != -1)
        {
          localObject = getChildAt(this.Kb - getFirstVisiblePosition());
          if ((localObject != null) && (localObject != localView) && (((View)localObject).isPressed()))
            ((View)localObject).setPressed(false);
        }
        this.Kb = j;
        float f3 = localView.getLeft();
        float f4 = localView.getTop();
        if (Build.VERSION.SDK_INT >= 21)
          localView.drawableHotspotChanged(f1 - f3, f2 - f4);
        if (!localView.isPressed())
          localView.setPressed(true);
        Object localObject = getSelector();
        if ((localObject != null) && (j != -1))
        {
          paramInt = 1;
          label406: if (paramInt != 0)
            ((Drawable)localObject).setVisible(false, false);
          super.a(j, localView);
          if (paramInt != 0)
          {
            Rect localRect = this.JW;
            f3 = localRect.exactCenterX();
            f4 = localRect.exactCenterY();
            if (getVisibility() != 0)
              break label541;
          }
        }
        label541: for (bool = true; ; bool = false)
        {
          ((Drawable)localObject).setVisible(bool, false);
          a.a((Drawable)localObject, f3, f4);
          localObject = getSelector();
          if ((localObject != null) && (j != -1))
            a.a((Drawable)localObject, f1, f2);
          J(false);
          refreshDrawableState();
          if (i != 1)
            break;
          performItemClick(localView, j, getItemIdAtPosition(j));
          break;
          paramInt = 0;
          break label406;
        }
        if (this.JK == null)
          break label152;
        this.JK.l(false);
        return bool;
      }
    }

    public final boolean hasFocus()
    {
      return (this.JH) || (super.hasFocus());
    }

    public final boolean hasWindowFocus()
    {
      return (this.JH) || (super.hasWindowFocus());
    }

    public final boolean isFocused()
    {
      return (this.JH) || (super.isFocused());
    }

    public final boolean isInTouchMode()
    {
      return ((this.JH) && (this.JG)) || (super.isInTouchMode());
    }
  }

  public static abstract class b
    implements View.OnTouchListener
  {
    private final float JL;
    private final int JM;
    private final int JN;
    private final View JO;
    private Runnable JP;
    private Runnable JQ;
    private boolean JR;
    private boolean JS;
    private final int[] JT = new int[2];
    private int lB;

    public b(View paramView)
    {
      this.JO = paramView;
      this.JL = ViewConfiguration.get(paramView.getContext()).getScaledTouchSlop();
      this.JM = ViewConfiguration.getTapTimeout();
      this.JN = ((this.JM + ViewConfiguration.getLongPressTimeout()) / 2);
    }

    private void dy()
    {
      if (this.JQ != null)
        this.JO.removeCallbacks(this.JQ);
      if (this.JP != null)
        this.JO.removeCallbacks(this.JP);
    }

    private boolean m(MotionEvent paramMotionEvent)
    {
      boolean bool1 = true;
      Object localObject1 = this.JO;
      Object localObject2 = ci();
      if ((localObject2 == null) || (!((ListPopupWindow)localObject2).Jh.isShowing()))
        bool1 = false;
      while (true)
      {
        return bool1;
        localObject2 = ListPopupWindow.a((ListPopupWindow)localObject2);
        if ((localObject2 == null) || (!((ListPopupWindow.a)localObject2).isShown()))
          return false;
        MotionEvent localMotionEvent = MotionEvent.obtainNoHistory(paramMotionEvent);
        int[] arrayOfInt = this.JT;
        ((View)localObject1).getLocationOnScreen(arrayOfInt);
        localMotionEvent.offsetLocation(arrayOfInt[0], arrayOfInt[1]);
        localObject1 = this.JT;
        ((View)localObject2).getLocationOnScreen((int[])localObject1);
        localMotionEvent.offsetLocation(-localObject1[0], -localObject1[1]);
        boolean bool2 = ((ListPopupWindow.a)localObject2).g(localMotionEvent, this.lB);
        localMotionEvent.recycle();
        int i = n.d(paramMotionEvent);
        if ((i != 1) && (i != 3));
        for (i = 1; (!bool2) || (i == 0); i = 0)
          return false;
      }
    }

    protected boolean cV()
    {
      ListPopupWindow localListPopupWindow = ci();
      if ((localListPopupWindow != null) && (localListPopupWindow.Jh.isShowing()))
        localListPopupWindow.dismiss();
      return true;
    }

    public abstract ListPopupWindow ci();

    public boolean cj()
    {
      ListPopupWindow localListPopupWindow = ci();
      if ((localListPopupWindow != null) && (!localListPopupWindow.Jh.isShowing()))
        localListPopupWindow.show();
      return true;
    }

    public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
    {
      boolean bool2 = false;
      boolean bool3 = this.JR;
      if (bool3)
      {
        if (this.JS)
          bool1 = m(paramMotionEvent);
        while (true)
        {
          this.JR = bool1;
          if (!bool1)
          {
            bool1 = bool2;
            if (!bool3);
          }
          else
          {
            bool1 = true;
          }
          return bool1;
          if ((m(paramMotionEvent)) || (!cV()))
            bool1 = true;
          else
            bool1 = false;
        }
      }
      paramView = this.JO;
      if (paramView.isEnabled());
      label128: int i;
      switch (n.d(paramMotionEvent))
      {
      default:
        i = 0;
        label131: if ((i == 0) || (!cj()))
          break;
      case 0:
      case 2:
      case 1:
      case 3:
      }
      for (boolean bool1 = true; ; bool1 = false)
      {
        if (bool1)
        {
          long l = SystemClock.uptimeMillis();
          paramView = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
          this.JO.onTouchEvent(paramView);
          paramView.recycle();
        }
        break;
        this.lB = paramMotionEvent.getPointerId(0);
        this.JS = false;
        if (this.JP == null)
          this.JP = new a((byte)0);
        paramView.postDelayed(this.JP, this.JM);
        if (this.JQ == null)
          this.JQ = new b((byte)0);
        paramView.postDelayed(this.JQ, this.JN);
        break label128;
        i = paramMotionEvent.findPointerIndex(this.lB);
        if (i < 0)
          break label128;
        float f1 = paramMotionEvent.getX(i);
        float f2 = paramMotionEvent.getY(i);
        float f3 = this.JL;
        if ((f1 >= -f3) && (f2 >= -f3) && (f1 < paramView.getRight() - paramView.getLeft() + f3) && (f2 < paramView.getBottom() - paramView.getTop() + f3));
        for (i = 1; i == 0; i = 0)
        {
          dy();
          paramView.getParent().requestDisallowInterceptTouchEvent(true);
          i = 1;
          break label131;
        }
        dy();
        break label128;
      }
    }

    private final class a
      implements Runnable
    {
      private a()
      {
      }

      public final void run()
      {
        ListPopupWindow.b.a(ListPopupWindow.b.this).getParent().requestDisallowInterceptTouchEvent(true);
      }
    }

    private final class b
      implements Runnable
    {
      private b()
      {
      }

      public final void run()
      {
        ListPopupWindow.b.b(ListPopupWindow.b.this);
      }
    }
  }

  private final class c
    implements Runnable
  {
    private c()
    {
    }

    public final void run()
    {
      ListPopupWindow.this.clearListSelection();
    }
  }

  private final class d extends DataSetObserver
  {
    private d()
    {
    }

    public final void onChanged()
    {
      if (ListPopupWindow.this.Jh.isShowing())
        ListPopupWindow.this.show();
    }

    public final void onInvalidated()
    {
      ListPopupWindow.this.dismiss();
    }
  }

  private final class e
    implements AbsListView.OnScrollListener
  {
    private e()
    {
    }

    public final void onScroll(AbsListView paramAbsListView, int paramInt1, int paramInt2, int paramInt3)
    {
    }

    public final void onScrollStateChanged(AbsListView paramAbsListView, int paramInt)
    {
      if ((paramInt == 1) && (!ListPopupWindow.this.isInputMethodNotNeeded()) && (ListPopupWindow.b(ListPopupWindow.this).getContentView() != null))
      {
        ListPopupWindow.d(ListPopupWindow.this).removeCallbacks(ListPopupWindow.c(ListPopupWindow.this));
        ListPopupWindow.c(ListPopupWindow.this).run();
      }
    }
  }

  private final class f
    implements View.OnTouchListener
  {
    private f()
    {
    }

    public final boolean onTouch(View paramView, MotionEvent paramMotionEvent)
    {
      int i = paramMotionEvent.getAction();
      int j = (int)paramMotionEvent.getX();
      int k = (int)paramMotionEvent.getY();
      if ((i == 0) && (ListPopupWindow.b(ListPopupWindow.this) != null) && (ListPopupWindow.b(ListPopupWindow.this).isShowing()) && (j >= 0) && (j < ListPopupWindow.b(ListPopupWindow.this).getWidth()) && (k >= 0) && (k < ListPopupWindow.b(ListPopupWindow.this).getHeight()))
        ListPopupWindow.d(ListPopupWindow.this).postDelayed(ListPopupWindow.c(ListPopupWindow.this), 250L);
      while (true)
      {
        return false;
        if (i == 1)
          ListPopupWindow.d(ListPopupWindow.this).removeCallbacks(ListPopupWindow.c(ListPopupWindow.this));
      }
    }
  }

  private final class g
    implements Runnable
  {
    private g()
    {
    }

    public final void run()
    {
      if ((ListPopupWindow.a(ListPopupWindow.this) != null) && (y.F(ListPopupWindow.a(ListPopupWindow.this))) && (ListPopupWindow.a(ListPopupWindow.this).getCount() > ListPopupWindow.a(ListPopupWindow.this).getChildCount()) && (ListPopupWindow.a(ListPopupWindow.this).getChildCount() <= ListPopupWindow.this.Jq))
      {
        ListPopupWindow.b(ListPopupWindow.this).setInputMethodMode(2);
        ListPopupWindow.this.show();
      }
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.ListPopupWindow
 * JD-Core Version:    0.6.2
 */