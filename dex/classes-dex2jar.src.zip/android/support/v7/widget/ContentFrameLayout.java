package android.support.v7.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View.MeasureSpec;
import android.widget.FrameLayout;

public class ContentFrameLayout extends FrameLayout
{
  public TypedValue IG;
  public TypedValue IH;
  public TypedValue II;
  public TypedValue IJ;
  public TypedValue IK;
  public TypedValue IL;
  public final Rect IM = new Rect();
  public a IN;

  public ContentFrameLayout(Context paramContext)
  {
    this(paramContext, null);
  }

  public ContentFrameLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public ContentFrameLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
  }

  public final void b(Rect paramRect)
  {
    fitSystemWindows(paramRect);
  }

  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
  }

  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    if (this.IN != null)
      this.IN.onDetachedFromWindow();
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int n = 0;
    DisplayMetrics localDisplayMetrics = getContext().getResources().getDisplayMetrics();
    int j;
    int i1;
    int i2;
    TypedValue localTypedValue;
    label61: int i;
    if (localDisplayMetrics.widthPixels < localDisplayMetrics.heightPixels)
    {
      j = 1;
      i1 = View.MeasureSpec.getMode(paramInt1);
      i2 = View.MeasureSpec.getMode(paramInt2);
      if (i1 != -2147483648)
        break label495;
      if (j == 0)
        break label353;
      localTypedValue = this.IJ;
      if ((localTypedValue == null) || (localTypedValue.type == 0))
        break label495;
      if (localTypedValue.type != 5)
        break label362;
      i = (int)localTypedValue.getDimension(localDisplayMetrics);
    }
    while (true)
    {
      label92: int m;
      int k;
      if (i > 0)
      {
        m = View.MeasureSpec.makeMeasureSpec(Math.min(i - (this.IM.left + this.IM.right), View.MeasureSpec.getSize(paramInt1)), 1073741824);
        k = 1;
      }
      while (true)
      {
        i = paramInt2;
        if (i2 == -2147483648)
        {
          if (j == 0)
            break label394;
          localTypedValue = this.IK;
          label150: i = paramInt2;
          if (localTypedValue != null)
          {
            i = paramInt2;
            if (localTypedValue.type != 0)
            {
              if (localTypedValue.type != 5)
                break label403;
              paramInt1 = (int)localTypedValue.getDimension(localDisplayMetrics);
            }
          }
        }
        while (true)
        {
          label185: i = paramInt2;
          if (paramInt1 > 0)
            i = View.MeasureSpec.makeMeasureSpec(Math.min(paramInt1 - (this.IM.top + this.IM.bottom), View.MeasureSpec.getSize(paramInt2)), 1073741824);
          super.onMeasure(m, i);
          i2 = getMeasuredWidth();
          m = View.MeasureSpec.makeMeasureSpec(i2, 1073741824);
          if ((k == 0) && (i1 == -2147483648))
            if (j != 0)
            {
              localTypedValue = this.IH;
              label266: if ((localTypedValue == null) || (localTypedValue.type == 0))
                break label476;
              if (localTypedValue.type != 5)
                break label444;
              paramInt1 = (int)localTypedValue.getDimension(localDisplayMetrics);
            }
          while (true)
          {
            label297: paramInt2 = paramInt1;
            if (paramInt1 > 0)
              paramInt2 = paramInt1 - (this.IM.left + this.IM.right);
            if (i2 < paramInt2)
              paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824);
            for (paramInt2 = 1; ; paramInt2 = n)
            {
              if (paramInt2 != 0)
                super.onMeasure(paramInt1, i);
              return;
              j = 0;
              break;
              label353: localTypedValue = this.II;
              break label61;
              label362: if (localTypedValue.type != 6)
                break label504;
              i = (int)localTypedValue.getFraction(localDisplayMetrics.widthPixels, localDisplayMetrics.widthPixels);
              break label92;
              label394: localTypedValue = this.IL;
              break label150;
              label403: if (localTypedValue.type != 6)
                break label490;
              paramInt1 = (int)localTypedValue.getFraction(localDisplayMetrics.heightPixels, localDisplayMetrics.heightPixels);
              break label185;
              localTypedValue = this.IG;
              break label266;
              label444: if (localTypedValue.type != 6)
                break label485;
              paramInt1 = (int)localTypedValue.getFraction(localDisplayMetrics.widthPixels, localDisplayMetrics.widthPixels);
              break label297;
              label476: paramInt1 = m;
            }
            label485: paramInt1 = 0;
          }
          label490: paramInt1 = 0;
        }
        label495: k = 0;
        m = paramInt1;
      }
      label504: i = 0;
    }
  }

  public static abstract interface a
  {
    public abstract void onDetachedFromWindow();
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.ContentFrameLayout
 * JD-Core Version:    0.6.2
 */