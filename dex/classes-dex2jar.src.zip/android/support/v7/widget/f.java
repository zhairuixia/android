package android.support.v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.v4.a.a.a;
import android.support.v4.widget.c;
import android.support.v7.a.a.k;
import android.util.AttributeSet;
import android.widget.CompoundButton;

final class f
{
  private boolean HA = false;
  private boolean HB;
  private final g Hp;
  private final CompoundButton Hw;
  private ColorStateList Hx = null;
  private PorterDuff.Mode Hy = null;
  private boolean Hz = false;

  f(CompoundButton paramCompoundButton, g paramg)
  {
    this.Hw = paramCompoundButton;
    this.Hp = paramg;
  }

  private void jdMethod_do()
  {
    Drawable localDrawable = c.a(this.Hw);
    if ((localDrawable != null) && ((this.Hz) || (this.HA)))
    {
      localDrawable = a.f(localDrawable).mutate();
      if (this.Hz)
        a.a(localDrawable, this.Hx);
      if (this.HA)
        a.a(localDrawable, this.Hy);
      if (localDrawable.isStateful())
        localDrawable.setState(this.Hw.getDrawableState());
      this.Hw.setButtonDrawable(localDrawable);
    }
  }

  final void a(AttributeSet paramAttributeSet, int paramInt)
  {
    paramAttributeSet = this.Hw.getContext().obtainStyledAttributes(paramAttributeSet, a.k.zh, paramInt, 0);
    try
    {
      if (paramAttributeSet.hasValue(a.k.zi))
      {
        paramInt = paramAttributeSet.getResourceId(a.k.zi, 0);
        if (paramInt != 0)
          this.Hw.setButtonDrawable(this.Hp.a(this.Hw.getContext(), paramInt, false));
      }
      if (paramAttributeSet.hasValue(a.k.zj))
        c.a(this.Hw, paramAttributeSet.getColorStateList(a.k.zj));
      if (paramAttributeSet.hasValue(a.k.zk))
        c.a(this.Hw, o.ai(paramAttributeSet.getInt(a.k.zk, -1)));
      return;
    }
    finally
    {
      paramAttributeSet.recycle();
    }
  }

  final int ah(int paramInt)
  {
    int i = paramInt;
    if (Build.VERSION.SDK_INT < 17)
    {
      Drawable localDrawable = c.a(this.Hw);
      i = paramInt;
      if (localDrawable != null)
        i = paramInt + localDrawable.getIntrinsicWidth();
    }
    return i;
  }

  final void c(ColorStateList paramColorStateList)
  {
    this.Hx = paramColorStateList;
    this.Hz = true;
    jdMethod_do();
  }

  final void c(PorterDuff.Mode paramMode)
  {
    this.Hy = paramMode;
    this.HA = true;
    jdMethod_do();
  }

  final void dn()
  {
    if (this.HB)
    {
      this.HB = false;
      return;
    }
    this.HB = true;
    jdMethod_do();
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.f
 * JD-Core Version:    0.6.2
 */