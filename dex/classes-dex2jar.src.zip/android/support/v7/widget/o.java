package android.support.v7.widget;

import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;
import android.graphics.drawable.DrawableContainer.DrawableContainerState;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ScaleDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build.VERSION;
import android.support.v4.a.a.c;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class o
{
  public static final Rect IO = new Rect();
  private static Class<?> IP;

  static
  {
    if (Build.VERSION.SDK_INT >= 18);
    try
    {
      IP = Class.forName("android.graphics.Insets");
      return;
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
    }
  }

  static PorterDuff.Mode ai(int paramInt)
  {
    switch (paramInt)
    {
    case 4:
    case 6:
    case 7:
    case 8:
    case 10:
    case 11:
    case 12:
    case 13:
    default:
    case 3:
    case 5:
    case 9:
    case 14:
    case 15:
    case 16:
    }
    do
    {
      return null;
      return PorterDuff.Mode.SRC_OVER;
      return PorterDuff.Mode.SRC_IN;
      return PorterDuff.Mode.SRC_ATOP;
      return PorterDuff.Mode.MULTIPLY;
      return PorterDuff.Mode.SCREEN;
    }
    while (Build.VERSION.SDK_INT < 11);
    return PorterDuff.Mode.valueOf("ADD");
  }

  public static Rect l(Drawable paramDrawable)
  {
    if (IP != null);
    while (true)
    {
      Object localObject;
      Rect localRect;
      int j;
      int i;
      try
      {
        paramDrawable = android.support.v4.a.a.a.g(paramDrawable);
        localObject = paramDrawable.getClass().getMethod("getOpticalInsets", new Class[0]).invoke(paramDrawable, new Object[0]);
        if (localObject != null)
        {
          localRect = new Rect();
          Field[] arrayOfField = IP.getFields();
          int k = arrayOfField.length;
          j = 0;
          paramDrawable = localRect;
          if (j >= k)
            break label211;
          paramDrawable = arrayOfField[j];
          String str = paramDrawable.getName();
          i = -1;
          switch (str.hashCode())
          {
          case 3317767:
            if (!str.equals("left"))
              break;
            i = 0;
            break;
          case 115029:
            if (!str.equals("top"))
              break;
            i = 1;
            break;
          case 108511772:
            if (!str.equals("right"))
              break;
            i = 2;
            break;
          case -1383228885:
            if (!str.equals("bottom"))
              break;
            i = 3;
            break;
            localRect.left = paramDrawable.getInt(localObject);
          }
        }
      }
      catch (Exception paramDrawable)
      {
      }
      paramDrawable = IO;
      label211: return paramDrawable;
      localRect.top = paramDrawable.getInt(localObject);
      break label288;
      localRect.right = paramDrawable.getInt(localObject);
      break label288;
      localRect.bottom = paramDrawable.getInt(localObject);
      break label288;
      switch (i)
      {
      case 0:
      case 1:
      case 2:
      case 3:
      }
      label288: j += 1;
    }
  }

  static void m(Drawable paramDrawable)
  {
    int[] arrayOfInt;
    if ((Build.VERSION.SDK_INT == 21) && ("android.graphics.drawable.VectorDrawable".equals(paramDrawable.getClass().getName())))
    {
      arrayOfInt = paramDrawable.getState();
      if ((arrayOfInt != null) && (arrayOfInt.length != 0))
        break label52;
      paramDrawable.setState(u.Mp);
    }
    while (true)
    {
      paramDrawable.setState(arrayOfInt);
      return;
      label52: paramDrawable.setState(u.EMPTY_STATE_SET);
    }
  }

  public static boolean n(Drawable paramDrawable)
  {
    while (true)
    {
      if ((paramDrawable instanceof LayerDrawable))
        return Build.VERSION.SDK_INT >= 16;
      if ((paramDrawable instanceof InsetDrawable))
        return Build.VERSION.SDK_INT >= 14;
      if ((paramDrawable instanceof StateListDrawable))
        return Build.VERSION.SDK_INT >= 8;
      if ((paramDrawable instanceof GradientDrawable))
        return Build.VERSION.SDK_INT >= 14;
      if ((paramDrawable instanceof DrawableContainer))
      {
        paramDrawable = paramDrawable.getConstantState();
        if (!(paramDrawable instanceof DrawableContainer.DrawableContainerState))
          break;
        paramDrawable = ((DrawableContainer.DrawableContainerState)paramDrawable).getChildren();
        int j = paramDrawable.length;
        int i = 0;
        while (i < j)
        {
          if (!n(paramDrawable[i]))
            return false;
          i += 1;
        }
      }
      if ((paramDrawable instanceof c))
      {
        paramDrawable = ((c)paramDrawable).ak();
      }
      else if ((paramDrawable instanceof android.support.v7.b.a.a))
      {
        paramDrawable = ((android.support.v7.b.a.a)paramDrawable).mDrawable;
      }
      else
      {
        if (!(paramDrawable instanceof ScaleDrawable))
          break;
        paramDrawable = ((ScaleDrawable)paramDrawable).getDrawable();
      }
    }
    return true;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.o
 * JD-Core Version:    0.6.2
 */