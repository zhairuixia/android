package android.support.v7.widget;

import android.content.res.AssetFileDescriptor;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Movie;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import java.io.InputStream;

class q extends Resources
{
  private final Resources pp;

  public q(Resources paramResources)
  {
    super(paramResources.getAssets(), paramResources.getDisplayMetrics(), paramResources.getConfiguration());
    this.pp = paramResources;
  }

  public XmlResourceParser getAnimation(int paramInt)
  {
    return this.pp.getAnimation(paramInt);
  }

  public boolean getBoolean(int paramInt)
  {
    return this.pp.getBoolean(paramInt);
  }

  public int getColor(int paramInt)
  {
    return this.pp.getColor(paramInt);
  }

  public ColorStateList getColorStateList(int paramInt)
  {
    return this.pp.getColorStateList(paramInt);
  }

  public Configuration getConfiguration()
  {
    return this.pp.getConfiguration();
  }

  public float getDimension(int paramInt)
  {
    return this.pp.getDimension(paramInt);
  }

  public int getDimensionPixelOffset(int paramInt)
  {
    return this.pp.getDimensionPixelOffset(paramInt);
  }

  public int getDimensionPixelSize(int paramInt)
  {
    return this.pp.getDimensionPixelSize(paramInt);
  }

  public DisplayMetrics getDisplayMetrics()
  {
    return this.pp.getDisplayMetrics();
  }

  public Drawable getDrawable(int paramInt)
  {
    return this.pp.getDrawable(paramInt);
  }

  public Drawable getDrawable(int paramInt, Resources.Theme paramTheme)
  {
    return this.pp.getDrawable(paramInt, paramTheme);
  }

  public Drawable getDrawableForDensity(int paramInt1, int paramInt2)
  {
    return this.pp.getDrawableForDensity(paramInt1, paramInt2);
  }

  public Drawable getDrawableForDensity(int paramInt1, int paramInt2, Resources.Theme paramTheme)
  {
    return this.pp.getDrawableForDensity(paramInt1, paramInt2, paramTheme);
  }

  public float getFraction(int paramInt1, int paramInt2, int paramInt3)
  {
    return this.pp.getFraction(paramInt1, paramInt2, paramInt3);
  }

  public int getIdentifier(String paramString1, String paramString2, String paramString3)
  {
    return this.pp.getIdentifier(paramString1, paramString2, paramString3);
  }

  public int[] getIntArray(int paramInt)
  {
    return this.pp.getIntArray(paramInt);
  }

  public int getInteger(int paramInt)
  {
    return this.pp.getInteger(paramInt);
  }

  public XmlResourceParser getLayout(int paramInt)
  {
    return this.pp.getLayout(paramInt);
  }

  public Movie getMovie(int paramInt)
  {
    return this.pp.getMovie(paramInt);
  }

  public String getQuantityString(int paramInt1, int paramInt2)
  {
    return this.pp.getQuantityString(paramInt1, paramInt2);
  }

  public String getQuantityString(int paramInt1, int paramInt2, Object[] paramArrayOfObject)
  {
    return this.pp.getQuantityString(paramInt1, paramInt2, paramArrayOfObject);
  }

  public CharSequence getQuantityText(int paramInt1, int paramInt2)
  {
    return this.pp.getQuantityText(paramInt1, paramInt2);
  }

  public String getResourceEntryName(int paramInt)
  {
    return this.pp.getResourceEntryName(paramInt);
  }

  public String getResourceName(int paramInt)
  {
    return this.pp.getResourceName(paramInt);
  }

  public String getResourcePackageName(int paramInt)
  {
    return this.pp.getResourcePackageName(paramInt);
  }

  public String getResourceTypeName(int paramInt)
  {
    return this.pp.getResourceTypeName(paramInt);
  }

  public String getString(int paramInt)
  {
    return this.pp.getString(paramInt);
  }

  public String getString(int paramInt, Object[] paramArrayOfObject)
  {
    return this.pp.getString(paramInt, paramArrayOfObject);
  }

  public String[] getStringArray(int paramInt)
  {
    return this.pp.getStringArray(paramInt);
  }

  public CharSequence getText(int paramInt)
  {
    return this.pp.getText(paramInt);
  }

  public CharSequence getText(int paramInt, CharSequence paramCharSequence)
  {
    return this.pp.getText(paramInt, paramCharSequence);
  }

  public CharSequence[] getTextArray(int paramInt)
  {
    return this.pp.getTextArray(paramInt);
  }

  public void getValue(int paramInt, TypedValue paramTypedValue, boolean paramBoolean)
  {
    this.pp.getValue(paramInt, paramTypedValue, paramBoolean);
  }

  public void getValue(String paramString, TypedValue paramTypedValue, boolean paramBoolean)
  {
    this.pp.getValue(paramString, paramTypedValue, paramBoolean);
  }

  public void getValueForDensity(int paramInt1, int paramInt2, TypedValue paramTypedValue, boolean paramBoolean)
  {
    this.pp.getValueForDensity(paramInt1, paramInt2, paramTypedValue, paramBoolean);
  }

  public XmlResourceParser getXml(int paramInt)
  {
    return this.pp.getXml(paramInt);
  }

  public TypedArray obtainAttributes(AttributeSet paramAttributeSet, int[] paramArrayOfInt)
  {
    return this.pp.obtainAttributes(paramAttributeSet, paramArrayOfInt);
  }

  public TypedArray obtainTypedArray(int paramInt)
  {
    return this.pp.obtainTypedArray(paramInt);
  }

  public InputStream openRawResource(int paramInt)
  {
    return this.pp.openRawResource(paramInt);
  }

  public InputStream openRawResource(int paramInt, TypedValue paramTypedValue)
  {
    return this.pp.openRawResource(paramInt, paramTypedValue);
  }

  public AssetFileDescriptor openRawResourceFd(int paramInt)
  {
    return this.pp.openRawResourceFd(paramInt);
  }

  public void parseBundleExtra(String paramString, AttributeSet paramAttributeSet, Bundle paramBundle)
  {
    this.pp.parseBundleExtra(paramString, paramAttributeSet, paramBundle);
  }

  public void parseBundleExtras(XmlResourceParser paramXmlResourceParser, Bundle paramBundle)
  {
    this.pp.parseBundleExtras(paramXmlResourceParser, paramBundle);
  }

  public void updateConfiguration(Configuration paramConfiguration, DisplayMetrics paramDisplayMetrics)
  {
    super.updateConfiguration(paramConfiguration, paramDisplayMetrics);
    if (this.pp != null)
      this.pp.updateConfiguration(paramConfiguration, paramDisplayMetrics);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.q
 * JD-Core Version:    0.6.2
 */