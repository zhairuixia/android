package android.support.v7.widget;

import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.v4.content.a;
import android.support.v7.a.a.k;
import android.util.AttributeSet;
import android.widget.ImageView;

public final class h
{
  private final ImageView HS;
  private final g Hp;

  public h(ImageView paramImageView, g paramg)
  {
    this.HS = paramImageView;
    this.Hp = paramg;
  }

  public final void a(AttributeSet paramAttributeSet, int paramInt)
  {
    paramAttributeSet = y.a(this.HS.getContext(), paramAttributeSet, a.k.yN, paramInt);
    try
    {
      Drawable localDrawable = paramAttributeSet.am(a.k.yO);
      if (localDrawable != null)
        this.HS.setImageDrawable(localDrawable);
      paramInt = paramAttributeSet.getResourceId(a.k.yP, -1);
      if (paramInt != -1)
      {
        localDrawable = this.Hp.a(this.HS.getContext(), paramInt, false);
        if (localDrawable != null)
          this.HS.setImageDrawable(localDrawable);
      }
      localDrawable = this.HS.getDrawable();
      if (localDrawable != null)
        o.m(localDrawable);
      return;
    }
    finally
    {
      paramAttributeSet.MF.recycle();
    }
  }

  public final void setImageResource(int paramInt)
  {
    if (paramInt != 0)
    {
      if (this.Hp != null);
      for (Drawable localDrawable = this.Hp.a(this.HS.getContext(), paramInt, false); ; localDrawable = a.a(this.HS.getContext(), paramInt))
      {
        if (localDrawable != null)
          o.m(localDrawable);
        this.HS.setImageDrawable(localDrawable);
        return;
      }
    }
    this.HS.setImageDrawable(null);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.h
 * JD-Core Version:    0.6.2
 */