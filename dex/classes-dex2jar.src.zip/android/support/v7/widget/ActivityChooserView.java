package android.support.v7.widget;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.drawable.Drawable;
import android.support.v7.a.a.d;
import android.support.v7.a.a.f;
import android.support.v7.a.a.h;
import android.support.v7.a.a.i;
import android.support.v7.a.a.k;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.PopupWindow.OnDismissListener;
import android.widget.TextView;
import java.util.List;

public class ActivityChooserView extends ViewGroup
{
  private final a GR;
  private final b GS;
  private final LinearLayoutCompat GT;
  private final Drawable GU;
  private final FrameLayout GV;
  private final ImageView GW;
  private final FrameLayout GX;
  private final ImageView GY;
  private final int GZ;
  android.support.v4.view.d Ha;
  private final DataSetObserver Hb = new DataSetObserver()
  {
    public final void onChanged()
    {
      super.onChanged();
      ActivityChooserView.a(ActivityChooserView.this).notifyDataSetChanged();
    }

    public final void onInvalidated()
    {
      super.onInvalidated();
      ActivityChooserView.a(ActivityChooserView.this).notifyDataSetInvalidated();
    }
  };
  private final ViewTreeObserver.OnGlobalLayoutListener Hc = new ViewTreeObserver.OnGlobalLayoutListener()
  {
    public final void onGlobalLayout()
    {
      if (ActivityChooserView.this.dj())
      {
        if (ActivityChooserView.this.isShown())
          break label31;
        ActivityChooserView.b(ActivityChooserView.this).dismiss();
      }
      label31: 
      do
      {
        return;
        ActivityChooserView.b(ActivityChooserView.this).show();
      }
      while (ActivityChooserView.this.Ha == null);
      ActivityChooserView.this.Ha.i(true);
    }
  };
  private ListPopupWindow Hd;
  private PopupWindow.OnDismissListener He;
  boolean Hf;
  int Hg = 4;
  boolean Hh;
  private int Hi;

  public ActivityChooserView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public ActivityChooserView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    Object localObject = paramContext.obtainStyledAttributes(paramAttributeSet, a.k.yD, paramInt, 0);
    this.Hg = ((TypedArray)localObject).getInt(a.k.yF, 4);
    paramAttributeSet = ((TypedArray)localObject).getDrawable(a.k.yE);
    ((TypedArray)localObject).recycle();
    LayoutInflater.from(getContext()).inflate(a.h.xF, this, true);
    this.GS = new b((byte)0);
    this.GT = ((LinearLayoutCompat)findViewById(a.f.wW));
    this.GU = this.GT.getBackground();
    this.GX = ((FrameLayout)findViewById(a.f.xc));
    this.GX.setOnClickListener(this.GS);
    this.GX.setOnLongClickListener(this.GS);
    this.GY = ((ImageView)this.GX.findViewById(a.f.xf));
    localObject = (FrameLayout)findViewById(a.f.xe);
    ((FrameLayout)localObject).setOnClickListener(this.GS);
    ((FrameLayout)localObject).setOnTouchListener(new ListPopupWindow.b((View)localObject)
    {
      protected final boolean cV()
      {
        ActivityChooserView.this.di();
        return true;
      }

      public final ListPopupWindow ci()
      {
        return ActivityChooserView.b(ActivityChooserView.this);
      }

      protected final boolean cj()
      {
        ActivityChooserView localActivityChooserView = ActivityChooserView.this;
        if ((localActivityChooserView.dj()) || (!localActivityChooserView.Hh));
        while (true)
        {
          return true;
          localActivityChooserView.Hf = false;
          localActivityChooserView.ae(localActivityChooserView.Hg);
        }
      }
    });
    this.GV = ((FrameLayout)localObject);
    this.GW = ((ImageView)((FrameLayout)localObject).findViewById(a.f.xf));
    this.GW.setImageDrawable(paramAttributeSet);
    this.GR = new a((byte)0);
    this.GR.registerDataSetObserver(new DataSetObserver()
    {
      public final void onChanged()
      {
        super.onChanged();
        ActivityChooserView.c(ActivityChooserView.this);
      }
    });
    paramContext = paramContext.getResources();
    this.GZ = Math.max(paramContext.getDisplayMetrics().widthPixels / 2, paramContext.getDimensionPixelSize(a.d.vU));
  }

  private ListPopupWindow dk()
  {
    if (this.Hd == null)
    {
      this.Hd = new ListPopupWindow(getContext());
      this.Hd.setAdapter(this.GR);
      this.Hd.Ju = this;
      this.Hd.dv();
      this.Hd.Jw = this.GS;
      this.Hd.setOnDismissListener(this.GS);
    }
    return this.Hd;
  }

  final void ae(int paramInt)
  {
    if (this.GR.Hk == null)
      throw new IllegalStateException("No data model. Did you call #setDataModel?");
    getViewTreeObserver().addOnGlobalLayoutListener(this.Hc);
    boolean bool;
    int i;
    label63: label95: ListPopupWindow localListPopupWindow;
    if (this.GX.getVisibility() == 0)
    {
      bool = true;
      int j = this.GR.Hk.da();
      if (!bool)
        break label198;
      i = 1;
      if ((paramInt == 2147483647) || (j <= i + paramInt))
        break label203;
      this.GR.G(true);
      this.GR.af(paramInt - 1);
      localListPopupWindow = dk();
      if (!localListPopupWindow.Jh.isShowing())
      {
        if ((!this.Hf) && (bool))
          break label222;
        this.GR.b(true, bool);
      }
    }
    while (true)
    {
      localListPopupWindow.setContentWidth(Math.min(this.GR.dl(), this.GZ));
      localListPopupWindow.show();
      if (this.Ha != null)
        this.Ha.i(true);
      localListPopupWindow.Ji.setContentDescription(getContext().getString(a.i.xW));
      return;
      bool = false;
      break;
      label198: i = 0;
      break label63;
      label203: this.GR.G(false);
      this.GR.af(paramInt);
      break label95;
      label222: this.GR.b(false, false);
    }
  }

  public final boolean di()
  {
    if (dk().Jh.isShowing())
    {
      dk().dismiss();
      ViewTreeObserver localViewTreeObserver = getViewTreeObserver();
      if (localViewTreeObserver.isAlive())
        localViewTreeObserver.removeGlobalOnLayoutListener(this.Hc);
    }
    return true;
  }

  public final boolean dj()
  {
    return dk().Jh.isShowing();
  }

  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    d locald = this.GR.Hk;
    if (locald != null)
      locald.registerObserver(this.Hb);
    this.Hh = true;
  }

  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    Object localObject = this.GR.Hk;
    if (localObject != null)
      ((d)localObject).unregisterObserver(this.Hb);
    localObject = getViewTreeObserver();
    if (((ViewTreeObserver)localObject).isAlive())
      ((ViewTreeObserver)localObject).removeGlobalOnLayoutListener(this.Hc);
    if (dj())
      di();
    this.Hh = false;
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.GT.layout(0, 0, paramInt3 - paramInt1, paramInt4 - paramInt2);
    if (!dj())
      di();
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    LinearLayoutCompat localLinearLayoutCompat = this.GT;
    int i = paramInt2;
    if (this.GX.getVisibility() != 0)
      i = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(paramInt2), 1073741824);
    measureChild(localLinearLayoutCompat, paramInt1, i);
    setMeasuredDimension(localLinearLayoutCompat.getMeasuredWidth(), localLinearLayoutCompat.getMeasuredHeight());
  }

  public static class InnerLayout extends LinearLayoutCompat
  {
    private static final int[] Dj = { 16842964 };

    public InnerLayout(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      paramContext = new y(paramContext, paramContext.obtainStyledAttributes(paramAttributeSet, Dj));
      setBackgroundDrawable(paramContext.getDrawable(0));
      paramContext.MF.recycle();
    }
  }

  private final class a extends BaseAdapter
  {
    d Hk;
    private int Hl = 4;
    boolean Hm;
    private boolean Hn;
    private boolean Ho;

    private a()
    {
    }

    public final void G(boolean paramBoolean)
    {
      if (this.Ho != paramBoolean)
      {
        this.Ho = paramBoolean;
        notifyDataSetChanged();
      }
    }

    public final void af(int paramInt)
    {
      if (this.Hl != paramInt)
      {
        this.Hl = paramInt;
        notifyDataSetChanged();
      }
    }

    public final void b(boolean paramBoolean1, boolean paramBoolean2)
    {
      if ((this.Hm != paramBoolean1) || (this.Hn != paramBoolean2))
      {
        this.Hm = paramBoolean1;
        this.Hn = paramBoolean2;
        notifyDataSetChanged();
      }
    }

    public final int dl()
    {
      int i = 0;
      int k = this.Hl;
      this.Hl = 2147483647;
      int m = View.MeasureSpec.makeMeasureSpec(0, 0);
      int n = View.MeasureSpec.makeMeasureSpec(0, 0);
      int i1 = getCount();
      View localView = null;
      int j = 0;
      while (i < i1)
      {
        localView = getView(i, localView, null);
        localView.measure(m, n);
        j = Math.max(j, localView.getMeasuredWidth());
        i += 1;
      }
      this.Hl = k;
      return j;
    }

    public final int getCount()
    {
      int j = this.Hk.da();
      int i = j;
      if (!this.Hm)
      {
        i = j;
        if (this.Hk.db() != null)
          i = j - 1;
      }
      j = Math.min(i, this.Hl);
      i = j;
      if (this.Ho)
        i = j + 1;
      return i;
    }

    public final Object getItem(int paramInt)
    {
      switch (getItemViewType(paramInt))
      {
      default:
        throw new IllegalArgumentException();
      case 1:
        return null;
      case 0:
      }
      int i = paramInt;
      if (!this.Hm)
      {
        i = paramInt;
        if (this.Hk.db() != null)
          i = paramInt + 1;
      }
      return this.Hk.ac(i);
    }

    public final long getItemId(int paramInt)
    {
      return paramInt;
    }

    public final int getItemViewType(int paramInt)
    {
      if ((this.Ho) && (paramInt == getCount() - 1))
        return 1;
      return 0;
    }

    public final View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
    {
      View localView;
      switch (getItemViewType(paramInt))
      {
      default:
        throw new IllegalArgumentException();
      case 1:
        if (paramView != null)
        {
          localView = paramView;
          if (paramView.getId() == 1);
        }
        else
        {
          localView = LayoutInflater.from(ActivityChooserView.this.getContext()).inflate(a.h.xG, paramViewGroup, false);
          localView.setId(1);
          ((TextView)localView.findViewById(a.f.title)).setText(ActivityChooserView.this.getContext().getString(a.i.xV));
        }
        return localView;
      case 0:
      }
      if (paramView != null)
      {
        localView = paramView;
        if (paramView.getId() == a.f.xg);
      }
      else
      {
        localView = LayoutInflater.from(ActivityChooserView.this.getContext()).inflate(a.h.xG, paramViewGroup, false);
      }
      paramView = ActivityChooserView.this.getContext().getPackageManager();
      paramViewGroup = (ImageView)localView.findViewById(a.f.icon);
      ResolveInfo localResolveInfo = (ResolveInfo)getItem(paramInt);
      paramViewGroup.setImageDrawable(localResolveInfo.loadIcon(paramView));
      ((TextView)localView.findViewById(a.f.title)).setText(localResolveInfo.loadLabel(paramView));
      if ((this.Hm) && (paramInt == 0) && (this.Hn))
      {
        android.support.v4.view.y.a(localView, true);
        return localView;
      }
      android.support.v4.view.y.a(localView, false);
      return localView;
    }

    public final int getViewTypeCount()
    {
      return 3;
    }
  }

  private final class b
    implements View.OnClickListener, View.OnLongClickListener, AdapterView.OnItemClickListener, PopupWindow.OnDismissListener
  {
    private b()
    {
    }

    public final void onClick(View paramView)
    {
      if (paramView == ActivityChooserView.e(ActivityChooserView.this))
      {
        ActivityChooserView.this.di();
        paramView = ActivityChooserView.a(ActivityChooserView.this).Hk.db();
        int i = ActivityChooserView.a(ActivityChooserView.this).Hk.a(paramView);
        paramView = ActivityChooserView.a(ActivityChooserView.this).Hk.ad(i);
        if (paramView != null)
        {
          paramView.addFlags(524288);
          ActivityChooserView.this.getContext().startActivity(paramView);
        }
        return;
      }
      if (paramView == ActivityChooserView.f(ActivityChooserView.this))
      {
        ActivityChooserView.a(ActivityChooserView.this, false);
        ActivityChooserView.a(ActivityChooserView.this, ActivityChooserView.g(ActivityChooserView.this));
        return;
      }
      throw new IllegalArgumentException();
    }

    public final void onDismiss()
    {
      if (ActivityChooserView.h(ActivityChooserView.this) != null)
        ActivityChooserView.h(ActivityChooserView.this).onDismiss();
      if (ActivityChooserView.this.Ha != null)
        ActivityChooserView.this.Ha.i(false);
    }

    public final void onItemClick(AdapterView<?> arg1, View paramView, int paramInt, long paramLong)
    {
      switch (((ActivityChooserView.a)???.getAdapter()).getItemViewType(paramInt))
      {
      default:
        throw new IllegalArgumentException();
      case 1:
        ActivityChooserView.a(ActivityChooserView.this, 2147483647);
      case 0:
      }
      do
      {
        return;
        ActivityChooserView.this.di();
        if (!ActivityChooserView.d(ActivityChooserView.this))
          break;
      }
      while (paramInt <= 0);
      paramView = ActivityChooserView.a(ActivityChooserView.this).Hk;
      while (true)
      {
        synchronized (paramView.GE)
        {
          paramView.dc();
          d.a locala1 = (d.a)paramView.GF.get(paramInt);
          d.a locala2 = (d.a)paramView.GF.get(0);
          if (locala2 != null)
          {
            f = locala2.weight - locala1.weight + 5.0F;
            paramView.a(new d.c(new ComponentName(locala1.resolveInfo.activityInfo.packageName, locala1.resolveInfo.activityInfo.name), System.currentTimeMillis(), f));
            return;
          }
        }
        float f = 1.0F;
      }
      if (ActivityChooserView.a(ActivityChooserView.this).Hm);
      while (true)
      {
        ??? = ActivityChooserView.a(ActivityChooserView.this).Hk.ad(paramInt);
        if (??? == null)
          break;
        ???.addFlags(524288);
        ActivityChooserView.this.getContext().startActivity(???);
        return;
        paramInt += 1;
      }
    }

    public final boolean onLongClick(View paramView)
    {
      if (paramView == ActivityChooserView.e(ActivityChooserView.this))
      {
        if (ActivityChooserView.a(ActivityChooserView.this).getCount() > 0)
        {
          ActivityChooserView.a(ActivityChooserView.this, true);
          ActivityChooserView.a(ActivityChooserView.this, ActivityChooserView.g(ActivityChooserView.this));
        }
        return true;
      }
      throw new IllegalArgumentException();
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.ActivityChooserView
 * JD-Core Version:    0.6.2
 */