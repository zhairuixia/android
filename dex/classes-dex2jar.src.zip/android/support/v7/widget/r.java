package android.support.v7.widget;

final class r
{
  int Ke = 0;
  int Kf = 0;
  int Kg = -2147483648;
  int Kh = 0;
  int Ki = 0;
  boolean Kj = false;
  boolean Kk = false;
  int jo = -2147483648;

  public final void r(int paramInt1, int paramInt2)
  {
    this.Kg = paramInt1;
    this.jo = paramInt2;
    this.Kk = true;
    if (this.Kj)
    {
      if (paramInt2 != -2147483648)
        this.Ke = paramInt2;
      if (paramInt1 != -2147483648)
        this.Kf = paramInt1;
    }
    do
    {
      return;
      if (paramInt1 != -2147483648)
        this.Ke = paramInt1;
    }
    while (paramInt2 == -2147483648);
    this.Kf = paramInt2;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.r
 * JD-Core Version:    0.6.2
 */