package android.support.v7.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

final class v extends ContextWrapper
{
  private static final ArrayList<WeakReference<v>> MA = new ArrayList();
  private Resources pp;

  private v(Context paramContext)
  {
    super(paramContext);
  }

  public static Context n(Context paramContext)
  {
    Object localObject = paramContext;
    int j;
    int i;
    if (!(paramContext instanceof v))
    {
      j = MA.size();
      i = 0;
    }
    while (i < j)
    {
      localObject = (WeakReference)MA.get(i);
      if (localObject != null);
      for (localObject = (v)((WeakReference)localObject).get(); (localObject != null) && (((v)localObject).getBaseContext() == paramContext); localObject = null)
        return localObject;
      i += 1;
    }
    paramContext = new v(paramContext);
    MA.add(new WeakReference(paramContext));
    return paramContext;
  }

  public final Resources getResources()
  {
    if (this.pp == null)
      this.pp = new x(this, super.getResources());
    return this.pp;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.v
 * JD-Core Version:    0.6.2
 */