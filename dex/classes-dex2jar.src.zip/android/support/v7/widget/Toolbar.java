package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.view.e;
import android.support.v4.view.k;
import android.support.v7.a.a.a;
import android.support.v7.a.a.k;
import android.support.v7.app.ActionBar.LayoutParams;
import android.support.v7.view.c;
import android.support.v7.view.menu.f;
import android.support.v7.view.menu.f.a;
import android.support.v7.view.menu.h;
import android.support.v7.view.menu.l.a;
import android.support.v7.view.menu.p;
import android.text.TextUtils;
import android.text.TextUtils.TruncateAt;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class Toolbar extends ViewGroup
{
  private Context EJ;
  ActionMenuView EK;
  private boolean EO;
  private boolean EP;
  private int Gn;
  l.a Gp;
  f.a Gq;
  private final g Hp;
  TextView MG;
  TextView MH;
  ImageButton MI;
  private ImageView MJ;
  private Drawable MK;
  private CharSequence ML;
  private ImageButton MM;
  View MN;
  int MO;
  int MP;
  private int MQ;
  private int MR;
  private int MS;
  private int MT;
  private int MU;
  private int MV;
  final r MW = new r();
  CharSequence MX;
  CharSequence MY;
  private int MZ;
  private int Na;
  private final ArrayList<View> Nb = new ArrayList();
  final ArrayList<View> Nc = new ArrayList();
  private final int[] Nd = new int[2];
  private b Ne;
  private final ActionMenuView.d Nf = new ActionMenuView.d()
  {
    public final boolean cZ()
    {
      if (Toolbar.a(Toolbar.this) != null)
        return Toolbar.a(Toolbar.this).cZ();
      return false;
    }
  };
  private z Ng;
  private ActionMenuPresenter Nh;
  a Ni;
  boolean Nj;
  private final Runnable Nk = new Runnable()
  {
    public final void run()
    {
      Toolbar.this.showOverflowMenu();
    }
  };
  private int ky = 8388627;

  public Toolbar(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, a.a.toolbarStyle);
  }

  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    paramContext = y.a(getContext(), paramAttributeSet, a.k.AZ, paramInt);
    this.MO = paramContext.getResourceId(a.k.Bw, 0);
    this.MP = paramContext.getResourceId(a.k.Bo, 0);
    paramInt = a.k.Ba;
    int i = this.ky;
    this.ky = paramContext.MF.getInteger(paramInt, i);
    this.MQ = 48;
    paramInt = paramContext.getDimensionPixelOffset(a.k.Bv, 0);
    this.MV = paramInt;
    this.MU = paramInt;
    this.MT = paramInt;
    this.MS = paramInt;
    paramInt = paramContext.getDimensionPixelOffset(a.k.Bt, -1);
    if (paramInt >= 0)
      this.MS = paramInt;
    paramInt = paramContext.getDimensionPixelOffset(a.k.Bs, -1);
    if (paramInt >= 0)
      this.MT = paramInt;
    paramInt = paramContext.getDimensionPixelOffset(a.k.Bu, -1);
    if (paramInt >= 0)
      this.MU = paramInt;
    paramInt = paramContext.getDimensionPixelOffset(a.k.Br, -1);
    if (paramInt >= 0)
      this.MV = paramInt;
    this.MR = paramContext.getDimensionPixelSize(a.k.Bj, -1);
    paramInt = paramContext.getDimensionPixelOffset(a.k.Bg, -2147483648);
    i = paramContext.getDimensionPixelOffset(a.k.Bd, -2147483648);
    int j = paramContext.getDimensionPixelSize(a.k.Be, 0);
    int k = paramContext.getDimensionPixelSize(a.k.Bf, 0);
    paramAttributeSet = this.MW;
    paramAttributeSet.Kk = false;
    if (j != -2147483648)
    {
      paramAttributeSet.Kh = j;
      paramAttributeSet.Ke = j;
    }
    if (k != -2147483648)
    {
      paramAttributeSet.Ki = k;
      paramAttributeSet.Kf = k;
    }
    if ((paramInt != -2147483648) || (i != -2147483648))
      this.MW.r(paramInt, i);
    this.MK = paramContext.getDrawable(a.k.Bc);
    this.ML = paramContext.getText(a.k.Bb);
    paramAttributeSet = paramContext.getText(a.k.Bq);
    if (!TextUtils.isEmpty(paramAttributeSet))
      setTitle(paramAttributeSet);
    paramAttributeSet = paramContext.getText(a.k.Bn);
    if (!TextUtils.isEmpty(paramAttributeSet))
      setSubtitle(paramAttributeSet);
    this.EJ = getContext();
    setPopupTheme(paramContext.getResourceId(a.k.Bm, 0));
    paramAttributeSet = paramContext.getDrawable(a.k.Bl);
    if (paramAttributeSet != null)
      setNavigationIcon(paramAttributeSet);
    paramAttributeSet = paramContext.getText(a.k.Bk);
    if (!TextUtils.isEmpty(paramAttributeSet))
      setNavigationContentDescription(paramAttributeSet);
    paramAttributeSet = paramContext.getDrawable(a.k.Bh);
    if (paramAttributeSet != null)
      setLogo(paramAttributeSet);
    paramAttributeSet = paramContext.getText(a.k.Bi);
    if (!TextUtils.isEmpty(paramAttributeSet))
    {
      if (!TextUtils.isEmpty(paramAttributeSet))
        dQ();
      if (this.MJ != null)
        this.MJ.setContentDescription(paramAttributeSet);
    }
    if (paramContext.hasValue(a.k.Bx))
    {
      paramInt = paramContext.an(a.k.Bx);
      this.MZ = paramInt;
      if (this.MG != null)
        this.MG.setTextColor(paramInt);
    }
    if (paramContext.hasValue(a.k.Bp))
    {
      paramInt = paramContext.an(a.k.Bp);
      this.Na = paramInt;
      if (this.MH != null)
        this.MH.setTextColor(paramInt);
    }
    paramContext.MF.recycle();
    this.Hp = g.dp();
  }

  private int a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt)
  {
    ViewGroup.MarginLayoutParams localMarginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = localMarginLayoutParams.leftMargin - paramArrayOfInt[0];
    int j = localMarginLayoutParams.rightMargin - paramArrayOfInt[1];
    int k = Math.max(0, i) + Math.max(0, j);
    paramArrayOfInt[0] = Math.max(0, -i);
    paramArrayOfInt[1] = Math.max(0, -j);
    paramView.measure(getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + k + paramInt2, localMarginLayoutParams.width), getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + localMarginLayoutParams.topMargin + localMarginLayoutParams.bottomMargin + paramInt4, localMarginLayoutParams.height));
    return paramView.getMeasuredWidth() + k;
  }

  private int a(View paramView, int paramInt1, int[] paramArrayOfInt, int paramInt2)
  {
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = localLayoutParams.leftMargin - paramArrayOfInt[0];
    paramInt1 = Math.max(0, i) + paramInt1;
    paramArrayOfInt[0] = Math.max(0, -i);
    paramInt2 = k(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramView.getMeasuredHeight() + paramInt2);
    return localLayoutParams.rightMargin + i + paramInt1;
  }

  private void a(List<View> paramList, int paramInt)
  {
    int i = 1;
    int j = 0;
    if (android.support.v4.view.y.k(this) == 1);
    int m;
    int k;
    View localView;
    LayoutParams localLayoutParams;
    while (true)
    {
      m = getChildCount();
      k = e.getAbsoluteGravity(paramInt, android.support.v4.view.y.k(this));
      paramList.clear();
      paramInt = j;
      if (i == 0)
        break;
      paramInt = m - 1;
      while (paramInt >= 0)
      {
        localView = getChildAt(paramInt);
        localLayoutParams = (LayoutParams)localView.getLayoutParams();
        if ((localLayoutParams.Nn == 0) && (am(localView)) && (ao(localLayoutParams.gravity) == k))
          paramList.add(localView);
        paramInt -= 1;
      }
      i = 0;
    }
    while (paramInt < m)
    {
      localView = getChildAt(paramInt);
      localLayoutParams = (LayoutParams)localView.getLayoutParams();
      if ((localLayoutParams.Nn == 0) && (am(localView)) && (ao(localLayoutParams.gravity) == k))
        paramList.add(localView);
      paramInt += 1;
    }
  }

  private boolean am(View paramView)
  {
    return (paramView != null) && (paramView.getParent() == this) && (paramView.getVisibility() != 8);
  }

  private static int an(View paramView)
  {
    paramView = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = k.a(paramView);
    return k.b(paramView) + i;
  }

  private int ao(int paramInt)
  {
    int j = android.support.v4.view.y.k(this);
    int i = e.getAbsoluteGravity(paramInt, j) & 0x7;
    paramInt = i;
    switch (i)
    {
    case 2:
    case 4:
    default:
      if (j == 1)
        paramInt = 5;
      break;
    case 1:
    case 3:
    case 5:
      return paramInt;
    }
    return 3;
  }

  private static int ao(View paramView)
  {
    paramView = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = paramView.topMargin;
    return paramView.bottomMargin + i;
  }

  private boolean ap(View paramView)
  {
    return (paramView.getParent() == this) || (this.Nc.contains(paramView));
  }

  private int b(View paramView, int paramInt1, int[] paramArrayOfInt, int paramInt2)
  {
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = localLayoutParams.rightMargin - paramArrayOfInt[1];
    paramInt1 -= Math.max(0, i);
    paramArrayOfInt[1] = Math.max(0, -i);
    paramInt2 = k(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - i, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - (localLayoutParams.leftMargin + i);
  }

  private static LayoutParams c(ViewGroup.LayoutParams paramLayoutParams)
  {
    if ((paramLayoutParams instanceof LayoutParams))
      return new LayoutParams((LayoutParams)paramLayoutParams);
    if ((paramLayoutParams instanceof ActionBar.LayoutParams))
      return new LayoutParams((ActionBar.LayoutParams)paramLayoutParams);
    if ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams))
      return new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams);
    return new LayoutParams(paramLayoutParams);
  }

  private void d(View paramView, boolean paramBoolean)
  {
    Object localObject = paramView.getLayoutParams();
    if (localObject == null)
      localObject = new LayoutParams();
    while (true)
    {
      ((LayoutParams)localObject).Nn = 1;
      if ((!paramBoolean) || (this.MN == null))
        break;
      paramView.setLayoutParams((ViewGroup.LayoutParams)localObject);
      this.Nc.add(paramView);
      return;
      if (!checkLayoutParams((ViewGroup.LayoutParams)localObject))
        localObject = c((ViewGroup.LayoutParams)localObject);
      else
        localObject = (LayoutParams)localObject;
    }
    addView(paramView, (ViewGroup.LayoutParams)localObject);
  }

  private void dQ()
  {
    if (this.MJ == null)
      this.MJ = new ImageView(getContext());
  }

  private void dR()
  {
    if (this.EK == null)
    {
      this.EK = new ActionMenuView(getContext());
      this.EK.setPopupTheme(this.Gn);
      this.EK.Gu = this.Nf;
      this.EK.a(this.Gp, this.Gq);
      LayoutParams localLayoutParams = new LayoutParams();
      localLayoutParams.gravity = (0x800005 | this.MQ & 0x70);
      this.EK.setLayoutParams(localLayoutParams);
      d(this.EK, false);
    }
  }

  private void dS()
  {
    if (this.MI == null)
    {
      this.MI = new ImageButton(getContext(), null, a.a.vM);
      LayoutParams localLayoutParams = new LayoutParams();
      localLayoutParams.gravity = (0x800003 | this.MQ & 0x70);
      this.MI.setLayoutParams(localLayoutParams);
    }
  }

  protected static LayoutParams dT()
  {
    return new LayoutParams();
  }

  private void e(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    ViewGroup.MarginLayoutParams localMarginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + localMarginLayoutParams.leftMargin + localMarginLayoutParams.rightMargin + paramInt2, localMarginLayoutParams.width);
    paramInt2 = getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + localMarginLayoutParams.topMargin + localMarginLayoutParams.bottomMargin + 0, localMarginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824)
    {
      paramInt1 = paramInt2;
      if (paramInt4 >= 0)
      {
        paramInt1 = paramInt4;
        if (paramInt3 != 0)
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt4);
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      }
    }
    paramView.measure(i, paramInt1);
  }

  private int k(View paramView, int paramInt)
  {
    LayoutParams localLayoutParams = (LayoutParams)paramView.getLayoutParams();
    int k = paramView.getMeasuredHeight();
    int j;
    int i;
    int m;
    if (paramInt > 0)
    {
      paramInt = (k - paramInt) / 2;
      j = localLayoutParams.gravity & 0x70;
      i = j;
      switch (j)
      {
      default:
        i = this.ky & 0x70;
      case 16:
      case 48:
      case 80:
      }
      switch (i)
      {
      default:
        i = getPaddingTop();
        j = getPaddingBottom();
        m = getHeight();
        paramInt = (m - i - j - k) / 2;
        if (paramInt < localLayoutParams.topMargin)
          paramInt = localLayoutParams.topMargin;
        break;
      case 48:
      case 80:
      }
    }
    while (true)
    {
      return paramInt + i;
      paramInt = 0;
      break;
      return getPaddingTop() - paramInt;
      return getHeight() - getPaddingBottom() - k - localLayoutParams.bottomMargin - paramInt;
      j = m - j - k - paramInt - i;
      if (j < localLayoutParams.bottomMargin)
        paramInt = Math.max(0, paramInt - (localLayoutParams.bottomMargin - j));
    }
  }

  public final void a(f paramf, ActionMenuPresenter paramActionMenuPresenter)
  {
    if ((paramf == null) && (this.EK == null));
    f localf;
    do
    {
      return;
      dR();
      localf = this.EK.vF;
    }
    while (localf == paramf);
    if (localf != null)
    {
      localf.b(this.Nh);
      localf.b(this.Ni);
    }
    if (this.Ni == null)
      this.Ni = new a((byte)0);
    paramActionMenuPresenter.FX = true;
    if (paramf != null)
    {
      paramf.a(paramActionMenuPresenter, this.EJ);
      paramf.a(this.Ni, this.EJ);
    }
    while (true)
    {
      this.EK.setPopupTheme(this.Gn);
      this.EK.a(paramActionMenuPresenter);
      this.Nh = paramActionMenuPresenter;
      return;
      paramActionMenuPresenter.a(this.EJ, null);
      this.Ni.a(this.EJ, null);
      paramActionMenuPresenter.w(true);
      this.Ni.w(true);
    }
  }

  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return (super.checkLayoutParams(paramLayoutParams)) && ((paramLayoutParams instanceof LayoutParams));
  }

  public final void collapseActionView()
  {
    if (this.Ni == null);
    for (h localh = null; ; localh = this.Ni.Nm)
    {
      if (localh != null)
        localh.collapseActionView();
      return;
    }
  }

  public final n dU()
  {
    if (this.Ng == null)
      this.Ng = new z(this);
    return this.Ng;
  }

  public final Menu getMenu()
  {
    dR();
    if (this.EK.vF == null)
    {
      f localf = (f)this.EK.getMenu();
      if (this.Ni == null)
        this.Ni = new a((byte)0);
      this.EK.Go.FX = true;
      localf.a(this.Ni, this.EJ);
    }
    return this.EK.getMenu();
  }

  public final CharSequence getNavigationContentDescription()
  {
    if (this.MI != null)
      return this.MI.getContentDescription();
    return null;
  }

  public final boolean isOverflowMenuShowing()
  {
    if (this.EK != null)
    {
      ActionMenuView localActionMenuView = this.EK;
      if ((localActionMenuView.Go != null) && (localActionMenuView.Go.isOverflowMenuShowing()));
      for (int i = 1; i != 0; i = 0)
        return true;
    }
    return false;
  }

  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    removeCallbacks(this.Nk);
  }

  public boolean onHoverEvent(MotionEvent paramMotionEvent)
  {
    int i = android.support.v4.view.n.d(paramMotionEvent);
    if (i == 9)
      this.EP = false;
    if (!this.EP)
    {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if ((i == 9) && (!bool))
        this.EP = true;
    }
    if ((i == 10) || (i == 3))
      this.EP = false;
    return true;
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int k;
    int i1;
    int i4;
    int i;
    int i2;
    int i3;
    int i5;
    int[] arrayOfInt;
    int n;
    if (android.support.v4.view.y.k(this) == 1)
    {
      k = 1;
      i1 = getWidth();
      i4 = getHeight();
      i = getPaddingLeft();
      i2 = getPaddingRight();
      i3 = getPaddingTop();
      i5 = getPaddingBottom();
      paramInt4 = i1 - i2;
      arrayOfInt = this.Nd;
      arrayOfInt[1] = 0;
      arrayOfInt[0] = 0;
      n = android.support.v4.view.y.q(this);
      if (!am(this.MI))
        break label1721;
      if (k == 0)
        break label888;
      paramInt4 = b(this.MI, paramInt4, arrayOfInt, n);
      paramInt1 = i;
    }
    while (true)
    {
      label111: paramInt2 = paramInt4;
      paramInt3 = paramInt1;
      if (am(this.MM))
      {
        if (k != 0)
        {
          paramInt2 = b(this.MM, paramInt4, arrayOfInt, n);
          paramInt3 = paramInt1;
        }
      }
      else
      {
        label151: paramInt1 = paramInt2;
        paramInt4 = paramInt3;
        if (am(this.EK))
        {
          if (k == 0)
            break label927;
          paramInt4 = a(this.EK, paramInt3, arrayOfInt, n);
          paramInt1 = paramInt2;
        }
        label191: arrayOfInt[0] = Math.max(0, this.MW.Ke - paramInt4);
        arrayOfInt[1] = Math.max(0, this.MW.Kf - (i1 - i2 - paramInt1));
        paramInt3 = Math.max(paramInt4, this.MW.Ke);
        paramInt4 = Math.min(paramInt1, i1 - i2 - this.MW.Kf);
        paramInt2 = paramInt4;
        paramInt1 = paramInt3;
        if (am(this.MN))
        {
          if (k == 0)
            break label948;
          paramInt2 = b(this.MN, paramInt4, arrayOfInt, n);
          paramInt1 = paramInt3;
        }
        label305: if (!am(this.MJ))
          break label1715;
        if (k == 0)
          break label969;
        paramInt2 = b(this.MJ, paramInt2, arrayOfInt, n);
        paramInt3 = paramInt1;
      }
      while (true)
      {
        label338: paramBoolean = am(this.MG);
        boolean bool = am(this.MH);
        paramInt1 = 0;
        Object localObject1;
        if (paramBoolean)
        {
          localObject1 = (LayoutParams)this.MG.getLayoutParams();
          paramInt1 = ((LayoutParams)localObject1).topMargin;
          paramInt4 = this.MG.getMeasuredHeight();
          paramInt1 = ((LayoutParams)localObject1).bottomMargin + (paramInt1 + paramInt4) + 0;
        }
        int j;
        if (bool)
        {
          localObject1 = (LayoutParams)this.MH.getLayoutParams();
          paramInt4 = ((LayoutParams)localObject1).topMargin;
          j = this.MH.getMeasuredHeight();
        }
        label1683: for (int m = ((LayoutParams)localObject1).bottomMargin + (paramInt4 + j) + paramInt1; ; m = paramInt1)
        {
          label476: Object localObject2;
          if (!paramBoolean)
          {
            paramInt4 = paramInt2;
            paramInt1 = paramInt3;
            if (!bool);
          }
          else
          {
            if (!paramBoolean)
              break label987;
            localObject1 = this.MG;
            if (!bool)
              break label996;
            localObject2 = this.MH;
            label487: localObject1 = (LayoutParams)((View)localObject1).getLayoutParams();
            localObject2 = (LayoutParams)((View)localObject2).getLayoutParams();
            if (((!paramBoolean) || (this.MG.getMeasuredWidth() <= 0)) && ((!bool) || (this.MH.getMeasuredWidth() <= 0)))
              break label1005;
            j = 1;
            label539: switch (this.ky & 0x70)
            {
            default:
              paramInt1 = (i4 - i3 - i5 - m) / 2;
              if (paramInt1 < ((LayoutParams)localObject1).topMargin + this.MU)
                paramInt1 = ((LayoutParams)localObject1).topMargin + this.MU;
              break;
            case 48:
            case 80:
            }
          }
          label927: label1700: label1706: 
          while (true)
          {
            label611: paramInt1 = i3 + paramInt1;
            label616: if (k != 0)
              if (j != 0)
              {
                paramInt4 = this.MS;
                label632: paramInt4 -= arrayOfInt[1];
                paramInt2 -= Math.max(0, paramInt4);
                arrayOfInt[1] = Math.max(0, -paramInt4);
                if (!paramBoolean)
                  break label1700;
                localObject1 = (LayoutParams)this.MG.getLayoutParams();
                paramInt4 = paramInt2 - this.MG.getMeasuredWidth();
                k = this.MG.getMeasuredHeight() + paramInt1;
                this.MG.layout(paramInt4, paramInt1, paramInt2, k);
                m = this.MT;
                paramInt1 = k + ((LayoutParams)localObject1).bottomMargin;
                paramInt4 -= m;
              }
            while (true)
            {
              if (bool)
              {
                localObject1 = (LayoutParams)this.MH.getLayoutParams();
                paramInt1 = ((LayoutParams)localObject1).topMargin + paramInt1;
                k = this.MH.getMeasuredWidth();
                m = this.MH.getMeasuredHeight();
                this.MH.layout(paramInt2 - k, paramInt1, paramInt2, m + paramInt1);
                paramInt1 = this.MT;
                k = ((LayoutParams)localObject1).bottomMargin;
              }
              for (paramInt1 = paramInt2 - paramInt1; ; paramInt1 = paramInt2)
              {
                if (j != 0);
                for (paramInt1 = Math.min(paramInt4, paramInt1); ; paramInt1 = paramInt2)
                {
                  paramInt4 = paramInt1;
                  paramInt1 = paramInt3;
                  a(this.Nb, 3);
                  paramInt3 = this.Nb.size();
                  paramInt2 = 0;
                  while (true)
                    if (paramInt2 < paramInt3)
                    {
                      paramInt1 = a((View)this.Nb.get(paramInt2), paramInt1, arrayOfInt, n);
                      paramInt2 += 1;
                      continue;
                      k = 0;
                      break;
                      label888: paramInt1 = a(this.MI, i, arrayOfInt, n);
                      break label111;
                      paramInt3 = a(this.MM, paramInt1, arrayOfInt, n);
                      paramInt2 = paramInt4;
                      break label151;
                      paramInt1 = b(this.EK, paramInt2, arrayOfInt, n);
                      paramInt4 = paramInt3;
                      break label191;
                      label948: paramInt1 = a(this.MN, paramInt3, arrayOfInt, n);
                      paramInt2 = paramInt4;
                      break label305;
                      label969: paramInt3 = a(this.MJ, paramInt1, arrayOfInt, n);
                      break label338;
                      label987: localObject1 = this.MH;
                      break label476;
                      label996: localObject2 = this.MG;
                      break label487;
                      label1005: j = 0;
                      break label539;
                      paramInt1 = getPaddingTop();
                      paramInt1 = ((LayoutParams)localObject1).topMargin + paramInt1 + this.MU;
                      break label616;
                      paramInt4 = i4 - i5 - m - paramInt1 - i3;
                      if (paramInt4 >= ((LayoutParams)localObject1).bottomMargin + this.MV)
                        break label1706;
                      paramInt1 = Math.max(0, paramInt1 - (((LayoutParams)localObject2).bottomMargin + this.MV - paramInt4));
                      break label611;
                      paramInt1 = i4 - i5 - ((LayoutParams)localObject2).bottomMargin - this.MV - m;
                      break label616;
                      paramInt4 = 0;
                      break label632;
                      if (j != 0)
                      {
                        paramInt4 = this.MS;
                        label1125: paramInt4 -= arrayOfInt[0];
                        paramInt3 += Math.max(0, paramInt4);
                        arrayOfInt[0] = Math.max(0, -paramInt4);
                        if (!paramBoolean)
                          break label1683;
                        localObject1 = (LayoutParams)this.MG.getLayoutParams();
                        k = this.MG.getMeasuredWidth() + paramInt3;
                        paramInt4 = this.MG.getMeasuredHeight() + paramInt1;
                        this.MG.layout(paramInt3, paramInt1, k, paramInt4);
                        m = this.MT;
                        paramInt1 = ((LayoutParams)localObject1).bottomMargin;
                        k += m;
                        paramInt1 += paramInt4;
                      }
                    }
                  while (true)
                  {
                    if (bool)
                    {
                      localObject1 = (LayoutParams)this.MH.getLayoutParams();
                      paramInt4 = paramInt1 + ((LayoutParams)localObject1).topMargin;
                      paramInt1 = this.MH.getMeasuredWidth() + paramInt3;
                      m = this.MH.getMeasuredHeight();
                      this.MH.layout(paramInt3, paramInt4, paramInt1, m + paramInt4);
                      paramInt4 = this.MT;
                      m = ((LayoutParams)localObject1).bottomMargin;
                    }
                    for (m = paramInt4 + paramInt1; ; m = paramInt3)
                    {
                      paramInt4 = paramInt2;
                      paramInt1 = paramInt3;
                      if (j == 0)
                        break;
                      paramInt1 = Math.max(k, m);
                      paramInt4 = paramInt2;
                      break;
                      paramInt4 = 0;
                      break label1125;
                      a(this.Nb, 5);
                      j = this.Nb.size();
                      paramInt3 = 0;
                      paramInt2 = paramInt4;
                      while (paramInt3 < j)
                      {
                        paramInt2 = b((View)this.Nb.get(paramInt3), paramInt2, arrayOfInt, n);
                        paramInt3 += 1;
                      }
                      a(this.Nb, 1);
                      localObject1 = this.Nb;
                      k = arrayOfInt[0];
                      j = arrayOfInt[1];
                      m = ((List)localObject1).size();
                      paramInt4 = 0;
                      paramInt3 = 0;
                      while (paramInt4 < m)
                      {
                        localObject2 = (View)((List)localObject1).get(paramInt4);
                        LayoutParams localLayoutParams = (LayoutParams)((View)localObject2).getLayoutParams();
                        k = localLayoutParams.leftMargin - k;
                        j = localLayoutParams.rightMargin - j;
                        i3 = Math.max(0, k);
                        i4 = Math.max(0, j);
                        k = Math.max(0, -k);
                        j = Math.max(0, -j);
                        i5 = ((View)localObject2).getMeasuredWidth();
                        paramInt4 += 1;
                        paramInt3 += i5 + i3 + i4;
                      }
                      paramInt4 = (i1 - i - i2) / 2 + i - paramInt3 / 2;
                      paramInt3 = paramInt4 + paramInt3;
                      if (paramInt4 < paramInt1);
                      while (true)
                      {
                        paramInt4 = this.Nb.size();
                        paramInt3 = 0;
                        paramInt2 = paramInt1;
                        paramInt1 = paramInt3;
                        while (paramInt1 < paramInt4)
                        {
                          paramInt2 = a((View)this.Nb.get(paramInt1), paramInt2, arrayOfInt, n);
                          paramInt1 += 1;
                        }
                        paramInt1 = paramInt4;
                        if (paramInt3 > paramInt2)
                          paramInt1 = paramInt4 - (paramInt3 - paramInt2);
                      }
                      this.Nb.clear();
                      return;
                    }
                    k = paramInt3;
                  }
                }
              }
              paramInt4 = paramInt2;
            }
          }
        }
        label1715: paramInt3 = paramInt1;
      }
      label1721: paramInt1 = i;
    }
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    Object localObject1 = this.Nd;
    int n;
    int i1;
    int i;
    int m;
    int k;
    if (aa.aq(this))
    {
      n = 0;
      i1 = 1;
      i = 0;
      if (!am(this.MI))
        break label1057;
      e(this.MI, paramInt1, 0, paramInt2, this.MR);
      i = this.MI.getMeasuredWidth() + an(this.MI);
      m = Math.max(0, this.MI.getMeasuredHeight() + ao(this.MI));
      k = aa.combineMeasuredStates(0, android.support.v4.view.y.o(this.MI));
    }
    while (true)
    {
      int i2 = i;
      i = k;
      int j = m;
      if (am(this.MM))
      {
        e(this.MM, paramInt1, 0, paramInt2, this.MR);
        i2 = this.MM.getMeasuredWidth() + an(this.MM);
        j = Math.max(m, this.MM.getMeasuredHeight() + ao(this.MM));
        i = aa.combineMeasuredStates(k, android.support.v4.view.y.o(this.MM));
      }
      Object localObject2 = this.MW;
      label206: int i3;
      if (((r)localObject2).Kj)
      {
        k = ((r)localObject2).Kf;
        i3 = Math.max(k, i2) + 0;
        localObject1[i1] = Math.max(0, k - i2);
        i1 = 0;
        k = i;
        m = j;
        if (am(this.EK))
        {
          e(this.EK, paramInt1, i3, paramInt2, this.MR);
          i1 = this.EK.getMeasuredWidth() + an(this.EK);
          m = Math.max(j, this.EK.getMeasuredHeight() + ao(this.EK));
          k = aa.combineMeasuredStates(i, android.support.v4.view.y.o(this.EK));
        }
        localObject2 = this.MW;
        if (!((r)localObject2).Kj)
          break label668;
        i = ((r)localObject2).Ke;
        label340: i2 = i3 + Math.max(i, i1);
        localObject1[n] = Math.max(0, i - i1);
        n = i2;
        i = k;
        j = m;
        if (am(this.MN))
        {
          n = i2 + a(this.MN, paramInt1, i2, paramInt2, 0, (int[])localObject1);
          j = Math.max(m, this.MN.getMeasuredHeight() + ao(this.MN));
          i = aa.combineMeasuredStates(k, android.support.v4.view.y.o(this.MN));
        }
        k = n;
        i1 = i;
        m = j;
        if (am(this.MJ))
        {
          k = n + a(this.MJ, paramInt1, n, paramInt2, 0, (int[])localObject1);
          m = Math.max(j, this.MJ.getMeasuredHeight() + ao(this.MJ));
          i1 = aa.combineMeasuredStates(i, android.support.v4.view.y.o(this.MJ));
        }
        i2 = getChildCount();
        n = 0;
        i = i1;
        j = m;
        m = n;
        i1 = k;
        label542: if (m >= i2)
          break label677;
        localObject2 = getChildAt(m);
        if ((((LayoutParams)((View)localObject2).getLayoutParams()).Nn != 0) || (!am((View)localObject2)))
          break label1044;
        i1 += a((View)localObject2, paramInt1, i1, paramInt2, 0, (int[])localObject1);
        k = Math.max(j, ((View)localObject2).getMeasuredHeight() + ao((View)localObject2));
        j = aa.combineMeasuredStates(i, android.support.v4.view.y.o((View)localObject2));
      }
      for (i = k; ; i = k)
      {
        m += 1;
        k = i;
        i = j;
        j = k;
        break label542;
        n = 1;
        i1 = 0;
        break;
        k = ((r)localObject2).Ke;
        break label206;
        label668: i = ((r)localObject2).Kf;
        break label340;
        label677: n = 0;
        m = 0;
        int i4 = this.MU + this.MV;
        int i5 = this.MS + this.MT;
        k = i;
        if (am(this.MG))
        {
          a(this.MG, paramInt1, i1 + i5, paramInt2, i4, (int[])localObject1);
          k = this.MG.getMeasuredWidth();
          n = an(this.MG) + k;
          m = this.MG.getMeasuredHeight() + ao(this.MG);
          k = aa.combineMeasuredStates(i, android.support.v4.view.y.o(this.MG));
        }
        i3 = m;
        i2 = n;
        i = k;
        if (am(this.MH))
        {
          i2 = Math.max(n, a(this.MH, paramInt1, i1 + i5, paramInt2, i4 + m, (int[])localObject1));
          i3 = m + (this.MH.getMeasuredHeight() + ao(this.MH));
          i = aa.combineMeasuredStates(k, android.support.v4.view.y.o(this.MH));
        }
        k = Math.max(j, i3);
        j = getPaddingLeft();
        i3 = getPaddingRight();
        m = getPaddingTop();
        n = getPaddingBottom();
        j = android.support.v4.view.y.resolveSizeAndState(Math.max(i2 + i1 + (j + i3), getSuggestedMinimumWidth()), paramInt1, 0xFF000000 & i);
        paramInt2 = android.support.v4.view.y.resolveSizeAndState(Math.max(k + (m + n), getSuggestedMinimumHeight()), paramInt2, i << 16);
        if (!this.Nj)
          paramInt1 = 0;
        while (true)
        {
          if (paramInt1 != 0)
            paramInt2 = 0;
          setMeasuredDimension(j, paramInt2);
          return;
          i = getChildCount();
          paramInt1 = 0;
          while (true)
          {
            if (paramInt1 >= i)
              break label1039;
            localObject1 = getChildAt(paramInt1);
            if ((am((View)localObject1)) && (((View)localObject1).getMeasuredWidth() > 0) && (((View)localObject1).getMeasuredHeight() > 0))
            {
              paramInt1 = 0;
              break;
            }
            paramInt1 += 1;
          }
          label1039: paramInt1 = 1;
        }
        label1044: k = j;
        j = i;
      }
      label1057: k = 0;
      m = 0;
    }
  }

  protected void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if (!(paramParcelable instanceof SavedState))
    {
      super.onRestoreInstanceState(paramParcelable);
      return;
    }
    SavedState localSavedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(localSavedState.getSuperState());
    if (this.EK != null);
    for (paramParcelable = this.EK.vF; ; paramParcelable = null)
    {
      if ((localSavedState.No != 0) && (this.Ni != null) && (paramParcelable != null))
      {
        paramParcelable = paramParcelable.findItem(localSavedState.No);
        if (paramParcelable != null)
          android.support.v4.view.l.b(paramParcelable);
      }
      if (!localSavedState.Np)
        break;
      removeCallbacks(this.Nk);
      post(this.Nk);
      return;
    }
  }

  public void onRtlPropertiesChanged(int paramInt)
  {
    boolean bool = true;
    if (Build.VERSION.SDK_INT >= 17)
      super.onRtlPropertiesChanged(paramInt);
    r localr = this.MW;
    if (paramInt == 1)
      if (bool != localr.Kj)
      {
        localr.Kj = bool;
        if (!localr.Kk)
          break label164;
        if (!bool)
          break label109;
        if (localr.jo == -2147483648)
          break label93;
        paramInt = localr.jo;
        label63: localr.Ke = paramInt;
        if (localr.Kg == -2147483648)
          break label101;
      }
    label93: label101: for (paramInt = localr.Kg; ; paramInt = localr.Ki)
    {
      localr.Kf = paramInt;
      return;
      bool = false;
      break;
      paramInt = localr.Kh;
      break label63;
    }
    label109: if (localr.Kg != -2147483648)
    {
      paramInt = localr.Kg;
      localr.Ke = paramInt;
      if (localr.jo == -2147483648)
        break label156;
    }
    label156: for (paramInt = localr.jo; ; paramInt = localr.Ki)
    {
      localr.Kf = paramInt;
      return;
      paramInt = localr.Kh;
      break;
    }
    label164: localr.Ke = localr.Kh;
    localr.Kf = localr.Ki;
  }

  protected Parcelable onSaveInstanceState()
  {
    SavedState localSavedState = new SavedState(super.onSaveInstanceState());
    if ((this.Ni != null) && (this.Ni.Nm != null))
      localSavedState.No = this.Ni.Nm.getItemId();
    localSavedState.Np = isOverflowMenuShowing();
    return localSavedState;
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    int i = android.support.v4.view.n.d(paramMotionEvent);
    if (i == 0)
      this.EO = false;
    if (!this.EO)
    {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if ((i == 0) && (!bool))
        this.EO = true;
    }
    if ((i == 1) || (i == 3))
      this.EO = false;
    return true;
  }

  public final void setLogo(Drawable paramDrawable)
  {
    if (paramDrawable != null)
    {
      dQ();
      if (!ap(this.MJ))
        d(this.MJ, true);
    }
    while (true)
    {
      if (this.MJ != null)
        this.MJ.setImageDrawable(paramDrawable);
      return;
      if ((this.MJ != null) && (ap(this.MJ)))
      {
        removeView(this.MJ);
        this.Nc.remove(this.MJ);
      }
    }
  }

  public final void setNavigationContentDescription(CharSequence paramCharSequence)
  {
    if (!TextUtils.isEmpty(paramCharSequence))
      dS();
    if (this.MI != null)
      this.MI.setContentDescription(paramCharSequence);
  }

  public final void setNavigationIcon(Drawable paramDrawable)
  {
    if (paramDrawable != null)
    {
      dS();
      if (!ap(this.MI))
        d(this.MI, true);
    }
    while (true)
    {
      if (this.MI != null)
        this.MI.setImageDrawable(paramDrawable);
      return;
      if ((this.MI != null) && (ap(this.MI)))
      {
        removeView(this.MI);
        this.Nc.remove(this.MI);
      }
    }
  }

  public final void setNavigationOnClickListener(View.OnClickListener paramOnClickListener)
  {
    dS();
    this.MI.setOnClickListener(paramOnClickListener);
  }

  public final void setPopupTheme(int paramInt)
  {
    if (this.Gn != paramInt)
    {
      this.Gn = paramInt;
      if (paramInt == 0)
        this.EJ = getContext();
    }
    else
    {
      return;
    }
    this.EJ = new ContextThemeWrapper(getContext(), paramInt);
  }

  public final void setSubtitle(CharSequence paramCharSequence)
  {
    if (!TextUtils.isEmpty(paramCharSequence))
    {
      if (this.MH == null)
      {
        Context localContext = getContext();
        this.MH = new TextView(localContext);
        this.MH.setSingleLine();
        this.MH.setEllipsize(TextUtils.TruncateAt.END);
        if (this.MP != 0)
          this.MH.setTextAppearance(localContext, this.MP);
        if (this.Na != 0)
          this.MH.setTextColor(this.Na);
      }
      if (!ap(this.MH))
        d(this.MH, true);
    }
    while (true)
    {
      if (this.MH != null)
        this.MH.setText(paramCharSequence);
      this.MY = paramCharSequence;
      return;
      if ((this.MH != null) && (ap(this.MH)))
      {
        removeView(this.MH);
        this.Nc.remove(this.MH);
      }
    }
  }

  public final void setTitle(CharSequence paramCharSequence)
  {
    if (!TextUtils.isEmpty(paramCharSequence))
    {
      if (this.MG == null)
      {
        Context localContext = getContext();
        this.MG = new TextView(localContext);
        this.MG.setSingleLine();
        this.MG.setEllipsize(TextUtils.TruncateAt.END);
        if (this.MO != 0)
          this.MG.setTextAppearance(localContext, this.MO);
        if (this.MZ != 0)
          this.MG.setTextColor(this.MZ);
      }
      if (!ap(this.MG))
        d(this.MG, true);
    }
    while (true)
    {
      if (this.MG != null)
        this.MG.setText(paramCharSequence);
      this.MX = paramCharSequence;
      return;
      if ((this.MG != null) && (ap(this.MG)))
      {
        removeView(this.MG);
        this.Nc.remove(this.MG);
      }
    }
  }

  public final boolean showOverflowMenu()
  {
    if (this.EK != null)
    {
      ActionMenuView localActionMenuView = this.EK;
      if ((localActionMenuView.Go != null) && (localActionMenuView.Go.showOverflowMenu()));
      for (int i = 1; i != 0; i = 0)
        return true;
    }
    return false;
  }

  public static class LayoutParams extends ActionBar.LayoutParams
  {
    int Nn = 0;

    public LayoutParams()
    {
      super(-2);
      this.gravity = 8388627;
    }

    public LayoutParams(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
    }

    public LayoutParams(ActionBar.LayoutParams paramLayoutParams)
    {
      super();
    }

    public LayoutParams(LayoutParams paramLayoutParams)
    {
      super();
      this.Nn = paramLayoutParams.Nn;
    }

    public LayoutParams(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }

    public LayoutParams(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      super();
      this.leftMargin = paramMarginLayoutParams.leftMargin;
      this.topMargin = paramMarginLayoutParams.topMargin;
      this.rightMargin = paramMarginLayoutParams.rightMargin;
      this.bottomMargin = paramMarginLayoutParams.bottomMargin;
    }
  }

  public static class SavedState extends View.BaseSavedState
  {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator()
    {
    };
    int No;
    boolean Np;

    public SavedState(Parcel paramParcel)
    {
      super();
      this.No = paramParcel.readInt();
      if (paramParcel.readInt() != 0);
      for (boolean bool = true; ; bool = false)
      {
        this.Np = bool;
        return;
      }
    }

    public SavedState(Parcelable paramParcelable)
    {
      super();
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      super.writeToParcel(paramParcel, paramInt);
      paramParcel.writeInt(this.No);
      if (this.Np);
      for (paramInt = 1; ; paramInt = 0)
      {
        paramParcel.writeInt(paramInt);
        return;
      }
    }
  }

  private final class a
    implements android.support.v7.view.menu.l
  {
    h Nm;
    f vF;

    private a()
    {
    }

    public final void a(Context paramContext, f paramf)
    {
      if ((this.vF != null) && (this.Nm != null))
        this.vF.g(this.Nm);
      this.vF = paramf;
    }

    public final void a(f paramf, boolean paramBoolean)
    {
    }

    public final boolean a(p paramp)
    {
      return false;
    }

    public final boolean c(h paramh)
    {
      Toolbar.b(Toolbar.this);
      if (Toolbar.c(Toolbar.this).getParent() != Toolbar.this)
        Toolbar.this.addView(Toolbar.c(Toolbar.this));
      Toolbar.this.MN = paramh.getActionView();
      this.Nm = paramh;
      if (Toolbar.this.MN.getParent() != Toolbar.this)
      {
        localObject = Toolbar.dT();
        ((Toolbar.LayoutParams)localObject).gravity = (0x800003 | Toolbar.d(Toolbar.this) & 0x70);
        ((Toolbar.LayoutParams)localObject).Nn = 2;
        Toolbar.this.MN.setLayoutParams((ViewGroup.LayoutParams)localObject);
        Toolbar.this.addView(Toolbar.this.MN);
      }
      Object localObject = Toolbar.this;
      int i = ((Toolbar)localObject).getChildCount() - 1;
      while (i >= 0)
      {
        View localView = ((Toolbar)localObject).getChildAt(i);
        if ((((Toolbar.LayoutParams)localView.getLayoutParams()).Nn != 2) && (localView != ((Toolbar)localObject).EK))
        {
          ((Toolbar)localObject).removeViewAt(i);
          ((Toolbar)localObject).Nc.add(localView);
        }
        i -= 1;
      }
      Toolbar.this.requestLayout();
      paramh.D(true);
      if ((Toolbar.this.MN instanceof c))
        ((c)Toolbar.this.MN).onActionViewExpanded();
      return true;
    }

    public final boolean ck()
    {
      return false;
    }

    public final boolean d(h paramh)
    {
      if ((Toolbar.this.MN instanceof c))
        ((c)Toolbar.this.MN).onActionViewCollapsed();
      Toolbar.this.removeView(Toolbar.this.MN);
      Toolbar.this.removeView(Toolbar.c(Toolbar.this));
      Toolbar.this.MN = null;
      Toolbar localToolbar = Toolbar.this;
      int i = localToolbar.Nc.size() - 1;
      while (i >= 0)
      {
        localToolbar.addView((View)localToolbar.Nc.get(i));
        i -= 1;
      }
      localToolbar.Nc.clear();
      this.Nm = null;
      Toolbar.this.requestLayout();
      paramh.D(false);
      return true;
    }

    public final void w(boolean paramBoolean)
    {
      int k = 0;
      int j;
      int m;
      int i;
      if (this.Nm != null)
      {
        j = k;
        if (this.vF != null)
        {
          m = this.vF.size();
          i = 0;
        }
      }
      while (true)
      {
        j = k;
        if (i < m)
        {
          if (this.vF.getItem(i) == this.Nm)
            j = 1;
        }
        else
        {
          if (j == 0)
            d(this.Nm);
          return;
        }
        i += 1;
      }
    }
  }

  public static abstract interface b
  {
    public abstract boolean cZ();
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.Toolbar
 * JD-Core Version:    0.6.2
 */