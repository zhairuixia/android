package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

public final class y
{
  public final TypedArray MF;
  private final Context mContext;

  y(Context paramContext, TypedArray paramTypedArray)
  {
    this.mContext = paramContext;
    this.MF = paramTypedArray;
  }

  public static y a(Context paramContext, AttributeSet paramAttributeSet, int[] paramArrayOfInt, int paramInt)
  {
    return new y(paramContext, paramContext.obtainStyledAttributes(paramAttributeSet, paramArrayOfInt, paramInt, 0));
  }

  public final Drawable am(int paramInt)
  {
    if (this.MF.hasValue(paramInt))
    {
      paramInt = this.MF.getResourceId(paramInt, 0);
      if (paramInt != 0)
        return g.dp().a(this.mContext, paramInt, true);
    }
    return null;
  }

  public final int an(int paramInt)
  {
    return this.MF.getColor(paramInt, -1);
  }

  public final boolean getBoolean(int paramInt, boolean paramBoolean)
  {
    return this.MF.getBoolean(paramInt, paramBoolean);
  }

  public final int getDimensionPixelOffset(int paramInt1, int paramInt2)
  {
    return this.MF.getDimensionPixelOffset(paramInt1, paramInt2);
  }

  public final int getDimensionPixelSize(int paramInt1, int paramInt2)
  {
    return this.MF.getDimensionPixelSize(paramInt1, paramInt2);
  }

  public final Drawable getDrawable(int paramInt)
  {
    if (this.MF.hasValue(paramInt))
    {
      int i = this.MF.getResourceId(paramInt, 0);
      if (i != 0)
        return g.dp().a(this.mContext, i, false);
    }
    return this.MF.getDrawable(paramInt);
  }

  public final int getInt(int paramInt1, int paramInt2)
  {
    return this.MF.getInt(paramInt1, paramInt2);
  }

  public final int getLayoutDimension(int paramInt1, int paramInt2)
  {
    return this.MF.getLayoutDimension(paramInt1, paramInt2);
  }

  public final int getResourceId(int paramInt1, int paramInt2)
  {
    return this.MF.getResourceId(paramInt1, paramInt2);
  }

  public final CharSequence getText(int paramInt)
  {
    return this.MF.getText(paramInt);
  }

  public final boolean hasValue(int paramInt)
  {
    return this.MF.hasValue(paramInt);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.y
 * JD-Core Version:    0.6.2
 */