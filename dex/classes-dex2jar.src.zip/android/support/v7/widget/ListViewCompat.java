package android.support.v7.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.v7.b.a.a;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.widget.AbsListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import java.lang.reflect.Field;

public class ListViewCompat extends ListView
{
  private static final int[] JV = { 0 };
  final Rect JW = new Rect();
  int JX = 0;
  int JY = 0;
  int JZ = 0;
  int Ka = 0;
  protected int Kb;
  private Field Kc;
  private a Kd;

  public ListViewCompat(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public ListViewCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    try
    {
      this.Kc = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
      this.Kc.setAccessible(true);
      return;
    }
    catch (NoSuchFieldException paramContext)
    {
    }
  }

  protected final void J(boolean paramBoolean)
  {
    if (this.Kd != null)
      this.Kd.ny = paramBoolean;
  }

  void a(int paramInt, View paramView)
  {
    Rect localRect = this.JW;
    localRect.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
    localRect.left -= this.JX;
    localRect.top -= this.JY;
    localRect.right += this.JZ;
    localRect.bottom += this.Ka;
    try
    {
      boolean bool = this.Kc.getBoolean(this);
      if (paramView.isEnabled() != bool)
      {
        paramView = this.Kc;
        if (bool)
          break label134;
      }
      label134: for (bool = true; ; bool = false)
      {
        paramView.set(this, Boolean.valueOf(bool));
        if (paramInt != -1)
          refreshDrawableState();
        return;
      }
    }
    catch (IllegalAccessException paramView)
    {
    }
  }

  protected void dispatchDraw(Canvas paramCanvas)
  {
    if (!this.JW.isEmpty())
    {
      Drawable localDrawable = getSelector();
      if (localDrawable != null)
      {
        localDrawable.setBounds(this.JW);
        localDrawable.draw(paramCanvas);
      }
    }
    super.dispatchDraw(paramCanvas);
  }

  protected void drawableStateChanged()
  {
    int i = 1;
    super.drawableStateChanged();
    J(true);
    Drawable localDrawable = getSelector();
    if (localDrawable != null)
      if ((!dx()) || (!isPressed()))
        break label48;
    while (true)
    {
      if (i != 0)
        localDrawable.setState(getDrawableState());
      return;
      label48: i = 0;
    }
  }

  protected boolean dx()
  {
    return false;
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    switch (paramMotionEvent.getAction())
    {
    default:
    case 0:
    }
    while (true)
    {
      return super.onTouchEvent(paramMotionEvent);
      this.Kb = pointToPosition((int)paramMotionEvent.getX(), (int)paramMotionEvent.getY());
    }
  }

  public final int q(int paramInt1, int paramInt2)
  {
    int i = getListPaddingTop();
    int k = getListPaddingBottom();
    getListPaddingLeft();
    getListPaddingRight();
    int j = getDividerHeight();
    Object localObject = getDivider();
    ListAdapter localListAdapter = getAdapter();
    if (localListAdapter == null)
    {
      i += k;
      return i;
    }
    i = k + i;
    label66: label84: int n;
    label116: View localView;
    if ((j > 0) && (localObject != null))
    {
      int i1 = localListAdapter.getCount();
      k = 0;
      int m = 0;
      localObject = null;
      if (k >= i1)
        break label251;
      n = localListAdapter.getItemViewType(k);
      if (n == m)
        break label253;
      m = n;
      localObject = null;
      localView = localListAdapter.getView(k, (View)localObject, this);
      ViewGroup.LayoutParams localLayoutParams = localView.getLayoutParams();
      localObject = localLayoutParams;
      if (localLayoutParams == null)
      {
        localObject = generateDefaultLayoutParams();
        localView.setLayoutParams((ViewGroup.LayoutParams)localObject);
      }
      if (((ViewGroup.LayoutParams)localObject).height <= 0)
        break label241;
      n = View.MeasureSpec.makeMeasureSpec(((ViewGroup.LayoutParams)localObject).height, 1073741824);
      label179: localView.measure(paramInt1, n);
      localView.forceLayout();
      if (k <= 0)
        break label256;
      i += j;
    }
    label256: 
    while (true)
    {
      n = localView.getMeasuredHeight() + i;
      i = paramInt2;
      if (n >= paramInt2)
        break;
      k += 1;
      i = n;
      localObject = localView;
      break label84;
      j = 0;
      break label66;
      label241: n = View.MeasureSpec.makeMeasureSpec(0, 0);
      break label179;
      label251: return i;
      label253: break label116;
    }
  }

  public void setSelector(Drawable paramDrawable)
  {
    if (paramDrawable != null);
    for (Object localObject = new a(paramDrawable); ; localObject = null)
    {
      this.Kd = ((a)localObject);
      super.setSelector(this.Kd);
      localObject = new Rect();
      if (paramDrawable != null)
        paramDrawable.getPadding((Rect)localObject);
      this.JX = ((Rect)localObject).left;
      this.JY = ((Rect)localObject).top;
      this.JZ = ((Rect)localObject).right;
      this.Ka = ((Rect)localObject).bottom;
      return;
    }
  }

  private static final class a extends a
  {
    boolean ny = true;

    public a(Drawable paramDrawable)
    {
      super();
    }

    public final void draw(Canvas paramCanvas)
    {
      if (this.ny)
        super.draw(paramCanvas);
    }

    public final void setHotspot(float paramFloat1, float paramFloat2)
    {
      if (this.ny)
        super.setHotspot(paramFloat1, paramFloat2);
    }

    public final void setHotspotBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      if (this.ny)
        super.setHotspotBounds(paramInt1, paramInt2, paramInt3, paramInt4);
    }

    public final boolean setState(int[] paramArrayOfInt)
    {
      if (this.ny)
        return super.setState(paramArrayOfInt);
      return false;
    }

    public final boolean setVisible(boolean paramBoolean1, boolean paramBoolean2)
    {
      if (this.ny)
        return super.setVisible(paramBoolean1, paramBoolean2);
      return false;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.ListViewCompat
 * JD-Core Version:    0.6.2
 */