package android.support.v7.widget;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;

class b extends Drawable
{
  final ActionBarContainer ET;

  public b(ActionBarContainer paramActionBarContainer)
  {
    this.ET = paramActionBarContainer;
  }

  public void draw(Canvas paramCanvas)
  {
    if (this.ET.Fa)
      if (this.ET.EZ != null)
        this.ET.EZ.draw(paramCanvas);
    do
    {
      return;
      if (this.ET.Dn != null)
        this.ET.Dn.draw(paramCanvas);
    }
    while ((this.ET.EY == null) || (!this.ET.Fb));
    this.ET.EY.draw(paramCanvas);
  }

  public int getOpacity()
  {
    return 0;
  }

  public void setAlpha(int paramInt)
  {
  }

  public void setColorFilter(ColorFilter paramColorFilter)
  {
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.b
 * JD-Core Version:    0.6.2
 */