package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.v7.a.a.a;
import android.support.v7.a.a.k;
import android.support.v7.c.a;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.widget.TextView;

class k
{
  private static final int[] It = { 16842804, 16843119, 16843117, 16843120, 16843118 };
  private static final int[] Iu = { a.a.textAllCaps };
  final TextView Iv;
  private w Iw;
  private w Ix;
  private w Iy;
  private w Iz;

  k(TextView paramTextView)
  {
    this.Iv = paramTextView;
  }

  protected static w a(Context paramContext, g paramg, int paramInt)
  {
    paramContext = paramg.d(paramContext, paramInt);
    if (paramContext != null)
    {
      paramg = new w();
      paramg.MD = true;
      paramg.MB = paramContext;
      return paramg;
    }
    return null;
  }

  static k b(TextView paramTextView)
  {
    if (Build.VERSION.SDK_INT >= 17)
      return new l(paramTextView);
    return new k(paramTextView);
  }

  private void setAllCaps(boolean paramBoolean)
  {
    TextView localTextView = this.Iv;
    if (paramBoolean);
    for (a locala = new a(this.Iv.getContext()); ; locala = null)
    {
      localTextView.setTransformationMethod(locala);
      return;
    }
  }

  final void a(Drawable paramDrawable, w paramw)
  {
    if ((paramDrawable != null) && (paramw != null))
      g.a(paramDrawable, paramw, this.Iv.getDrawableState());
  }

  void a(AttributeSet paramAttributeSet, int paramInt)
  {
    int j = 1;
    Context localContext = this.Iv.getContext();
    Object localObject = g.dp();
    TypedArray localTypedArray = localContext.obtainStyledAttributes(paramAttributeSet, It, paramInt, 0);
    int i = localTypedArray.getResourceId(0, -1);
    if (localTypedArray.hasValue(1))
      this.Iw = a(localContext, (g)localObject, localTypedArray.getResourceId(1, 0));
    if (localTypedArray.hasValue(2))
      this.Ix = a(localContext, (g)localObject, localTypedArray.getResourceId(2, 0));
    if (localTypedArray.hasValue(3))
      this.Iy = a(localContext, (g)localObject, localTypedArray.getResourceId(3, 0));
    if (localTypedArray.hasValue(4))
      this.Iz = a(localContext, (g)localObject, localTypedArray.getResourceId(4, 0));
    localTypedArray.recycle();
    boolean bool;
    if (!(this.Iv.getTransformationMethod() instanceof PasswordTransformationMethod))
    {
      if (i == -1)
        break label268;
      localObject = localContext.obtainStyledAttributes(i, a.k.AT);
      if (!((TypedArray)localObject).hasValue(a.k.AY))
        break label260;
      bool = ((TypedArray)localObject).getBoolean(a.k.AY, false);
      i = 1;
      ((TypedArray)localObject).recycle();
    }
    while (true)
    {
      paramAttributeSet = localContext.obtainStyledAttributes(paramAttributeSet, Iu, paramInt, 0);
      if (paramAttributeSet.hasValue(0))
        bool = paramAttributeSet.getBoolean(0, false);
      for (paramInt = j; ; paramInt = i)
      {
        paramAttributeSet.recycle();
        if (paramInt != 0)
          setAllCaps(bool);
        return;
      }
      label260: i = 0;
      bool = false;
      break;
      label268: i = 0;
      bool = false;
    }
  }

  void ds()
  {
    if ((this.Iw != null) || (this.Ix != null) || (this.Iy != null) || (this.Iz != null))
    {
      Drawable[] arrayOfDrawable = this.Iv.getCompoundDrawables();
      a(arrayOfDrawable[0], this.Iw);
      a(arrayOfDrawable[1], this.Ix);
      a(arrayOfDrawable[2], this.Iy);
      a(arrayOfDrawable[3], this.Iz);
    }
  }

  final void f(Context paramContext, int paramInt)
  {
    paramContext = paramContext.obtainStyledAttributes(paramInt, Iu);
    if (paramContext.hasValue(0))
      setAllCaps(paramContext.getBoolean(0, false));
    paramContext.recycle();
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.k
 * JD-Core Version:    0.6.2
 */