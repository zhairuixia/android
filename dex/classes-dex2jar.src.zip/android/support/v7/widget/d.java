package android.support.v7.widget;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.DataSetObservable;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.text.TextUtils;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class d extends DataSetObservable
{
  private static final Object GC = new Object();
  private static final Map<String, d> GD = new HashMap();
  private static final String qS = d.class.getSimpleName();
  final Object GE;
  final List<a> GF;
  private final List<c> GG;
  private final String GH;
  private b GI;
  private int GJ;
  private boolean GK;
  private boolean GL;
  private boolean GM;
  private boolean GN;
  private d GO;
  private final Context mContext;
  private Intent mIntent;

  private boolean dd()
  {
    if ((this.GI != null) && (this.mIntent != null) && (!this.GF.isEmpty()) && (!this.GG.isEmpty()))
    {
      Collections.unmodifiableList(this.GG);
      return true;
    }
    return false;
  }

  private void de()
  {
    int j = this.GG.size() - this.GJ;
    if (j <= 0);
    while (true)
    {
      return;
      this.GM = true;
      int i = 0;
      while (i < j)
      {
        this.GG.remove(0);
        i += 1;
      }
    }
  }

  // ERROR //
  private void df()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 74	android/support/v7/widget/d:mContext	Landroid/content/Context;
    //   4: aload_0
    //   5: getfield 77	android/support/v7/widget/d:GH	Ljava/lang/String;
    //   8: invokevirtual 127	android/content/Context:openFileInput	(Ljava/lang/String;)Ljava/io/FileInputStream;
    //   11: astore_2
    //   12: invokestatic 133	android/util/Xml:newPullParser	()Lorg/xmlpull/v1/XmlPullParser;
    //   15: astore_3
    //   16: aload_3
    //   17: aload_2
    //   18: ldc 135
    //   20: invokeinterface 141 3 0
    //   25: iconst_0
    //   26: istore_1
    //   27: iload_1
    //   28: iconst_1
    //   29: if_icmpeq +18 -> 47
    //   32: iload_1
    //   33: iconst_2
    //   34: if_icmpeq +13 -> 47
    //   37: aload_3
    //   38: invokeinterface 144 1 0
    //   43: istore_1
    //   44: goto -17 -> 27
    //   47: ldc 146
    //   49: aload_3
    //   50: invokeinterface 149 1 0
    //   55: invokevirtual 155	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   58: ifne +40 -> 98
    //   61: new 119	org/xmlpull/v1/XmlPullParserException
    //   64: dup
    //   65: ldc 157
    //   67: invokespecial 160	org/xmlpull/v1/XmlPullParserException:<init>	(Ljava/lang/String;)V
    //   70: athrow
    //   71: astore_3
    //   72: new 162	java/lang/StringBuilder
    //   75: dup
    //   76: ldc 164
    //   78: invokespecial 165	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   81: aload_0
    //   82: getfield 77	android/support/v7/widget/d:GH	Ljava/lang/String;
    //   85: invokevirtual 169	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   88: pop
    //   89: aload_2
    //   90: ifnull +7 -> 97
    //   93: aload_2
    //   94: invokevirtual 174	java/io/FileInputStream:close	()V
    //   97: return
    //   98: aload_0
    //   99: getfield 95	android/support/v7/widget/d:GG	Ljava/util/List;
    //   102: astore 4
    //   104: aload 4
    //   106: invokeinterface 177 1 0
    //   111: aload_3
    //   112: invokeinterface 144 1 0
    //   117: istore_1
    //   118: iload_1
    //   119: iconst_1
    //   120: if_icmpeq +128 -> 248
    //   123: iload_1
    //   124: iconst_3
    //   125: if_icmpeq -14 -> 111
    //   128: iload_1
    //   129: iconst_4
    //   130: if_icmpeq -19 -> 111
    //   133: ldc 179
    //   135: aload_3
    //   136: invokeinterface 149 1 0
    //   141: invokevirtual 155	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   144: ifne +42 -> 186
    //   147: new 119	org/xmlpull/v1/XmlPullParserException
    //   150: dup
    //   151: ldc 181
    //   153: invokespecial 160	org/xmlpull/v1/XmlPullParserException:<init>	(Ljava/lang/String;)V
    //   156: athrow
    //   157: astore_3
    //   158: new 162	java/lang/StringBuilder
    //   161: dup
    //   162: ldc 164
    //   164: invokespecial 165	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   167: aload_0
    //   168: getfield 77	android/support/v7/widget/d:GH	Ljava/lang/String;
    //   171: invokevirtual 169	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   174: pop
    //   175: aload_2
    //   176: ifnull -79 -> 97
    //   179: aload_2
    //   180: invokevirtual 174	java/io/FileInputStream:close	()V
    //   183: return
    //   184: astore_2
    //   185: return
    //   186: aload 4
    //   188: new 12	android/support/v7/widget/d$c
    //   191: dup
    //   192: aload_3
    //   193: aconst_null
    //   194: ldc 183
    //   196: invokeinterface 187 3 0
    //   201: aload_3
    //   202: aconst_null
    //   203: ldc 189
    //   205: invokeinterface 187 3 0
    //   210: invokestatic 195	java/lang/Long:parseLong	(Ljava/lang/String;)J
    //   213: aload_3
    //   214: aconst_null
    //   215: ldc 197
    //   217: invokeinterface 187 3 0
    //   222: invokestatic 203	java/lang/Float:parseFloat	(Ljava/lang/String;)F
    //   225: invokespecial 206	android/support/v7/widget/d$c:<init>	(Ljava/lang/String;JF)V
    //   228: invokeinterface 209 2 0
    //   233: pop
    //   234: goto -123 -> 111
    //   237: astore_3
    //   238: aload_2
    //   239: ifnull +7 -> 246
    //   242: aload_2
    //   243: invokevirtual 174	java/io/FileInputStream:close	()V
    //   246: aload_3
    //   247: athrow
    //   248: aload_2
    //   249: ifnull -152 -> 97
    //   252: aload_2
    //   253: invokevirtual 174	java/io/FileInputStream:close	()V
    //   256: return
    //   257: astore_2
    //   258: return
    //   259: astore_2
    //   260: return
    //   261: astore_2
    //   262: goto -16 -> 246
    //   265: astore_2
    //   266: return
    //
    // Exception table:
    //   from	to	target	type
    //   12	25	71	org/xmlpull/v1/XmlPullParserException
    //   37	44	71	org/xmlpull/v1/XmlPullParserException
    //   47	71	71	org/xmlpull/v1/XmlPullParserException
    //   98	111	71	org/xmlpull/v1/XmlPullParserException
    //   111	118	71	org/xmlpull/v1/XmlPullParserException
    //   133	157	71	org/xmlpull/v1/XmlPullParserException
    //   186	234	71	org/xmlpull/v1/XmlPullParserException
    //   12	25	157	java/io/IOException
    //   37	44	157	java/io/IOException
    //   47	71	157	java/io/IOException
    //   98	111	157	java/io/IOException
    //   111	118	157	java/io/IOException
    //   133	157	157	java/io/IOException
    //   186	234	157	java/io/IOException
    //   179	183	184	java/io/IOException
    //   12	25	237	finally
    //   37	44	237	finally
    //   47	71	237	finally
    //   72	89	237	finally
    //   98	111	237	finally
    //   111	118	237	finally
    //   133	157	237	finally
    //   158	175	237	finally
    //   186	234	237	finally
    //   252	256	257	java/io/IOException
    //   93	97	259	java/io/IOException
    //   242	246	261	java/io/IOException
    //   0	12	265	java/io/FileNotFoundException
  }

  public final int a(ResolveInfo paramResolveInfo)
  {
    while (true)
    {
      int i;
      synchronized (this.GE)
      {
        dc();
        List localList = this.GF;
        int j = localList.size();
        i = 0;
        if (i < j)
        {
          if (((a)localList.get(i)).resolveInfo == paramResolveInfo)
            return i;
        }
        else
          return -1;
      }
      i += 1;
    }
  }

  final boolean a(c paramc)
  {
    boolean bool = this.GG.add(paramc);
    Object[] arrayOfObject;
    if (bool)
    {
      this.GM = true;
      de();
      if (!this.GL)
        throw new IllegalStateException("No preceding call to #readHistoricalData");
      if (this.GM)
      {
        this.GM = false;
        if (!TextUtils.isEmpty(this.GH))
        {
          paramc = new e((byte)0);
          arrayOfObject = new Object[2];
          arrayOfObject[0] = new ArrayList(this.GG);
          arrayOfObject[1] = this.GH;
          if (Build.VERSION.SDK_INT < 11)
            break label127;
          paramc.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, arrayOfObject);
        }
      }
    }
    while (true)
    {
      dd();
      notifyChanged();
      return bool;
      label127: paramc.execute(arrayOfObject);
    }
  }

  public final ResolveInfo ac(int paramInt)
  {
    synchronized (this.GE)
    {
      dc();
      ResolveInfo localResolveInfo = ((a)this.GF.get(paramInt)).resolveInfo;
      return localResolveInfo;
    }
  }

  public final Intent ad(int paramInt)
  {
    synchronized (this.GE)
    {
      if (this.mIntent == null)
        return null;
      dc();
      Object localObject2 = (a)this.GF.get(paramInt);
      localObject2 = new ComponentName(((a)localObject2).resolveInfo.activityInfo.packageName, ((a)localObject2).resolveInfo.activityInfo.name);
      Intent localIntent = new Intent(this.mIntent);
      localIntent.setComponent((ComponentName)localObject2);
      if (this.GO != null)
      {
        new Intent(localIntent);
        if (this.GO.dh())
          return null;
      }
      a(new c((ComponentName)localObject2, System.currentTimeMillis(), 1.0F));
      return localIntent;
    }
  }

  public final int da()
  {
    synchronized (this.GE)
    {
      dc();
      int i = this.GF.size();
      return i;
    }
  }

  public final ResolveInfo db()
  {
    synchronized (this.GE)
    {
      dc();
      if (!this.GF.isEmpty())
      {
        ResolveInfo localResolveInfo = ((a)this.GF.get(0)).resolveInfo;
        return localResolveInfo;
      }
      return null;
    }
  }

  final void dc()
  {
    int j = 1;
    int i;
    if ((this.GN) && (this.mIntent != null))
    {
      this.GN = false;
      this.GF.clear();
      List localList = this.mContext.getPackageManager().queryIntentActivities(this.mIntent, 0);
      int k = localList.size();
      i = 0;
      while (i < k)
      {
        ResolveInfo localResolveInfo = (ResolveInfo)localList.get(i);
        this.GF.add(new a(localResolveInfo));
        i += 1;
      }
      i = 1;
      if ((!this.GK) || (!this.GM) || (TextUtils.isEmpty(this.GH)))
        break label167;
      this.GK = false;
      this.GL = true;
      df();
    }
    while (true)
    {
      de();
      if ((i | j) != 0)
      {
        dd();
        notifyChanged();
      }
      return;
      i = 0;
      break;
      label167: j = 0;
    }
  }

  public final int getHistorySize()
  {
    synchronized (this.GE)
    {
      dc();
      int i = this.GG.size();
      return i;
    }
  }

  public final class a
    implements Comparable<a>
  {
    public final ResolveInfo resolveInfo;
    public float weight;

    public a(ResolveInfo arg2)
    {
      Object localObject;
      this.resolveInfo = localObject;
    }

    public final boolean equals(Object paramObject)
    {
      if (this == paramObject);
      do
      {
        return true;
        if (paramObject == null)
          return false;
        if (getClass() != paramObject.getClass())
          return false;
        paramObject = (a)paramObject;
      }
      while (Float.floatToIntBits(this.weight) == Float.floatToIntBits(paramObject.weight));
      return false;
    }

    public final int hashCode()
    {
      return Float.floatToIntBits(this.weight) + 31;
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("[");
      localStringBuilder.append("resolveInfo:").append(this.resolveInfo.toString());
      localStringBuilder.append("; weight:").append(new BigDecimal(this.weight));
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }

  public static abstract interface b
  {
  }

  public static final class c
  {
    public final ComponentName GQ;
    public final long time;
    public final float weight;

    public c(ComponentName paramComponentName, long paramLong, float paramFloat)
    {
      this.GQ = paramComponentName;
      this.time = paramLong;
      this.weight = paramFloat;
    }

    public c(String paramString, long paramLong, float paramFloat)
    {
      this(ComponentName.unflattenFromString(paramString), paramLong, paramFloat);
    }

    public final boolean equals(Object paramObject)
    {
      if (this == paramObject);
      do
      {
        return true;
        if (paramObject == null)
          return false;
        if (getClass() != paramObject.getClass())
          return false;
        paramObject = (c)paramObject;
        if (this.GQ == null)
        {
          if (paramObject.GQ != null)
            return false;
        }
        else if (!this.GQ.equals(paramObject.GQ))
          return false;
        if (this.time != paramObject.time)
          return false;
      }
      while (Float.floatToIntBits(this.weight) == Float.floatToIntBits(paramObject.weight));
      return false;
    }

    public final int hashCode()
    {
      if (this.GQ == null);
      for (int i = 0; ; i = this.GQ.hashCode())
        return ((i + 31) * 31 + (int)(this.time ^ this.time >>> 32)) * 31 + Float.floatToIntBits(this.weight);
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("[");
      localStringBuilder.append("; activity:").append(this.GQ);
      localStringBuilder.append("; time:").append(this.time);
      localStringBuilder.append("; weight:").append(new BigDecimal(this.weight));
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }

  public static abstract interface d
  {
    public abstract boolean dh();
  }

  private final class e extends AsyncTask<Object, Void, Void>
  {
    private e()
    {
    }

    // ERROR //
    private Void b(Object[] paramArrayOfObject)
    {
      // Byte code:
      //   0: iconst_0
      //   1: istore_2
      //   2: aload_1
      //   3: iconst_0
      //   4: aaload
      //   5: checkcast 33	java/util/List
      //   8: astore 4
      //   10: aload_1
      //   11: iconst_1
      //   12: aaload
      //   13: checkcast 35	java/lang/String
      //   16: astore_1
      //   17: aload_0
      //   18: getfield 14	android/support/v7/widget/d$e:GP	Landroid/support/v7/widget/d;
      //   21: invokestatic 39	android/support/v7/widget/d:a	(Landroid/support/v7/widget/d;)Landroid/content/Context;
      //   24: aload_1
      //   25: iconst_0
      //   26: invokevirtual 45	android/content/Context:openFileOutput	(Ljava/lang/String;I)Ljava/io/FileOutputStream;
      //   29: astore_1
      //   30: invokestatic 51	android/util/Xml:newSerializer	()Lorg/xmlpull/v1/XmlSerializer;
      //   33: astore 5
      //   35: aload 5
      //   37: aload_1
      //   38: aconst_null
      //   39: invokeinterface 57 3 0
      //   44: aload 5
      //   46: ldc 59
      //   48: iconst_1
      //   49: invokestatic 65	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
      //   52: invokeinterface 69 3 0
      //   57: aload 5
      //   59: aconst_null
      //   60: ldc 71
      //   62: invokeinterface 75 3 0
      //   67: pop
      //   68: aload 4
      //   70: invokeinterface 79 1 0
      //   75: istore_3
      //   76: iload_2
      //   77: iload_3
      //   78: if_icmpge +109 -> 187
      //   81: aload 4
      //   83: iconst_0
      //   84: invokeinterface 83 2 0
      //   89: checkcast 85	android/support/v7/widget/d$c
      //   92: astore 6
      //   94: aload 5
      //   96: aconst_null
      //   97: ldc 87
      //   99: invokeinterface 75 3 0
      //   104: pop
      //   105: aload 5
      //   107: aconst_null
      //   108: ldc 89
      //   110: aload 6
      //   112: getfield 93	android/support/v7/widget/d$c:GQ	Landroid/content/ComponentName;
      //   115: invokevirtual 99	android/content/ComponentName:flattenToString	()Ljava/lang/String;
      //   118: invokeinterface 103 4 0
      //   123: pop
      //   124: aload 5
      //   126: aconst_null
      //   127: ldc 105
      //   129: aload 6
      //   131: getfield 108	android/support/v7/widget/d$c:time	J
      //   134: invokestatic 111	java/lang/String:valueOf	(J)Ljava/lang/String;
      //   137: invokeinterface 103 4 0
      //   142: pop
      //   143: aload 5
      //   145: aconst_null
      //   146: ldc 113
      //   148: aload 6
      //   150: getfield 116	android/support/v7/widget/d$c:weight	F
      //   153: invokestatic 119	java/lang/String:valueOf	(F)Ljava/lang/String;
      //   156: invokeinterface 103 4 0
      //   161: pop
      //   162: aload 5
      //   164: aconst_null
      //   165: ldc 87
      //   167: invokeinterface 122 3 0
      //   172: pop
      //   173: iload_2
      //   174: iconst_1
      //   175: iadd
      //   176: istore_2
      //   177: goto -101 -> 76
      //   180: astore_1
      //   181: invokestatic 125	android/support/v7/widget/d:dg	()Ljava/lang/String;
      //   184: pop
      //   185: aconst_null
      //   186: areturn
      //   187: aload 5
      //   189: aconst_null
      //   190: ldc 71
      //   192: invokeinterface 122 3 0
      //   197: pop
      //   198: aload 5
      //   200: invokeinterface 128 1 0
      //   205: aload_0
      //   206: getfield 14	android/support/v7/widget/d$e:GP	Landroid/support/v7/widget/d;
      //   209: invokestatic 132	android/support/v7/widget/d:c	(Landroid/support/v7/widget/d;)Z
      //   212: pop
      //   213: aload_1
      //   214: ifnull -29 -> 185
      //   217: aload_1
      //   218: invokevirtual 137	java/io/FileOutputStream:close	()V
      //   221: aconst_null
      //   222: areturn
      //   223: astore_1
      //   224: aconst_null
      //   225: areturn
      //   226: astore 4
      //   228: invokestatic 125	android/support/v7/widget/d:dg	()Ljava/lang/String;
      //   231: pop
      //   232: new 139	java/lang/StringBuilder
      //   235: dup
      //   236: ldc 141
      //   238: invokespecial 144	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   241: aload_0
      //   242: getfield 14	android/support/v7/widget/d$e:GP	Landroid/support/v7/widget/d;
      //   245: invokestatic 147	android/support/v7/widget/d:b	(Landroid/support/v7/widget/d;)Ljava/lang/String;
      //   248: invokevirtual 151	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   251: pop
      //   252: aload_0
      //   253: getfield 14	android/support/v7/widget/d$e:GP	Landroid/support/v7/widget/d;
      //   256: invokestatic 132	android/support/v7/widget/d:c	(Landroid/support/v7/widget/d;)Z
      //   259: pop
      //   260: aload_1
      //   261: ifnull -76 -> 185
      //   264: aload_1
      //   265: invokevirtual 137	java/io/FileOutputStream:close	()V
      //   268: aconst_null
      //   269: areturn
      //   270: astore_1
      //   271: aconst_null
      //   272: areturn
      //   273: astore 4
      //   275: invokestatic 125	android/support/v7/widget/d:dg	()Ljava/lang/String;
      //   278: pop
      //   279: new 139	java/lang/StringBuilder
      //   282: dup
      //   283: ldc 141
      //   285: invokespecial 144	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   288: aload_0
      //   289: getfield 14	android/support/v7/widget/d$e:GP	Landroid/support/v7/widget/d;
      //   292: invokestatic 147	android/support/v7/widget/d:b	(Landroid/support/v7/widget/d;)Ljava/lang/String;
      //   295: invokevirtual 151	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   298: pop
      //   299: aload_0
      //   300: getfield 14	android/support/v7/widget/d$e:GP	Landroid/support/v7/widget/d;
      //   303: invokestatic 132	android/support/v7/widget/d:c	(Landroid/support/v7/widget/d;)Z
      //   306: pop
      //   307: aload_1
      //   308: ifnull -123 -> 185
      //   311: aload_1
      //   312: invokevirtual 137	java/io/FileOutputStream:close	()V
      //   315: aconst_null
      //   316: areturn
      //   317: astore_1
      //   318: aconst_null
      //   319: areturn
      //   320: astore 4
      //   322: invokestatic 125	android/support/v7/widget/d:dg	()Ljava/lang/String;
      //   325: pop
      //   326: new 139	java/lang/StringBuilder
      //   329: dup
      //   330: ldc 141
      //   332: invokespecial 144	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   335: aload_0
      //   336: getfield 14	android/support/v7/widget/d$e:GP	Landroid/support/v7/widget/d;
      //   339: invokestatic 147	android/support/v7/widget/d:b	(Landroid/support/v7/widget/d;)Ljava/lang/String;
      //   342: invokevirtual 151	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   345: pop
      //   346: aload_0
      //   347: getfield 14	android/support/v7/widget/d$e:GP	Landroid/support/v7/widget/d;
      //   350: invokestatic 132	android/support/v7/widget/d:c	(Landroid/support/v7/widget/d;)Z
      //   353: pop
      //   354: aload_1
      //   355: ifnull -170 -> 185
      //   358: aload_1
      //   359: invokevirtual 137	java/io/FileOutputStream:close	()V
      //   362: aconst_null
      //   363: areturn
      //   364: astore_1
      //   365: aconst_null
      //   366: areturn
      //   367: astore 4
      //   369: aload_0
      //   370: getfield 14	android/support/v7/widget/d$e:GP	Landroid/support/v7/widget/d;
      //   373: invokestatic 132	android/support/v7/widget/d:c	(Landroid/support/v7/widget/d;)Z
      //   376: pop
      //   377: aload_1
      //   378: ifnull +7 -> 385
      //   381: aload_1
      //   382: invokevirtual 137	java/io/FileOutputStream:close	()V
      //   385: aload 4
      //   387: athrow
      //   388: astore_1
      //   389: goto -4 -> 385
      //
      // Exception table:
      //   from	to	target	type
      //   17	30	180	java/io/FileNotFoundException
      //   217	221	223	java/io/IOException
      //   35	76	226	java/lang/IllegalArgumentException
      //   81	173	226	java/lang/IllegalArgumentException
      //   187	205	226	java/lang/IllegalArgumentException
      //   264	268	270	java/io/IOException
      //   35	76	273	java/lang/IllegalStateException
      //   81	173	273	java/lang/IllegalStateException
      //   187	205	273	java/lang/IllegalStateException
      //   311	315	317	java/io/IOException
      //   35	76	320	java/io/IOException
      //   81	173	320	java/io/IOException
      //   187	205	320	java/io/IOException
      //   358	362	364	java/io/IOException
      //   35	76	367	finally
      //   81	173	367	finally
      //   187	205	367	finally
      //   228	252	367	finally
      //   275	299	367	finally
      //   322	346	367	finally
      //   381	385	388	java/io/IOException
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.d
 * JD-Core Version:    0.6.2
 */