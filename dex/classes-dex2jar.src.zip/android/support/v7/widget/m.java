package android.support.v7.widget;

import android.support.v7.view.menu.l.a;
import android.view.Menu;
import android.view.Window.Callback;

public abstract interface m
{
  public abstract void a(Menu paramMenu, l.a parama);

  public abstract void aa(int paramInt);

  public abstract void b(Window.Callback paramCallback);

  public abstract boolean cO();

  public abstract boolean cP();

  public abstract void cQ();

  public abstract void cR();

  public abstract void e(CharSequence paramCharSequence);

  public abstract boolean hideOverflowMenu();

  public abstract boolean isOverflowMenuShowing();

  public abstract boolean showOverflowMenu();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.m
 * JD-Core Version:    0.6.2
 */