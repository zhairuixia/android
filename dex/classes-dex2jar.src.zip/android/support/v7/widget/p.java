package android.support.v7.widget;

import android.graphics.Rect;

public abstract interface p
{
  public abstract void a(a parama);

  public static abstract interface a
  {
    public abstract void a(Rect paramRect);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.p
 * JD-Core Version:    0.6.2
 */