package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.CheckedTextView;

public class AppCompatCheckedTextView extends CheckedTextView
{
  private static final int[] Dj = { 16843016 };
  private g Hp;
  private k Hr = k.b(this);

  public AppCompatCheckedTextView(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 16843720);
  }

  public AppCompatCheckedTextView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(v.n(paramContext), paramAttributeSet, paramInt);
    this.Hr.a(paramAttributeSet, paramInt);
    this.Hr.ds();
    this.Hp = g.dp();
    paramContext = y.a(getContext(), paramAttributeSet, Dj, paramInt);
    setCheckMarkDrawable(paramContext.getDrawable(0));
    paramContext.MF.recycle();
  }

  protected void drawableStateChanged()
  {
    super.drawableStateChanged();
    if (this.Hr != null)
      this.Hr.ds();
  }

  public void setCheckMarkDrawable(int paramInt)
  {
    if (this.Hp != null)
    {
      setCheckMarkDrawable(this.Hp.a(getContext(), paramInt, false));
      return;
    }
    super.setCheckMarkDrawable(paramInt);
  }

  public void setTextAppearance(Context paramContext, int paramInt)
  {
    super.setTextAppearance(paramContext, paramInt);
    if (this.Hr != null)
      this.Hr.f(paramContext, paramInt);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.AppCompatCheckedTextView
 * JD-Core Version:    0.6.2
 */