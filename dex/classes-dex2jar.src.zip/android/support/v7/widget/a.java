package android.support.v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.support.v4.view.ah;
import android.support.v4.view.al;
import android.support.v4.view.n;
import android.support.v4.view.y;
import android.support.v7.a.a.g;
import android.support.v7.a.a.k;
import android.support.v7.view.menu.f;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;

abstract class a extends ViewGroup
{
  protected final a EI = new a();
  protected final Context EJ;
  protected ActionMenuView EK;
  protected ActionMenuPresenter EL;
  protected int EM;
  protected ah EN;
  private boolean EO;
  private boolean EP;

  a(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    paramAttributeSet = new TypedValue();
    if ((paramContext.getTheme().resolveAttribute(android.support.v7.a.a.a.actionBarPopupTheme, paramAttributeSet, true)) && (paramAttributeSet.resourceId != 0))
    {
      this.EJ = new ContextThemeWrapper(paramContext, paramAttributeSet.resourceId);
      return;
    }
    this.EJ = paramContext;
  }

  protected static int a(View paramView, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    int i = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    paramInt2 = (paramInt3 - j) / 2 + paramInt2;
    if (paramBoolean)
      paramView.layout(paramInt1 - i, paramInt2, paramInt1, j + paramInt2);
    while (true)
    {
      paramInt1 = i;
      if (paramBoolean)
        paramInt1 = -i;
      return paramInt1;
      paramView.layout(paramInt1, paramInt2, paramInt1 + i, j + paramInt2);
    }
  }

  protected static int c(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    if (paramBoolean)
      return paramInt1 - paramInt2;
    return paramInt1 + paramInt2;
  }

  protected static int e(View paramView, int paramInt1, int paramInt2)
  {
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1, -2147483648), paramInt2);
    return Math.max(0, paramInt1 - paramView.getMeasuredWidth() + 0);
  }

  public void Y(int paramInt)
  {
    this.EM = paramInt;
    requestLayout();
  }

  public ah b(int paramInt, long paramLong)
  {
    if (this.EN != null)
      this.EN.cancel();
    if (paramInt == 0)
    {
      if (getVisibility() != 0)
        y.b(this, 0.0F);
      localah = y.r(this).e(1.0F);
      localah.d(paramLong);
      localah.a(this.EI.a(localah, paramInt));
      return localah;
    }
    ah localah = y.r(this).e(0.0F);
    localah.d(paramLong);
    localah.a(this.EI.a(localah, paramInt));
    return localah;
  }

  protected void onConfigurationChanged(Configuration paramConfiguration)
  {
    if (Build.VERSION.SDK_INT >= 8)
      super.onConfigurationChanged(paramConfiguration);
    paramConfiguration = getContext().obtainStyledAttributes(null, a.k.xZ, android.support.v7.a.a.a.actionBarStyle, 0);
    Y(paramConfiguration.getLayoutDimension(a.k.yk, 0));
    paramConfiguration.recycle();
    if (this.EL != null)
    {
      paramConfiguration = this.EL;
      if (!paramConfiguration.FU)
        paramConfiguration.FT = paramConfiguration.mContext.getResources().getInteger(a.g.xA);
      if (paramConfiguration.vF != null)
        paramConfiguration.vF.y(true);
    }
  }

  public boolean onHoverEvent(MotionEvent paramMotionEvent)
  {
    int i = n.d(paramMotionEvent);
    if (i == 9)
      this.EP = false;
    if (!this.EP)
    {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if ((i == 9) && (!bool))
        this.EP = true;
    }
    if ((i == 10) || (i == 3))
      this.EP = false;
    return true;
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    int i = n.d(paramMotionEvent);
    if (i == 0)
      this.EO = false;
    if (!this.EO)
    {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if ((i == 0) && (!bool))
        this.EO = true;
    }
    if ((i == 1) || (i == 3))
      this.EO = false;
    return true;
  }

  public void setVisibility(int paramInt)
  {
    if (paramInt != getVisibility())
    {
      if (this.EN != null)
        this.EN.cancel();
      super.setVisibility(paramInt);
    }
  }

  public boolean showOverflowMenu()
  {
    if (this.EL != null)
      return this.EL.showOverflowMenu();
    return false;
  }

  protected final class a
    implements al
  {
    private boolean EQ = false;
    int ER;

    protected a()
    {
    }

    public final void L(View paramView)
    {
      a.a(a.this);
      this.EQ = false;
    }

    public final void M(View paramView)
    {
      if (this.EQ)
        return;
      a.this.EN = null;
      a.a(a.this, this.ER);
    }

    public final void N(View paramView)
    {
      this.EQ = true;
    }

    public final a a(ah paramah, int paramInt)
    {
      a.this.EN = paramah;
      this.ER = paramInt;
      return this;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.a
 * JD-Core Version:    0.6.2
 */