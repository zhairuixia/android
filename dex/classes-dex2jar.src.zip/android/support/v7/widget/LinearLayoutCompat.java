package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.v4.view.e;
import android.support.v7.a.a.k;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class LinearLayoutCompat extends ViewGroup
{
  boolean IR = true;
  private int IS = -1;
  private int IT = 0;
  private int IU;
  private int IV;
  private float IW;
  private boolean IX;
  private int[] IY;
  private int[] IZ;
  private Drawable Ja;
  int Jb;
  private int Jc;
  private int Jd;
  private int Je;
  private int ky = 8388659;

  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
  }

  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    paramContext = y.a(paramContext, paramAttributeSet, a.k.zm, paramInt);
    paramInt = paramContext.getInt(a.k.zu, -1);
    if ((paramInt >= 0) && (this.IU != paramInt))
    {
      this.IU = paramInt;
      requestLayout();
    }
    paramInt = paramContext.getInt(a.k.zt, -1);
    if (paramInt >= 0)
      setGravity(paramInt);
    boolean bool2 = paramContext.getBoolean(a.k.zq, true);
    if (!bool2)
      this.IR = bool2;
    paramInt = a.k.zv;
    this.IW = paramContext.MF.getFloat(paramInt, -1.0F);
    this.IS = paramContext.getInt(a.k.zr, -1);
    this.IX = paramContext.getBoolean(a.k.zy, false);
    paramAttributeSet = paramContext.getDrawable(a.k.zw);
    if (paramAttributeSet != this.Ja)
    {
      this.Ja = paramAttributeSet;
      if (paramAttributeSet == null)
        break label239;
      this.Jb = paramAttributeSet.getIntrinsicWidth();
      this.Jc = paramAttributeSet.getIntrinsicHeight();
      if (paramAttributeSet != null)
        break label252;
    }
    while (true)
    {
      setWillNotDraw(bool1);
      requestLayout();
      this.Jd = paramContext.getInt(a.k.zz, 0);
      this.Je = paramContext.getDimensionPixelSize(a.k.zx, 0);
      paramContext.MF.recycle();
      return;
      label239: this.Jb = 0;
      this.Jc = 0;
      break;
      label252: bool1 = false;
    }
  }

  private void a(Canvas paramCanvas, int paramInt)
  {
    this.Ja.setBounds(getPaddingLeft() + this.Je, paramInt, getWidth() - getPaddingRight() - this.Je, this.Jc + paramInt);
    this.Ja.draw(paramCanvas);
  }

  private boolean aj(int paramInt)
  {
    if (paramInt == 0)
      if ((this.Jd & 0x1) == 0);
    do
    {
      return true;
      return false;
      if (paramInt != getChildCount())
        break;
    }
    while ((this.Jd & 0x4) != 0);
    return false;
    if ((this.Jd & 0x2) != 0)
    {
      paramInt -= 1;
      while (true)
      {
        if (paramInt < 0)
          break label75;
        if (getChildAt(paramInt).getVisibility() != 8)
          break;
        paramInt -= 1;
      }
    }
    return false;
    label75: return false;
  }

  private void b(Canvas paramCanvas, int paramInt)
  {
    this.Ja.setBounds(paramInt, getPaddingTop() + this.Je, this.Jb + paramInt, getHeight() - getPaddingBottom() - this.Je);
    this.Ja.draw(paramCanvas);
  }

  private void c(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    measureChildWithMargins(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }

  private static void d(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramView.layout(paramInt1, paramInt2, paramInt1 + paramInt3, paramInt2 + paramInt4);
  }

  private void o(int paramInt1, int paramInt2)
  {
    int j = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    int i = 0;
    while (i < paramInt1)
    {
      View localView = getChildAt(i);
      if (localView.getVisibility() != 8)
      {
        LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
        if (localLayoutParams.width == -1)
        {
          int k = localLayoutParams.height;
          localLayoutParams.height = localView.getMeasuredHeight();
          measureChildWithMargins(localView, j, 0, paramInt2, 0);
          localLayoutParams.height = k;
        }
      }
      i += 1;
    }
  }

  private void p(int paramInt1, int paramInt2)
  {
    this.IV = 0;
    int i1 = 0;
    int m = 0;
    int k = 0;
    int i3 = 0;
    int n = 1;
    float f1 = 0.0F;
    int i10 = getChildCount();
    int i12 = View.MeasureSpec.getMode(paramInt1);
    int i11 = View.MeasureSpec.getMode(paramInt2);
    int i2 = 0;
    int j = 0;
    if ((this.IY == null) || (this.IZ == null))
    {
      this.IY = new int[4];
      this.IZ = new int[4];
    }
    Object localObject1 = this.IY;
    Object localObject2 = this.IZ;
    localObject1[3] = -1;
    localObject1[2] = -1;
    localObject1[1] = -1;
    localObject1[0] = -1;
    localObject2[3] = -1;
    localObject2[2] = -1;
    localObject2[1] = -1;
    localObject2[0] = -1;
    boolean bool1 = this.IR;
    boolean bool2 = this.IX;
    if (i12 == 1073741824);
    int i;
    int i4;
    Object localObject3;
    int i7;
    int i6;
    for (int i5 = 1; ; i5 = 0)
    {
      i = -2147483648;
      for (i4 = 0; ; i4 = i7)
      {
        if (i4 >= i10)
          break label894;
        localObject3 = getChildAt(i4);
        if (localObject3 != null)
          break;
        this.IV += 0;
        i7 = i4;
        i6 = m;
        i4 = k;
        m = i3;
        k = n;
        i7 += 1;
        n = k;
        i3 = m;
        k = i4;
        m = i6;
      }
    }
    LayoutParams localLayoutParams;
    label340: label361: int i8;
    label386: int i9;
    if (((View)localObject3).getVisibility() != 8)
    {
      if (aj(i4))
        this.IV += this.Jb;
      localLayoutParams = (LayoutParams)((View)localObject3).getLayoutParams();
      f1 += localLayoutParams.weight;
      if ((i12 == 1073741824) && (localLayoutParams.width == 0) && (localLayoutParams.weight > 0.0F))
        if (i5 != 0)
        {
          this.IV += localLayoutParams.leftMargin + localLayoutParams.rightMargin;
          if (!bool1)
            break label643;
          i6 = View.MeasureSpec.makeMeasureSpec(0, 0);
          ((View)localObject3).measure(i6, i6);
          i6 = 0;
          if ((i11 == 1073741824) || (localLayoutParams.height != -1))
            break label2320;
          i2 = 1;
          i6 = 1;
          i7 = localLayoutParams.topMargin + localLayoutParams.bottomMargin;
          i8 = ((View)localObject3).getMeasuredHeight() + i7;
          i9 = aa.combineMeasuredStates(m, android.support.v4.view.y.o((View)localObject3));
          if (bool1)
          {
            int i13 = ((View)localObject3).getBaseline();
            if (i13 != -1)
            {
              if (localLayoutParams.gravity >= 0)
                break label823;
              m = this.ky;
              label453: m = ((m & 0x70) >> 4 & 0xFFFFFFFE) >> 1;
              localObject1[m] = Math.max(localObject1[m], i13);
              localObject2[m] = Math.max(localObject2[m], i8 - i13);
            }
          }
          i1 = Math.max(i1, i8);
          if ((n == 0) || (localLayoutParams.height != -1))
            break label833;
          m = 1;
          label526: if (localLayoutParams.weight <= 0.0F)
            break label846;
          if (i6 == 0)
            break label839;
          label541: n = Math.max(i3, i7);
          i6 = m;
          m = n;
          i7 = i;
          i3 = i9;
          n = k;
          k = i6;
          i = j;
          j = i7;
        }
    }
    while (true)
    {
      i7 = i4 + 0;
      i4 = i;
      i = j;
      j = i4;
      i4 = n;
      i6 = i3;
      break;
      i6 = this.IV;
      this.IV = Math.max(i6, localLayoutParams.leftMargin + i6 + localLayoutParams.rightMargin);
      break label340;
      label643: j = 1;
      break label361;
      i7 = -2147483648;
      i6 = i7;
      if (localLayoutParams.width == 0)
      {
        i6 = i7;
        if (localLayoutParams.weight > 0.0F)
        {
          i6 = 0;
          localLayoutParams.width = -2;
        }
      }
      if (f1 == 0.0F)
      {
        i7 = this.IV;
        label701: c((View)localObject3, paramInt1, i7, paramInt2, 0);
        if (i6 != -2147483648)
          localLayoutParams.width = i6;
        i6 = ((View)localObject3).getMeasuredWidth();
        if (i5 == 0)
          break label786;
        this.IV += localLayoutParams.leftMargin + i6 + localLayoutParams.rightMargin + 0;
      }
      while (true)
        if (bool2)
        {
          i = Math.max(i6, i);
          break;
          i7 = 0;
          break label701;
          label786: i7 = this.IV;
          this.IV = Math.max(i7, i7 + i6 + localLayoutParams.leftMargin + localLayoutParams.rightMargin + 0);
          continue;
          label823: m = localLayoutParams.gravity;
          break label453;
          label833: m = 0;
          break label526;
          label839: i7 = i8;
          break label541;
          label846: if (i6 != 0);
          while (true)
          {
            n = Math.max(k, i7);
            k = m;
            i6 = j;
            m = i3;
            j = i;
            i = i6;
            i3 = i9;
            break;
            i7 = i8;
          }
          label894: if ((this.IV > 0) && (aj(i10)))
            this.IV += this.Jb;
          if ((localObject1[1] != -1) || (localObject1[0] != -1) || (localObject1[2] != -1) || (localObject1[3] != -1));
          for (i4 = Math.max(i1, Math.max(localObject1[3], Math.max(localObject1[0], Math.max(localObject1[1], localObject1[2]))) + Math.max(localObject2[3], Math.max(localObject2[0], Math.max(localObject2[1], localObject2[2])))); ; i4 = i1)
          {
            if ((bool2) && ((i12 == -2147483648) || (i12 == 0)))
            {
              this.IV = 0;
              i1 = 0;
              if (i1 < i10)
              {
                localObject3 = getChildAt(i1);
                if (localObject3 == null)
                  this.IV += 0;
                while (true)
                {
                  i1 += 1;
                  break;
                  if (((View)localObject3).getVisibility() == 8)
                  {
                    i1 += 0;
                  }
                  else
                  {
                    localObject3 = (LayoutParams)((View)localObject3).getLayoutParams();
                    if (i5 != 0)
                    {
                      i6 = this.IV;
                      i7 = ((LayoutParams)localObject3).leftMargin;
                      this.IV = (((LayoutParams)localObject3).rightMargin + (i7 + i) + 0 + i6);
                    }
                    else
                    {
                      i6 = this.IV;
                      i7 = ((LayoutParams)localObject3).leftMargin;
                      this.IV = Math.max(i6, ((LayoutParams)localObject3).rightMargin + (i6 + i + i7) + 0);
                    }
                  }
                }
              }
            }
            this.IV += getPaddingLeft() + getPaddingRight();
            i8 = android.support.v4.view.y.resolveSizeAndState(Math.max(this.IV, getSuggestedMinimumWidth()), paramInt1, 0);
            i1 = (0xFFFFFF & i8) - this.IV;
            if ((j != 0) || ((i1 != 0) && (f1 > 0.0F)))
            {
              if (this.IW > 0.0F)
                f1 = this.IW;
              localObject1[3] = -1;
              localObject1[2] = -1;
              localObject1[1] = -1;
              localObject1[0] = -1;
              localObject2[3] = -1;
              localObject2[2] = -1;
              localObject2[1] = -1;
              localObject2[0] = -1;
              this.IV = 0;
              i3 = 0;
              j = n;
              n = -1;
              i = m;
              m = n;
              n = i1;
              if (i3 < i10)
              {
                localObject3 = getChildAt(i3);
                if ((localObject3 == null) || (((View)localObject3).getVisibility() == 8))
                  break label2282;
                localLayoutParams = (LayoutParams)((View)localObject3).getLayoutParams();
                float f2 = localLayoutParams.weight;
                if (f2 <= 0.0F)
                  break label2267;
                i4 = (int)(n * f2 / f1);
                i7 = getChildMeasureSpec(paramInt2, getPaddingTop() + getPaddingBottom() + localLayoutParams.topMargin + localLayoutParams.bottomMargin, localLayoutParams.height);
                if ((localLayoutParams.width != 0) || (i12 != 1073741824))
                {
                  i6 = i4 + ((View)localObject3).getMeasuredWidth();
                  i1 = i6;
                  if (i6 < 0)
                    i1 = 0;
                  label1468: ((View)localObject3).measure(View.MeasureSpec.makeMeasureSpec(i1, 1073741824), i7);
                  i = aa.combineMeasuredStates(i, android.support.v4.view.y.o((View)localObject3) & 0xFF000000);
                  f1 -= f2;
                  i1 = n - i4;
                  n = i;
                  i = i1;
                  label1518: if (i5 == 0)
                    break label1791;
                  this.IV += ((View)localObject3).getMeasuredWidth() + localLayoutParams.leftMargin + localLayoutParams.rightMargin + 0;
                  label1551: if ((i11 == 1073741824) || (localLayoutParams.height != -1))
                    break label1831;
                  i1 = 1;
                  label1570: i7 = localLayoutParams.topMargin + localLayoutParams.bottomMargin;
                  i6 = ((View)localObject3).getMeasuredHeight() + i7;
                  i4 = Math.max(m, i6);
                  if (i1 == 0)
                    break label1837;
                  m = i7;
                  label1611: m = Math.max(k, m);
                  if ((j == 0) || (localLayoutParams.height != -1))
                    break label1844;
                  j = 1;
                  label1637: if (bool1)
                  {
                    i1 = ((View)localObject3).getBaseline();
                    if (i1 != -1)
                    {
                      if (localLayoutParams.gravity >= 0)
                        break label1850;
                      k = this.ky;
                      k = ((k & 0x70) >> 4 & 0xFFFFFFFE) >> 1;
                      localObject1[k] = Math.max(localObject1[k], i1);
                      localObject2[k] = Math.max(localObject2[k], i6 - i1);
                    }
                  }
                  label1669: i1 = n;
                  n = j;
                  k = i4;
                  j = i1;
                }
              }
            }
            while (true)
            {
              i4 = i3 + 1;
              i1 = n;
              i3 = k;
              n = i;
              i = j;
              j = i1;
              k = m;
              m = i3;
              i3 = i4;
              break;
              if (i4 > 0)
              {
                i1 = i4;
                break label1468;
              }
              i1 = 0;
              break label1468;
              label1791: i1 = this.IV;
              this.IV = Math.max(i1, ((View)localObject3).getMeasuredWidth() + i1 + localLayoutParams.leftMargin + localLayoutParams.rightMargin + 0);
              break label1551;
              label1831: i1 = 0;
              break label1570;
              label1837: m = i6;
              break label1611;
              label1844: j = 0;
              break label1637;
              label1850: k = localLayoutParams.gravity;
              break label1669;
              this.IV += getPaddingLeft() + getPaddingRight();
              if ((localObject1[1] == -1) && (localObject1[0] == -1) && (localObject1[2] == -1))
              {
                n = m;
                if (localObject1[3] == -1);
              }
              else
              {
                n = Math.max(m, Math.max(localObject1[3], Math.max(localObject1[0], Math.max(localObject1[1], localObject1[2]))) + Math.max(localObject2[3], Math.max(localObject2[0], Math.max(localObject2[1], localObject2[2]))));
              }
              m = i;
              i1 = j;
              j = n;
              i = k;
              while (true)
              {
                if ((i1 == 0) && (i11 != 1073741824));
                while (true)
                {
                  setMeasuredDimension(0xFF000000 & m | i8, android.support.v4.view.y.resolveSizeAndState(Math.max(i + (getPaddingTop() + getPaddingBottom()), getSuggestedMinimumHeight()), paramInt2, m << 16));
                  if (i2 != 0)
                  {
                    i = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
                    paramInt2 = 0;
                    while (paramInt2 < i10)
                    {
                      localObject1 = getChildAt(paramInt2);
                      if (((View)localObject1).getVisibility() != 8)
                      {
                        localObject2 = (LayoutParams)((View)localObject1).getLayoutParams();
                        if (((LayoutParams)localObject2).height == -1)
                        {
                          j = ((LayoutParams)localObject2).width;
                          ((LayoutParams)localObject2).width = ((View)localObject1).getMeasuredWidth();
                          measureChildWithMargins((View)localObject1, paramInt1, 0, i, 0);
                          ((LayoutParams)localObject2).width = j;
                        }
                      }
                      paramInt2 += 1;
                      continue;
                      k = Math.max(k, i3);
                      if ((!bool2) || (i12 == 1073741824))
                        break label2252;
                      j = 0;
                      while (j < i10)
                      {
                        localObject1 = getChildAt(j);
                        if ((localObject1 != null) && (((View)localObject1).getVisibility() != 8) && (((LayoutParams)((View)localObject1).getLayoutParams()).weight > 0.0F))
                          ((View)localObject1).measure(View.MeasureSpec.makeMeasureSpec(i, 1073741824), View.MeasureSpec.makeMeasureSpec(((View)localObject1).getMeasuredHeight(), 1073741824));
                        j += 1;
                      }
                    }
                  }
                  return;
                  i = j;
                }
                label2252: i = k;
                j = i4;
                i1 = n;
              }
              label2267: i1 = i;
              i = n;
              n = i1;
              break label1518;
              label2282: i4 = j;
              j = i;
              i1 = m;
              i = n;
              n = i4;
              m = k;
              k = i1;
            }
          }
          label2320: break label386;
        }
      break label361;
      i7 = j;
      i6 = k;
      i8 = m;
      j = i;
      i = i7;
      k = n;
      m = i3;
      n = i6;
      i3 = i8;
    }
  }

  public LayoutParams b(AttributeSet paramAttributeSet)
  {
    return new LayoutParams(getContext(), paramAttributeSet);
  }

  protected LayoutParams b(ViewGroup.LayoutParams paramLayoutParams)
  {
    return new LayoutParams(paramLayoutParams);
  }

  protected LayoutParams cY()
  {
    if (this.IU == 0)
      return new LayoutParams(-2, -2);
    if (this.IU == 1)
      return new LayoutParams(-1, -2);
    return null;
  }

  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return paramLayoutParams instanceof LayoutParams;
  }

  public int getBaseline()
  {
    int i = -1;
    if (this.IS < 0)
      i = super.getBaseline();
    View localView;
    int j;
    do
    {
      return i;
      if (getChildCount() <= this.IS)
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
      localView = getChildAt(this.IS);
      j = localView.getBaseline();
      if (j != -1)
        break;
    }
    while (this.IS == 0);
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
    i = this.IT;
    if (this.IU == 1)
    {
      int k = this.ky & 0x70;
      if (k != 48)
        switch (k)
        {
        default:
        case 80:
        case 16:
        }
    }
    while (true)
    {
      return ((LayoutParams)localView.getLayoutParams()).topMargin + i + j;
      i = getBottom() - getTop() - getPaddingBottom() - this.IV;
      continue;
      i += (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.IV) / 2;
    }
  }

  protected void onDraw(Canvas paramCanvas)
  {
    if (this.Ja == null);
    int i;
    LayoutParams localLayoutParams;
    int k;
    boolean bool;
    label259: 
    do
    {
      int j;
      do
      {
        return;
        if (this.IU != 1)
          break;
        j = getChildCount();
        i = 0;
        while (i < j)
        {
          localView = getChildAt(i);
          if ((localView != null) && (localView.getVisibility() != 8) && (aj(i)))
          {
            localLayoutParams = (LayoutParams)localView.getLayoutParams();
            a(paramCanvas, localView.getTop() - localLayoutParams.topMargin - this.Jc);
          }
          i += 1;
        }
      }
      while (!aj(j));
      localView = getChildAt(j - 1);
      if (localView == null);
      for (i = getHeight() - getPaddingBottom() - this.Jc; ; i = localLayoutParams.bottomMargin + i)
      {
        a(paramCanvas, i);
        return;
        localLayoutParams = (LayoutParams)localView.getLayoutParams();
        i = localView.getBottom();
      }
      k = getChildCount();
      bool = aa.aq(this);
      i = 0;
      if (i < k)
      {
        localView = getChildAt(i);
        if ((localView != null) && (localView.getVisibility() != 8) && (aj(i)))
        {
          localLayoutParams = (LayoutParams)localView.getLayoutParams();
          if (!bool)
            break label259;
          j = localView.getRight();
        }
        for (j = localLayoutParams.rightMargin + j; ; j = localView.getLeft() - localLayoutParams.leftMargin - this.Jb)
        {
          b(paramCanvas, j);
          i += 1;
          break;
        }
      }
    }
    while (!aj(k));
    View localView = getChildAt(k - 1);
    if (localView == null)
      if (bool)
        i = getPaddingLeft();
    while (true)
    {
      b(paramCanvas, i);
      return;
      i = getWidth() - getPaddingRight() - this.Jb;
      continue;
      localLayoutParams = (LayoutParams)localView.getLayoutParams();
      if (bool)
      {
        i = localView.getLeft() - localLayoutParams.leftMargin - this.Jb;
      }
      else
      {
        i = localView.getRight();
        i = localLayoutParams.rightMargin + i;
      }
    }
  }

  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
  {
    if (Build.VERSION.SDK_INT >= 14)
    {
      super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
      paramAccessibilityEvent.setClassName(LinearLayoutCompat.class.getName());
    }
  }

  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo)
  {
    if (Build.VERSION.SDK_INT >= 14)
    {
      super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
      paramAccessibilityNodeInfo.setClassName(LinearLayoutCompat.class.getName());
    }
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i;
    int j;
    int k;
    int m;
    int n;
    int i1;
    label93: Object localObject1;
    if (this.IU == 1)
    {
      i = getPaddingLeft();
      j = paramInt3 - paramInt1;
      k = getPaddingRight();
      m = getPaddingRight();
      n = getChildCount();
      paramInt1 = this.ky;
      i1 = this.ky;
      switch (paramInt1 & 0x70)
      {
      default:
        paramInt1 = getPaddingTop();
        paramInt3 = 0;
        paramInt2 = paramInt1;
        paramInt1 = paramInt3;
        if (paramInt1 < n)
        {
          localObject1 = getChildAt(paramInt1);
          if (localObject1 == null)
            paramInt2 += 0;
        }
        break;
      case 80:
      case 16:
      }
    }
    while (true)
    {
      paramInt1 += 1;
      break label93;
      paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - this.IV;
      break;
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - this.IV) / 2;
      break;
      if (((View)localObject1).getVisibility() != 8)
      {
        int i2 = ((View)localObject1).getMeasuredWidth();
        int i3 = ((View)localObject1).getMeasuredHeight();
        Object localObject2 = (LayoutParams)((View)localObject1).getLayoutParams();
        paramInt4 = ((LayoutParams)localObject2).gravity;
        paramInt3 = paramInt4;
        if (paramInt4 < 0)
          paramInt3 = 0x800007 & i1;
        switch (e.getAbsoluteGravity(paramInt3, android.support.v4.view.y.k(this)) & 0x7)
        {
        default:
          paramInt3 = ((LayoutParams)localObject2).leftMargin + i;
        case 1:
        case 5:
        }
        while (true)
        {
          paramInt4 = paramInt2;
          if (aj(paramInt1))
            paramInt4 = paramInt2 + this.Jc;
          paramInt2 = paramInt4 + ((LayoutParams)localObject2).topMargin;
          d((View)localObject1, paramInt3, paramInt2 + 0, i2, i3);
          paramInt2 += ((LayoutParams)localObject2).bottomMargin + i3 + 0;
          paramInt1 += 0;
          break;
          paramInt3 = (j - i - m - i2) / 2 + i + ((LayoutParams)localObject2).leftMargin - ((LayoutParams)localObject2).rightMargin;
          continue;
          paramInt3 = j - k - i2 - ((LayoutParams)localObject2).rightMargin;
        }
        paramBoolean = aa.aq(this);
        k = getPaddingTop();
        n = paramInt4 - paramInt2;
        i1 = getPaddingBottom();
        i2 = getPaddingBottom();
        i3 = getChildCount();
        paramInt2 = this.ky;
        int i4 = this.ky;
        boolean bool = this.IR;
        localObject1 = this.IY;
        localObject2 = this.IZ;
        switch (e.getAbsoluteGravity(paramInt2 & 0x800007, android.support.v4.view.y.k(this)))
        {
        default:
          paramInt1 = getPaddingLeft();
          if (paramBoolean)
            i = i3 - 1;
          break;
        case 5:
        case 1:
        }
        for (paramInt4 = -1; ; paramInt4 = 1)
        {
          paramInt2 = 0;
          paramInt3 = paramInt1;
          label507: int i7;
          View localView;
          if (paramInt2 < i3)
          {
            i7 = i + paramInt4 * paramInt2;
            localView = getChildAt(i7);
            if (localView == null)
            {
              paramInt3 += 0;
              paramInt1 = paramInt2;
            }
          }
          while (true)
          {
            paramInt2 = paramInt1 + 1;
            break label507;
            paramInt1 = getPaddingLeft() + paramInt3 - paramInt1 - this.IV;
            break;
            paramInt1 = getPaddingLeft() + (paramInt3 - paramInt1 - this.IV) / 2;
            break;
            if (localView.getVisibility() != 8)
            {
              int i5 = localView.getMeasuredWidth();
              int i6 = localView.getMeasuredHeight();
              paramInt1 = -1;
              LayoutParams localLayoutParams = (LayoutParams)localView.getLayoutParams();
              j = paramInt1;
              if (bool)
              {
                j = paramInt1;
                if (localLayoutParams.height != -1)
                  j = localView.getBaseline();
              }
              m = localLayoutParams.gravity;
              paramInt1 = m;
              if (m < 0)
                paramInt1 = i4 & 0x70;
              switch (paramInt1 & 0x70)
              {
              default:
                paramInt1 = k;
              case 48:
              case 16:
              case 80:
              }
              label715: label895: 
              while (true)
              {
                if (aj(i7))
                  paramInt3 = this.Jb + paramInt3;
                while (true)
                {
                  paramInt3 += localLayoutParams.leftMargin;
                  d(localView, paramInt3 + 0, paramInt1, i5, i6);
                  paramInt3 += localLayoutParams.rightMargin + i5 + 0;
                  paramInt1 = paramInt2 + 0;
                  break;
                  m = localLayoutParams.topMargin + k;
                  paramInt1 = m;
                  if (j == -1)
                    break label895;
                  paramInt1 = localObject1[1] - j + m;
                  break label715;
                  paramInt1 = (n - k - i2 - i6) / 2 + k + localLayoutParams.topMargin - localLayoutParams.bottomMargin;
                  break label715;
                  m = n - i1 - i6 - localLayoutParams.bottomMargin;
                  paramInt1 = m;
                  if (j == -1)
                    break label895;
                  paramInt1 = localView.getMeasuredHeight();
                  paramInt1 = m - (localObject2[2] - (paramInt1 - j));
                  break label715;
                  return;
                }
              }
            }
            paramInt1 = paramInt2;
          }
          i = 0;
        }
      }
    }
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int k;
    int i;
    int j;
    int i3;
    int m;
    float f1;
    int i9;
    int i10;
    int i11;
    int i2;
    int i1;
    boolean bool;
    int n;
    int i4;
    Object localObject;
    int i8;
    int i7;
    int i6;
    int i5;
    LayoutParams localLayoutParams;
    if (this.IU == 1)
    {
      this.IV = 0;
      k = 0;
      i = 0;
      j = 0;
      i3 = 0;
      m = 1;
      f1 = 0.0F;
      i9 = getChildCount();
      i10 = View.MeasureSpec.getMode(paramInt1);
      i11 = View.MeasureSpec.getMode(paramInt2);
      i2 = 0;
      i1 = 0;
      int i12 = this.IS;
      bool = this.IX;
      n = -2147483648;
      i4 = 0;
      while (true)
        if (i4 < i9)
        {
          localObject = getChildAt(i4);
          if (localObject == null)
          {
            this.IV += 0;
            i8 = i4;
            i7 = k;
            i6 = i;
            i5 = j;
            i4 = i3;
            k = m;
            j = i1;
            i = n;
            i8 += 1;
            n = i;
            i1 = j;
            m = k;
            i3 = i4;
            j = i5;
            i = i6;
            k = i7;
            i4 = i8;
          }
          else
          {
            if (((View)localObject).getVisibility() == 8)
              break label1656;
            if (aj(i4))
              this.IV += this.Jc;
            localLayoutParams = (LayoutParams)((View)localObject).getLayoutParams();
            f1 += localLayoutParams.weight;
            if ((i11 == 1073741824) && (localLayoutParams.height == 0) && (localLayoutParams.weight > 0.0F))
            {
              i1 = this.IV;
              this.IV = Math.max(i1, localLayoutParams.topMargin + i1 + localLayoutParams.bottomMargin);
              i1 = 1;
              label283: if ((i12 >= 0) && (i12 == i4 + 1))
                this.IT = this.IV;
              if ((i4 < i12) && (localLayoutParams.weight > 0.0F))
                throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
            }
            else
            {
              i6 = -2147483648;
              i5 = i6;
              if (localLayoutParams.height == 0)
              {
                i5 = i6;
                if (localLayoutParams.weight > 0.0F)
                {
                  i5 = 0;
                  localLayoutParams.height = -2;
                }
              }
              if (f1 == 0.0F);
              for (i6 = this.IV; ; i6 = 0)
              {
                c((View)localObject, paramInt1, 0, paramInt2, i6);
                if (i5 != -2147483648)
                  localLayoutParams.height = i5;
                i5 = ((View)localObject).getMeasuredHeight();
                i6 = this.IV;
                this.IV = Math.max(i6, i6 + i5 + localLayoutParams.topMargin + localLayoutParams.bottomMargin + 0);
                if (!bool)
                  break label1653;
                n = Math.max(i5, n);
                break;
              }
            }
            i5 = 0;
            if ((i10 == 1073741824) || (localLayoutParams.width != -1))
              break label1650;
            i2 = 1;
            i5 = 1;
            label499: i6 = localLayoutParams.leftMargin + localLayoutParams.rightMargin;
            i7 = ((View)localObject).getMeasuredWidth() + i6;
            k = Math.max(k, i7);
            i8 = aa.combineMeasuredStates(i, android.support.v4.view.y.o((View)localObject));
            if ((m != 0) && (localLayoutParams.width == -1))
            {
              i = 1;
              label560: if (localLayoutParams.weight <= 0.0F)
                break label678;
              if (i5 == 0)
                break label671;
              label575: i3 = Math.max(i3, i6);
              m = j;
              j = i1;
              i1 = k;
              k = i3;
              i5 = n;
              i3 = i8;
              n = m;
              m = k;
              k = i;
              i = j;
              j = i5;
            }
          }
        }
    }
    while (true)
    {
      i8 = i4 + 0;
      i4 = i;
      i = j;
      j = i4;
      i4 = m;
      i5 = n;
      i6 = i3;
      i7 = i1;
      break;
      i = 0;
      break label560;
      label671: i6 = i7;
      break label575;
      label678: if (i5 != 0);
      while (true)
      {
        i5 = Math.max(j, i6);
        m = i;
        i = i1;
        j = n;
        i1 = k;
        k = m;
        m = i3;
        n = i5;
        i3 = i8;
        break;
        i6 = i7;
      }
      if ((this.IV > 0) && (aj(i9)))
        this.IV += this.Jc;
      if ((bool) && ((i11 == -2147483648) || (i11 == 0)))
      {
        this.IV = 0;
        i4 = 0;
        if (i4 < i9)
        {
          localObject = getChildAt(i4);
          if (localObject == null)
            this.IV += 0;
          while (true)
          {
            i4 += 1;
            break;
            if (((View)localObject).getVisibility() == 8)
            {
              i4 += 0;
            }
            else
            {
              localObject = (LayoutParams)((View)localObject).getLayoutParams();
              i5 = this.IV;
              i6 = ((LayoutParams)localObject).topMargin;
              this.IV = Math.max(i5, ((LayoutParams)localObject).bottomMargin + (i5 + n + i6) + 0);
            }
          }
        }
      }
      this.IV += getPaddingTop() + getPaddingBottom();
      i6 = android.support.v4.view.y.resolveSizeAndState(Math.max(this.IV, getSuggestedMinimumHeight()), paramInt2, 0);
      i4 = (0xFFFFFF & i6) - this.IV;
      if ((i1 != 0) || ((i4 != 0) && (f1 > 0.0F)))
      {
        if (this.IW > 0.0F)
          f1 = this.IW;
        this.IV = 0;
        i3 = 0;
        n = m;
        m = k;
        k = j;
        j = n;
        n = i4;
        if (i3 < i9)
        {
          localObject = getChildAt(i3);
          if (((View)localObject).getVisibility() == 8)
            break label1623;
          localLayoutParams = (LayoutParams)((View)localObject).getLayoutParams();
          float f2 = localLayoutParams.weight;
          if (f2 <= 0.0F)
            break label1608;
          i4 = (int)(n * f2 / f1);
          i7 = getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + localLayoutParams.leftMargin + localLayoutParams.rightMargin, localLayoutParams.width);
          if ((localLayoutParams.height != 0) || (i11 != 1073741824))
          {
            i5 = i4 + ((View)localObject).getMeasuredHeight();
            i1 = i5;
            if (i5 < 0)
              i1 = 0;
            label1133: ((View)localObject).measure(i7, View.MeasureSpec.makeMeasureSpec(i1, 1073741824));
            i = aa.combineMeasuredStates(i, android.support.v4.view.y.o((View)localObject) & 0xFFFFFF00);
            i1 = n - i4;
            n = i;
            f1 -= f2;
            i = i1;
            label1183: i4 = localLayoutParams.leftMargin + localLayoutParams.rightMargin;
            i5 = ((View)localObject).getMeasuredWidth() + i4;
            i1 = Math.max(m, i5);
            if ((i10 == 1073741824) || (localLayoutParams.width != -1))
              break label1377;
            m = 1;
            label1234: if (m == 0)
              break label1383;
            m = i4;
            label1243: k = Math.max(k, m);
            if ((j == 0) || (localLayoutParams.width != -1))
              break label1390;
            j = 1;
            label1269: m = this.IV;
            i4 = ((View)localObject).getMeasuredHeight();
            i5 = localLayoutParams.topMargin;
            this.IV = Math.max(m, localLayoutParams.bottomMargin + (i4 + m + i5) + 0);
            m = j;
            j = i1;
          }
        }
      }
      while (true)
      {
        i4 = i3 + 1;
        i3 = n;
        i1 = j;
        n = i;
        i = i3;
        j = m;
        m = i1;
        i3 = i4;
        break;
        if (i4 > 0)
        {
          i1 = i4;
          break label1133;
        }
        i1 = 0;
        break label1133;
        label1377: m = 0;
        break label1234;
        label1383: m = i5;
        break label1243;
        label1390: j = 0;
        break label1269;
        this.IV += getPaddingTop() + getPaddingBottom();
        n = k;
        k = m;
        m = j;
        for (j = n; ; j = i1)
        {
          if ((m == 0) && (i10 != 1073741824));
          while (true)
          {
            setMeasuredDimension(android.support.v4.view.y.resolveSizeAndState(Math.max(j + (getPaddingLeft() + getPaddingRight()), getSuggestedMinimumWidth()), paramInt1, i), i6);
            if (i2 != 0)
              o(i9, paramInt2);
            return;
            i1 = Math.max(j, i3);
            if ((!bool) || (i11 == 1073741824))
              break;
            j = 0;
            while (j < i9)
            {
              localObject = getChildAt(j);
              if ((localObject != null) && (((View)localObject).getVisibility() != 8) && (((LayoutParams)((View)localObject).getLayoutParams()).weight > 0.0F))
                ((View)localObject).measure(View.MeasureSpec.makeMeasureSpec(((View)localObject).getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(n, 1073741824));
              j += 1;
            }
            p(paramInt1, paramInt2);
            return;
            j = k;
          }
        }
        label1608: i1 = i;
        i = n;
        n = i1;
        break label1183;
        label1623: i1 = j;
        j = m;
        m = i;
        i = n;
        n = m;
        m = i1;
      }
      label1650: break label499;
      label1653: break label283;
      label1656: i5 = n;
      i6 = i1;
      n = j;
      i1 = k;
      i7 = i;
      j = i5;
      i = i6;
      k = m;
      m = i3;
      i3 = i7;
    }
  }

  public final void setGravity(int paramInt)
  {
    if (this.ky != paramInt)
    {
      if ((0x800007 & paramInt) != 0)
        break label46;
      paramInt = 0x800003 | paramInt;
    }
    label46: 
    while (true)
    {
      int i = paramInt;
      if ((paramInt & 0x70) == 0)
        i = paramInt | 0x30;
      this.ky = i;
      requestLayout();
      return;
    }
  }

  public boolean shouldDelayChildPressedState()
  {
    return false;
  }

  public static class LayoutParams extends ViewGroup.MarginLayoutParams
  {
    public int gravity = -1;
    public float weight;

    public LayoutParams(int paramInt1, int paramInt2)
    {
      super(paramInt2);
      this.weight = 0.0F;
    }

    public LayoutParams(Context paramContext, AttributeSet paramAttributeSet)
    {
      super(paramAttributeSet);
      paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, a.k.zn);
      this.weight = paramContext.getFloat(a.k.zp, 0.0F);
      this.gravity = paramContext.getInt(a.k.zo, -1);
      paramContext.recycle();
    }

    public LayoutParams(ViewGroup.LayoutParams paramLayoutParams)
    {
      super();
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.LinearLayoutCompat
 * JD-Core Version:    0.6.2
 */