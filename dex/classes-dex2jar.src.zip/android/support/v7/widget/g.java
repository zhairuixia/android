package android.support.v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.XmlResourceParser;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.LayerDrawable;
import android.os.Build.VERSION;
import android.support.v4.d.e;
import android.support.v7.a.a.a;
import android.support.v7.a.a.e;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.TypedValue;
import android.util.Xml;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public final class g
{
  private static final PorterDuff.Mode HC = PorterDuff.Mode.SRC_IN;
  private static g HD;
  private static final b HE = new b();
  private static final int[] HF = { a.e.wL, a.e.wJ, a.e.vY };
  private static final int[] HG = { a.e.wi, a.e.wl, a.e.ws, a.e.wk, a.e.wj, a.e.wr, a.e.wm, a.e.wn, a.e.wq, a.e.wp, a.e.wo, a.e.wt };
  private static final int[] HH = { a.e.wI, a.e.wK, a.e.wg, a.e.wH };
  private static final int[] HI = { a.e.ww, a.e.we, a.e.wv };
  private static final int[] HJ = { a.e.wh, a.e.wG, a.e.wM, a.e.wC, a.e.wD, a.e.wx, a.e.wF, a.e.wE, a.e.wc, a.e.vZ };
  private static final int[] HK = { a.e.wa, a.e.wd };
  private WeakHashMap<Context, SparseArray<ColorStateList>> HL;
  private android.support.v4.d.a<String, c> HM;
  private SparseArray<String> HN;
  private final Object HO = new Object();
  private final WeakHashMap<Context, e<WeakReference<Drawable.ConstantState>>> HP = new WeakHashMap(0);
  private TypedValue HQ;

  private static long a(TypedValue paramTypedValue)
  {
    return paramTypedValue.assetCookie << 32 | paramTypedValue.data;
  }

  private static PorterDuffColorFilter a(int paramInt, PorterDuff.Mode paramMode)
  {
    PorterDuffColorFilter localPorterDuffColorFilter2 = (PorterDuffColorFilter)HE.get(Integer.valueOf(b.b(paramInt, paramMode)));
    PorterDuffColorFilter localPorterDuffColorFilter1 = localPorterDuffColorFilter2;
    if (localPorterDuffColorFilter2 == null)
    {
      localPorterDuffColorFilter1 = new PorterDuffColorFilter(paramInt, paramMode);
      HE.put(Integer.valueOf(b.b(paramInt, paramMode)), localPorterDuffColorFilter1);
    }
    return localPorterDuffColorFilter1;
  }

  private Drawable a(Context paramContext, long paramLong)
  {
    while (true)
    {
      e locale;
      synchronized (this.HO)
      {
        locale = (e)this.HP.get(paramContext);
        if (locale == null)
          return null;
        i = android.support.v4.d.b.a(locale.jf, locale.jh, paramLong);
        if (i < 0)
          break label188;
        if (locale.jg[i] == e.jd)
        {
          break label188;
          localObject1 = (WeakReference)localObject1;
          if (localObject1 == null)
            break label183;
          localObject1 = (Drawable.ConstantState)((WeakReference)localObject1).get();
          if (localObject1 == null)
            break label131;
          paramContext = ((Drawable.ConstantState)localObject1).newDrawable(paramContext.getResources());
          return paramContext;
        }
      }
      Object localObject1 = locale.jg[i];
      continue;
      label131: int i = android.support.v4.d.b.a(locale.jf, locale.jh, paramLong);
      if ((i >= 0) && (locale.jg[i] != e.jd))
      {
        locale.jg[i] = e.jd;
        locale.je = true;
      }
      label183: return null;
      label188: localObject1 = null;
    }
  }

  private static void a(Drawable paramDrawable, int paramInt, PorterDuff.Mode paramMode)
  {
    Drawable localDrawable = paramDrawable;
    if (o.n(paramDrawable))
      localDrawable = paramDrawable.mutate();
    paramDrawable = paramMode;
    if (paramMode == null)
      paramDrawable = HC;
    localDrawable.setColorFilter(a(paramInt, paramDrawable));
  }

  public static void a(Drawable paramDrawable, w paramw, int[] paramArrayOfInt)
  {
    Object localObject2 = null;
    if ((o.n(paramDrawable)) && (paramDrawable.mutate() != paramDrawable));
    label57: label73: label97: label104: label124: 
    while (true)
    {
      return;
      ColorStateList localColorStateList;
      Object localObject1;
      if ((paramw.MD) || (paramw.MC))
        if (paramw.MD)
        {
          localColorStateList = paramw.MB;
          if (!paramw.MC)
            break label97;
          paramw = paramw.bi;
          localObject1 = localObject2;
          if (localColorStateList != null)
          {
            if (paramw != null)
              break label104;
            localObject1 = localObject2;
          }
          paramDrawable.setColorFilter((ColorFilter)localObject1);
        }
      while (true)
      {
        if (Build.VERSION.SDK_INT > 23)
          break label124;
        paramDrawable.invalidateSelf();
        return;
        localColorStateList = null;
        break;
        paramw = HC;
        break label57;
        localObject1 = a(localColorStateList.getColorForState(paramArrayOfInt, 0), paramw);
        break label73;
        paramDrawable.clearColorFilter();
      }
    }
  }

  private void a(String paramString, c paramc)
  {
    if (this.HM == null)
      this.HM = new android.support.v4.d.a();
    this.HM.put(paramString, paramc);
  }

  static boolean a(Context paramContext, int paramInt, Drawable paramDrawable)
  {
    PorterDuff.Mode localMode = HC;
    int i;
    int j;
    if (a(HF, paramInt))
    {
      i = a.a.colorControlNormal;
      j = 1;
      paramInt = -1;
    }
    while (true)
      if (j != 0)
      {
        Drawable localDrawable = paramDrawable;
        if (o.n(paramDrawable))
          localDrawable = paramDrawable.mutate();
        localDrawable.setColorFilter(a(u.g(paramContext, i), localMode));
        if (paramInt != -1)
          localDrawable.setAlpha(paramInt);
        return true;
        if (a(HH, paramInt))
        {
          i = a.a.colorControlActivated;
          j = 1;
          paramInt = -1;
        }
        else if (a(HI, paramInt))
        {
          localMode = PorterDuff.Mode.MULTIPLY;
          j = 1;
          i = 16842801;
          paramInt = -1;
        }
        else if (paramInt == a.e.wu)
        {
          i = 16842800;
          paramInt = Math.round(40.799999F);
          j = 1;
        }
      }
      else
      {
        return false;
        paramInt = -1;
        i = 0;
        j = 0;
      }
  }

  private boolean a(Context paramContext, long paramLong, Drawable paramDrawable)
  {
    Drawable.ConstantState localConstantState = paramDrawable.getConstantState();
    if (localConstantState != null)
      synchronized (this.HO)
      {
        e locale = (e)this.HP.get(paramContext);
        paramDrawable = locale;
        if (locale == null)
        {
          paramDrawable = new e();
          this.HP.put(paramContext, paramDrawable);
        }
        paramDrawable.put(paramLong, new WeakReference(localConstantState));
        return true;
      }
    return false;
  }

  private static boolean a(int[] paramArrayOfInt, int paramInt)
  {
    boolean bool2 = false;
    int j = paramArrayOfInt.length;
    int i = 0;
    while (true)
    {
      boolean bool1 = bool2;
      if (i < j)
      {
        if (paramArrayOfInt[i] == paramInt)
          bool1 = true;
      }
      else
        return bool1;
      i += 1;
    }
  }

  private Drawable c(Context paramContext, int paramInt)
  {
    if ((this.HM != null) && (!this.HM.isEmpty()))
    {
      if (this.HN != null)
      {
        localObject1 = (String)this.HN.get(paramInt);
        if (("appcompat_skip_skip".equals(localObject1)) || ((localObject1 != null) && (this.HM.get(localObject1) == null)))
        {
          localObject1 = null;
          return localObject1;
        }
      }
      else
      {
        this.HN = new SparseArray();
      }
      if (this.HQ == null)
        this.HQ = new TypedValue();
      TypedValue localTypedValue = this.HQ;
      Object localObject1 = paramContext.getResources();
      ((Resources)localObject1).getValue(paramInt, localTypedValue, true);
      long l = a(localTypedValue);
      Drawable localDrawable = a(paramContext, l);
      if (localDrawable != null)
        return localDrawable;
      Object localObject2 = localDrawable;
      XmlResourceParser localXmlResourceParser;
      AttributeSet localAttributeSet;
      if (localTypedValue.string != null)
      {
        localObject2 = localDrawable;
        if (localTypedValue.string.toString().endsWith(".xml"))
        {
          localObject2 = localDrawable;
          try
          {
            localXmlResourceParser = ((Resources)localObject1).getXml(paramInt);
            localObject2 = localDrawable;
            localAttributeSet = Xml.asAttributeSet(localXmlResourceParser);
            int i;
            do
            {
              localObject2 = localDrawable;
              i = localXmlResourceParser.next();
            }
            while ((i != 2) && (i != 1));
            if (i != 2)
            {
              localObject2 = localDrawable;
              throw new XmlPullParserException("No start tag found");
            }
          }
          catch (Exception paramContext)
          {
          }
        }
      }
      for (paramContext = (Context)localObject2; ; paramContext = (Context)localObject1)
      {
        localObject1 = paramContext;
        if (paramContext != null)
          break;
        this.HN.append(paramInt, "appcompat_skip_skip");
        return paramContext;
        localObject2 = localDrawable;
        localObject1 = localXmlResourceParser.getName();
        localObject2 = localDrawable;
        this.HN.append(paramInt, localObject1);
        localObject2 = localDrawable;
        c localc = (c)this.HM.get(localObject1);
        localObject1 = localDrawable;
        if (localc != null)
        {
          localObject2 = localDrawable;
          localObject1 = localc.a(paramContext, localXmlResourceParser, localAttributeSet, paramContext.getTheme());
        }
        if (localObject1 != null)
        {
          localObject2 = localObject1;
          ((Drawable)localObject1).setChangingConfigurations(localTypedValue.changingConfigurations);
          localObject2 = localObject1;
          a(paramContext, l, (Drawable)localObject1);
        }
      }
    }
    return null;
  }

  public static g dp()
  {
    if (HD == null)
    {
      g localg = new g();
      HD = localg;
      int i = Build.VERSION.SDK_INT;
      if (i < 23)
      {
        localg.a("vector", new d((byte)0));
        if (i >= 11)
          localg.a("animated-vector", new a((byte)0));
      }
    }
    return HD;
  }

  private static ColorStateList e(Context paramContext, int paramInt)
  {
    int k = u.g(paramContext, a.a.colorControlHighlight);
    int[] arrayOfInt1 = u.Mw;
    int i = u.i(paramContext, a.a.colorButtonNormal);
    paramContext = u.PRESSED_STATE_SET;
    int j = android.support.v4.a.a.e(k, paramInt);
    int[] arrayOfInt2 = u.FOCUSED_STATE_SET;
    k = android.support.v4.a.a.e(k, paramInt);
    return new ColorStateList(new int[][] { arrayOfInt1, paramContext, arrayOfInt2, u.EMPTY_STATE_SET }, new int[] { i, j, k, paramInt });
  }

  public final Drawable a(Context paramContext, int paramInt, boolean paramBoolean)
  {
    Object localObject1 = c(paramContext, paramInt);
    Object localObject2 = localObject1;
    if (localObject1 == null)
    {
      if (this.HQ == null)
        this.HQ = new TypedValue();
      TypedValue localTypedValue = this.HQ;
      paramContext.getResources().getValue(paramInt, localTypedValue, true);
      long l = a(localTypedValue);
      localObject2 = a(paramContext, l);
      localObject1 = localObject2;
      if (localObject2 == null)
      {
        if (paramInt == a.e.wf)
          localObject2 = new LayerDrawable(new Drawable[] { a(paramContext, a.e.we, false), a(paramContext, a.e.wg, false) });
        localObject1 = localObject2;
        if (localObject2 != null)
        {
          ((Drawable)localObject2).setChangingConfigurations(localTypedValue.changingConfigurations);
          a(paramContext, l, (Drawable)localObject2);
          localObject1 = localObject2;
        }
      }
      localObject2 = localObject1;
    }
    localObject1 = localObject2;
    if (localObject2 == null)
      localObject1 = android.support.v4.content.a.a(paramContext, paramInt);
    localObject2 = localObject1;
    if (localObject1 != null)
    {
      localObject2 = d(paramContext, paramInt);
      if (localObject2 == null)
        break label270;
      paramContext = (Context)localObject1;
      if (o.n((Drawable)localObject1))
        paramContext = ((Drawable)localObject1).mutate();
      localObject1 = android.support.v4.a.a.a.f(paramContext);
      android.support.v4.a.a.a.a((Drawable)localObject1, (ColorStateList)localObject2);
      paramContext = null;
      if (paramInt == a.e.wE)
        paramContext = PorterDuff.Mode.MULTIPLY;
      localObject2 = localObject1;
      if (paramContext != null)
      {
        android.support.v4.a.a.a.a((Drawable)localObject1, paramContext);
        localObject2 = localObject1;
      }
    }
    while (true)
    {
      if (localObject2 != null)
        o.m((Drawable)localObject2);
      return localObject2;
      label270: if (paramInt == a.e.wB)
      {
        localObject2 = (LayerDrawable)localObject1;
        a(((LayerDrawable)localObject2).findDrawableByLayerId(16908288), u.g(paramContext, a.a.colorControlNormal), HC);
        a(((LayerDrawable)localObject2).findDrawableByLayerId(16908303), u.g(paramContext, a.a.colorControlNormal), HC);
        a(((LayerDrawable)localObject2).findDrawableByLayerId(16908301), u.g(paramContext, a.a.colorControlActivated), HC);
        localObject2 = localObject1;
      }
      else if ((paramInt == a.e.wy) || (paramInt == a.e.wz))
      {
        localObject2 = (LayerDrawable)localObject1;
        a(((LayerDrawable)localObject2).findDrawableByLayerId(16908288), u.i(paramContext, a.a.colorControlNormal), HC);
        a(((LayerDrawable)localObject2).findDrawableByLayerId(16908303), u.g(paramContext, a.a.colorControlActivated), HC);
        a(((LayerDrawable)localObject2).findDrawableByLayerId(16908301), u.g(paramContext, a.a.colorControlActivated), HC);
        localObject2 = localObject1;
      }
      else
      {
        localObject2 = localObject1;
        if (!a(paramContext, paramInt, (Drawable)localObject1))
        {
          localObject2 = localObject1;
          if (paramBoolean)
            localObject2 = null;
        }
      }
    }
  }

  public final ColorStateList d(Context paramContext, int paramInt)
  {
    Object localObject1;
    Object localObject2;
    int i;
    int j;
    Object localObject3;
    int k;
    if (this.HL != null)
    {
      localObject1 = (SparseArray)this.HL.get(paramContext);
      if (localObject1 != null)
      {
        localObject1 = (ColorStateList)((SparseArray)localObject1).get(paramInt);
        localObject2 = localObject1;
        if (localObject1 == null)
        {
          if (paramInt != a.e.wh)
            break label230;
          localObject1 = u.Mw;
          i = u.i(paramContext, a.a.colorControlNormal);
          localObject2 = u.My;
          j = u.g(paramContext, a.a.colorControlNormal);
          localObject3 = u.EMPTY_STATE_SET;
          k = u.g(paramContext, a.a.colorControlActivated);
          localObject1 = new ColorStateList(new int[][] { localObject1, localObject2, localObject3 }, new int[] { i, j, k });
        }
      }
    }
    while (true)
    {
      if (localObject1 != null)
      {
        if (this.HL == null)
          this.HL = new WeakHashMap();
        localObject3 = (SparseArray)this.HL.get(paramContext);
        localObject2 = localObject3;
        if (localObject3 == null)
        {
          localObject2 = new SparseArray();
          this.HL.put(paramContext, localObject2);
        }
        ((SparseArray)localObject2).append(paramInt, localObject1);
      }
      localObject2 = localObject1;
      return localObject2;
      localObject1 = null;
      break;
      localObject1 = null;
      break;
      label230: if (paramInt == a.e.wF)
      {
        localObject1 = u.Mw;
        i = u.a(paramContext, 16842800, 0.1F);
        localObject2 = u.Mp;
        j = u.a(paramContext, a.a.colorControlActivated, 0.3F);
        localObject3 = u.EMPTY_STATE_SET;
        k = u.a(paramContext, 16842800, 0.3F);
        localObject1 = new ColorStateList(new int[][] { localObject1, localObject2, localObject3 }, new int[] { i, j, k });
      }
      else
      {
        if (paramInt == a.e.wE)
        {
          localObject1 = new int[3][];
          localObject2 = new int[3];
          localObject3 = u.h(paramContext, a.a.vJ);
          if ((localObject3 != null) && (((ColorStateList)localObject3).isStateful()))
          {
            localObject1[0] = u.Mw;
            localObject2[0] = ((ColorStateList)localObject3).getColorForState(localObject1[0], 0);
            localObject1[1] = u.Mp;
            localObject2[1] = u.g(paramContext, a.a.colorControlActivated);
            localObject1[2] = u.EMPTY_STATE_SET;
            localObject2[2] = ((ColorStateList)localObject3).getDefaultColor();
          }
          while (true)
          {
            localObject1 = new ColorStateList((int[][])localObject1, (int[])localObject2);
            break;
            localObject1[0] = u.Mw;
            localObject2[0] = u.i(paramContext, a.a.vJ);
            localObject1[1] = u.Mp;
            localObject2[1] = u.g(paramContext, a.a.colorControlActivated);
            localObject1[2] = u.EMPTY_STATE_SET;
            localObject2[2] = u.g(paramContext, a.a.vJ);
          }
        }
        if (paramInt == a.e.wc)
        {
          localObject1 = e(paramContext, u.g(paramContext, a.a.colorButtonNormal));
        }
        else if (paramInt == a.e.vZ)
        {
          localObject1 = e(paramContext, 0);
        }
        else if (paramInt == a.e.wb)
        {
          localObject1 = e(paramContext, u.g(paramContext, a.a.colorAccent));
        }
        else if ((paramInt == a.e.wC) || (paramInt == a.e.wD))
        {
          localObject1 = u.Mw;
          i = u.i(paramContext, a.a.colorControlNormal);
          localObject2 = u.My;
          j = u.g(paramContext, a.a.colorControlNormal);
          localObject3 = u.EMPTY_STATE_SET;
          k = u.g(paramContext, a.a.colorControlActivated);
          localObject1 = new ColorStateList(new int[][] { localObject1, localObject2, localObject3 }, new int[] { i, j, k });
        }
        else if (a(HG, paramInt))
        {
          localObject1 = u.h(paramContext, a.a.colorControlNormal);
        }
        else if (a(HJ, paramInt))
        {
          i = u.g(paramContext, a.a.colorControlNormal);
          j = u.g(paramContext, a.a.colorControlActivated);
          localObject1 = u.Mw;
          k = u.i(paramContext, a.a.colorControlNormal);
          localObject1 = new ColorStateList(new int[][] { localObject1, u.FOCUSED_STATE_SET, u.Mx, u.PRESSED_STATE_SET, u.Mp, u.SELECTED_STATE_SET, u.EMPTY_STATE_SET }, new int[] { k, j, j, j, j, j, i });
        }
        else if (a(HK, paramInt))
        {
          localObject1 = u.Mw;
          i = u.i(paramContext, a.a.colorControlNormal);
          localObject2 = u.Mp;
          j = u.g(paramContext, a.a.colorControlActivated);
          localObject3 = u.EMPTY_STATE_SET;
          k = u.g(paramContext, a.a.colorControlNormal);
          localObject1 = new ColorStateList(new int[][] { localObject1, localObject2, localObject3 }, new int[] { i, j, k });
        }
        else if (paramInt == a.e.wA)
        {
          localObject1 = u.Mw;
          i = u.i(paramContext, a.a.colorControlActivated);
          localObject2 = u.EMPTY_STATE_SET;
          j = u.g(paramContext, a.a.colorControlActivated);
          localObject1 = new ColorStateList(new int[][] { localObject1, localObject2 }, new int[] { i, j });
        }
      }
    }
  }

  private static final class a
    implements g.c
  {
    public final Drawable a(Context paramContext, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
    {
      try
      {
        paramContext = android.support.a.a.b.a(paramContext, paramContext.getResources(), paramXmlPullParser, paramAttributeSet, paramTheme);
        return paramContext;
      }
      catch (Exception paramContext)
      {
      }
      return null;
    }
  }

  private static final class b extends android.support.v4.d.f<Integer, PorterDuffColorFilter>
  {
    public b()
    {
      super();
    }

    static int b(int paramInt, PorterDuff.Mode paramMode)
    {
      return (paramInt + 31) * 31 + paramMode.hashCode();
    }
  }

  private static abstract interface c
  {
    public abstract Drawable a(Context paramContext, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme);
  }

  private static final class d
    implements g.c
  {
    public final Drawable a(Context paramContext, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
    {
      try
      {
        paramContext = android.support.a.a.f.a(paramContext.getResources(), paramXmlPullParser, paramAttributeSet, paramTheme);
        return paramContext;
      }
      catch (Exception paramContext)
      {
      }
      return null;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.g
 * JD-Core Version:    0.6.2
 */