package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.v7.a.a.f;
import android.support.v7.a.a.k;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;

public class ActionBarContainer extends FrameLayout
{
  Drawable Dn;
  private boolean EU;
  View EV;
  private View EW;
  private View EX;
  Drawable EY;
  Drawable EZ;
  boolean Fa;
  boolean Fb;
  private int Fc;

  public ActionBarContainer(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    Object localObject;
    boolean bool;
    if (Build.VERSION.SDK_INT >= 21)
    {
      localObject = new c(this);
      setBackgroundDrawable((Drawable)localObject);
      paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, a.k.xZ);
      this.Dn = paramContext.getDrawable(a.k.yc);
      this.EY = paramContext.getDrawable(a.k.ye);
      this.Fc = paramContext.getDimensionPixelSize(a.k.yk, -1);
      if (getId() == a.f.xv)
      {
        this.Fa = true;
        this.EZ = paramContext.getDrawable(a.k.yd);
      }
      paramContext.recycle();
      if (!this.Fa)
        break label143;
      if (this.EZ != null)
        break label138;
      bool = true;
    }
    while (true)
    {
      setWillNotDraw(bool);
      return;
      localObject = new b(this);
      break;
      label138: bool = false;
      continue;
      label143: if ((this.Dn == null) && (this.EY == null))
        bool = true;
      else
        bool = false;
    }
  }

  private static boolean ak(View paramView)
  {
    return (paramView == null) || (paramView.getVisibility() == 8) || (paramView.getMeasuredHeight() == 0);
  }

  private static int al(View paramView)
  {
    FrameLayout.LayoutParams localLayoutParams = (FrameLayout.LayoutParams)paramView.getLayoutParams();
    int i = paramView.getMeasuredHeight();
    int j = localLayoutParams.topMargin;
    return localLayoutParams.bottomMargin + (i + j);
  }

  public final void E(boolean paramBoolean)
  {
    this.EU = paramBoolean;
    if (paramBoolean);
    for (int i = 393216; ; i = 262144)
    {
      setDescendantFocusability(i);
      return;
    }
  }

  public final void a(s params)
  {
    if (this.EV != null)
      removeView(this.EV);
    this.EV = params;
    if (params != null)
    {
      addView(params);
      ViewGroup.LayoutParams localLayoutParams = params.getLayoutParams();
      localLayoutParams.width = -1;
      localLayoutParams.height = -2;
      params.Ko = false;
    }
  }

  protected void drawableStateChanged()
  {
    super.drawableStateChanged();
    if ((this.Dn != null) && (this.Dn.isStateful()))
      this.Dn.setState(getDrawableState());
    if ((this.EY != null) && (this.EY.isStateful()))
      this.EY.setState(getDrawableState());
    if ((this.EZ != null) && (this.EZ.isStateful()))
      this.EZ.setState(getDrawableState());
  }

  public void jumpDrawablesToCurrentState()
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      super.jumpDrawablesToCurrentState();
      if (this.Dn != null)
        this.Dn.jumpToCurrentState();
      if (this.EY != null)
        this.EY.jumpToCurrentState();
      if (this.EZ != null)
        this.EZ.jumpToCurrentState();
    }
  }

  public final void k(Drawable paramDrawable)
  {
    boolean bool = true;
    if (this.Dn != null)
    {
      this.Dn.setCallback(null);
      unscheduleDrawable(this.Dn);
    }
    this.Dn = paramDrawable;
    if (paramDrawable != null)
    {
      paramDrawable.setCallback(this);
      if (this.EW != null)
        this.Dn.setBounds(this.EW.getLeft(), this.EW.getTop(), this.EW.getRight(), this.EW.getBottom());
    }
    if (this.Fa)
      if (this.EZ != null);
    while (true)
    {
      setWillNotDraw(bool);
      invalidate();
      return;
      bool = false;
      continue;
      if ((this.Dn != null) || (this.EY != null))
        bool = false;
    }
  }

  public void onFinishInflate()
  {
    super.onFinishInflate();
    this.EW = findViewById(a.f.wN);
    this.EX = findViewById(a.f.wS);
  }

  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
  {
    return (this.EU) || (super.onInterceptTouchEvent(paramMotionEvent));
  }

  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = 1;
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    View localView = this.EV;
    if ((localView != null) && (localView.getVisibility() != 8))
    {
      paramBoolean = true;
      if ((localView != null) && (localView.getVisibility() != 8))
      {
        paramInt2 = getMeasuredHeight();
        FrameLayout.LayoutParams localLayoutParams = (FrameLayout.LayoutParams)localView.getLayoutParams();
        localView.layout(paramInt1, paramInt2 - localView.getMeasuredHeight() - localLayoutParams.bottomMargin, paramInt3, paramInt2 - localLayoutParams.bottomMargin);
      }
      if (!this.Fa)
        break label143;
      if (this.EZ == null)
        break label323;
      this.EZ.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
      paramInt1 = i;
    }
    while (true)
    {
      if (paramInt1 != 0)
        invalidate();
      return;
      paramBoolean = false;
      break;
      label143: if (this.Dn != null)
        if (this.EW.getVisibility() == 0)
          this.Dn.setBounds(this.EW.getLeft(), this.EW.getTop(), this.EW.getRight(), this.EW.getBottom());
      label195: for (paramInt1 = 1; ; paramInt1 = 0)
      {
        this.Fb = paramBoolean;
        if ((paramBoolean) && (this.EY != null))
        {
          this.EY.setBounds(localView.getLeft(), localView.getTop(), localView.getRight(), localView.getBottom());
          paramInt1 = i;
          break;
          if ((this.EX != null) && (this.EX.getVisibility() == 0))
          {
            this.Dn.setBounds(this.EX.getLeft(), this.EX.getTop(), this.EX.getRight(), this.EX.getBottom());
            break label195;
          }
          this.Dn.setBounds(0, 0, 0, 0);
          break label195;
        }
        break;
      }
      label323: paramInt1 = 0;
    }
  }

  public void onMeasure(int paramInt1, int paramInt2)
  {
    int i = paramInt2;
    if (this.EW == null)
    {
      i = paramInt2;
      if (View.MeasureSpec.getMode(paramInt2) == -2147483648)
      {
        i = paramInt2;
        if (this.Fc >= 0)
          i = View.MeasureSpec.makeMeasureSpec(Math.min(this.Fc, View.MeasureSpec.getSize(paramInt2)), -2147483648);
      }
    }
    super.onMeasure(paramInt1, i);
    if (this.EW == null);
    do
    {
      return;
      paramInt2 = View.MeasureSpec.getMode(i);
    }
    while ((this.EV == null) || (this.EV.getVisibility() == 8) || (paramInt2 == 1073741824));
    if (!ak(this.EW))
    {
      paramInt1 = al(this.EW);
      if (paramInt2 != -2147483648)
        break label168;
    }
    label168: for (paramInt2 = View.MeasureSpec.getSize(i); ; paramInt2 = 2147483647)
    {
      setMeasuredDimension(getMeasuredWidth(), Math.min(paramInt1 + al(this.EV), paramInt2));
      return;
      if (!ak(this.EX))
      {
        paramInt1 = al(this.EX);
        break;
      }
      paramInt1 = 0;
      break;
    }
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    super.onTouchEvent(paramMotionEvent);
    return true;
  }

  public void setVisibility(int paramInt)
  {
    super.setVisibility(paramInt);
    if (paramInt == 0);
    for (boolean bool = true; ; bool = false)
    {
      if (this.Dn != null)
        this.Dn.setVisible(bool, false);
      if (this.EY != null)
        this.EY.setVisible(bool, false);
      if (this.EZ != null)
        this.EZ.setVisible(bool, false);
      return;
    }
  }

  public ActionMode startActionModeForChild(View paramView, ActionMode.Callback paramCallback)
  {
    return null;
  }

  protected boolean verifyDrawable(Drawable paramDrawable)
  {
    return ((paramDrawable == this.Dn) && (!this.Fa)) || ((paramDrawable == this.EY) && (this.Fb)) || ((paramDrawable == this.EZ) && (this.Fa)) || (super.verifyDrawable(paramDrawable));
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.ActionBarContainer
 * JD-Core Version:    0.6.2
 */