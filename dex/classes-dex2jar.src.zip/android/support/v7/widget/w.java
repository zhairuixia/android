package android.support.v7.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

final class w
{
  public ColorStateList MB;
  public boolean MC;
  public boolean MD;
  public PorterDuff.Mode bi;
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.w
 * JD-Core Version:    0.6.2
 */