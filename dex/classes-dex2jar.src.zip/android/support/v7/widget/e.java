package android.support.v7.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build.VERSION;
import android.support.v4.view.y;
import android.support.v7.a.a.k;
import android.util.AttributeSet;
import android.view.View;

final class e
{
  private final g Hp;
  private w Hs;
  private w Ht;
  private w Hu;
  private final View mView;

  e(View paramView, g paramg)
  {
    this.mView = paramView;
    this.Hp = paramg;
  }

  final void a(AttributeSet paramAttributeSet, int paramInt)
  {
    paramAttributeSet = this.mView.getContext().obtainStyledAttributes(paramAttributeSet, a.k.Bz, paramInt, 0);
    try
    {
      if (paramAttributeSet.hasValue(a.k.BA))
      {
        ColorStateList localColorStateList = this.Hp.d(this.mView.getContext(), paramAttributeSet.getResourceId(a.k.BA, -1));
        if (localColorStateList != null)
          d(localColorStateList);
      }
      if (paramAttributeSet.hasValue(a.k.BB))
        y.a(this.mView, paramAttributeSet.getColorStateList(a.k.BB));
      if (paramAttributeSet.hasValue(a.k.BC))
        y.a(this.mView, o.ai(paramAttributeSet.getInt(a.k.BC, -1)));
      return;
    }
    finally
    {
      paramAttributeSet.recycle();
    }
  }

  final ColorStateList aC()
  {
    if (this.Ht != null)
      return this.Ht.MB;
    return null;
  }

  final PorterDuff.Mode aD()
  {
    if (this.Ht != null)
      return this.Ht.bi;
    return null;
  }

  final void ag(int paramInt)
  {
    if (this.Hp != null);
    for (ColorStateList localColorStateList = this.Hp.d(this.mView.getContext(), paramInt); ; localColorStateList = null)
    {
      d(localColorStateList);
      return;
    }
  }

  final void b(ColorStateList paramColorStateList)
  {
    if (this.Ht == null)
      this.Ht = new w();
    this.Ht.MB = paramColorStateList;
    this.Ht.MD = true;
    dm();
  }

  final void b(PorterDuff.Mode paramMode)
  {
    if (this.Ht == null)
      this.Ht = new w();
    this.Ht.bi = paramMode;
    this.Ht.MC = true;
    dm();
  }

  final void d(ColorStateList paramColorStateList)
  {
    if (paramColorStateList != null)
    {
      if (this.Hs == null)
        this.Hs = new w();
      this.Hs.MB = paramColorStateList;
      this.Hs.MD = true;
    }
    while (true)
    {
      dm();
      return;
      this.Hs = null;
    }
  }

  final void dm()
  {
    Drawable localDrawable = this.mView.getBackground();
    if (localDrawable != null)
    {
      if (this.Ht == null)
        break label35;
      g.a(localDrawable, this.Ht, this.mView.getDrawableState());
    }
    label35: label202: 
    while (true)
    {
      return;
      if (this.Hs != null)
      {
        g.a(localDrawable, this.Hs, this.mView.getDrawableState());
        return;
      }
      if ((Build.VERSION.SDK_INT == 21) && ((localDrawable instanceof GradientDrawable)));
      for (int i = 1; ; i = 0)
      {
        if (i == 0)
          break label202;
        if (this.Hu == null)
          this.Hu = new w();
        w localw = this.Hu;
        localw.MB = null;
        localw.MD = false;
        localw.bi = null;
        localw.MC = false;
        Object localObject = y.A(this.mView);
        if (localObject != null)
        {
          localw.MD = true;
          localw.MB = ((ColorStateList)localObject);
        }
        localObject = y.B(this.mView);
        if (localObject != null)
        {
          localw.MC = true;
          localw.bi = ((PorterDuff.Mode)localObject);
        }
        if ((!localw.MD) && (!localw.MC))
          break;
        g.a(localDrawable, localw, this.mView.getDrawableState());
        return;
      }
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.e
 * JD-Core Version:    0.6.2
 */