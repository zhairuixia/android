package android.support.v7.app;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;

final class m
{
  static final a uU = new a((byte)0);
  final Context mContext;
  private final LocationManager uV;

  m(Context paramContext)
  {
    this.mContext = paramContext;
    this.uV = ((LocationManager)paramContext.getSystemService("location"));
  }

  static boolean a(a parama)
  {
    return (parama != null) && (parama.vb > System.currentTimeMillis());
  }

  static void b(Location paramLocation)
  {
    a locala = uU;
    long l1 = System.currentTimeMillis();
    if (l.uR == null)
      l.uR = new l();
    l locall = l.uR;
    locall.a(l1 - 86400000L, paramLocation.getLatitude(), paramLocation.getLongitude());
    long l2 = locall.uS;
    locall.a(l1, paramLocation.getLatitude(), paramLocation.getLongitude());
    if (locall.state == 1);
    long l3;
    long l4;
    long l5;
    for (boolean bool = true; ; bool = false)
    {
      l3 = locall.uT;
      l4 = locall.uS;
      locall.a(86400000L + l1, paramLocation.getLatitude(), paramLocation.getLongitude());
      l5 = locall.uT;
      if ((l3 != -1L) && (l4 != -1L))
        break;
      l1 = 43200000L + l1;
      locala.uW = bool;
      locala.uX = l2;
      locala.uY = l3;
      locala.uZ = l4;
      locala.va = l5;
      locala.vb = l1;
      return;
    }
    if (l1 > l4)
      l1 = 0L + l5;
    while (true)
    {
      l1 += 60000L;
      break;
      if (l1 > l3)
        l1 = 0L + l4;
      else
        l1 = 0L + l3;
    }
  }

  final Location n(String paramString)
  {
    if (this.uV != null)
      try
      {
        if (this.uV.isProviderEnabled(paramString))
        {
          paramString = this.uV.getLastKnownLocation(paramString);
          return paramString;
        }
      }
      catch (Exception paramString)
      {
      }
    return null;
  }

  private static final class a
  {
    boolean uW;
    long uX;
    long uY;
    long uZ;
    long va;
    long vb;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.app.m
 * JD-Core Version:    0.6.2
 */