package android.support.v7.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnKeyListener;
import android.content.DialogInterface.OnMultiChoiceClickListener;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.support.v4.widget.NestedScrollView;
import android.support.v4.widget.NestedScrollView.b;
import android.support.v7.a.a.k;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.lang.ref.WeakReference;

public final class a
{
  CharSequence ic;
  public final Context mContext;
  Handler mHandler;
  public View mView;
  final i rY;
  final Window rZ;
  public int sA = -1;
  int sB;
  int sC;
  public int sD;
  public int sE;
  public int sF;
  public int sG;
  int sH = 0;
  final View.OnClickListener sI = new View.OnClickListener()
  {
    public final void onClick(View paramAnonymousView)
    {
      if ((paramAnonymousView == a.this.sj) && (a.this.sl != null))
        paramAnonymousView = Message.obtain(a.this.sl);
      while (true)
      {
        if (paramAnonymousView != null)
          paramAnonymousView.sendToTarget();
        a.this.mHandler.obtainMessage(1, a.this.rY).sendToTarget();
        return;
        if ((paramAnonymousView == a.this.sm) && (a.this.so != null))
          paramAnonymousView = Message.obtain(a.this.so);
        else if ((paramAnonymousView == a.this.sp) && (a.this.sr != null))
          paramAnonymousView = Message.obtain(a.this.sr);
        else
          paramAnonymousView = null;
      }
    }
  };
  public CharSequence sa;
  public ListView sc;
  public int sd;
  public int se;
  public int sf;
  public int sg;
  public int sh;
  public boolean si = false;
  Button sj;
  CharSequence sk;
  Message sl;
  Button sm;
  CharSequence sn;
  Message so;
  Button sp;
  CharSequence sq;
  Message sr;
  NestedScrollView ss;
  public int st = 0;
  public Drawable su;
  public ImageView sv;
  TextView sw;
  public TextView sx;
  public View sy;
  public ListAdapter sz;

  public a(Context paramContext, i parami, Window paramWindow)
  {
    this.mContext = paramContext;
    this.rY = parami;
    this.rZ = paramWindow;
    this.mHandler = new b(parami);
    paramContext = paramContext.obtainStyledAttributes(null, a.k.yG, android.support.v7.a.a.a.alertDialogStyle, 0);
    this.sB = paramContext.getResourceId(a.k.yH, 0);
    this.sC = paramContext.getResourceId(a.k.yI, 0);
    this.sD = paramContext.getResourceId(a.k.yK, 0);
    this.sE = paramContext.getResourceId(a.k.yL, 0);
    this.sF = paramContext.getResourceId(a.k.yM, 0);
    this.sG = paramContext.getResourceId(a.k.yJ, 0);
    paramContext.recycle();
    parami.bI().requestWindowFeature(1);
  }

  static boolean ah(View paramView)
  {
    if (paramView.onCheckIsTextEditor())
      return true;
    if (!(paramView instanceof ViewGroup))
      return false;
    paramView = (ViewGroup)paramView;
    int i = paramView.getChildCount();
    while (i > 0)
    {
      int j = i - 1;
      i = j;
      if (ah(paramView.getChildAt(j)))
        return true;
    }
    return false;
  }

  static ViewGroup b(View paramView1, View paramView2)
  {
    if (paramView1 == null)
      if (!(paramView2 instanceof ViewStub))
        break label71;
    label71: for (paramView1 = ((ViewStub)paramView2).inflate(); ; paramView1 = paramView2)
    {
      return (ViewGroup)paramView1;
      if (paramView2 != null)
      {
        ViewParent localViewParent = paramView2.getParent();
        if ((localViewParent instanceof ViewGroup))
          ((ViewGroup)localViewParent).removeView(paramView2);
      }
      if ((paramView1 instanceof ViewStub))
        paramView1 = ((ViewStub)paramView1).inflate();
      while (true)
        return (ViewGroup)paramView1;
    }
  }

  public final void a(int paramInt, CharSequence paramCharSequence, DialogInterface.OnClickListener paramOnClickListener, Message paramMessage)
  {
    if (paramOnClickListener != null)
      paramMessage = this.mHandler.obtainMessage(paramInt, paramOnClickListener);
    switch (paramInt)
    {
    default:
      throw new IllegalArgumentException("Button does not exist");
    case -1:
      this.sk = paramCharSequence;
      this.sl = paramMessage;
      return;
    case -2:
      this.sn = paramCharSequence;
      this.so = paramMessage;
      return;
    case -3:
    }
    this.sq = paramCharSequence;
    this.sr = paramMessage;
  }

  public final void setIcon(int paramInt)
  {
    this.su = null;
    this.st = paramInt;
    if (this.sv != null)
    {
      if (paramInt != 0)
      {
        this.sv.setVisibility(0);
        this.sv.setImageResource(this.st);
      }
    }
    else
      return;
    this.sv.setVisibility(8);
  }

  public final void setTitle(CharSequence paramCharSequence)
  {
    this.ic = paramCharSequence;
    if (this.sw != null)
      this.sw.setText(paramCharSequence);
  }

  public static final class a
  {
    public boolean cq;
    public CharSequence ic;
    public final Context mContext;
    public Cursor mCursor;
    public View mView;
    public final LayoutInflater qs;
    public int sA = -1;
    public int sM = 0;
    public CharSequence sN;
    public DialogInterface.OnClickListener sO;
    public CharSequence sP;
    public DialogInterface.OnClickListener sQ;
    public CharSequence sR;
    public DialogInterface.OnClickListener sS;
    public DialogInterface.OnCancelListener sT;
    public DialogInterface.OnDismissListener sU;
    public DialogInterface.OnKeyListener sV;
    public CharSequence[] sW;
    public DialogInterface.OnClickListener sX;
    public boolean[] sY;
    public boolean sZ;
    public CharSequence sa;
    public int sd;
    public int se;
    public int sf;
    public int sg;
    public int sh;
    public boolean si = false;
    public int st = 0;
    public Drawable su;
    public View sy;
    public ListAdapter sz;
    public boolean ta;
    public DialogInterface.OnMultiChoiceClickListener tb;
    public String tc;
    public String td;
    public AdapterView.OnItemSelectedListener te;
    public boolean tf = true;

    public a(Context paramContext)
    {
      this.mContext = paramContext;
      this.cq = true;
      this.qs = ((LayoutInflater)paramContext.getSystemService("layout_inflater"));
    }
  }

  private static final class b extends Handler
  {
    private WeakReference<DialogInterface> tl;

    public b(DialogInterface paramDialogInterface)
    {
      this.tl = new WeakReference(paramDialogInterface);
    }

    public final void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      case 0:
      default:
        return;
      case -3:
      case -2:
      case -1:
        ((DialogInterface.OnClickListener)paramMessage.obj).onClick((DialogInterface)this.tl.get(), paramMessage.what);
        return;
      case 1:
      }
      ((DialogInterface)paramMessage.obj).dismiss();
    }
  }

  private static final class c extends ArrayAdapter<CharSequence>
  {
    public c(Context paramContext, int paramInt, CharSequence[] paramArrayOfCharSequence)
    {
      super(paramInt, 16908308, paramArrayOfCharSequence);
    }

    public final long getItemId(int paramInt)
    {
      return paramInt;
    }

    public final boolean hasStableIds()
    {
      return true;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.app.a
 * JD-Core Version:    0.6.2
 */