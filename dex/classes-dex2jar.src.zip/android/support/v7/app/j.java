package android.support.v7.app;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.support.v4.d.a;
import android.support.v4.view.y;
import android.support.v7.a.a.k;
import android.support.v7.view.d;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Map;

final class j
{
  private static final Class<?>[] uB = { Context.class, AttributeSet.class };
  private static final int[] uC = { 16843375 };
  private static final String[] uD = { "android.widget.", "android.view.", "android.webkit." };
  private static final Map<String, Constructor<? extends View>> uE = new a();
  private final Object[] uF = new Object[2];

  static Context a(Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean1, boolean paramBoolean2)
  {
    paramAttributeSet = paramContext.obtainStyledAttributes(paramAttributeSet, a.k.By, 0, 0);
    if (paramBoolean1);
    for (int i = paramAttributeSet.getResourceId(a.k.BH, 0); ; i = 0)
    {
      if (i == 0)
        i = paramAttributeSet.getResourceId(a.k.BI, 0);
      while (true)
      {
        paramAttributeSet.recycle();
        paramAttributeSet = paramContext;
        if (i != 0)
          if ((paramContext instanceof d))
          {
            paramAttributeSet = paramContext;
            if (((d)paramContext).BL == i);
          }
          else
          {
            paramAttributeSet = new d(paramContext, i);
          }
        return paramAttributeSet;
      }
    }
  }

  static void a(View paramView, AttributeSet paramAttributeSet)
  {
    Object localObject = paramView.getContext();
    if ((!(localObject instanceof ContextWrapper)) || ((Build.VERSION.SDK_INT >= 15) && (!y.G(paramView))))
      return;
    paramAttributeSet = ((Context)localObject).obtainStyledAttributes(paramAttributeSet, uC);
    localObject = paramAttributeSet.getString(0);
    if (localObject != null)
      paramView.setOnClickListener(new a(paramView, (String)localObject));
    paramAttributeSet.recycle();
  }

  private View b(Context paramContext, String paramString1, String paramString2)
  {
    Constructor localConstructor = (Constructor)uE.get(paramString1);
    Object localObject = localConstructor;
    if (localConstructor == null);
    try
    {
      localObject = paramContext.getClassLoader();
      if (paramString2 != null);
      for (paramContext = paramString2 + paramString1; ; paramContext = paramString1)
      {
        localObject = ((ClassLoader)localObject).loadClass(paramContext).asSubclass(View.class).getConstructor(uB);
        uE.put(paramString1, localObject);
        ((Constructor)localObject).setAccessible(true);
        paramContext = (View)((Constructor)localObject).newInstance(this.uF);
        return paramContext;
      }
    }
    catch (Exception paramContext)
    {
    }
    return null;
  }

  final View a(Context paramContext, String paramString, AttributeSet paramAttributeSet)
  {
    String str = paramString;
    if (paramString.equals("view"))
      str = paramAttributeSet.getAttributeValue(null, "class");
    try
    {
      this.uF[0] = paramContext;
      this.uF[1] = paramAttributeSet;
      if (-1 == str.indexOf('.'))
      {
        int i = 0;
        while (i < uD.length)
        {
          paramString = b(paramContext, str, uD[i]);
          if (paramString != null)
            return paramString;
          i += 1;
        }
        return null;
      }
      paramContext = b(paramContext, str, null);
      return paramContext;
    }
    catch (Exception paramContext)
    {
      return null;
    }
    finally
    {
      this.uF[0] = null;
      this.uF[1] = null;
    }
    throw paramContext;
  }

  private static final class a
    implements View.OnClickListener
  {
    private final View uG;
    private final String uH;
    private Method uI;
    private Context uJ;

    public a(View paramView, String paramString)
    {
      this.uG = paramView;
      this.uH = paramString;
    }

    // ERROR //
    public final void onClick(View paramView)
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 37	android/support/v7/app/j$a:uI	Ljava/lang/reflect/Method;
      //   4: ifnonnull +60 -> 64
      //   7: aload_0
      //   8: getfield 24	android/support/v7/app/j$a:uG	Landroid/view/View;
      //   11: invokevirtual 43	android/view/View:getContext	()Landroid/content/Context;
      //   14: astore_3
      //   15: aload_3
      //   16: ifnull +94 -> 110
      //   19: aload_3
      //   20: invokevirtual 49	android/content/Context:isRestricted	()Z
      //   23: ifne +64 -> 87
      //   26: aload_3
      //   27: invokevirtual 53	java/lang/Object:getClass	()Ljava/lang/Class;
      //   30: aload_0
      //   31: getfield 26	android/support/v7/app/j$a:uH	Ljava/lang/String;
      //   34: iconst_1
      //   35: anewarray 55	java/lang/Class
      //   38: dup
      //   39: iconst_0
      //   40: ldc 39
      //   42: aastore
      //   43: invokevirtual 59	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   46: astore 4
      //   48: aload 4
      //   50: ifnull +37 -> 87
      //   53: aload_0
      //   54: aload 4
      //   56: putfield 37	android/support/v7/app/j$a:uI	Ljava/lang/reflect/Method;
      //   59: aload_0
      //   60: aload_3
      //   61: putfield 61	android/support/v7/app/j$a:uJ	Landroid/content/Context;
      //   64: aload_0
      //   65: getfield 37	android/support/v7/app/j$a:uI	Ljava/lang/reflect/Method;
      //   68: aload_0
      //   69: getfield 61	android/support/v7/app/j$a:uJ	Landroid/content/Context;
      //   72: iconst_1
      //   73: anewarray 4	java/lang/Object
      //   76: dup
      //   77: iconst_0
      //   78: aload_1
      //   79: aastore
      //   80: invokevirtual 67	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   83: pop
      //   84: return
      //   85: astore 4
      //   87: aload_3
      //   88: instanceof 69
      //   91: ifeq +14 -> 105
      //   94: aload_3
      //   95: checkcast 69	android/content/ContextWrapper
      //   98: invokevirtual 72	android/content/ContextWrapper:getBaseContext	()Landroid/content/Context;
      //   101: astore_3
      //   102: goto -87 -> 15
      //   105: aconst_null
      //   106: astore_3
      //   107: goto -92 -> 15
      //   110: aload_0
      //   111: getfield 24	android/support/v7/app/j$a:uG	Landroid/view/View;
      //   114: invokevirtual 76	android/view/View:getId	()I
      //   117: istore_2
      //   118: iload_2
      //   119: iconst_m1
      //   120: if_icmpne +52 -> 172
      //   123: ldc 78
      //   125: astore_1
      //   126: new 80	java/lang/IllegalStateException
      //   129: dup
      //   130: new 82	java/lang/StringBuilder
      //   133: dup
      //   134: ldc 84
      //   136: invokespecial 87	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   139: aload_0
      //   140: getfield 26	android/support/v7/app/j$a:uH	Ljava/lang/String;
      //   143: invokevirtual 91	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   146: ldc 93
      //   148: invokevirtual 91	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   151: aload_0
      //   152: getfield 24	android/support/v7/app/j$a:uG	Landroid/view/View;
      //   155: invokevirtual 53	java/lang/Object:getClass	()Ljava/lang/Class;
      //   158: invokevirtual 96	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
      //   161: aload_1
      //   162: invokevirtual 91	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   165: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   168: invokespecial 101	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
      //   171: athrow
      //   172: new 82	java/lang/StringBuilder
      //   175: dup
      //   176: ldc 103
      //   178: invokespecial 87	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   181: aload_0
      //   182: getfield 24	android/support/v7/app/j$a:uG	Landroid/view/View;
      //   185: invokevirtual 43	android/view/View:getContext	()Landroid/content/Context;
      //   188: invokevirtual 107	android/content/Context:getResources	()Landroid/content/res/Resources;
      //   191: iload_2
      //   192: invokevirtual 113	android/content/res/Resources:getResourceEntryName	(I)Ljava/lang/String;
      //   195: invokevirtual 91	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   198: ldc 115
      //   200: invokevirtual 91	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   203: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   206: astore_1
      //   207: goto -81 -> 126
      //   210: astore_1
      //   211: new 80	java/lang/IllegalStateException
      //   214: dup
      //   215: ldc 117
      //   217: aload_1
      //   218: invokespecial 120	java/lang/IllegalStateException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
      //   221: athrow
      //   222: astore_1
      //   223: new 80	java/lang/IllegalStateException
      //   226: dup
      //   227: ldc 122
      //   229: aload_1
      //   230: invokespecial 120	java/lang/IllegalStateException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
      //   233: athrow
      //
      // Exception table:
      //   from	to	target	type
      //   19	48	85	java/lang/NoSuchMethodException
      //   53	64	85	java/lang/NoSuchMethodException
      //   64	84	210	java/lang/IllegalAccessException
      //   64	84	222	java/lang/reflect/InvocationTargetException
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.app.j
 * JD-Core Version:    0.6.2
 */