package android.support.v7.view;

import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SearchEvent;
import android.view.View;
import android.view.Window.Callback;
import android.view.WindowManager.LayoutParams;
import android.view.accessibility.AccessibilityEvent;

public class i
  implements Window.Callback
{
  final Window.Callback CG;

  public i(Window.Callback paramCallback)
  {
    if (paramCallback == null)
      throw new IllegalArgumentException("Window callback may not be null");
    this.CG = paramCallback;
  }

  public boolean dispatchGenericMotionEvent(MotionEvent paramMotionEvent)
  {
    return this.CG.dispatchGenericMotionEvent(paramMotionEvent);
  }

  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent)
  {
    return this.CG.dispatchKeyEvent(paramKeyEvent);
  }

  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent)
  {
    return this.CG.dispatchKeyShortcutEvent(paramKeyEvent);
  }

  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
  {
    return this.CG.dispatchPopulateAccessibilityEvent(paramAccessibilityEvent);
  }

  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent)
  {
    return this.CG.dispatchTouchEvent(paramMotionEvent);
  }

  public boolean dispatchTrackballEvent(MotionEvent paramMotionEvent)
  {
    return this.CG.dispatchTrackballEvent(paramMotionEvent);
  }

  public void onActionModeFinished(ActionMode paramActionMode)
  {
    this.CG.onActionModeFinished(paramActionMode);
  }

  public void onActionModeStarted(ActionMode paramActionMode)
  {
    this.CG.onActionModeStarted(paramActionMode);
  }

  public void onAttachedToWindow()
  {
    this.CG.onAttachedToWindow();
  }

  public void onContentChanged()
  {
    this.CG.onContentChanged();
  }

  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu)
  {
    return this.CG.onCreatePanelMenu(paramInt, paramMenu);
  }

  public View onCreatePanelView(int paramInt)
  {
    return this.CG.onCreatePanelView(paramInt);
  }

  public void onDetachedFromWindow()
  {
    this.CG.onDetachedFromWindow();
  }

  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem)
  {
    return this.CG.onMenuItemSelected(paramInt, paramMenuItem);
  }

  public boolean onMenuOpened(int paramInt, Menu paramMenu)
  {
    return this.CG.onMenuOpened(paramInt, paramMenu);
  }

  public void onPanelClosed(int paramInt, Menu paramMenu)
  {
    this.CG.onPanelClosed(paramInt, paramMenu);
  }

  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu)
  {
    return this.CG.onPreparePanel(paramInt, paramView, paramMenu);
  }

  public boolean onSearchRequested()
  {
    return this.CG.onSearchRequested();
  }

  public boolean onSearchRequested(SearchEvent paramSearchEvent)
  {
    return this.CG.onSearchRequested(paramSearchEvent);
  }

  public void onWindowAttributesChanged(WindowManager.LayoutParams paramLayoutParams)
  {
    this.CG.onWindowAttributesChanged(paramLayoutParams);
  }

  public void onWindowFocusChanged(boolean paramBoolean)
  {
    this.CG.onWindowFocusChanged(paramBoolean);
  }

  public ActionMode onWindowStartingActionMode(ActionMode.Callback paramCallback)
  {
    return this.CG.onWindowStartingActionMode(paramCallback);
  }

  public ActionMode onWindowStartingActionMode(ActionMode.Callback paramCallback, int paramInt)
  {
    return this.CG.onWindowStartingActionMode(paramCallback, paramInt);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.view.i
 * JD-Core Version:    0.6.2
 */