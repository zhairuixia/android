package android.support.v7.view.menu;

import android.content.Context;

public abstract interface l
{
  public abstract void a(Context paramContext, f paramf);

  public abstract void a(f paramf, boolean paramBoolean);

  public abstract boolean a(p paramp);

  public abstract boolean c(h paramh);

  public abstract boolean ck();

  public abstract boolean d(h paramh);

  public abstract void w(boolean paramBoolean);

  public static abstract interface a
  {
    public abstract void a(f paramf, boolean paramBoolean);

    public abstract boolean c(f paramf);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.view.menu.l
 * JD-Core Version:    0.6.2
 */