package android.support.v7.view.menu;

import android.content.Context;
import android.os.Build.VERSION;
import android.support.v4.b.a.a;
import android.support.v4.b.a.b;
import android.view.Menu;
import android.view.MenuItem;

public final class n
{
  public static Menu a(Context paramContext, a parama)
  {
    if (Build.VERSION.SDK_INT >= 14)
      return new o(paramContext, parama);
    throw new UnsupportedOperationException();
  }

  public static MenuItem a(Context paramContext, b paramb)
  {
    if (Build.VERSION.SDK_INT >= 16)
      return new j(paramContext, paramb);
    if (Build.VERSION.SDK_INT >= 14)
      return new i(paramContext, paramb);
    throw new UnsupportedOperationException();
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.view.menu.n
 * JD-Core Version:    0.6.2
 */