package android.support.v7.view.menu;

public class d<T>
{
  public final T Di;

  d(T paramT)
  {
    if (paramT == null)
      throw new IllegalArgumentException("Wrapped Object can not be null.");
    this.Di = paramT;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.view.menu.d
 * JD-Core Version:    0.6.2
 */