package android.support.v7.view;

import android.support.v4.view.ah;
import android.support.v4.view.ah.g;
import android.support.v4.view.al;
import android.support.v4.view.am;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;

public final class h
{
  al CA;
  boolean CB;
  private final am CC = new am()
  {
    private boolean CD = false;
    private int CE = 0;

    public final void L(View paramAnonymousView)
    {
      if (this.CD);
      do
      {
        return;
        this.CD = true;
      }
      while (h.this.CA == null);
      h.this.CA.L(null);
    }

    public final void M(View paramAnonymousView)
    {
      int i = this.CE + 1;
      this.CE = i;
      if (i == h.this.Z.size())
      {
        if (h.this.CA != null)
          h.this.CA.M(null);
        this.CE = 0;
        this.CD = false;
        h.this.CB = false;
      }
    }
  };
  private long Cz = -1L;
  final ArrayList<ah> Z = new ArrayList();
  private Interpolator mInterpolator;

  public final h a(ah paramah1, ah paramah2)
  {
    this.Z.add(paramah1);
    paramah1 = (View)paramah1.mi.get();
    if (paramah1 != null);
    for (long l = ah.mm.K(paramah1); ; l = 0L)
    {
      paramah1 = (View)paramah2.mi.get();
      if (paramah1 != null)
        ah.mm.b(paramah1, l);
      this.Z.add(paramah2);
      return this;
    }
  }

  public final h a(Interpolator paramInterpolator)
  {
    if (!this.CB)
      this.mInterpolator = paramInterpolator;
    return this;
  }

  public final h b(al paramal)
  {
    if (!this.CB)
      this.CA = paramal;
    return this;
  }

  public final void cancel()
  {
    if (!this.CB)
      return;
    Iterator localIterator = this.Z.iterator();
    while (localIterator.hasNext())
      ((ah)localIterator.next()).cancel();
    this.CB = false;
  }

  public final h cc()
  {
    if (!this.CB)
      this.Cz = 250L;
    return this;
  }

  public final h g(ah paramah)
  {
    if (!this.CB)
      this.Z.add(paramah);
    return this;
  }

  public final void start()
  {
    if (this.CB)
      return;
    Iterator localIterator = this.Z.iterator();
    while (localIterator.hasNext())
    {
      ah localah = (ah)localIterator.next();
      if (this.Cz >= 0L)
        localah.d(this.Cz);
      if (this.mInterpolator != null)
      {
        localObject = this.mInterpolator;
        View localView = (View)localah.mi.get();
        if (localView != null)
          ah.mm.a(localView, (Interpolator)localObject);
      }
      if (this.CA != null)
        localah.a(this.CC);
      Object localObject = (View)localah.mi.get();
      if (localObject != null)
        ah.mm.b(localah, (View)localObject);
    }
    this.CB = true;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.view.h
 * JD-Core Version:    0.6.2
 */