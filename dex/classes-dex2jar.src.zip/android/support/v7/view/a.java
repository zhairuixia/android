package android.support.v7.view;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.res.Resources;
import android.support.v7.a.a.b;

public final class a
{
  public Context mContext;

  private a(Context paramContext)
  {
    this.mContext = paramContext;
  }

  public static a l(Context paramContext)
  {
    return new a(paramContext);
  }

  public final boolean bW()
  {
    if (this.mContext.getApplicationInfo().targetSdkVersion >= 16)
      return this.mContext.getResources().getBoolean(a.b.vN);
    return this.mContext.getResources().getBoolean(a.b.vO);
  }

  public final boolean bX()
  {
    return this.mContext.getApplicationInfo().targetSdkVersion < 14;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.view.a
 * JD-Core Version:    0.6.2
 */