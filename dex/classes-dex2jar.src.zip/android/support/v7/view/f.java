package android.support.v7.view;

import android.annotation.TargetApi;
import android.content.Context;
import android.support.v4.b.a.a;
import android.support.v4.d.h;
import android.support.v7.view.menu.n;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import java.util.ArrayList;

@TargetApi(11)
public final class f extends ActionMode
{
  final b BO;
  final Context mContext;

  public f(Context paramContext, b paramb)
  {
    this.mContext = paramContext;
    this.BO = paramb;
  }

  public final void finish()
  {
    this.BO.finish();
  }

  public final View getCustomView()
  {
    return this.BO.getCustomView();
  }

  public final Menu getMenu()
  {
    return n.a(this.mContext, (a)this.BO.getMenu());
  }

  public final MenuInflater getMenuInflater()
  {
    return this.BO.getMenuInflater();
  }

  public final CharSequence getSubtitle()
  {
    return this.BO.getSubtitle();
  }

  public final Object getTag()
  {
    return this.BO.BJ;
  }

  public final CharSequence getTitle()
  {
    return this.BO.getTitle();
  }

  public final boolean getTitleOptionalHint()
  {
    return this.BO.BK;
  }

  public final void invalidate()
  {
    this.BO.invalidate();
  }

  public final boolean isTitleOptional()
  {
    return this.BO.isTitleOptional();
  }

  public final void setCustomView(View paramView)
  {
    this.BO.setCustomView(paramView);
  }

  public final void setSubtitle(int paramInt)
  {
    this.BO.setSubtitle(paramInt);
  }

  public final void setSubtitle(CharSequence paramCharSequence)
  {
    this.BO.setSubtitle(paramCharSequence);
  }

  public final void setTag(Object paramObject)
  {
    this.BO.BJ = paramObject;
  }

  public final void setTitle(int paramInt)
  {
    this.BO.setTitle(paramInt);
  }

  public final void setTitle(CharSequence paramCharSequence)
  {
    this.BO.setTitle(paramCharSequence);
  }

  public final void setTitleOptionalHint(boolean paramBoolean)
  {
    this.BO.setTitleOptionalHint(paramBoolean);
  }

  public static final class a
    implements b.a
  {
    final ActionMode.Callback BP;
    final ArrayList<f> BQ;
    final h<Menu, Menu> BR;
    final Context mContext;

    public a(Context paramContext, ActionMode.Callback paramCallback)
    {
      this.mContext = paramContext;
      this.BP = paramCallback;
      this.BQ = new ArrayList();
      this.BR = new h();
    }

    private Menu b(Menu paramMenu)
    {
      Menu localMenu2 = (Menu)this.BR.get(paramMenu);
      Menu localMenu1 = localMenu2;
      if (localMenu2 == null)
      {
        localMenu1 = n.a(this.mContext, (a)paramMenu);
        this.BR.put(paramMenu, localMenu1);
      }
      return localMenu1;
    }

    public final void a(b paramb)
    {
      this.BP.onDestroyActionMode(b(paramb));
    }

    public final boolean a(b paramb, Menu paramMenu)
    {
      return this.BP.onCreateActionMode(b(paramb), b(paramMenu));
    }

    public final boolean a(b paramb, MenuItem paramMenuItem)
    {
      return this.BP.onActionItemClicked(b(paramb), n.a(this.mContext, (android.support.v4.b.a.b)paramMenuItem));
    }

    public final ActionMode b(b paramb)
    {
      int j = this.BQ.size();
      int i = 0;
      while (i < j)
      {
        f localf = (f)this.BQ.get(i);
        if ((localf != null) && (localf.BO == paramb))
          return localf;
        i += 1;
      }
      paramb = new f(this.mContext, paramb);
      this.BQ.add(paramb);
      return paramb;
    }

    public final boolean b(b paramb, Menu paramMenu)
    {
      return this.BP.onPrepareActionMode(b(paramb), b(paramMenu));
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.view.f
 * JD-Core Version:    0.6.2
 */