package android.support.v7.view;

public abstract interface c
{
  public abstract void onActionViewCollapsed();

  public abstract void onActionViewExpanded();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.view.c
 * JD-Core Version:    0.6.2
 */