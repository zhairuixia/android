package android.support.v7.view;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.support.v7.a.a.j;
import android.view.LayoutInflater;

public final class d extends ContextWrapper
{
  public int BL;
  private Resources.Theme BM;
  private LayoutInflater qs;

  public d(Context paramContext, int paramInt)
  {
    super(paramContext);
    this.BL = paramInt;
  }

  private void bY()
  {
    if (this.BM == null);
    for (int i = 1; ; i = 0)
    {
      if (i != 0)
      {
        this.BM = getResources().newTheme();
        Resources.Theme localTheme = getBaseContext().getTheme();
        if (localTheme != null)
          this.BM.setTo(localTheme);
      }
      this.BM.applyStyle(this.BL, true);
      return;
    }
  }

  public final Object getSystemService(String paramString)
  {
    if ("layout_inflater".equals(paramString))
    {
      if (this.qs == null)
        this.qs = LayoutInflater.from(getBaseContext()).cloneInContext(this);
      return this.qs;
    }
    return getBaseContext().getSystemService(paramString);
  }

  public final Resources.Theme getTheme()
  {
    if (this.BM != null)
      return this.BM;
    if (this.BL == 0)
      this.BL = a.j.xY;
    bY();
    return this.BM;
  }

  public final void setTheme(int paramInt)
  {
    if (this.BL != paramInt)
    {
      this.BL = paramInt;
      bY();
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v7.view.d
 * JD-Core Version:    0.6.2
 */