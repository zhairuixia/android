package android.support.v4.d;

import java.io.Writer;

public final class d extends Writer
{
  private final String cU;
  private StringBuilder jc = new StringBuilder(128);

  public d(String paramString)
  {
    this.cU = paramString;
  }

  private void aw()
  {
    if (this.jc.length() > 0)
      this.jc.delete(0, this.jc.length());
  }

  public final void close()
  {
    aw();
  }

  public final void flush()
  {
    aw();
  }

  public final void write(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    int i = 0;
    if (i < paramInt2)
    {
      char c = paramArrayOfChar[(paramInt1 + i)];
      if (c == '\n')
        aw();
      while (true)
      {
        i += 1;
        break;
        this.jc.append(c);
      }
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.d.d
 * JD-Core Version:    0.6.2
 */