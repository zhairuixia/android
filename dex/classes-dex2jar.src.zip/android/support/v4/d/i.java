package android.support.v4.d;

public final class i<E>
  implements Cloneable
{
  private static final Object jd = new Object();
  private boolean je = false;
  private Object[] jg;
  private int jh;
  private int[] jw;

  public i()
  {
    this(10);
  }

  public i(int paramInt)
  {
    if (paramInt == 0)
      this.jw = b.iZ;
    for (this.jg = b.jb; ; this.jg = new Object[paramInt])
    {
      this.jh = 0;
      return;
      paramInt = b.q(paramInt);
      this.jw = new int[paramInt];
    }
  }

  // ERROR //
  private i<E> az()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial 56	java/lang/Object:clone	()Ljava/lang/Object;
    //   4: checkcast 2	android/support/v4/d/i
    //   7: astore_1
    //   8: aload_1
    //   9: aload_0
    //   10: getfield 37	android/support/v4/d/i:jw	[I
    //   13: invokevirtual 58	[I:clone	()Ljava/lang/Object;
    //   16: checkcast 57	[I
    //   19: putfield 37	android/support/v4/d/i:jw	[I
    //   22: aload_1
    //   23: aload_0
    //   24: getfield 42	android/support/v4/d/i:jg	[Ljava/lang/Object;
    //   27: invokevirtual 60	[Ljava/lang/Object;:clone	()Ljava/lang/Object;
    //   30: checkcast 59	[Ljava/lang/Object;
    //   33: putfield 42	android/support/v4/d/i:jg	[Ljava/lang/Object;
    //   36: aload_1
    //   37: areturn
    //   38: astore_1
    //   39: aconst_null
    //   40: areturn
    //   41: astore_2
    //   42: aload_1
    //   43: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	8	38	java/lang/CloneNotSupportedException
    //   8	36	41	java/lang/CloneNotSupportedException
  }

  private void gc()
  {
    int m = this.jh;
    int[] arrayOfInt = this.jw;
    Object[] arrayOfObject = this.jg;
    int i = 0;
    int k;
    for (int j = 0; i < m; j = k)
    {
      Object localObject = arrayOfObject[i];
      k = j;
      if (localObject != jd)
      {
        if (i != j)
        {
          arrayOfInt[j] = arrayOfInt[i];
          arrayOfObject[j] = localObject;
          arrayOfObject[i] = null;
        }
        k = j + 1;
      }
      i += 1;
    }
    this.je = false;
    this.jh = j;
  }

  public final void clear()
  {
    int j = this.jh;
    Object[] arrayOfObject = this.jg;
    int i = 0;
    while (i < j)
    {
      arrayOfObject[i] = null;
      i += 1;
    }
    this.jh = 0;
    this.je = false;
  }

  public final E get(int paramInt)
  {
    paramInt = b.a(this.jw, this.jh, paramInt);
    if ((paramInt < 0) || (this.jg[paramInt] == jd))
      return null;
    return this.jg[paramInt];
  }

  public final int indexOfKey(int paramInt)
  {
    if (this.je)
      gc();
    return b.a(this.jw, this.jh, paramInt);
  }

  public final int keyAt(int paramInt)
  {
    if (this.je)
      gc();
    return this.jw[paramInt];
  }

  public final void put(int paramInt, E paramE)
  {
    int i = b.a(this.jw, this.jh, paramInt);
    if (i >= 0)
    {
      this.jg[i] = paramE;
      return;
    }
    int j = i ^ 0xFFFFFFFF;
    if ((j < this.jh) && (this.jg[j] == jd))
    {
      this.jw[j] = paramInt;
      this.jg[j] = paramE;
      return;
    }
    i = j;
    if (this.je)
    {
      i = j;
      if (this.jh >= this.jw.length)
      {
        gc();
        i = b.a(this.jw, this.jh, paramInt) ^ 0xFFFFFFFF;
      }
    }
    if (this.jh >= this.jw.length)
    {
      j = b.q(this.jh + 1);
      int[] arrayOfInt = new int[j];
      Object[] arrayOfObject = new Object[j];
      System.arraycopy(this.jw, 0, arrayOfInt, 0, this.jw.length);
      System.arraycopy(this.jg, 0, arrayOfObject, 0, this.jg.length);
      this.jw = arrayOfInt;
      this.jg = arrayOfObject;
    }
    if (this.jh - i != 0)
    {
      System.arraycopy(this.jw, i, this.jw, i + 1, this.jh - i);
      System.arraycopy(this.jg, i, this.jg, i + 1, this.jh - i);
    }
    this.jw[i] = paramInt;
    this.jg[i] = paramE;
    this.jh += 1;
  }

  public final void remove(int paramInt)
  {
    paramInt = b.a(this.jw, this.jh, paramInt);
    if ((paramInt >= 0) && (this.jg[paramInt] != jd))
    {
      this.jg[paramInt] = jd;
      this.je = true;
    }
  }

  public final void removeAt(int paramInt)
  {
    if (this.jg[paramInt] != jd)
    {
      this.jg[paramInt] = jd;
      this.je = true;
    }
  }

  public final int size()
  {
    if (this.je)
      gc();
    return this.jh;
  }

  public final String toString()
  {
    if (size() <= 0)
      return "{}";
    StringBuilder localStringBuilder = new StringBuilder(this.jh * 28);
    localStringBuilder.append('{');
    int i = 0;
    if (i < this.jh)
    {
      if (i > 0)
        localStringBuilder.append(", ");
      localStringBuilder.append(keyAt(i));
      localStringBuilder.append('=');
      Object localObject = valueAt(i);
      if (localObject != this)
        localStringBuilder.append(localObject);
      while (true)
      {
        i += 1;
        break;
        localStringBuilder.append("(this Map)");
      }
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }

  public final E valueAt(int paramInt)
  {
    if (this.je)
      gc();
    return this.jg[paramInt];
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.d.i
 * JD-Core Version:    0.6.2
 */