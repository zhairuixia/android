package android.support.v4.d;

public final class e<E>
  implements Cloneable
{
  public static final Object jd = new Object();
  public boolean je = false;
  public long[] jf;
  public Object[] jg;
  public int jh;

  public e()
  {
    this((byte)0);
  }

  private e(byte paramByte)
  {
    paramByte = b.r(10);
    this.jf = new long[paramByte];
    this.jg = new Object[paramByte];
    this.jh = 0;
  }

  // ERROR //
  private e<E> ax()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial 50	java/lang/Object:clone	()Ljava/lang/Object;
    //   4: checkcast 2	android/support/v4/d/e
    //   7: astore_1
    //   8: aload_1
    //   9: aload_0
    //   10: getfield 38	android/support/v4/d/e:jf	[J
    //   13: invokevirtual 52	[J:clone	()Ljava/lang/Object;
    //   16: checkcast 51	[J
    //   19: putfield 38	android/support/v4/d/e:jf	[J
    //   22: aload_1
    //   23: aload_0
    //   24: getfield 40	android/support/v4/d/e:jg	[Ljava/lang/Object;
    //   27: invokevirtual 54	[Ljava/lang/Object;:clone	()Ljava/lang/Object;
    //   30: checkcast 53	[Ljava/lang/Object;
    //   33: putfield 40	android/support/v4/d/e:jg	[Ljava/lang/Object;
    //   36: aload_1
    //   37: areturn
    //   38: astore_1
    //   39: aconst_null
    //   40: areturn
    //   41: astore_2
    //   42: aload_1
    //   43: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   0	8	38	java/lang/CloneNotSupportedException
    //   8	36	41	java/lang/CloneNotSupportedException
  }

  private void gc()
  {
    int m = this.jh;
    long[] arrayOfLong = this.jf;
    Object[] arrayOfObject = this.jg;
    int i = 0;
    int k;
    for (int j = 0; i < m; j = k)
    {
      Object localObject = arrayOfObject[i];
      k = j;
      if (localObject != jd)
      {
        if (i != j)
        {
          arrayOfLong[j] = arrayOfLong[i];
          arrayOfObject[j] = localObject;
          arrayOfObject[i] = null;
        }
        k = j + 1;
      }
      i += 1;
    }
    this.je = false;
    this.jh = j;
  }

  private long keyAt(int paramInt)
  {
    if (this.je)
      gc();
    return this.jf[paramInt];
  }

  private E valueAt(int paramInt)
  {
    if (this.je)
      gc();
    return this.jg[paramInt];
  }

  public final void put(long paramLong, E paramE)
  {
    int i = b.a(this.jf, this.jh, paramLong);
    if (i >= 0)
    {
      this.jg[i] = paramE;
      return;
    }
    int j = i ^ 0xFFFFFFFF;
    if ((j < this.jh) && (this.jg[j] == jd))
    {
      this.jf[j] = paramLong;
      this.jg[j] = paramE;
      return;
    }
    i = j;
    if (this.je)
    {
      i = j;
      if (this.jh >= this.jf.length)
      {
        gc();
        i = b.a(this.jf, this.jh, paramLong) ^ 0xFFFFFFFF;
      }
    }
    if (this.jh >= this.jf.length)
    {
      j = b.r(this.jh + 1);
      long[] arrayOfLong = new long[j];
      Object[] arrayOfObject = new Object[j];
      System.arraycopy(this.jf, 0, arrayOfLong, 0, this.jf.length);
      System.arraycopy(this.jg, 0, arrayOfObject, 0, this.jg.length);
      this.jf = arrayOfLong;
      this.jg = arrayOfObject;
    }
    if (this.jh - i != 0)
    {
      System.arraycopy(this.jf, i, this.jf, i + 1, this.jh - i);
      System.arraycopy(this.jg, i, this.jg, i + 1, this.jh - i);
    }
    this.jf[i] = paramLong;
    this.jg[i] = paramE;
    this.jh += 1;
  }

  public final String toString()
  {
    if (this.je)
      gc();
    if (this.jh <= 0)
      return "{}";
    StringBuilder localStringBuilder = new StringBuilder(this.jh * 28);
    localStringBuilder.append('{');
    int i = 0;
    if (i < this.jh)
    {
      if (i > 0)
        localStringBuilder.append(", ");
      localStringBuilder.append(keyAt(i));
      localStringBuilder.append('=');
      Object localObject = valueAt(i);
      if (localObject != this)
        localStringBuilder.append(localObject);
      while (true)
      {
        i += 1;
        break;
        localStringBuilder.append("(this Map)");
      }
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.d.e
 * JD-Core Version:    0.6.2
 */