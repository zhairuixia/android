package android.support.v4.d;

import java.util.Map;

public class h<K, V>
{
  static Object[] jq;
  static int jr;
  static Object[] js;
  static int jt;
  int jh;
  int[] ju;
  Object[] jv;

  public h()
  {
    this.ju = b.iZ;
    this.jv = b.jb;
    this.jh = 0;
  }

  public h(int paramInt)
  {
    if (paramInt == 0)
    {
      this.ju = b.iZ;
      this.jv = b.jb;
    }
    while (true)
    {
      this.jh = 0;
      return;
      u(paramInt);
    }
  }

  static void a(int[] paramArrayOfInt, Object[] paramArrayOfObject, int paramInt)
  {
    if (paramArrayOfInt.length == 8)
      try
      {
        if (jt < 10)
        {
          paramArrayOfObject[0] = js;
          paramArrayOfObject[1] = paramArrayOfInt;
          paramInt = (paramInt << 1) - 1;
          break label117;
          js = paramArrayOfObject;
          jt += 1;
        }
        return;
      }
      finally
      {
      }
    else
      if (paramArrayOfInt.length != 4)
        break label133;
    while (true)
    {
      try
      {
        if (jr < 10)
        {
          paramArrayOfObject[0] = jq;
          paramArrayOfObject[1] = paramArrayOfInt;
          paramInt = (paramInt << 1) - 1;
          break label134;
          jq = paramArrayOfObject;
          jr += 1;
        }
        return;
      }
      finally
      {
      }
      label117: 
      while (paramInt >= 2)
      {
        paramArrayOfObject[paramInt] = null;
        paramInt -= 1;
      }
      break;
      label133: return;
      label134: 
      while (paramInt >= 2)
      {
        paramArrayOfObject[paramInt] = null;
        paramInt -= 1;
      }
    }
  }

  private int ay()
  {
    int m = this.jh;
    int i;
    if (m == 0)
      i = -1;
    int j;
    do
    {
      do
      {
        return i;
        j = b.a(this.ju, m, 0);
        i = j;
      }
      while (j < 0);
      i = j;
    }
    while (this.jv[(j << 1)] == null);
    int k = j + 1;
    while ((k < m) && (this.ju[k] == 0))
    {
      if (this.jv[(k << 1)] == null)
        return k;
      k += 1;
    }
    j -= 1;
    while (true)
    {
      if ((j < 0) || (this.ju[j] != 0))
        break label121;
      i = j;
      if (this.jv[(j << 1)] == null)
        break;
      j -= 1;
    }
    label121: return k ^ 0xFFFFFFFF;
  }

  private int indexOf(Object paramObject, int paramInt)
  {
    int m = this.jh;
    int i;
    if (m == 0)
      i = -1;
    int j;
    do
    {
      do
      {
        return i;
        j = b.a(this.ju, m, paramInt);
        i = j;
      }
      while (j < 0);
      i = j;
    }
    while (paramObject.equals(this.jv[(j << 1)]));
    int k = j + 1;
    while ((k < m) && (this.ju[k] == paramInt))
    {
      if (paramObject.equals(this.jv[(k << 1)]))
        return k;
      k += 1;
    }
    j -= 1;
    while (true)
    {
      if ((j < 0) || (this.ju[j] != paramInt))
        break label156;
      i = j;
      if (paramObject.equals(this.jv[(j << 1)]))
        break;
      j -= 1;
    }
    label156: return k ^ 0xFFFFFFFF;
  }

  public void clear()
  {
    if (this.jh != 0)
    {
      a(this.ju, this.jv, this.jh);
      this.ju = b.iZ;
      this.jv = b.jb;
      this.jh = 0;
    }
  }

  public boolean containsKey(Object paramObject)
  {
    return indexOfKey(paramObject) >= 0;
  }

  public boolean containsValue(Object paramObject)
  {
    return indexOfValue(paramObject) >= 0;
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject);
    while (true)
    {
      return true;
      if ((paramObject instanceof Map))
      {
        paramObject = (Map)paramObject;
        if (size() != paramObject.size())
          return false;
        int i = 0;
        try
        {
          while (i < this.jh)
          {
            Object localObject1 = keyAt(i);
            Object localObject2 = valueAt(i);
            Object localObject3 = paramObject.get(localObject1);
            if (localObject2 == null)
            {
              if (localObject3 != null)
                break label121;
              if (!paramObject.containsKey(localObject1))
                break label121;
            }
            else
            {
              boolean bool = localObject2.equals(localObject3);
              if (!bool)
                return false;
            }
            i += 1;
          }
        }
        catch (NullPointerException paramObject)
        {
          return false;
        }
        catch (ClassCastException paramObject)
        {
          return false;
        }
      }
    }
    return false;
    label121: return false;
  }

  public V get(Object paramObject)
  {
    int i = indexOfKey(paramObject);
    if (i >= 0)
      return this.jv[((i << 1) + 1)];
    return null;
  }

  public int hashCode()
  {
    int[] arrayOfInt = this.ju;
    Object[] arrayOfObject = this.jv;
    int n = this.jh;
    int i = 1;
    int j = 0;
    int k = 0;
    if (j < n)
    {
      Object localObject = arrayOfObject[i];
      int i1 = arrayOfInt[j];
      if (localObject == null);
      for (int m = 0; ; m = localObject.hashCode())
      {
        k += (m ^ i1);
        j += 1;
        i += 2;
        break;
      }
    }
    return k;
  }

  public final int indexOfKey(Object paramObject)
  {
    if (paramObject == null)
      return ay();
    return indexOf(paramObject, paramObject.hashCode());
  }

  final int indexOfValue(Object paramObject)
  {
    int i = 1;
    int j = 1;
    int k = this.jh * 2;
    Object[] arrayOfObject = this.jv;
    if (paramObject == null)
    {
      i = j;
      while (i < k)
      {
        if (arrayOfObject[i] == null)
          return i >> 1;
        i += 2;
      }
    }
    do
    {
      i += 2;
      if (i >= k)
        break;
    }
    while (!paramObject.equals(arrayOfObject[i]));
    return i >> 1;
    return -1;
  }

  public boolean isEmpty()
  {
    return this.jh <= 0;
  }

  public final K keyAt(int paramInt)
  {
    return this.jv[(paramInt << 1)];
  }

  public V put(K paramK, V paramV)
  {
    int k = 8;
    int i;
    int j;
    if (paramK == null)
    {
      i = ay();
      j = 0;
    }
    while (i >= 0)
    {
      i = (i << 1) + 1;
      paramK = this.jv[i];
      this.jv[i] = paramV;
      return paramK;
      j = paramK.hashCode();
      i = indexOf(paramK, j);
    }
    int m = i ^ 0xFFFFFFFF;
    if (this.jh >= this.ju.length)
    {
      if (this.jh < 8)
        break label267;
      i = this.jh + (this.jh >> 1);
    }
    while (true)
    {
      int[] arrayOfInt = this.ju;
      Object[] arrayOfObject = this.jv;
      u(i);
      if (this.ju.length > 0)
      {
        System.arraycopy(arrayOfInt, 0, this.ju, 0, arrayOfInt.length);
        System.arraycopy(arrayOfObject, 0, this.jv, 0, arrayOfObject.length);
      }
      a(arrayOfInt, arrayOfObject, this.jh);
      if (m < this.jh)
      {
        System.arraycopy(this.ju, m, this.ju, m + 1, this.jh - m);
        System.arraycopy(this.jv, m << 1, this.jv, m + 1 << 1, this.jh - m << 1);
      }
      this.ju[m] = j;
      this.jv[(m << 1)] = paramK;
      this.jv[((m << 1) + 1)] = paramV;
      this.jh += 1;
      return null;
      label267: i = k;
      if (this.jh < 4)
        i = 4;
    }
  }

  public V remove(Object paramObject)
  {
    int i = indexOfKey(paramObject);
    if (i >= 0)
      return removeAt(i);
    return null;
  }

  public final V removeAt(int paramInt)
  {
    int i = 8;
    Object localObject = this.jv[((paramInt << 1) + 1)];
    if (this.jh <= 1)
    {
      a(this.ju, this.jv, this.jh);
      this.ju = b.iZ;
      this.jv = b.jb;
      this.jh = 0;
    }
    int[] arrayOfInt;
    Object[] arrayOfObject;
    do
    {
      return localObject;
      if ((this.ju.length <= 8) || (this.jh >= this.ju.length / 3))
        break;
      if (this.jh > 8)
        i = this.jh + (this.jh >> 1);
      arrayOfInt = this.ju;
      arrayOfObject = this.jv;
      u(i);
      this.jh -= 1;
      if (paramInt > 0)
      {
        System.arraycopy(arrayOfInt, 0, this.ju, 0, paramInt);
        System.arraycopy(arrayOfObject, 0, this.jv, 0, paramInt << 1);
      }
    }
    while (paramInt >= this.jh);
    System.arraycopy(arrayOfInt, paramInt + 1, this.ju, paramInt, this.jh - paramInt);
    System.arraycopy(arrayOfObject, paramInt + 1 << 1, this.jv, paramInt << 1, this.jh - paramInt << 1);
    return localObject;
    this.jh -= 1;
    if (paramInt < this.jh)
    {
      System.arraycopy(this.ju, paramInt + 1, this.ju, paramInt, this.jh - paramInt);
      System.arraycopy(this.jv, paramInt + 1 << 1, this.jv, paramInt << 1, this.jh - paramInt << 1);
    }
    this.jv[(this.jh << 1)] = null;
    this.jv[((this.jh << 1) + 1)] = null;
    return localObject;
  }

  public final V setValueAt(int paramInt, V paramV)
  {
    paramInt = (paramInt << 1) + 1;
    Object localObject = this.jv[paramInt];
    this.jv[paramInt] = paramV;
    return localObject;
  }

  public int size()
  {
    return this.jh;
  }

  public String toString()
  {
    if (isEmpty())
      return "{}";
    StringBuilder localStringBuilder = new StringBuilder(this.jh * 28);
    localStringBuilder.append('{');
    int i = 0;
    if (i < this.jh)
    {
      if (i > 0)
        localStringBuilder.append(", ");
      Object localObject = keyAt(i);
      if (localObject != this)
      {
        localStringBuilder.append(localObject);
        label70: localStringBuilder.append('=');
        localObject = valueAt(i);
        if (localObject == this)
          break label111;
        localStringBuilder.append(localObject);
      }
      while (true)
      {
        i += 1;
        break;
        localStringBuilder.append("(this Map)");
        break label70;
        label111: localStringBuilder.append("(this Map)");
      }
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }

  final void u(int paramInt)
  {
    if (paramInt == 8);
    while (true)
    {
      try
      {
        if (js != null)
        {
          Object[] arrayOfObject1 = js;
          this.jv = arrayOfObject1;
          js = (Object[])arrayOfObject1[0];
          this.ju = ((int[])arrayOfObject1[1]);
          arrayOfObject1[1] = null;
          arrayOfObject1[0] = null;
          jt -= 1;
          return;
        }
        this.ju = new int[paramInt];
        this.jv = new Object[paramInt << 1];
        return;
      }
      finally
      {
      }
      if (paramInt == 4)
        try
        {
          if (jq != null)
          {
            Object[] arrayOfObject2 = jq;
            this.jv = arrayOfObject2;
            jq = (Object[])arrayOfObject2[0];
            this.ju = ((int[])arrayOfObject2[1]);
            arrayOfObject2[1] = null;
            arrayOfObject2[0] = null;
            jr -= 1;
            return;
          }
        }
        finally
        {
        }
    }
  }

  public final V valueAt(int paramInt)
  {
    return this.jv[((paramInt << 1) + 1)];
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.d.h
 * JD-Core Version:    0.6.2
 */