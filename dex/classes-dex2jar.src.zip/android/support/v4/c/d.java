package android.support.v4.c;

import android.os.Build.VERSION;
import android.text.TextUtils;
import java.util.Locale;

public final class d
{
  public static final Locale ROOT;
  private static final a iU;
  private static String iV;
  private static String iW;

  static
  {
    if (Build.VERSION.SDK_INT >= 17);
    for (iU = new b((byte)0); ; iU = new a((byte)0))
    {
      ROOT = new Locale("", "");
      iV = "Arab";
      iW = "Hebr";
      return;
    }
  }

  public static int getLayoutDirectionFromLocale(Locale paramLocale)
  {
    return iU.getLayoutDirectionFromLocale(paramLocale);
  }

  private static class a
  {
    public int getLayoutDirectionFromLocale(Locale paramLocale)
    {
      int j = 1;
      if ((paramLocale != null) && (!paramLocale.equals(d.ROOT)))
      {
        String str = a.a(paramLocale);
        int i;
        if (str == null)
        {
          i = j;
          switch (Character.getDirectionality(paramLocale.getDisplayName(paramLocale).charAt(0)))
          {
          default:
            i = 0;
          case 1:
          case 2:
          }
        }
        do
        {
          do
          {
            return i;
            i = j;
          }
          while (str.equalsIgnoreCase(d.aq()));
          i = j;
        }
        while (str.equalsIgnoreCase(d.ar()));
      }
      return 0;
    }
  }

  private static final class b extends d.a
  {
    private b()
    {
      super();
    }

    public final int getLayoutDirectionFromLocale(Locale paramLocale)
    {
      return TextUtils.getLayoutDirectionFromLocale(paramLocale);
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.c.d
 * JD-Core Version:    0.6.2
 */