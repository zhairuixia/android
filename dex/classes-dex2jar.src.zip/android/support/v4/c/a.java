package android.support.v4.c;

import android.os.Build.VERSION;
import java.util.Locale;

public final class a
{
  private static final a iR = new b();

  static
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 21)
    {
      iR = new d();
      return;
    }
    if (i >= 14)
    {
      iR = new c();
      return;
    }
  }

  public static String a(Locale paramLocale)
  {
    return iR.a(paramLocale);
  }

  static abstract interface a
  {
    public abstract String a(Locale paramLocale);
  }

  static final class b
    implements a.a
  {
    public final String a(Locale paramLocale)
    {
      return null;
    }
  }

  static final class c
    implements a.a
  {
    public final String a(Locale paramLocale)
    {
      return c.a(paramLocale);
    }
  }

  static final class d
    implements a.a
  {
    public final String a(Locale paramLocale)
    {
      return b.a(paramLocale);
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.c.a
 * JD-Core Version:    0.6.2
 */