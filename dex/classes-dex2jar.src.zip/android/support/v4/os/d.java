package android.support.v4.os;

import android.os.Parcel;
import android.os.Parcelable.ClassLoaderCreator;

final class d<T>
  implements Parcelable.ClassLoaderCreator<T>
{
  private final c<T> iL;

  public d(c<T> paramc)
  {
    this.iL = paramc;
  }

  public final T createFromParcel(Parcel paramParcel)
  {
    return this.iL.createFromParcel(paramParcel, null);
  }

  public final T createFromParcel(Parcel paramParcel, ClassLoader paramClassLoader)
  {
    return this.iL.createFromParcel(paramParcel, paramClassLoader);
  }

  public final T[] newArray(int paramInt)
  {
    return this.iL.newArray(paramInt);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.os.d
 * JD-Core Version:    0.6.2
 */