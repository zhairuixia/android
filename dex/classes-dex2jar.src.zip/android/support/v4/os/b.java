package android.support.v4.os;

import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable.Creator;

public final class b
{
  public static <T> Parcelable.Creator<T> a(c<T> paramc)
  {
    if (Build.VERSION.SDK_INT >= 13)
      return new d(paramc);
    return new a(paramc);
  }

  static final class a<T>
    implements Parcelable.Creator<T>
  {
    final c<T> iL;

    public a(c<T> paramc)
    {
      this.iL = paramc;
    }

    public final T createFromParcel(Parcel paramParcel)
    {
      return this.iL.createFromParcel(paramParcel, null);
    }

    public final T[] newArray(int paramInt)
    {
      return this.iL.newArray(paramInt);
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.os.b
 * JD-Core Version:    0.6.2
 */