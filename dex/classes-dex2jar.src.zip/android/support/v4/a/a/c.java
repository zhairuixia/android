package android.support.v4.a.a;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;

public abstract interface c
{
  public abstract void a(ColorStateList paramColorStateList);

  public abstract void a(PorterDuff.Mode paramMode);

  public abstract Drawable ak();

  public abstract void i(Drawable paramDrawable);

  public abstract void o(int paramInt);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.a.a.c
 * JD-Core Version:    0.6.2
 */