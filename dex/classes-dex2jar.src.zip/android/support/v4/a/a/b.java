package android.support.v4.a.a;

import android.graphics.drawable.Drawable;
import java.lang.reflect.Method;

final class b
{
  static Method hq;
  static boolean hr;
  private static Method hs;
  private static boolean ht;

  public static int h(Drawable paramDrawable)
  {
    if (!ht);
    try
    {
      Method localMethod = Drawable.class.getDeclaredMethod("getLayoutDirection", new Class[0]);
      hs = localMethod;
      localMethod.setAccessible(true);
      label27: ht = true;
      if (hs != null)
        try
        {
          int i = ((Integer)hs.invoke(paramDrawable, new Object[0])).intValue();
          return i;
        }
        catch (Exception paramDrawable)
        {
          hs = null;
        }
      return -1;
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      break label27;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.a.a.b
 * JD-Core Version:    0.6.2
 */