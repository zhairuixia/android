package android.support.v4.a.a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;

public final class a
{
  static final b hp = new a();

  static
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23)
    {
      hp = new h();
      return;
    }
    if (i >= 21)
    {
      hp = new g();
      return;
    }
    if (i >= 19)
    {
      hp = new f();
      return;
    }
    if (i >= 17)
    {
      hp = new e();
      return;
    }
    if (i >= 11)
    {
      hp = new d();
      return;
    }
    if (i >= 5)
    {
      hp = new c();
      return;
    }
  }

  public static void a(Drawable paramDrawable)
  {
    hp.a(paramDrawable);
  }

  public static void a(Drawable paramDrawable, float paramFloat1, float paramFloat2)
  {
    hp.a(paramDrawable, paramFloat1, paramFloat2);
  }

  public static void a(Drawable paramDrawable, int paramInt)
  {
    hp.a(paramDrawable, paramInt);
  }

  public static void a(Drawable paramDrawable, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    hp.a(paramDrawable, paramInt1, paramInt2, paramInt3, paramInt4);
  }

  public static void a(Drawable paramDrawable, ColorStateList paramColorStateList)
  {
    hp.a(paramDrawable, paramColorStateList);
  }

  public static void a(Drawable paramDrawable, Resources.Theme paramTheme)
  {
    hp.a(paramDrawable, paramTheme);
  }

  public static void a(Drawable paramDrawable, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
  {
    hp.a(paramDrawable, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
  }

  public static void a(Drawable paramDrawable, PorterDuff.Mode paramMode)
  {
    hp.a(paramDrawable, paramMode);
  }

  public static void a(Drawable paramDrawable, boolean paramBoolean)
  {
    hp.a(paramDrawable, paramBoolean);
  }

  public static void b(Drawable paramDrawable, int paramInt)
  {
    hp.b(paramDrawable, paramInt);
  }

  public static boolean b(Drawable paramDrawable)
  {
    return hp.b(paramDrawable);
  }

  public static int c(Drawable paramDrawable)
  {
    return hp.c(paramDrawable);
  }

  public static boolean d(Drawable paramDrawable)
  {
    return hp.d(paramDrawable);
  }

  public static ColorFilter e(Drawable paramDrawable)
  {
    return hp.e(paramDrawable);
  }

  public static Drawable f(Drawable paramDrawable)
  {
    return hp.f(paramDrawable);
  }

  public static <T extends Drawable> T g(Drawable paramDrawable)
  {
    Drawable localDrawable = paramDrawable;
    if ((paramDrawable instanceof c))
      localDrawable = ((c)paramDrawable).ak();
    return localDrawable;
  }

  public static int h(Drawable paramDrawable)
  {
    return hp.h(paramDrawable);
  }

  static class a
    implements a.b
  {
    public void a(Drawable paramDrawable)
    {
    }

    public void a(Drawable paramDrawable, float paramFloat1, float paramFloat2)
    {
    }

    public void a(Drawable paramDrawable, int paramInt)
    {
      if ((paramDrawable instanceof c))
        ((c)paramDrawable).o(paramInt);
    }

    public void a(Drawable paramDrawable, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
    }

    public void a(Drawable paramDrawable, ColorStateList paramColorStateList)
    {
      if ((paramDrawable instanceof c))
        ((c)paramDrawable).a(paramColorStateList);
    }

    public void a(Drawable paramDrawable, Resources.Theme paramTheme)
    {
    }

    public void a(Drawable paramDrawable, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
    {
      paramDrawable.inflate(paramResources, paramXmlPullParser, paramAttributeSet);
    }

    public void a(Drawable paramDrawable, PorterDuff.Mode paramMode)
    {
      if ((paramDrawable instanceof c))
        ((c)paramDrawable).a(paramMode);
    }

    public void a(Drawable paramDrawable, boolean paramBoolean)
    {
    }

    public void b(Drawable paramDrawable, int paramInt)
    {
    }

    public boolean b(Drawable paramDrawable)
    {
      return false;
    }

    public int c(Drawable paramDrawable)
    {
      return 0;
    }

    public boolean d(Drawable paramDrawable)
    {
      return false;
    }

    public ColorFilter e(Drawable paramDrawable)
    {
      return null;
    }

    public Drawable f(Drawable paramDrawable)
    {
      Object localObject = paramDrawable;
      if (!(paramDrawable instanceof d))
        localObject = new d(paramDrawable);
      return localObject;
    }

    public int h(Drawable paramDrawable)
    {
      return 0;
    }
  }

  static abstract interface b
  {
    public abstract void a(Drawable paramDrawable);

    public abstract void a(Drawable paramDrawable, float paramFloat1, float paramFloat2);

    public abstract void a(Drawable paramDrawable, int paramInt);

    public abstract void a(Drawable paramDrawable, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

    public abstract void a(Drawable paramDrawable, ColorStateList paramColorStateList);

    public abstract void a(Drawable paramDrawable, Resources.Theme paramTheme);

    public abstract void a(Drawable paramDrawable, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme);

    public abstract void a(Drawable paramDrawable, PorterDuff.Mode paramMode);

    public abstract void a(Drawable paramDrawable, boolean paramBoolean);

    public abstract void b(Drawable paramDrawable, int paramInt);

    public abstract boolean b(Drawable paramDrawable);

    public abstract int c(Drawable paramDrawable);

    public abstract boolean d(Drawable paramDrawable);

    public abstract ColorFilter e(Drawable paramDrawable);

    public abstract Drawable f(Drawable paramDrawable);

    public abstract int h(Drawable paramDrawable);
  }

  static class c extends a.a
  {
    public Drawable f(Drawable paramDrawable)
    {
      Object localObject = paramDrawable;
      if (!(paramDrawable instanceof e))
        localObject = new e(paramDrawable);
      return localObject;
    }
  }

  static class d extends a.c
  {
    public final void a(Drawable paramDrawable)
    {
      paramDrawable.jumpToCurrentState();
    }

    public Drawable f(Drawable paramDrawable)
    {
      Object localObject = paramDrawable;
      if (!(paramDrawable instanceof f))
        localObject = new f(paramDrawable);
      return localObject;
    }
  }

  static class e extends a.d
  {
    public void b(Drawable paramDrawable, int paramInt)
    {
      if (!b.hr);
      try
      {
        Method localMethod = Drawable.class.getDeclaredMethod("setLayoutDirection", new Class[] { Integer.TYPE });
        b.hq = localMethod;
        localMethod.setAccessible(true);
        label33: b.hr = true;
        if (b.hq != null);
        try
        {
          b.hq.invoke(paramDrawable, new Object[] { Integer.valueOf(paramInt) });
          return;
        }
        catch (Exception paramDrawable)
        {
          b.hq = null;
          return;
        }
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        break label33;
      }
    }

    public int h(Drawable paramDrawable)
    {
      int i = b.h(paramDrawable);
      if (i >= 0)
        return i;
      return 0;
    }
  }

  static class f extends a.e
  {
    public final void a(Drawable paramDrawable, boolean paramBoolean)
    {
      paramDrawable.setAutoMirrored(paramBoolean);
    }

    public final boolean b(Drawable paramDrawable)
    {
      return paramDrawable.isAutoMirrored();
    }

    public final int c(Drawable paramDrawable)
    {
      return paramDrawable.getAlpha();
    }

    public Drawable f(Drawable paramDrawable)
    {
      Object localObject = paramDrawable;
      if (!(paramDrawable instanceof g))
        localObject = new g(paramDrawable);
      return localObject;
    }
  }

  static class g extends a.f
  {
    public final void a(Drawable paramDrawable, float paramFloat1, float paramFloat2)
    {
      paramDrawable.setHotspot(paramFloat1, paramFloat2);
    }

    public final void a(Drawable paramDrawable, int paramInt)
    {
      paramDrawable.setTint(paramInt);
    }

    public final void a(Drawable paramDrawable, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      paramDrawable.setHotspotBounds(paramInt1, paramInt2, paramInt3, paramInt4);
    }

    public final void a(Drawable paramDrawable, ColorStateList paramColorStateList)
    {
      paramDrawable.setTintList(paramColorStateList);
    }

    public final void a(Drawable paramDrawable, Resources.Theme paramTheme)
    {
      paramDrawable.applyTheme(paramTheme);
    }

    public final void a(Drawable paramDrawable, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme)
    {
      paramDrawable.inflate(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
    }

    public final void a(Drawable paramDrawable, PorterDuff.Mode paramMode)
    {
      paramDrawable.setTintMode(paramMode);
    }

    public final boolean d(Drawable paramDrawable)
    {
      return paramDrawable.canApplyTheme();
    }

    public final ColorFilter e(Drawable paramDrawable)
    {
      return paramDrawable.getColorFilter();
    }

    public Drawable f(Drawable paramDrawable)
    {
      Object localObject = paramDrawable;
      if (!(paramDrawable instanceof h))
        localObject = new h(paramDrawable);
      return localObject;
    }
  }

  static final class h extends a.g
  {
    public final void b(Drawable paramDrawable, int paramInt)
    {
      paramDrawable.setLayoutDirection(paramInt);
    }

    public final Drawable f(Drawable paramDrawable)
    {
      return paramDrawable;
    }

    public final int h(Drawable paramDrawable)
    {
      return paramDrawable.getLayoutDirection();
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.a.a.a
 * JD-Core Version:    0.6.2
 */