package android.support.v4.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

public abstract interface r
{
  public abstract void c(ColorStateList paramColorStateList);

  public abstract void c(PorterDuff.Mode paramMode);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.r
 * JD-Core Version:    0.6.2
 */