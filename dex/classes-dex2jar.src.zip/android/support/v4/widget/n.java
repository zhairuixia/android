package android.support.v4.widget;

import android.widget.PopupWindow;
import java.lang.reflect.Field;

final class n
{
  private static Field qn;

  static
  {
    try
    {
      Field localField = PopupWindow.class.getDeclaredField("mOverlapAnchor");
      qn = localField;
      localField.setAccessible(true);
      return;
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
    }
  }

  static void a(PopupWindow paramPopupWindow, boolean paramBoolean)
  {
    if (qn != null);
    try
    {
      qn.set(paramPopupWindow, Boolean.valueOf(paramBoolean));
      return;
    }
    catch (IllegalAccessException paramPopupWindow)
    {
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.n
 * JD-Core Version:    0.6.2
 */