package android.support.v4.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.widget.CompoundButton;

public final class c
{
  private static final c nS = new b();

  static
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23)
    {
      nS = new a();
      return;
    }
    if (i >= 21)
    {
      nS = new d();
      return;
    }
  }

  public static Drawable a(CompoundButton paramCompoundButton)
  {
    return nS.a(paramCompoundButton);
  }

  public static void a(CompoundButton paramCompoundButton, ColorStateList paramColorStateList)
  {
    nS.a(paramCompoundButton, paramColorStateList);
  }

  public static void a(CompoundButton paramCompoundButton, PorterDuff.Mode paramMode)
  {
    nS.a(paramCompoundButton, paramMode);
  }

  static final class a extends c.d
  {
    public final Drawable a(CompoundButton paramCompoundButton)
    {
      return paramCompoundButton.getButtonDrawable();
    }
  }

  static class b
    implements c.c
  {
    public Drawable a(CompoundButton paramCompoundButton)
    {
      return d.a(paramCompoundButton);
    }

    public void a(CompoundButton paramCompoundButton, ColorStateList paramColorStateList)
    {
      if ((paramCompoundButton instanceof r))
        ((r)paramCompoundButton).c(paramColorStateList);
    }

    public void a(CompoundButton paramCompoundButton, PorterDuff.Mode paramMode)
    {
      if ((paramCompoundButton instanceof r))
        ((r)paramCompoundButton).c(paramMode);
    }
  }

  static abstract interface c
  {
    public abstract Drawable a(CompoundButton paramCompoundButton);

    public abstract void a(CompoundButton paramCompoundButton, ColorStateList paramColorStateList);

    public abstract void a(CompoundButton paramCompoundButton, PorterDuff.Mode paramMode);
  }

  static class d extends c.b
  {
    public final void a(CompoundButton paramCompoundButton, ColorStateList paramColorStateList)
    {
      paramCompoundButton.setButtonTintList(paramColorStateList);
    }

    public final void a(CompoundButton paramCompoundButton, PorterDuff.Mode paramMode)
    {
      paramCompoundButton.setButtonTintMode(paramMode);
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.c
 * JD-Core Version:    0.6.2
 */