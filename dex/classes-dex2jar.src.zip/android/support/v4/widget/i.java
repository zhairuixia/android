package android.support.v4.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Build.VERSION;
import android.widget.EdgeEffect;

public final class i
{
  private static final c pi = new a();
  private Object ph;

  static
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      pi = new d();
      return;
    }
    if (Build.VERSION.SDK_INT >= 14)
    {
      pi = new b();
      return;
    }
  }

  public i(Context paramContext)
  {
    this.ph = pi.k(paramContext);
  }

  public final boolean I(int paramInt)
  {
    return pi.l(this.ph, paramInt);
  }

  public final boolean bj()
  {
    return pi.H(this.ph);
  }

  public final boolean draw(Canvas paramCanvas)
  {
    return pi.a(this.ph, paramCanvas);
  }

  public final boolean e(float paramFloat1, float paramFloat2)
  {
    return pi.a(this.ph, paramFloat1, paramFloat2);
  }

  public final void finish()
  {
    pi.G(this.ph);
  }

  public final boolean h(float paramFloat)
  {
    return pi.a(this.ph, paramFloat);
  }

  public final boolean isFinished()
  {
    return pi.F(this.ph);
  }

  public final void setSize(int paramInt1, int paramInt2)
  {
    pi.a(this.ph, paramInt1, paramInt2);
  }

  static final class a
    implements i.c
  {
    public final boolean F(Object paramObject)
    {
      return true;
    }

    public final void G(Object paramObject)
    {
    }

    public final boolean H(Object paramObject)
    {
      return false;
    }

    public final void a(Object paramObject, int paramInt1, int paramInt2)
    {
    }

    public final boolean a(Object paramObject, float paramFloat)
    {
      return false;
    }

    public final boolean a(Object paramObject, float paramFloat1, float paramFloat2)
    {
      return false;
    }

    public final boolean a(Object paramObject, Canvas paramCanvas)
    {
      return false;
    }

    public final Object k(Context paramContext)
    {
      return null;
    }

    public final boolean l(Object paramObject, int paramInt)
    {
      return false;
    }
  }

  static class b
    implements i.c
  {
    public final boolean F(Object paramObject)
    {
      return ((EdgeEffect)paramObject).isFinished();
    }

    public final void G(Object paramObject)
    {
      ((EdgeEffect)paramObject).finish();
    }

    public final boolean H(Object paramObject)
    {
      paramObject = (EdgeEffect)paramObject;
      paramObject.onRelease();
      return paramObject.isFinished();
    }

    public final void a(Object paramObject, int paramInt1, int paramInt2)
    {
      ((EdgeEffect)paramObject).setSize(paramInt1, paramInt2);
    }

    public final boolean a(Object paramObject, float paramFloat)
    {
      return j.a(paramObject, paramFloat);
    }

    public boolean a(Object paramObject, float paramFloat1, float paramFloat2)
    {
      return j.a(paramObject, paramFloat1);
    }

    public final boolean a(Object paramObject, Canvas paramCanvas)
    {
      return ((EdgeEffect)paramObject).draw(paramCanvas);
    }

    public final Object k(Context paramContext)
    {
      return new EdgeEffect(paramContext);
    }

    public final boolean l(Object paramObject, int paramInt)
    {
      ((EdgeEffect)paramObject).onAbsorb(paramInt);
      return true;
    }
  }

  static abstract interface c
  {
    public abstract boolean F(Object paramObject);

    public abstract void G(Object paramObject);

    public abstract boolean H(Object paramObject);

    public abstract void a(Object paramObject, int paramInt1, int paramInt2);

    public abstract boolean a(Object paramObject, float paramFloat);

    public abstract boolean a(Object paramObject, float paramFloat1, float paramFloat2);

    public abstract boolean a(Object paramObject, Canvas paramCanvas);

    public abstract Object k(Context paramContext);

    public abstract boolean l(Object paramObject, int paramInt);
  }

  static final class d extends i.b
  {
    public final boolean a(Object paramObject, float paramFloat1, float paramFloat2)
    {
      ((EdgeEffect)paramObject).onPull(paramFloat1, paramFloat2);
      return true;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.i
 * JD-Core Version:    0.6.2
 */