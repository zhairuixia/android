package android.support.v4.widget;

import android.content.res.Resources;
import android.support.v4.view.n;
import android.support.v4.view.y;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;

public abstract class a
  implements View.OnTouchListener
{
  private static final int nA = ViewConfiguration.getTapTimeout();
  private final a nj = new a();
  private final Interpolator nk = new AccelerateInterpolator();
  private final View nl;
  private Runnable nm;
  private float[] nn = { 0.0F, 0.0F };
  private float[] no = { 3.4028235E+38F, 3.4028235E+38F };
  private int np;
  private int nq;
  private float[] nr = { 0.0F, 0.0F };
  private float[] ns = { 0.0F, 0.0F };
  private float[] nt = { 3.4028235E+38F, 3.4028235E+38F };
  private boolean nu;
  private boolean nv;
  private boolean nw;
  private boolean nx;
  private boolean ny;
  private boolean nz;

  public a(View paramView)
  {
    this.nl = paramView;
    paramView = Resources.getSystem().getDisplayMetrics();
    int i = (int)(1575.0F * paramView.density + 0.5F);
    int j = (int)(paramView.density * 315.0F + 0.5F);
    float f = i;
    this.nt[0] = (f / 1000.0F);
    this.nt[1] = (f / 1000.0F);
    f = j;
    this.ns[0] = (f / 1000.0F);
    this.ns[1] = (f / 1000.0F);
    this.np = 1;
    this.no[0] = 3.4028235E+38F;
    this.no[1] = 3.4028235E+38F;
    this.nn[0] = 0.2F;
    this.nn[1] = 0.2F;
    this.nr[0] = 0.001F;
    this.nr[1] = 0.001F;
    this.nq = nA;
    this.nj.nB = 500;
    this.nj.nC = 500;
  }

  private float a(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3)
  {
    float f1 = b(this.nn[paramInt] * paramFloat2, 0.0F, this.no[paramInt]);
    float f2 = d(paramFloat1, f1);
    paramFloat1 = d(paramFloat2 - paramFloat1, f1) - f2;
    if (paramFloat1 < 0.0F)
      paramFloat1 = -this.nk.getInterpolation(-paramFloat1);
    for (paramFloat1 = b(paramFloat1, -1.0F, 1.0F); ; paramFloat1 = 0.0F)
    {
      if (paramFloat1 != 0.0F)
        break label102;
      return 0.0F;
      if (paramFloat1 > 0.0F)
      {
        paramFloat1 = this.nk.getInterpolation(paramFloat1);
        break;
      }
    }
    label102: f2 = this.nr[paramInt];
    paramFloat2 = this.ns[paramInt];
    f1 = this.nt[paramInt];
    paramFloat3 = f2 * paramFloat3;
    if (paramFloat1 > 0.0F)
      return b(paramFloat1 * paramFloat3, paramFloat2, f1);
    return -b(-paramFloat1 * paramFloat3, paramFloat2, f1);
  }

  private static float b(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    if (paramFloat1 > paramFloat3)
      return paramFloat3;
    if (paramFloat1 < paramFloat2)
      return paramFloat2;
    return paramFloat1;
  }

  private boolean ba()
  {
    a locala = this.nj;
    int i = (int)(locala.nE / Math.abs(locala.nE));
    int j = (int)(locala.nD / Math.abs(locala.nD));
    if ((i == 0) || (!F(i)))
    {
      if (j != 0);
      return false;
    }
    return true;
  }

  private void bb()
  {
    if (this.nv)
    {
      this.nx = false;
      return;
    }
    a locala = this.nj;
    long l = AnimationUtils.currentAnimationTimeMillis();
    int i = (int)(l - locala.mStartTime);
    int j = locala.nC;
    if (i > j)
      i = j;
    while (true)
    {
      locala.nK = i;
      locala.nJ = locala.e(l);
      locala.nI = l;
      return;
      if (i < 0)
        i = 0;
    }
  }

  private float d(float paramFloat1, float paramFloat2)
  {
    if (paramFloat2 == 0.0F);
    do
    {
      do
      {
        do
        {
          return 0.0F;
          switch (this.np)
          {
          default:
            return 0.0F;
          case 0:
          case 1:
          case 2:
          }
        }
        while (paramFloat1 >= paramFloat2);
        if (paramFloat1 >= 0.0F)
          return 1.0F - paramFloat1 / paramFloat2;
      }
      while ((!this.nx) || (this.np != 1));
      return 1.0F;
    }
    while (paramFloat1 >= 0.0F);
    return paramFloat1 / -paramFloat2;
  }

  public abstract void E(int paramInt);

  public abstract boolean F(int paramInt);

  public final a l(boolean paramBoolean)
  {
    if ((this.ny) && (!paramBoolean))
      bb();
    this.ny = paramBoolean;
    return this;
  }

  public boolean onTouch(View paramView, MotionEvent paramMotionEvent)
  {
    if (!this.ny);
    while (true)
    {
      return false;
      switch (n.d(paramMotionEvent))
      {
      default:
      case 0:
      case 2:
      case 1:
      case 3:
      }
      while ((this.nz) && (this.nx))
      {
        return true;
        this.nw = true;
        this.nu = false;
        float f1 = a(0, paramMotionEvent.getX(), paramView.getWidth(), this.nl.getWidth());
        float f2 = a(1, paramMotionEvent.getY(), paramView.getHeight(), this.nl.getHeight());
        paramView = this.nj;
        paramView.nD = f1;
        paramView.nE = f2;
        if ((!this.nx) && (ba()))
        {
          if (this.nm == null)
            this.nm = new b((byte)0);
          this.nx = true;
          this.nv = true;
          if ((!this.nu) && (this.nq > 0))
            y.a(this.nl, this.nm, this.nq);
          while (true)
          {
            this.nu = true;
            break;
            this.nm.run();
          }
          bb();
        }
      }
    }
  }

  private static final class a
  {
    long mStartTime = -9223372036854775808L;
    int nB;
    int nC;
    float nD;
    float nE;
    long nF = 0L;
    int nG = 0;
    int nH = 0;
    long nI = -1L;
    float nJ;
    int nK;

    final float e(long paramLong)
    {
      if (paramLong < this.mStartTime)
        return 0.0F;
      if ((this.nI < 0L) || (paramLong < this.nI))
        return a.g((float)(paramLong - this.mStartTime) / this.nB) * 0.5F;
      long l = this.nI;
      float f1 = this.nJ;
      float f2 = this.nJ;
      return a.g((float)(paramLong - l) / this.nK) * f2 + (1.0F - f1);
    }
  }

  private final class b
    implements Runnable
  {
    private b()
    {
    }

    public final void run()
    {
      int j = 0;
      if (!a.a(a.this))
        return;
      if (a.b(a.this))
      {
        a.c(a.this);
        locala = a.d(a.this);
        locala.mStartTime = AnimationUtils.currentAnimationTimeMillis();
        locala.nI = -1L;
        locala.nF = locala.mStartTime;
        locala.nJ = 0.5F;
        locala.nG = 0;
        locala.nH = 0;
      }
      a.a locala = a.d(a.this);
      int i = j;
      if (locala.nI > 0L)
      {
        i = j;
        if (AnimationUtils.currentAnimationTimeMillis() > locala.nI + locala.nK)
          i = 1;
      }
      if ((i != 0) || (!a.e(a.this)))
      {
        a.f(a.this);
        return;
      }
      if (a.g(a.this))
      {
        a.h(a.this);
        a.i(a.this);
      }
      if (locala.nF == 0L)
        throw new RuntimeException("Cannot compute scroll delta before calling start()");
      long l1 = AnimationUtils.currentAnimationTimeMillis();
      float f = locala.e(l1);
      f = f * 4.0F + -4.0F * f * f;
      long l2 = l1 - locala.nF;
      locala.nF = l1;
      locala.nG = ((int)((float)l2 * f * locala.nD));
      locala.nH = ((int)(f * (float)l2 * locala.nE));
      i = locala.nH;
      a.this.E(i);
      y.a(a.j(a.this), this);
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.a
 * JD-Core Version:    0.6.2
 */