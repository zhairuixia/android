package android.support.v4.widget;

import android.graphics.drawable.Drawable;
import android.widget.CompoundButton;
import java.lang.reflect.Field;

final class d
{
  private static Field nT;
  private static boolean nU;

  static Drawable a(CompoundButton paramCompoundButton)
  {
    if (!nU);
    try
    {
      Field localField = CompoundButton.class.getDeclaredField("mButtonDrawable");
      nT = localField;
      localField.setAccessible(true);
      label23: nU = true;
      if (nT != null)
        try
        {
          paramCompoundButton = (Drawable)nT.get(paramCompoundButton);
          return paramCompoundButton;
        }
        catch (IllegalAccessException paramCompoundButton)
        {
          nT = null;
        }
      return null;
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      break label23;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.d
 * JD-Core Version:    0.6.2
 */