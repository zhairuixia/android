package android.support.v4.widget;

import android.os.Build.VERSION;
import android.view.View;
import android.widget.PopupWindow;
import java.lang.reflect.Method;

public final class m
{
  static final f qm = new c();

  static
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23)
    {
      qm = new b();
      return;
    }
    if (i >= 21)
    {
      qm = new a();
      return;
    }
    if (i >= 19)
    {
      qm = new e();
      return;
    }
    if (i >= 9)
    {
      qm = new d();
      return;
    }
  }

  public static void a(PopupWindow paramPopupWindow, int paramInt)
  {
    qm.a(paramPopupWindow, paramInt);
  }

  public static void a(PopupWindow paramPopupWindow, View paramView, int paramInt1, int paramInt2, int paramInt3)
  {
    qm.a(paramPopupWindow, paramView, paramInt1, paramInt2, paramInt3);
  }

  public static void a(PopupWindow paramPopupWindow, boolean paramBoolean)
  {
    qm.a(paramPopupWindow, paramBoolean);
  }

  static class a extends m.e
  {
    public void a(PopupWindow paramPopupWindow, boolean paramBoolean)
    {
      n.a(paramPopupWindow, paramBoolean);
    }
  }

  static final class b extends m.a
  {
    public final void a(PopupWindow paramPopupWindow, int paramInt)
    {
      paramPopupWindow.setWindowLayoutType(paramInt);
    }

    public final void a(PopupWindow paramPopupWindow, boolean paramBoolean)
    {
      paramPopupWindow.setOverlapAnchor(paramBoolean);
    }
  }

  static class c
    implements m.f
  {
    public void a(PopupWindow paramPopupWindow, int paramInt)
    {
    }

    public void a(PopupWindow paramPopupWindow, View paramView, int paramInt1, int paramInt2, int paramInt3)
    {
      paramPopupWindow.showAsDropDown(paramView, paramInt1, paramInt2);
    }

    public void a(PopupWindow paramPopupWindow, boolean paramBoolean)
    {
    }
  }

  static class d extends m.c
  {
    public void a(PopupWindow paramPopupWindow, int paramInt)
    {
      if (!o.qp);
      try
      {
        Method localMethod = PopupWindow.class.getDeclaredMethod("setWindowLayoutType", new Class[] { Integer.TYPE });
        o.qo = localMethod;
        localMethod.setAccessible(true);
        label33: o.qp = true;
        if (o.qo != null);
        try
        {
          o.qo.invoke(paramPopupWindow, new Object[] { Integer.valueOf(paramInt) });
          return;
        }
        catch (Exception paramPopupWindow)
        {
        }
      }
      catch (Exception localException)
      {
        break label33;
      }
    }
  }

  static class e extends m.d
  {
    public final void a(PopupWindow paramPopupWindow, View paramView, int paramInt1, int paramInt2, int paramInt3)
    {
      paramPopupWindow.showAsDropDown(paramView, paramInt1, paramInt2, paramInt3);
    }
  }

  static abstract interface f
  {
    public abstract void a(PopupWindow paramPopupWindow, int paramInt);

    public abstract void a(PopupWindow paramPopupWindow, View paramView, int paramInt1, int paramInt2, int paramInt3);

    public abstract void a(PopupWindow paramPopupWindow, boolean paramBoolean);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.m
 * JD-Core Version:    0.6.2
 */