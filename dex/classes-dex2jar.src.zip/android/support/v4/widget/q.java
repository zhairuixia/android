package android.support.v4.widget;

import android.content.Context;
import android.os.Build.VERSION;
import android.view.animation.Interpolator;
import android.widget.OverScroller;
import android.widget.Scroller;

public final class q
{
  public Object qt;
  public a qu;

  private q(int paramInt, Context paramContext, Interpolator paramInterpolator)
  {
    if (paramInt >= 14)
      this.qu = new d();
    while (true)
    {
      this.qt = this.qu.b(paramContext, paramInterpolator);
      return;
      if (paramInt >= 9)
        this.qu = new c();
      else
        this.qu = new b();
    }
  }

  public static q a(Context paramContext, Interpolator paramInterpolator)
  {
    return new q(Build.VERSION.SDK_INT, paramContext, paramInterpolator);
  }

  public final void abortAnimation()
  {
    this.qu.M(this.qt);
  }

  public final boolean computeScrollOffset()
  {
    return this.qu.L(this.qt);
  }

  public final boolean d(int paramInt1, int paramInt2, int paramInt3)
  {
    return this.qu.a(this.qt, paramInt1, paramInt2, 0, 0, 0, paramInt3);
  }

  public final float getCurrVelocity()
  {
    return this.qu.K(this.qt);
  }

  public final int getCurrX()
  {
    return this.qu.I(this.qt);
  }

  public final int getCurrY()
  {
    return this.qu.J(this.qt);
  }

  public final int getFinalX()
  {
    return this.qu.N(this.qt);
  }

  public final int getFinalY()
  {
    return this.qu.O(this.qt);
  }

  public final boolean isFinished()
  {
    return this.qu.F(this.qt);
  }

  public final void startScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    this.qu.a(this.qt, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
  }

  public static abstract interface a
  {
    public abstract boolean F(Object paramObject);

    public abstract int I(Object paramObject);

    public abstract int J(Object paramObject);

    public abstract float K(Object paramObject);

    public abstract boolean L(Object paramObject);

    public abstract void M(Object paramObject);

    public abstract int N(Object paramObject);

    public abstract int O(Object paramObject);

    public abstract void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

    public abstract void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);

    public abstract void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);

    public abstract void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10);

    public abstract boolean a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);

    public abstract Object b(Context paramContext, Interpolator paramInterpolator);
  }

  static final class b
    implements q.a
  {
    public final boolean F(Object paramObject)
    {
      return ((Scroller)paramObject).isFinished();
    }

    public final int I(Object paramObject)
    {
      return ((Scroller)paramObject).getCurrX();
    }

    public final int J(Object paramObject)
    {
      return ((Scroller)paramObject).getCurrY();
    }

    public final float K(Object paramObject)
    {
      return 0.0F;
    }

    public final boolean L(Object paramObject)
    {
      return ((Scroller)paramObject).computeScrollOffset();
    }

    public final void M(Object paramObject)
    {
      ((Scroller)paramObject).abortAnimation();
    }

    public final int N(Object paramObject)
    {
      return ((Scroller)paramObject).getFinalX();
    }

    public final int O(Object paramObject)
    {
      return ((Scroller)paramObject).getFinalY();
    }

    public final void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      ((Scroller)paramObject).startScroll(paramInt1, paramInt2, 0, paramInt4);
    }

    public final void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
    {
      ((Scroller)paramObject).startScroll(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }

    public final void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
    {
      ((Scroller)paramObject).fling(0, 0, 0, paramInt4, 0, 0, -2147483648, 2147483647);
    }

    public final void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10)
    {
      ((Scroller)paramObject).fling(paramInt1, paramInt2, 0, paramInt4, 0, 0, 0, paramInt8);
    }

    public final boolean a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
    {
      return false;
    }

    public final Object b(Context paramContext, Interpolator paramInterpolator)
    {
      if (paramInterpolator != null)
        return new Scroller(paramContext, paramInterpolator);
      return new Scroller(paramContext);
    }
  }

  static class c
    implements q.a
  {
    public final boolean F(Object paramObject)
    {
      return ((OverScroller)paramObject).isFinished();
    }

    public final int I(Object paramObject)
    {
      return ((OverScroller)paramObject).getCurrX();
    }

    public final int J(Object paramObject)
    {
      return ((OverScroller)paramObject).getCurrY();
    }

    public float K(Object paramObject)
    {
      return 0.0F;
    }

    public final boolean L(Object paramObject)
    {
      return ((OverScroller)paramObject).computeScrollOffset();
    }

    public final void M(Object paramObject)
    {
      ((OverScroller)paramObject).abortAnimation();
    }

    public final int N(Object paramObject)
    {
      return ((OverScroller)paramObject).getFinalX();
    }

    public final int O(Object paramObject)
    {
      return ((OverScroller)paramObject).getFinalY();
    }

    public final void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      ((OverScroller)paramObject).startScroll(paramInt1, paramInt2, 0, paramInt4);
    }

    public final void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
    {
      ((OverScroller)paramObject).startScroll(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }

    public final void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
    {
      ((OverScroller)paramObject).fling(0, 0, 0, paramInt4, 0, 0, -2147483648, 2147483647);
    }

    public final void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10)
    {
      ((OverScroller)paramObject).fling(paramInt1, paramInt2, 0, paramInt4, 0, 0, 0, paramInt8, 0, paramInt10);
    }

    public final boolean a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
    {
      return ((OverScroller)paramObject).springBack(paramInt1, paramInt2, 0, 0, 0, paramInt6);
    }

    public final Object b(Context paramContext, Interpolator paramInterpolator)
    {
      if (paramInterpolator != null)
        return new OverScroller(paramContext, paramInterpolator);
      return new OverScroller(paramContext);
    }
  }

  static final class d extends q.c
  {
    public final float K(Object paramObject)
    {
      return ((OverScroller)paramObject).getCurrVelocity();
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.q
 * JD-Core Version:    0.6.2
 */