package android.support.v4.content;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.SparseArray;

public abstract class WakefulBroadcastReceiver extends BroadcastReceiver
{
  private static final SparseArray<PowerManager.WakeLock> hm = new SparseArray();
  private static int hn = 1;

  public static ComponentName a(Context paramContext, Intent paramIntent)
  {
    synchronized (hm)
    {
      int i = hn;
      int j = hn + 1;
      hn = j;
      if (j <= 0)
        hn = 1;
      paramIntent.putExtra("android.support.content.wakelockid", i);
      paramIntent = paramContext.startService(paramIntent);
      if (paramIntent == null)
        return null;
      paramContext = ((PowerManager)paramContext.getSystemService("power")).newWakeLock(1, "wake:" + paramIntent.flattenToShortString());
      paramContext.setReferenceCounted(false);
      paramContext.acquire(60000L);
      hm.put(i, paramContext);
      return paramIntent;
    }
  }

  public static boolean a(Intent arg0)
  {
    int i = ???.getIntExtra("android.support.content.wakelockid", 0);
    if (i == 0)
      return false;
    synchronized (hm)
    {
      PowerManager.WakeLock localWakeLock = (PowerManager.WakeLock)hm.get(i);
      if (localWakeLock != null)
      {
        localWakeLock.release();
        hm.remove(i);
        return true;
      }
      return true;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.content.WakefulBroadcastReceiver
 * JD-Core Version:    0.6.2
 */