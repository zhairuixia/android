package android.support.v4.content;

import android.content.Context;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class c<D>
{
  public boolean fi = false;
  public int fk;
  public b<D> hg;
  public a<D> hh;
  public boolean hi = false;
  public boolean hj = true;
  public boolean hk = false;
  public boolean hl = false;
  Context mContext;

  public c(Context paramContext)
  {
    this.mContext = paramContext.getApplicationContext();
  }

  public final void a(a<D> parama)
  {
    if (this.hh == null)
      throw new IllegalStateException("No listener register");
    if (this.hh != parama)
      throw new IllegalArgumentException("Attempting to unregister the wrong listener");
    this.hh = null;
  }

  public final void a(b<D> paramb)
  {
    if (this.hg == null)
      throw new IllegalStateException("No listener register");
    if (this.hg != paramb)
      throw new IllegalArgumentException("Attempting to unregister the wrong listener");
    this.hg = null;
  }

  public final void deliverResult(D paramD)
  {
    if (this.hg != null)
      this.hg.b(this, paramD);
  }

  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mId=");
    paramPrintWriter.print(this.fk);
    paramPrintWriter.print(" mListener=");
    paramPrintWriter.println(this.hg);
    if ((this.fi) || (this.hk) || (this.hl))
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mStarted=");
      paramPrintWriter.print(this.fi);
      paramPrintWriter.print(" mContentChanged=");
      paramPrintWriter.print(this.hk);
      paramPrintWriter.print(" mProcessingChange=");
      paramPrintWriter.println(this.hl);
    }
    if ((this.hi) || (this.hj))
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAbandoned=");
      paramPrintWriter.print(this.hi);
      paramPrintWriter.print(" mReset=");
      paramPrintWriter.println(this.hj);
    }
  }

  public void onReset()
  {
  }

  public void onStartLoading()
  {
  }

  public void onStopLoading()
  {
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(64);
    android.support.v4.d.c.a(this, localStringBuilder);
    localStringBuilder.append(" id=");
    localStringBuilder.append(this.fk);
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }

  public static abstract interface a<D>
  {
  }

  public static abstract interface b<D>
  {
    public abstract void b(c<D> paramc, D paramD);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.content.c
 * JD-Core Version:    0.6.2
 */