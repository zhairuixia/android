package android.support.v4.content;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Process;
import java.io.File;

public class a
{
  public static final Drawable a(Context paramContext, int paramInt)
  {
    if (Build.VERSION.SDK_INT >= 21)
      return paramContext.getDrawable(paramInt);
    return paramContext.getResources().getDrawable(paramInt);
  }

  public static File b(File paramFile)
  {
    File localFile = paramFile;
    try
    {
      if (!paramFile.exists())
      {
        localFile = paramFile;
        if (!paramFile.mkdirs())
        {
          boolean bool = paramFile.exists();
          if (!bool)
            break label37;
        }
      }
      for (localFile = paramFile; ; localFile = null)
      {
        return localFile;
        label37: new StringBuilder("Unable to create files subdir ").append(paramFile.getPath());
      }
    }
    finally
    {
    }
    throw paramFile;
  }

  public static int d(Context paramContext, String paramString)
  {
    if (paramString == null)
      throw new IllegalArgumentException("permission is null");
    return paramContext.checkPermission(paramString, Process.myPid(), Process.myUid());
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.content.a
 * JD-Core Version:    0.6.2
 */