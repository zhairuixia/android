package android.support.v4.b.a;

import android.support.v4.view.d;
import android.support.v4.view.l.e;
import android.view.MenuItem;
import android.view.View;

public abstract interface b extends MenuItem
{
  public abstract b a(d paramd);

  public abstract b a(l.e parame);

  public abstract d an();

  public abstract boolean collapseActionView();

  public abstract boolean expandActionView();

  public abstract View getActionView();

  public abstract boolean isActionViewExpanded();

  public abstract MenuItem setActionView(int paramInt);

  public abstract MenuItem setActionView(View paramView);

  public abstract void setShowAsAction(int paramInt);

  public abstract MenuItem setShowAsActionFlags(int paramInt);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.b.a.b
 * JD-Core Version:    0.6.2
 */