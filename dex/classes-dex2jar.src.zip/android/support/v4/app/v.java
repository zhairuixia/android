package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.Builder;

public abstract interface v
{
  public abstract Notification.Builder ad();

  public abstract Notification build();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.v
 * JD-Core Version:    0.6.2
 */