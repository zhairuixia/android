package android.support.v4.app;

import android.support.v4.content.c;

public abstract class q
{
  public boolean W()
  {
    return false;
  }

  public abstract <D> c<D> a(int paramInt, a<D> parama);

  public abstract <D> c<D> b(int paramInt, a<D> parama);

  public abstract void destroyLoader(int paramInt);

  public abstract <D> c<D> l(int paramInt);

  public static abstract interface a<D>
  {
    public abstract void a(c<D> paramc, D paramD);

    public abstract c<D> m(int paramInt);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.q
 * JD-Core Version:    0.6.2
 */