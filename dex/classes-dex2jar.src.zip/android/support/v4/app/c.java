package android.support.v4.app;

import android.app.AppOpsManager;
import android.content.Context;
import android.os.Build.VERSION;

public final class c
{
  private static final b bv = new b((byte)0);

  static
  {
    if (Build.VERSION.SDK_INT >= 23)
    {
      bv = new a((byte)0);
      return;
    }
  }

  public static int a(Context paramContext, String paramString1, String paramString2)
  {
    return bv.a(paramContext, paramString1, paramString2);
  }

  public static String permissionToOp(String paramString)
  {
    return bv.permissionToOp(paramString);
  }

  private static final class a extends c.b
  {
    private a()
    {
      super();
    }

    public final int a(Context paramContext, String paramString1, String paramString2)
    {
      return ((AppOpsManager)paramContext.getSystemService(AppOpsManager.class)).noteProxyOp(paramString1, paramString2);
    }

    public final String permissionToOp(String paramString)
    {
      return AppOpsManager.permissionToOp(paramString);
    }
  }

  private static class b
  {
    public int a(Context paramContext, String paramString1, String paramString2)
    {
      return 1;
    }

    public String permissionToOp(String paramString)
    {
      return null;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.c
 * JD-Core Version:    0.6.2
 */