package android.support.v4.app;

public final class i
{
  final j<?> cP;

  i(j<?> paramj)
  {
    this.cP = paramj;
  }

  public final boolean execPendingActions()
  {
    return this.cP.cO.execPendingActions();
  }

  final Fragment i(String paramString)
  {
    return this.cP.cO.i(paramString);
  }

  public final void noteStateNotSaved()
  {
    this.cP.cO.eg = false;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.i
 * JD-Core Version:    0.6.2
 */