package android.support.v4.app;

import android.app.RemoteInput;
import android.app.RemoteInput.Builder;

final class af
{
  static RemoteInput[] a(ag.a[] paramArrayOfa)
  {
    if (paramArrayOfa == null)
      return null;
    RemoteInput[] arrayOfRemoteInput = new RemoteInput[paramArrayOfa.length];
    int i = 0;
    while (i < paramArrayOfa.length)
    {
      ag.a locala = paramArrayOfa[i];
      arrayOfRemoteInput[i] = new RemoteInput.Builder(locala.getResultKey()).setLabel(locala.getLabel()).setChoices(locala.getChoices()).setAllowFreeFormInput(locala.getAllowFreeFormInput()).addExtras(locala.getExtras()).build();
      i += 1;
    }
    return arrayOfRemoteInput;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.af
 * JD-Core Version:    0.6.2
 */