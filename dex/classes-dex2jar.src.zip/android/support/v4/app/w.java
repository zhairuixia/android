package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.Builder;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcelable;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.List;

public final class w
{
  private static final i fx = new l();

  static
  {
    if (Build.VERSION.SDK_INT >= 21)
    {
      fx = new k();
      return;
    }
    if (Build.VERSION.SDK_INT >= 20)
    {
      fx = new j();
      return;
    }
    if (Build.VERSION.SDK_INT >= 19)
    {
      fx = new q();
      return;
    }
    if (Build.VERSION.SDK_INT >= 16)
    {
      fx = new p();
      return;
    }
    if (Build.VERSION.SDK_INT >= 14)
    {
      fx = new o();
      return;
    }
    if (Build.VERSION.SDK_INT >= 11)
    {
      fx = new n();
      return;
    }
    if (Build.VERSION.SDK_INT >= 9)
    {
      fx = new m();
      return;
    }
  }

  public static Bundle a(Notification paramNotification)
  {
    return fx.a(paramNotification);
  }

  public static final class a extends z.a
  {
    public static final z.a.a fz = new z.a.a()
    {
    };
    public PendingIntent actionIntent;
    private final ae[] fy;
    public int icon;
    private final Bundle mExtras;
    public CharSequence title;

    public a(int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent)
    {
      this(paramInt, paramCharSequence, paramPendingIntent, new Bundle());
    }

    private a(int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent, Bundle paramBundle)
    {
      this.icon = paramInt;
      this.title = w.d.d(paramCharSequence);
      this.actionIntent = paramPendingIntent;
      this.mExtras = paramBundle;
      this.fy = null;
    }

    public final PendingIntent af()
    {
      return this.actionIntent;
    }

    public final Bundle getExtras()
    {
      return this.mExtras;
    }

    public final int getIcon()
    {
      return this.icon;
    }

    public final CharSequence getTitle()
    {
      return this.title;
    }
  }

  public static final class b extends w.r
  {
    Bitmap fA;
    Bitmap fB;
    boolean fC;
  }

  public static final class c extends w.r
  {
    CharSequence fD;
  }

  public static final class d
  {
    public CharSequence fE;
    public CharSequence fF;
    public PendingIntent fG;
    PendingIntent fH;
    RemoteViews fI;
    public Bitmap fJ;
    public CharSequence fK;
    public int fL;
    boolean fM = true;
    public boolean fN;
    public w.r fO;
    public CharSequence fP;
    int fQ;
    int fR;
    boolean fS;
    String fT;
    boolean fU;
    String fV;
    public ArrayList<w.a> fW = new ArrayList();
    public boolean fX = false;
    public String fY;
    int fZ = 0;
    int ga = 0;
    Notification gb;
    public Notification gc = new Notification();
    public ArrayList<String> gd;
    public Context mContext;
    Bundle mExtras;
    int mPriority;

    public d(Context paramContext)
    {
      this.mContext = paramContext;
      this.gc.when = System.currentTimeMillis();
      this.gc.audioStreamType = -1;
      this.mPriority = 0;
      this.gd = new ArrayList();
    }

    protected static CharSequence d(CharSequence paramCharSequence)
    {
      if (paramCharSequence == null);
      while (paramCharSequence.length() <= 5120)
        return paramCharSequence;
      return paramCharSequence.subSequence(0, 5120);
    }

    public final d a(int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent)
    {
      this.fW.add(new w.a(paramInt, paramCharSequence, paramPendingIntent));
      return this;
    }

    public final d a(CharSequence paramCharSequence)
    {
      this.fE = d(paramCharSequence);
      return this;
    }

    public final d b(int paramInt1, int paramInt2, boolean paramBoolean)
    {
      this.fQ = paramInt1;
      this.fR = paramInt2;
      this.fS = paramBoolean;
      return this;
    }

    public final d b(CharSequence paramCharSequence)
    {
      this.fF = d(paramCharSequence);
      return this;
    }

    public final Notification build()
    {
      w.i locali = w.ae();
      new w.e();
      return locali.b(this);
    }

    public final d c(long paramLong)
    {
      this.gc.when = paramLong;
      return this;
    }

    public final d c(CharSequence paramCharSequence)
    {
      this.gc.tickerText = d(paramCharSequence);
      return this;
    }

    @Deprecated
    public final Notification getNotification()
    {
      return build();
    }

    public final d h(boolean paramBoolean)
    {
      i(16, paramBoolean);
      return this;
    }

    public final void i(int paramInt, boolean paramBoolean)
    {
      if (paramBoolean)
      {
        localNotification = this.gc;
        localNotification.flags |= paramInt;
        return;
      }
      Notification localNotification = this.gc;
      localNotification.flags &= (paramInt ^ 0xFFFFFFFF);
    }

    public final d n(int paramInt)
    {
      this.gc.icon = paramInt;
      return this;
    }
  }

  protected static final class e
  {
  }

  public static final class f
    implements w.g
  {
    private Bitmap fJ;
    private int fZ = 0;
    public a ge;

    public final w.d a(w.d paramd)
    {
      if (Build.VERSION.SDK_INT < 21)
        return paramd;
      Bundle localBundle = new Bundle();
      if (this.fJ != null)
        localBundle.putParcelable("large_icon", this.fJ);
      if (this.fZ != 0)
        localBundle.putInt("app_color", this.fZ);
      if (this.ge != null)
        localBundle.putBundle("car_conversation", w.ae().a(this.ge));
      if (paramd.mExtras == null)
        paramd.mExtras = new Bundle();
      paramd.mExtras.putBundle("android.car.EXTENSIONS", localBundle);
      return paramd;
    }

    public static final class a extends z.b
    {
      static final z.b.a gl = new z.b.a()
      {
      };
      private final String[] gf;
      private final ae gg;
      private final PendingIntent gh;
      private final PendingIntent gi;
      private final String[] gj;
      private final long gk;

      public a(String[] paramArrayOfString1, ae paramae, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2, String[] paramArrayOfString2, long paramLong)
      {
        this.gf = paramArrayOfString1;
        this.gg = paramae;
        this.gi = paramPendingIntent2;
        this.gh = paramPendingIntent1;
        this.gj = paramArrayOfString2;
        this.gk = paramLong;
      }

      public final long getLatestTimestamp()
      {
        return this.gk;
      }

      public final String[] getMessages()
      {
        return this.gf;
      }

      public final String[] getParticipants()
      {
        return this.gj;
      }

      public final PendingIntent getReadPendingIntent()
      {
        return this.gi;
      }

      public final PendingIntent getReplyPendingIntent()
      {
        return this.gh;
      }

      public static final class a
      {
        public ae gg;
        public PendingIntent gh;
        public PendingIntent gi;
        public long gk;
        public final List<String> gm = new ArrayList();
        public final String gn;

        public a(String paramString)
        {
          this.gn = paramString;
        }
      }
    }
  }

  public static abstract interface g
  {
    public abstract w.d a(w.d paramd);
  }

  public static final class h extends w.r
  {
    ArrayList<CharSequence> go = new ArrayList();
  }

  static abstract interface i
  {
    public abstract Bundle a(Notification paramNotification);

    public abstract Bundle a(z.b paramb);

    public abstract Notification b(w.d paramd);
  }

  static class j extends w.q
  {
    public Notification b(w.d paramd)
    {
      x.a locala = new x.a(paramd.mContext, paramd.gc, paramd.fE, paramd.fF, paramd.fK, paramd.fI, paramd.fL, paramd.fG, paramd.fH, paramd.fJ, paramd.fQ, paramd.fR, paramd.fS, paramd.fM, paramd.fN, paramd.mPriority, paramd.fP, paramd.fX, paramd.gd, paramd.mExtras, paramd.fT, paramd.fU, paramd.fV);
      w.a(locala, paramd.fW);
      w.a(locala, paramd.fO);
      return locala.build();
    }
  }

  static final class k extends w.j
  {
    public final Bundle a(z.b paramb)
    {
      Parcelable[] arrayOfParcelable = null;
      int i = 0;
      if (paramb == null)
        return null;
      Bundle localBundle1 = new Bundle();
      Object localObject = arrayOfParcelable;
      if (paramb.getParticipants() != null)
      {
        localObject = arrayOfParcelable;
        if (paramb.getParticipants().length > 1)
          localObject = paramb.getParticipants()[0];
      }
      arrayOfParcelable = new Parcelable[paramb.getMessages().length];
      while (i < arrayOfParcelable.length)
      {
        Bundle localBundle2 = new Bundle();
        localBundle2.putString("text", paramb.getMessages()[i]);
        localBundle2.putString("author", (String)localObject);
        arrayOfParcelable[i] = localBundle2;
        i += 1;
      }
      localBundle1.putParcelableArray("messages", arrayOfParcelable);
      localObject = paramb.ah();
      if (localObject != null)
        localBundle1.putParcelable("remote_input", y.a((ag.a)localObject));
      localBundle1.putParcelable("on_reply", paramb.getReplyPendingIntent());
      localBundle1.putParcelable("on_read", paramb.getReadPendingIntent());
      localBundle1.putStringArray("participants", paramb.getParticipants());
      localBundle1.putLong("timestamp", paramb.getLatestTimestamp());
      return localBundle1;
    }

    public final Notification b(w.d paramd)
    {
      y.a locala = new y.a(paramd.mContext, paramd.gc, paramd.fE, paramd.fF, paramd.fK, paramd.fI, paramd.fL, paramd.fG, paramd.fH, paramd.fJ, paramd.fQ, paramd.fR, paramd.fS, paramd.fM, paramd.fN, paramd.mPriority, paramd.fP, paramd.fX, paramd.fY, paramd.gd, paramd.mExtras, paramd.fZ, paramd.ga, paramd.gb, paramd.fT, paramd.fU, paramd.fV);
      w.a(locala, paramd.fW);
      w.a(locala, paramd.fO);
      return locala.build();
    }
  }

  static class l
    implements w.i
  {
    public Bundle a(Notification paramNotification)
    {
      return null;
    }

    public Bundle a(z.b paramb)
    {
      return null;
    }

    public Notification b(w.d paramd)
    {
      Notification localNotification = paramd.gc;
      localNotification.setLatestEventInfo(paramd.mContext, paramd.fE, paramd.fF, paramd.fG);
      if (paramd.mPriority > 0)
        localNotification.flags |= 128;
      return localNotification;
    }
  }

  static final class m extends w.l
  {
    public final Notification b(w.d paramd)
    {
      Notification localNotification = paramd.gc;
      Context localContext = paramd.mContext;
      CharSequence localCharSequence1 = paramd.fE;
      CharSequence localCharSequence2 = paramd.fF;
      PendingIntent localPendingIntent1 = paramd.fG;
      PendingIntent localPendingIntent2 = paramd.fH;
      localNotification.setLatestEventInfo(localContext, localCharSequence1, localCharSequence2, localPendingIntent1);
      localNotification.fullScreenIntent = localPendingIntent2;
      if (paramd.mPriority > 0)
        localNotification.flags |= 128;
      return localNotification;
    }
  }

  static final class n extends w.l
  {
    public final Notification b(w.d paramd)
    {
      Object localObject2 = paramd.mContext;
      Notification localNotification = paramd.gc;
      Object localObject1 = paramd.fE;
      CharSequence localCharSequence1 = paramd.fF;
      CharSequence localCharSequence2 = paramd.fK;
      RemoteViews localRemoteViews = paramd.fI;
      int i = paramd.fL;
      PendingIntent localPendingIntent2 = paramd.fG;
      PendingIntent localPendingIntent1 = paramd.fH;
      paramd = paramd.fJ;
      localObject2 = new Notification.Builder((Context)localObject2).setWhen(localNotification.when).setSmallIcon(localNotification.icon, localNotification.iconLevel).setContent(localNotification.contentView).setTicker(localNotification.tickerText, localRemoteViews).setSound(localNotification.sound, localNotification.audioStreamType).setVibrate(localNotification.vibrate).setLights(localNotification.ledARGB, localNotification.ledOnMS, localNotification.ledOffMS);
      if ((localNotification.flags & 0x2) != 0)
      {
        bool = true;
        localObject2 = ((Notification.Builder)localObject2).setOngoing(bool);
        if ((localNotification.flags & 0x8) == 0)
          break label284;
        bool = true;
        label180: localObject2 = ((Notification.Builder)localObject2).setOnlyAlertOnce(bool);
        if ((localNotification.flags & 0x10) == 0)
          break label289;
        bool = true;
        label201: localObject1 = ((Notification.Builder)localObject2).setAutoCancel(bool).setDefaults(localNotification.defaults).setContentTitle((CharSequence)localObject1).setContentText(localCharSequence1).setContentInfo(localCharSequence2).setContentIntent(localPendingIntent2).setDeleteIntent(localNotification.deleteIntent);
        if ((localNotification.flags & 0x80) == 0)
          break label294;
      }
      label284: label289: label294: for (boolean bool = true; ; bool = false)
      {
        return ((Notification.Builder)localObject1).setFullScreenIntent(localPendingIntent1, bool).setLargeIcon(paramd).setNumber(i).getNotification();
        bool = false;
        break;
        bool = false;
        break label180;
        bool = false;
        break label201;
      }
    }
  }

  static final class o extends w.l
  {
    public final Notification b(w.d paramd)
    {
      return new aa.a(paramd.mContext, paramd.gc, paramd.fE, paramd.fF, paramd.fK, paramd.fI, paramd.fL, paramd.fG, paramd.fH, paramd.fJ, paramd.fQ, paramd.fR, paramd.fS).build();
    }
  }

  static class p extends w.l
  {
    public Bundle a(Notification paramNotification)
    {
      return ab.a(paramNotification);
    }

    public Notification b(w.d paramd)
    {
      ab.a locala = new ab.a(paramd.mContext, paramd.gc, paramd.fE, paramd.fF, paramd.fK, paramd.fI, paramd.fL, paramd.fG, paramd.fH, paramd.fJ, paramd.fQ, paramd.fR, paramd.fS, paramd.fN, paramd.mPriority, paramd.fP, paramd.fX, paramd.mExtras, paramd.fT, paramd.fU, paramd.fV);
      w.a(locala, paramd.fW);
      w.a(locala, paramd.fO);
      return locala.build();
    }
  }

  static class q extends w.p
  {
    public final Bundle a(Notification paramNotification)
    {
      return paramNotification.extras;
    }

    public Notification b(w.d paramd)
    {
      ac.a locala = new ac.a(paramd.mContext, paramd.gc, paramd.fE, paramd.fF, paramd.fK, paramd.fI, paramd.fL, paramd.fG, paramd.fH, paramd.fJ, paramd.fQ, paramd.fR, paramd.fS, paramd.fM, paramd.fN, paramd.mPriority, paramd.fP, paramd.fX, paramd.gd, paramd.mExtras, paramd.fT, paramd.fU, paramd.fV);
      w.a(locala, paramd.fW);
      w.a(locala, paramd.fO);
      return locala.build();
    }
  }

  public static abstract class r
  {
    CharSequence gp;
    CharSequence gq;
    boolean gr = false;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.w
 * JD-Core Version:    0.6.2
 */