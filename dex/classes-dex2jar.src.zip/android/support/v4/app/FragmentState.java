package android.support.v4.app;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

final class FragmentState
  implements Parcelable
{
  public static final Parcelable.Creator<FragmentState> CREATOR = new Parcelable.Creator()
  {
  };
  Bundle cB;
  final Bundle cE;
  final boolean cK;
  final int cS;
  final int cT;
  final String cU;
  final boolean cW;
  final boolean cX;
  final String eC;
  Fragment eD;
  final int mIndex;

  public FragmentState(Parcel paramParcel)
  {
    this.eC = paramParcel.readString();
    this.mIndex = paramParcel.readInt();
    if (paramParcel.readInt() != 0)
    {
      bool1 = true;
      this.cK = bool1;
      this.cS = paramParcel.readInt();
      this.cT = paramParcel.readInt();
      this.cU = paramParcel.readString();
      if (paramParcel.readInt() == 0)
        break label110;
      bool1 = true;
      label69: this.cX = bool1;
      if (paramParcel.readInt() == 0)
        break label115;
    }
    label110: label115: for (boolean bool1 = bool2; ; bool1 = false)
    {
      this.cW = bool1;
      this.cE = paramParcel.readBundle();
      this.cB = paramParcel.readBundle();
      return;
      bool1 = false;
      break;
      bool1 = false;
      break label69;
    }
  }

  public FragmentState(Fragment paramFragment)
  {
    this.eC = paramFragment.getClass().getName();
    this.mIndex = paramFragment.mIndex;
    this.cK = paramFragment.cK;
    this.cS = paramFragment.cS;
    this.cT = paramFragment.cT;
    this.cU = paramFragment.cU;
    this.cX = paramFragment.cX;
    this.cW = paramFragment.cW;
    this.cE = paramFragment.cE;
  }

  public final int describeContents()
  {
    return 0;
  }

  public final void writeToParcel(Parcel paramParcel, int paramInt)
  {
    int i = 1;
    paramParcel.writeString(this.eC);
    paramParcel.writeInt(this.mIndex);
    if (this.cK)
    {
      paramInt = 1;
      paramParcel.writeInt(paramInt);
      paramParcel.writeInt(this.cS);
      paramParcel.writeInt(this.cT);
      paramParcel.writeString(this.cU);
      if (!this.cX)
        break label106;
      paramInt = 1;
      label65: paramParcel.writeInt(paramInt);
      if (!this.cW)
        break label111;
    }
    label106: label111: for (paramInt = i; ; paramInt = 0)
    {
      paramParcel.writeInt(paramInt);
      paramParcel.writeBundle(this.cE);
      paramParcel.writeBundle(this.cB);
      return;
      paramInt = 0;
      break;
      paramInt = 0;
      break label65;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentState
 * JD-Core Version:    0.6.2
 */