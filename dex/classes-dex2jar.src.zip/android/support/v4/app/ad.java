package android.support.v4.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Build.VERSION;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.provider.Settings.Secure;
import android.util.Log;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public final class ad
{
  private static String gA;
  private static Set<String> gB;
  private static h gD;
  public static final b gE;
  private static final int gy;
  private static final Object gz = new Object();
  private static final Object sLock;
  public final NotificationManager gC;
  public final Context mContext;

  static
  {
    gB = new HashSet();
    sLock = new Object();
    if (Build.VERSION.SDK_INT >= 14)
      gE = new e();
    while (true)
    {
      gy = gE.ai();
      return;
      if (Build.VERSION.SDK_INT >= 5)
        gE = new d();
      else
        gE = new c();
    }
  }

  private ad(Context paramContext)
  {
    this.mContext = paramContext;
    this.gC = ((NotificationManager)this.mContext.getSystemService("notification"));
  }

  public static ad g(Context paramContext)
  {
    return new ad(paramContext);
  }

  public static Set<String> h(Context paramContext)
  {
    paramContext = Settings.Secure.getString(paramContext.getContentResolver(), "enabled_notification_listeners");
    HashSet localHashSet;
    if ((paramContext != null) && (!paramContext.equals(gA)))
    {
      ??? = paramContext.split(":");
      localHashSet = new HashSet(???.length);
      int j = ???.length;
      int i = 0;
      while (i < j)
      {
        ComponentName localComponentName = ComponentName.unflattenFromString(???[i]);
        if (localComponentName != null)
          localHashSet.add(localComponentName.getPackageName());
        i += 1;
      }
    }
    synchronized (gz)
    {
      gB = localHashSet;
      gA = paramContext;
      return gB;
    }
  }

  public final void a(i parami)
  {
    synchronized (sLock)
    {
      if (gD == null)
        gD = new h(this.mContext.getApplicationContext());
      gD.mHandler.obtainMessage(0, parami).sendToTarget();
      return;
    }
  }

  private static final class a
    implements ad.i
  {
    final boolean gF;
    final int id;
    final String packageName;
    final String tag;

    public a(String paramString1, int paramInt, String paramString2)
    {
      this.packageName = paramString1;
      this.id = paramInt;
      this.tag = null;
      this.gF = false;
    }

    public final void a(p paramp)
    {
      if (this.gF)
      {
        paramp.l(this.packageName);
        return;
      }
      paramp.a(this.packageName, this.id, this.tag);
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder("CancelTask[");
      localStringBuilder.append("packageName:").append(this.packageName);
      localStringBuilder.append(", id:").append(this.id);
      localStringBuilder.append(", tag:").append(this.tag);
      localStringBuilder.append(", all:").append(this.gF);
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }

  public static abstract interface b
  {
    public abstract void a(NotificationManager paramNotificationManager, String paramString, int paramInt);

    public abstract void a(NotificationManager paramNotificationManager, String paramString, int paramInt, Notification paramNotification);

    public abstract int ai();
  }

  static class c
    implements ad.b
  {
    public void a(NotificationManager paramNotificationManager, String paramString, int paramInt)
    {
      paramNotificationManager.cancel(paramInt);
    }

    public void a(NotificationManager paramNotificationManager, String paramString, int paramInt, Notification paramNotification)
    {
      paramNotificationManager.notify(paramInt, paramNotification);
    }

    public int ai()
    {
      return 1;
    }
  }

  static class d extends ad.c
  {
    public final void a(NotificationManager paramNotificationManager, String paramString, int paramInt)
    {
      paramNotificationManager.cancel(null, paramInt);
    }

    public final void a(NotificationManager paramNotificationManager, String paramString, int paramInt, Notification paramNotification)
    {
      paramNotificationManager.notify(null, paramInt, paramNotification);
    }
  }

  static final class e extends ad.d
  {
    public final int ai()
    {
      return 33;
    }
  }

  private static final class f
    implements ad.i
  {
    final Notification gG;
    final int id;
    final String packageName;
    final String tag;

    public f(String paramString1, int paramInt, String paramString2, Notification paramNotification)
    {
      this.packageName = paramString1;
      this.id = paramInt;
      this.tag = null;
      this.gG = paramNotification;
    }

    public final void a(p paramp)
    {
      paramp.a(this.packageName, this.id, this.tag, this.gG);
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder("NotifyTask[");
      localStringBuilder.append("packageName:").append(this.packageName);
      localStringBuilder.append(", id:").append(this.id);
      localStringBuilder.append(", tag:").append(this.tag);
      localStringBuilder.append("]");
      return localStringBuilder.toString();
    }
  }

  private static final class g
  {
    final ComponentName gH;
    final IBinder gI;

    public g(ComponentName paramComponentName, IBinder paramIBinder)
    {
      this.gH = paramComponentName;
      this.gI = paramIBinder;
    }
  }

  private static final class h
    implements ServiceConnection, Handler.Callback
  {
    private final HandlerThread gJ;
    private final Map<ComponentName, a> gK = new HashMap();
    private Set<String> gL = new HashSet();
    private final Context mContext;
    final Handler mHandler;

    public h(Context paramContext)
    {
      this.mContext = paramContext;
      this.gJ = new HandlerThread("NotificationManagerCompat");
      this.gJ.start();
      this.mHandler = new Handler(this.gJ.getLooper(), this);
    }

    private void a(a parama)
    {
      if (parama.gM)
      {
        this.mContext.unbindService(this);
        parama.gM = false;
      }
      parama.gN = null;
    }

    private void b(a parama)
    {
      if (this.mHandler.hasMessages(3, parama.gH))
        return;
      parama.retryCount += 1;
      if (parama.retryCount > 6)
      {
        new StringBuilder("Giving up on delivering ").append(parama.gO.size()).append(" tasks to ").append(parama.gH).append(" after ").append(parama.retryCount).append(" retries");
        parama.gO.clear();
        return;
      }
      int i = (1 << parama.retryCount - 1) * 1000;
      if (Log.isLoggable("NotifManCompat", 3))
        new StringBuilder("Scheduling retry for ").append(i).append(" ms");
      parama = this.mHandler.obtainMessage(3, parama.gH);
      this.mHandler.sendMessageDelayed(parama, i);
    }

    private void c(a parama)
    {
      if (Log.isLoggable("NotifManCompat", 3))
        new StringBuilder("Processing component ").append(parama.gH).append(", ").append(parama.gO.size()).append(" queued tasks");
      if (parama.gO.isEmpty());
      while (true)
      {
        return;
        boolean bool;
        if (parama.gM)
        {
          bool = true;
          if ((!bool) || (parama.gN == null))
            b(parama);
        }
        else
        {
          localObject = new Intent("android.support.BIND_NOTIFICATION_SIDE_CHANNEL").setComponent(parama.gH);
          parama.gM = this.mContext.bindService((Intent)localObject, this, ad.gy);
          if (parama.gM)
            parama.retryCount = 0;
          while (true)
          {
            bool = parama.gM;
            break;
            new StringBuilder("Unable to bind to listener ").append(parama.gH);
            this.mContext.unbindService(this);
          }
        }
        Object localObject = (ad.i)parama.gO.peek();
        if (localObject != null);
        try
        {
          if (Log.isLoggable("NotifManCompat", 3))
            new StringBuilder("Sending task ").append(localObject);
          ((ad.i)localObject).a(parama.gN);
          parama.gO.remove();
        }
        catch (DeadObjectException localDeadObjectException)
        {
          if (Log.isLoggable("NotifManCompat", 3))
            new StringBuilder("Remote service has died: ").append(parama.gH);
          if (parama.gO.isEmpty())
            continue;
          b(parama);
          return;
        }
        catch (RemoteException localRemoteException)
        {
          while (true)
            new StringBuilder("RemoteException communicating with ").append(parama.gH);
        }
      }
    }

    public final boolean handleMessage(Message paramMessage)
    {
      Object localObject1;
      switch (paramMessage.what)
      {
      default:
        return false;
      case 0:
        paramMessage = (ad.i)paramMessage.obj;
        Object localObject2 = ad.h(this.mContext);
        if (!((Set)localObject2).equals(this.gL))
        {
          this.gL = ((Set)localObject2);
          Object localObject3 = this.mContext.getPackageManager().queryIntentServices(new Intent().setAction("android.support.BIND_NOTIFICATION_SIDE_CHANNEL"), 4);
          localObject1 = new HashSet();
          localObject3 = ((List)localObject3).iterator();
          while (((Iterator)localObject3).hasNext())
          {
            ResolveInfo localResolveInfo = (ResolveInfo)((Iterator)localObject3).next();
            if (((Set)localObject2).contains(localResolveInfo.serviceInfo.packageName))
            {
              ComponentName localComponentName = new ComponentName(localResolveInfo.serviceInfo.packageName, localResolveInfo.serviceInfo.name);
              if (localResolveInfo.serviceInfo.permission != null)
                new StringBuilder("Permission present on component ").append(localComponentName).append(", not adding listener record.");
              else
                ((Set)localObject1).add(localComponentName);
            }
          }
          localObject2 = ((Set)localObject1).iterator();
          while (((Iterator)localObject2).hasNext())
          {
            localObject3 = (ComponentName)((Iterator)localObject2).next();
            if (!this.gK.containsKey(localObject3))
            {
              if (Log.isLoggable("NotifManCompat", 3))
                new StringBuilder("Adding listener record for ").append(localObject3);
              this.gK.put(localObject3, new a((ComponentName)localObject3));
            }
          }
          localObject2 = this.gK.entrySet().iterator();
          while (((Iterator)localObject2).hasNext())
          {
            localObject3 = (Map.Entry)((Iterator)localObject2).next();
            if (!((Set)localObject1).contains(((Map.Entry)localObject3).getKey()))
            {
              if (Log.isLoggable("NotifManCompat", 3))
                new StringBuilder("Removing listener record for ").append(((Map.Entry)localObject3).getKey());
              a((a)((Map.Entry)localObject3).getValue());
              ((Iterator)localObject2).remove();
            }
          }
        }
        localObject1 = this.gK.values().iterator();
        while (((Iterator)localObject1).hasNext())
        {
          localObject2 = (a)((Iterator)localObject1).next();
          ((a)localObject2).gO.add(paramMessage);
          c((a)localObject2);
        }
        return true;
      case 1:
        localObject1 = (ad.g)paramMessage.obj;
        paramMessage = ((ad.g)localObject1).gH;
        localObject1 = ((ad.g)localObject1).gI;
        paramMessage = (a)this.gK.get(paramMessage);
        if (paramMessage != null)
        {
          paramMessage.gN = p.a.a((IBinder)localObject1);
          paramMessage.retryCount = 0;
          c(paramMessage);
        }
        return true;
      case 2:
        paramMessage = (ComponentName)paramMessage.obj;
        paramMessage = (a)this.gK.get(paramMessage);
        if (paramMessage != null)
          a(paramMessage);
        return true;
      case 3:
      }
      paramMessage = (ComponentName)paramMessage.obj;
      paramMessage = (a)this.gK.get(paramMessage);
      if (paramMessage != null)
        c(paramMessage);
      return true;
    }

    public final void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder)
    {
      if (Log.isLoggable("NotifManCompat", 3))
        new StringBuilder("Connected to service ").append(paramComponentName);
      this.mHandler.obtainMessage(1, new ad.g(paramComponentName, paramIBinder)).sendToTarget();
    }

    public final void onServiceDisconnected(ComponentName paramComponentName)
    {
      if (Log.isLoggable("NotifManCompat", 3))
        new StringBuilder("Disconnected from service ").append(paramComponentName);
      this.mHandler.obtainMessage(2, paramComponentName).sendToTarget();
    }

    private static final class a
    {
      public final ComponentName gH;
      public boolean gM = false;
      public p gN;
      public LinkedList<ad.i> gO = new LinkedList();
      public int retryCount = 0;

      public a(ComponentName paramComponentName)
      {
        this.gH = paramComponentName;
      }
    }
  }

  private static abstract interface i
  {
    public abstract void a(p paramp);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.ad
 * JD-Core Version:    0.6.2
 */