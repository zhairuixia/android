package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import java.util.ArrayList;

final class BackStackState
  implements Parcelable
{
  public static final Parcelable.Creator<BackStackState> CREATOR = new Parcelable.Creator()
  {
  };
  final int bF;
  final int bG;
  final int bK;
  final CharSequence bL;
  final int bM;
  final CharSequence bN;
  final ArrayList<String> bO;
  final ArrayList<String> bP;
  final int[] cn;
  final int mIndex;
  final String mName;

  public BackStackState(Parcel paramParcel)
  {
    this.cn = paramParcel.createIntArray();
    this.bF = paramParcel.readInt();
    this.bG = paramParcel.readInt();
    this.mName = paramParcel.readString();
    this.mIndex = paramParcel.readInt();
    this.bK = paramParcel.readInt();
    this.bL = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.bM = paramParcel.readInt();
    this.bN = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.bO = paramParcel.createStringArrayList();
    this.bP = paramParcel.createStringArrayList();
  }

  public BackStackState(d paramd)
  {
    d.a locala = paramd.by;
    int j;
    for (int i = 0; locala != null; i = j)
    {
      j = i;
      if (locala.ci != null)
        j = i + locala.ci.size();
      locala = locala.ca;
    }
    this.cn = new int[i + paramd.bA * 7];
    if (!paramd.bH)
      throw new IllegalStateException("Not on back stack");
    locala = paramd.by;
    i = 0;
    if (locala != null)
    {
      int[] arrayOfInt = this.cn;
      j = i + 1;
      arrayOfInt[i] = locala.cc;
      arrayOfInt = this.cn;
      int k = j + 1;
      if (locala.cd != null);
      for (i = locala.cd.mIndex; ; i = -1)
      {
        arrayOfInt[j] = i;
        arrayOfInt = this.cn;
        i = k + 1;
        arrayOfInt[k] = locala.ce;
        arrayOfInt = this.cn;
        j = i + 1;
        arrayOfInt[i] = locala.cf;
        arrayOfInt = this.cn;
        i = j + 1;
        arrayOfInt[j] = locala.cg;
        arrayOfInt = this.cn;
        j = i + 1;
        arrayOfInt[i] = locala.ch;
        if (locala.ci == null)
          break label314;
        k = locala.ci.size();
        arrayOfInt = this.cn;
        i = j + 1;
        arrayOfInt[j] = k;
        j = 0;
        while (j < k)
        {
          this.cn[i] = ((Fragment)locala.ci.get(j)).mIndex;
          j += 1;
          i += 1;
        }
      }
      while (true)
      {
        locala = locala.ca;
        break;
        label314: arrayOfInt = this.cn;
        i = j + 1;
        arrayOfInt[j] = 0;
      }
    }
    this.bF = paramd.bF;
    this.bG = paramd.bG;
    this.mName = paramd.mName;
    this.mIndex = paramd.mIndex;
    this.bK = paramd.bK;
    this.bL = paramd.bL;
    this.bM = paramd.bM;
    this.bN = paramd.bN;
    this.bO = paramd.bO;
    this.bP = paramd.bP;
  }

  public final d a(l paraml)
  {
    d locald = new d(paraml);
    int k = 0;
    int i = 0;
    while (i < this.cn.length)
    {
      d.a locala = new d.a();
      Object localObject = this.cn;
      int j = i + 1;
      locala.cc = localObject[i];
      if (l.DEBUG)
        new StringBuilder("Instantiate ").append(locald).append(" op #").append(k).append(" base fragment #").append(this.cn[j]);
      localObject = this.cn;
      i = j + 1;
      j = localObject[j];
      if (j >= 0);
      for (locala.cd = ((Fragment)paraml.dT.get(j)); ; locala.cd = null)
      {
        localObject = this.cn;
        j = i + 1;
        locala.ce = localObject[i];
        localObject = this.cn;
        i = j + 1;
        locala.cf = localObject[j];
        localObject = this.cn;
        j = i + 1;
        locala.cg = localObject[i];
        localObject = this.cn;
        i = j + 1;
        locala.ch = localObject[j];
        localObject = this.cn;
        j = i + 1;
        int n = localObject[i];
        i = j;
        if (n <= 0)
          break;
        locala.ci = new ArrayList(n);
        int m = 0;
        while (true)
        {
          i = j;
          if (m >= n)
            break;
          if (l.DEBUG)
            new StringBuilder("Instantiate ").append(locald).append(" set remove fragment #").append(this.cn[j]);
          localObject = (Fragment)paraml.dT.get(this.cn[j]);
          locala.ci.add(localObject);
          m += 1;
          j += 1;
        }
      }
      locald.bB = locala.ce;
      locald.bC = locala.cf;
      locald.bD = locala.cg;
      locald.bE = locala.ch;
      locald.a(locala);
      k += 1;
    }
    locald.bF = this.bF;
    locald.bG = this.bG;
    locald.mName = this.mName;
    locald.mIndex = this.mIndex;
    locald.bH = true;
    locald.bK = this.bK;
    locald.bL = this.bL;
    locald.bM = this.bM;
    locald.bN = this.bN;
    locald.bO = this.bO;
    locald.bP = this.bP;
    locald.f(1);
    return locald;
  }

  public final int describeContents()
  {
    return 0;
  }

  public final void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeIntArray(this.cn);
    paramParcel.writeInt(this.bF);
    paramParcel.writeInt(this.bG);
    paramParcel.writeString(this.mName);
    paramParcel.writeInt(this.mIndex);
    paramParcel.writeInt(this.bK);
    TextUtils.writeToParcel(this.bL, paramParcel, 0);
    paramParcel.writeInt(this.bM);
    TextUtils.writeToParcel(this.bN, paramParcel, 0);
    paramParcel.writeStringList(this.bO);
    paramParcel.writeStringList(this.bP);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.BackStackState
 * JD-Core Version:    0.6.2
 */