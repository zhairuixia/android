package android.support.v4.app;

import android.os.Bundle;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public abstract class k
{
  public abstract n P();

  public abstract List<Fragment> Q();

  public abstract Fragment a(Bundle paramBundle, String paramString);

  public abstract void a(Bundle paramBundle, String paramString, Fragment paramFragment);

  public abstract void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);

  public abstract Fragment.SavedState e(Fragment paramFragment);

  public abstract boolean executePendingTransactions();

  public abstract Fragment g(int paramInt);

  public abstract void h(int paramInt);

  public abstract boolean isDestroyed();

  public abstract Fragment k(String paramString);

  public abstract void popBackStack();

  public abstract boolean popBackStackImmediate();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.k
 * JD-Core Version:    0.6.2
 */