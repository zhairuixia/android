package android.support.v4.app;

import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.d.c;
import android.support.v4.view.g;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class Fragment
  implements ComponentCallbacks, View.OnCreateContextMenuListener
{
  private static final android.support.v4.d.h<String, Class<?>> cx = new android.support.v4.d.h();
  static final Object cy = new Object();
  int cA;
  Bundle cB;
  SparseArray<Parcelable> cC;
  String cD;
  public Bundle cE;
  Fragment cF;
  int cG = -1;
  int cH;
  boolean cI;
  public boolean cJ;
  boolean cK;
  boolean cL;
  boolean cM;
  int cN;
  l cO;
  j cP;
  l cQ;
  Fragment cR;
  int cS;
  int cT;
  String cU;
  boolean cV;
  boolean cW;
  boolean cX;
  boolean cY;
  boolean cZ;
  View cz;
  boolean da = true;
  boolean db;
  int dc;
  ViewGroup dd;
  View de;
  boolean dg;
  boolean dh = true;
  r di;
  boolean dj;
  boolean dk;
  Object dl = null;
  Object dm = cy;
  Object dn = null;
  Object jdField_do = cy;
  Object dp = null;
  Object dq = cy;
  Boolean dr;
  Boolean ds;
  ai dt = null;
  ai du = null;
  int mIndex = -1;
  int mState = 0;
  public View mView;

  public static void A()
  {
  }

  public static void D()
  {
  }

  public static Animation F()
  {
    return null;
  }

  public static Fragment a(Context paramContext, String paramString, Bundle paramBundle)
  {
    try
    {
      Class localClass2 = (Class)cx.get(paramString);
      Class localClass1 = localClass2;
      if (localClass2 == null)
      {
        localClass1 = paramContext.getClassLoader().loadClass(paramString);
        cx.put(paramString, localClass1);
      }
      paramContext = (Fragment)localClass1.newInstance();
      if (paramBundle != null)
      {
        paramBundle.setClassLoader(paramContext.getClass().getClassLoader());
        paramContext.cE = paramBundle;
      }
      return paramContext;
    }
    catch (ClassNotFoundException paramContext)
    {
      throw new a("Unable to instantiate fragment " + paramString + ": make sure class name exists, is public, and has an empty constructor that is public", paramContext);
    }
    catch (InstantiationException paramContext)
    {
      throw new a("Unable to instantiate fragment " + paramString + ": make sure class name exists, is public, and has an empty constructor that is public", paramContext);
    }
    catch (IllegalAccessException paramContext)
    {
    }
    throw new a("Unable to instantiate fragment " + paramString + ": make sure class name exists, is public, and has an empty constructor that is public", paramContext);
  }

  public static Fragment b(Context paramContext, String paramString)
  {
    return a(paramContext, paramString, null);
  }

  static boolean c(Context paramContext, String paramString)
  {
    try
    {
      Class localClass2 = (Class)cx.get(paramString);
      Class localClass1 = localClass2;
      if (localClass2 == null)
      {
        localClass1 = paramContext.getClassLoader().loadClass(paramString);
        cx.put(paramString, localClass1);
      }
      boolean bool = Fragment.class.isAssignableFrom(localClass1);
      return bool;
    }
    catch (ClassNotFoundException paramContext)
    {
    }
    return false;
  }

  public static void onDestroyOptionsMenu()
  {
  }

  public final void B()
  {
    if (this.cZ != true)
    {
      this.cZ = true;
      if ((isAdded()) && (!this.cV))
        this.cP.N();
    }
  }

  public final q C()
  {
    if (this.di != null)
      return this.di;
    if (this.cP == null)
      throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    this.dk = true;
    this.di = this.cP.a(this.cD, this.dj, true);
    return this.di;
  }

  public final void E()
  {
    this.db = true;
    if (this.cP == null);
    for (Activity localActivity = null; ; localActivity = this.cP.dL)
    {
      if (localActivity != null)
      {
        this.db = false;
        this.db = true;
      }
      return;
    }
  }

  public void G()
  {
  }

  final void H()
  {
    this.cQ = new l();
    this.cQ.a(this.cP, new h()
    {
      public final View onFindViewById(int paramAnonymousInt)
      {
        if (Fragment.this.mView == null)
          throw new IllegalStateException("Fragment does not have a view");
        return Fragment.this.mView.findViewById(paramAnonymousInt);
      }

      public final boolean onHasView()
      {
        return Fragment.this.mView != null;
      }
    }
    , this);
  }

  final void I()
  {
    if (this.cQ != null)
      this.cQ.i(2);
    this.mState = 2;
    if (this.dj)
    {
      this.dj = false;
      if (!this.dk)
      {
        this.dk = true;
        this.di = this.cP.a(this.cD, this.dj, false);
      }
      if (this.di != null)
      {
        if (!this.cP.dO)
          break label89;
        this.di.Z();
      }
    }
    return;
    label89: this.di.Y();
  }

  final View a(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle)
  {
    if (this.cQ != null)
      this.cQ.eg = false;
    return onCreateView(paramLayoutInflater, paramViewGroup, paramBundle);
  }

  public LayoutInflater c(Bundle paramBundle)
  {
    paramBundle = this.cP.onGetLayoutInflater();
    if (this.cQ == null)
    {
      H();
      if (this.mState < 5)
        break label44;
      this.cQ.dispatchResume();
    }
    while (true)
    {
      g.a(paramBundle, this.cQ);
      return paramBundle;
      label44: if (this.mState >= 4)
        this.cQ.dispatchStart();
      else if (this.mState >= 2)
        this.cQ.dispatchActivityCreated();
      else if (this.mState > 0)
        this.cQ.dispatchCreate();
    }
  }

  final void c(int paramInt, Fragment paramFragment)
  {
    this.mIndex = paramInt;
    if (paramFragment != null)
    {
      this.cD = (paramFragment.cD + ":" + this.mIndex);
      return;
    }
    this.cD = ("android:fragment:" + this.mIndex);
  }

  final void d(Bundle paramBundle)
  {
    onSaveInstanceState(paramBundle);
    if (this.cQ != null)
    {
      Parcelable localParcelable = this.cQ.saveAllState();
      if (localParcelable != null)
        paramBundle.putParcelable("android:support:fragments", localParcelable);
    }
  }

  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mFragmentId=#");
    paramPrintWriter.print(Integer.toHexString(this.cS));
    paramPrintWriter.print(" mContainerId=#");
    paramPrintWriter.print(Integer.toHexString(this.cT));
    paramPrintWriter.print(" mTag=");
    paramPrintWriter.println(this.cU);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mState=");
    paramPrintWriter.print(this.mState);
    paramPrintWriter.print(" mIndex=");
    paramPrintWriter.print(this.mIndex);
    paramPrintWriter.print(" mWho=");
    paramPrintWriter.print(this.cD);
    paramPrintWriter.print(" mBackStackNesting=");
    paramPrintWriter.println(this.cN);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mAdded=");
    paramPrintWriter.print(this.cI);
    paramPrintWriter.print(" mRemoving=");
    paramPrintWriter.print(this.cJ);
    paramPrintWriter.print(" mFromLayout=");
    paramPrintWriter.print(this.cK);
    paramPrintWriter.print(" mInLayout=");
    paramPrintWriter.println(this.cL);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mHidden=");
    paramPrintWriter.print(this.cV);
    paramPrintWriter.print(" mDetached=");
    paramPrintWriter.print(this.cW);
    paramPrintWriter.print(" mMenuVisible=");
    paramPrintWriter.print(this.da);
    paramPrintWriter.print(" mHasMenu=");
    paramPrintWriter.println(this.cZ);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mRetainInstance=");
    paramPrintWriter.print(this.cX);
    paramPrintWriter.print(" mRetaining=");
    paramPrintWriter.print(this.cY);
    paramPrintWriter.print(" mUserVisibleHint=");
    paramPrintWriter.println(this.dh);
    if (this.cO != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mFragmentManager=");
      paramPrintWriter.println(this.cO);
    }
    if (this.cP != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mHost=");
      paramPrintWriter.println(this.cP);
    }
    if (this.cR != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mParentFragment=");
      paramPrintWriter.println(this.cR);
    }
    if (this.cE != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mArguments=");
      paramPrintWriter.println(this.cE);
    }
    if (this.cB != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedFragmentState=");
      paramPrintWriter.println(this.cB);
    }
    if (this.cC != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedViewState=");
      paramPrintWriter.println(this.cC);
    }
    if (this.cF != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mTarget=");
      paramPrintWriter.print(this.cF);
      paramPrintWriter.print(" mTargetRequestCode=");
      paramPrintWriter.println(this.cH);
    }
    if (this.dc != 0)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mNextAnim=");
      paramPrintWriter.println(this.dc);
    }
    if (this.dd != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mContainer=");
      paramPrintWriter.println(this.dd);
    }
    if (this.mView != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mView=");
      paramPrintWriter.println(this.mView);
    }
    if (this.de != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mInnerView=");
      paramPrintWriter.println(this.mView);
    }
    if (this.cz != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAnimatingAway=");
      paramPrintWriter.println(this.cz);
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mStateAfterAnimating=");
      paramPrintWriter.println(this.cA);
    }
    if (this.di != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Loader Manager:");
      this.di.dump(paramString + "  ", paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    }
    if (this.cQ != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Child " + this.cQ + ":");
      this.cQ.dump(paramString + "  ", paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    }
  }

  public final boolean equals(Object paramObject)
  {
    return super.equals(paramObject);
  }

  public final Resources getResources()
  {
    if (this.cP == null)
      throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    return this.cP.mContext.getResources();
  }

  public final String getString(int paramInt)
  {
    return getResources().getString(paramInt);
  }

  public final String getString(int paramInt, Object[] paramArrayOfObject)
  {
    return getResources().getString(paramInt, paramArrayOfObject);
  }

  public final int hashCode()
  {
    return super.hashCode();
  }

  public final boolean isAdded()
  {
    return (this.cP != null) && (this.cI);
  }

  public void onActivityCreated(Bundle paramBundle)
  {
    this.db = true;
  }

  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
  }

  @Deprecated
  public void onAttach(Activity paramActivity)
  {
    this.db = true;
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    this.db = true;
  }

  public boolean onContextItemSelected(MenuItem paramMenuItem)
  {
    return false;
  }

  public void onCreate(Bundle paramBundle)
  {
    this.db = true;
  }

  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo)
  {
    z().onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
  }

  public void onCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater)
  {
  }

  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle)
  {
    return null;
  }

  public void onDestroy()
  {
    this.db = true;
    if (!this.dk)
    {
      this.dk = true;
      this.di = this.cP.a(this.cD, this.dj, false);
    }
    if (this.di != null)
      this.di.ac();
  }

  public void onDestroyView()
  {
    this.db = true;
  }

  public void onDetach()
  {
    this.db = true;
  }

  public void onLowMemory()
  {
    this.db = true;
  }

  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    return false;
  }

  public void onPause()
  {
    this.db = true;
  }

  public void onPrepareOptionsMenu(Menu paramMenu)
  {
  }

  public void onResume()
  {
    this.db = true;
  }

  public void onSaveInstanceState(Bundle paramBundle)
  {
  }

  public void onStart()
  {
    this.db = true;
    if (!this.dj)
    {
      this.dj = true;
      if (!this.dk)
      {
        this.dk = true;
        this.di = this.cP.a(this.cD, this.dj, false);
      }
      if (this.di != null)
        this.di.X();
    }
  }

  public void onStop()
  {
    this.db = true;
  }

  public final void setArguments(Bundle paramBundle)
  {
    if (this.mIndex >= 0)
      throw new IllegalStateException("Fragment already active");
    this.cE = paramBundle;
  }

  public final void setMenuVisibility(boolean paramBoolean)
  {
    if (this.da != paramBoolean)
    {
      this.da = paramBoolean;
      if ((this.cZ) && (isAdded()) && (!this.cV))
        this.cP.N();
    }
  }

  public void setUserVisibleHint(boolean paramBoolean)
  {
    if ((!this.dh) && (paramBoolean) && (this.mState < 4))
      this.cO.f(this);
    this.dh = paramBoolean;
    if (!paramBoolean);
    for (paramBoolean = true; ; paramBoolean = false)
    {
      this.dg = paramBoolean;
      return;
    }
  }

  public void startActivity(Intent paramIntent)
  {
    if (this.cP == null)
      throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    this.cP.b(this, paramIntent, -1, null);
  }

  public final void startActivityForResult(Intent paramIntent, int paramInt)
  {
    if (this.cP == null)
      throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    this.cP.b(this, paramIntent, paramInt, null);
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(128);
    c.a(this, localStringBuilder);
    if (this.mIndex >= 0)
    {
      localStringBuilder.append(" #");
      localStringBuilder.append(this.mIndex);
    }
    if (this.cS != 0)
    {
      localStringBuilder.append(" id=0x");
      localStringBuilder.append(Integer.toHexString(this.cS));
    }
    if (this.cU != null)
    {
      localStringBuilder.append(" ");
      localStringBuilder.append(this.cU);
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }

  public final FragmentActivity z()
  {
    if (this.cP == null)
      return null;
    return (FragmentActivity)this.cP.dL;
  }

  public static class SavedState
    implements Parcelable
  {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator()
    {
    };
    final Bundle dw;

    SavedState(Bundle paramBundle)
    {
      this.dw = paramBundle;
    }

    SavedState(Parcel paramParcel)
    {
      this.dw = paramParcel.readBundle();
    }

    public int describeContents()
    {
      return 0;
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      paramParcel.writeBundle(this.dw);
    }
  }

  public static final class a extends RuntimeException
  {
    public a(String paramString, Exception paramException)
    {
      super(paramException);
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.Fragment
 * JD-Core Version:    0.6.2
 */