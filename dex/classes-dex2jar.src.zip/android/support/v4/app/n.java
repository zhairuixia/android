package android.support.v4.app;

public abstract class n
{
  public abstract n a(int paramInt, Fragment paramFragment);

  public abstract n a(int paramInt, Fragment paramFragment, String paramString);

  public abstract n a(Fragment paramFragment);

  public abstract n a(Fragment paramFragment, String paramString);

  public abstract n b(int paramInt, Fragment paramFragment);

  public abstract n b(Fragment paramFragment);

  public abstract n c(Fragment paramFragment);

  public abstract int commit();

  public abstract int commitAllowingStateLoss();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.n
 * JD-Core Version:    0.6.2
 */