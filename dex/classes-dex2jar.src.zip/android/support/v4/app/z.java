package android.support.v4.app;

import android.app.PendingIntent;
import android.os.Bundle;

public final class z
{
  public static abstract class a
  {
    public abstract PendingIntent af();

    public abstract ag.a[] ag();

    public abstract Bundle getExtras();

    public abstract int getIcon();

    public abstract CharSequence getTitle();

    public static abstract interface a
    {
    }
  }

  public static abstract class b
  {
    abstract ag.a ah();

    abstract long getLatestTimestamp();

    abstract String[] getMessages();

    abstract String[] getParticipants();

    abstract PendingIntent getReadPendingIntent();

    abstract PendingIntent getReplyPendingIntent();

    public static abstract interface a
    {
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.z
 * JD-Core Version:    0.6.2
 */