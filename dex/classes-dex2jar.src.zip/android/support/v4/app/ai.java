package android.support.v4.app;

public abstract class ai
{
  private static int gV = 1048576;
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.ai
 * JD-Core Version:    0.6.2
 */