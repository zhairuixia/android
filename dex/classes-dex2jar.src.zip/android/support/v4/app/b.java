package android.support.v4.app;

final class b
{
  public static abstract interface a
  {
    public abstract void e(int paramInt);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.b
 * JD-Core Version:    0.6.2
 */