package android.support.v4.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import android.view.View.BaseSavedState;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import java.util.ArrayList;

public class FragmentTabHost extends TabHost
  implements TabHost.OnTabChangeListener
{
  private int cT;
  private k eE;
  private final ArrayList<a> eJ = new ArrayList();
  private TabHost.OnTabChangeListener eK;
  private a eL;
  private boolean eM;
  private Context mContext;

  public FragmentTabHost(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, new int[] { 16842995 }, 0, 0);
    this.cT = paramContext.getResourceId(0, 0);
    paramContext.recycle();
    super.setOnTabChangedListener(this);
  }

  private n a(String paramString, n paramn)
  {
    Object localObject = null;
    int i = 0;
    if (i < this.eJ.size())
    {
      a locala = (a)this.eJ.get(i);
      if (!locala.tag.equals(paramString))
        break label213;
      localObject = locala;
    }
    label200: label213: 
    while (true)
    {
      i += 1;
      break;
      if (localObject == null)
        throw new IllegalStateException("No tab known for tag " + paramString);
      paramString = paramn;
      if (this.eL != localObject)
      {
        paramString = paramn;
        if (paramn == null)
          paramString = this.eE.P();
        if ((this.eL != null) && (this.eL.cd != null))
          paramString.b(this.eL.cd);
        if (localObject != null)
        {
          if (localObject.cd != null)
            break label200;
          localObject.cd = Fragment.a(this.mContext, localObject.eO.getName(), localObject.eP);
          paramString.a(this.cT, localObject.cd, localObject.tag);
        }
      }
      while (true)
      {
        this.eL = localObject;
        return paramString;
        paramString.c(localObject.cd);
      }
    }
  }

  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    String str = getCurrentTabTag();
    Object localObject1 = null;
    int i = 0;
    if (i < this.eJ.size())
    {
      a locala = (a)this.eJ.get(i);
      locala.cd = this.eE.k(locala.tag);
      Object localObject2 = localObject1;
      if (locala.cd != null)
      {
        localObject2 = localObject1;
        if (!locala.cd.cW)
        {
          if (!locala.tag.equals(str))
            break label108;
          this.eL = locala;
          localObject2 = localObject1;
        }
      }
      while (true)
      {
        i += 1;
        localObject1 = localObject2;
        break;
        label108: localObject2 = localObject1;
        if (localObject1 == null)
          localObject2 = this.eE.P();
        ((n)localObject2).b(locala.cd);
      }
    }
    this.eM = true;
    localObject1 = a(str, (n)localObject1);
    if (localObject1 != null)
    {
      ((n)localObject1).commit();
      this.eE.executePendingTransactions();
    }
  }

  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    this.eM = false;
  }

  protected void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if (!(paramParcelable instanceof SavedState))
    {
      super.onRestoreInstanceState(paramParcelable);
      return;
    }
    paramParcelable = (SavedState)paramParcelable;
    super.onRestoreInstanceState(paramParcelable.getSuperState());
    setCurrentTabByTag(paramParcelable.eN);
  }

  protected Parcelable onSaveInstanceState()
  {
    SavedState localSavedState = new SavedState(super.onSaveInstanceState());
    localSavedState.eN = getCurrentTabTag();
    return localSavedState;
  }

  public void onTabChanged(String paramString)
  {
    if (this.eM)
    {
      n localn = a(paramString, null);
      if (localn != null)
        localn.commit();
    }
    if (this.eK != null)
      this.eK.onTabChanged(paramString);
  }

  public void setOnTabChangedListener(TabHost.OnTabChangeListener paramOnTabChangeListener)
  {
    this.eK = paramOnTabChangeListener;
  }

  @Deprecated
  public void setup()
  {
    throw new IllegalStateException("Must call setup() that takes a Context and FragmentManager");
  }

  static class SavedState extends View.BaseSavedState
  {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator()
    {
    };
    String eN;

    private SavedState(Parcel paramParcel)
    {
      super();
      this.eN = paramParcel.readString();
    }

    SavedState(Parcelable paramParcelable)
    {
      super();
    }

    public String toString()
    {
      return "FragmentTabHost.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " curTab=" + this.eN + "}";
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      super.writeToParcel(paramParcel, paramInt);
      paramParcel.writeString(this.eN);
    }
  }

  static final class a
  {
    Fragment cd;
    final Class<?> eO;
    final Bundle eP;
    final String tag;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentTabHost
 * JD-Core Version:    0.6.2
 */