package android.support.v4.app;

import android.util.AndroidRuntimeException;

final class aj extends AndroidRuntimeException
{
  public aj(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.aj
 * JD-Core Version:    0.6.2
 */