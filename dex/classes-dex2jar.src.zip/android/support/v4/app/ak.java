package android.support.v4.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import java.util.ArrayList;
import java.util.Iterator;

public final class ak
  implements Iterable<Intent>
{
  private static final b gW = new c();
  public final ArrayList<Intent> gX = new ArrayList();
  public final Context gY;

  static
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      gW = new d();
      return;
    }
  }

  private ak(Context paramContext)
  {
    this.gY = paramContext;
  }

  public static ak i(Context paramContext)
  {
    return new ak(paramContext);
  }

  public final ak a(ComponentName paramComponentName)
  {
    int i = this.gX.size();
    try
    {
      for (paramComponentName = s.a(this.gY, paramComponentName); paramComponentName != null; paramComponentName = s.a(this.gY, paramComponentName.getComponent()))
        this.gX.add(i, paramComponentName);
    }
    catch (PackageManager.NameNotFoundException paramComponentName)
    {
      throw new IllegalArgumentException(paramComponentName);
    }
    return this;
  }

  public final Iterator<Intent> iterator()
  {
    return this.gX.iterator();
  }

  public static abstract interface a
  {
    public abstract Intent aj();
  }

  static abstract interface b
  {
  }

  static final class c
    implements ak.b
  {
  }

  static final class d
    implements ak.b
  {
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.app.ak
 * JD-Core Version:    0.6.2
 */