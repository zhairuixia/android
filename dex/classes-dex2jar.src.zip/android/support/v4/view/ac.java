package android.support.v4.view;

import android.graphics.Rect;
import android.view.View;
import android.view.View.OnApplyWindowInsetsListener;
import android.view.WindowInsets;

final class ac
{
  private static ThreadLocal<Rect> kS;

  static Rect aF()
  {
    if (kS == null)
      kS = new ThreadLocal();
    Rect localRect2 = (Rect)kS.get();
    Rect localRect1 = localRect2;
    if (localRect2 == null)
    {
      localRect1 = new Rect();
      kS.set(localRect1);
    }
    localRect1.setEmpty();
    return localRect1;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ac
 * JD-Core Version:    0.6.2
 */