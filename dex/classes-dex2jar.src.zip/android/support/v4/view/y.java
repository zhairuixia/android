package android.support.v4.view;

import android.animation.ValueAnimator;
import android.content.res.ColorStateList;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.view.View;
import android.view.View.AccessibilityDelegate;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.WeakHashMap;

public final class y
{
  static final m kM = new a();

  static
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 23)
    {
      kM = new l();
      return;
    }
    if (i >= 21)
    {
      kM = new k();
      return;
    }
    if (i >= 19)
    {
      kM = new j();
      return;
    }
    if (i >= 17)
    {
      kM = new h();
      return;
    }
    if (i >= 16)
    {
      kM = new g();
      return;
    }
    if (i >= 15)
    {
      kM = new e();
      return;
    }
    if (i >= 14)
    {
      kM = new f();
      return;
    }
    if (i >= 11)
    {
      kM = new d();
      return;
    }
    if (i >= 9)
    {
      kM = new c();
      return;
    }
    if (i >= 7)
    {
      kM = new b();
      return;
    }
  }

  public static ColorStateList A(View paramView)
  {
    return kM.A(paramView);
  }

  public static PorterDuff.Mode B(View paramView)
  {
    return kM.B(paramView);
  }

  public static boolean C(View paramView)
  {
    return kM.C(paramView);
  }

  public static void D(View paramView)
  {
    kM.D(paramView);
  }

  public static boolean E(View paramView)
  {
    return kM.E(paramView);
  }

  public static boolean F(View paramView)
  {
    return kM.F(paramView);
  }

  public static boolean G(View paramView)
  {
    return kM.G(paramView);
  }

  public static ao a(View paramView, ao paramao)
  {
    return kM.a(paramView, paramao);
  }

  public static void a(View paramView, float paramFloat)
  {
    kM.a(paramView, paramFloat);
  }

  public static void a(View paramView, int paramInt1, int paramInt2)
  {
    kM.a(paramView, paramInt1, 3);
  }

  public static void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    kM.a(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }

  public static void a(View paramView, int paramInt, Paint paramPaint)
  {
    kM.a(paramView, paramInt, paramPaint);
  }

  public static void a(View paramView, ColorStateList paramColorStateList)
  {
    kM.a(paramView, paramColorStateList);
  }

  public static void a(View paramView, Paint paramPaint)
  {
    kM.a(paramView, paramPaint);
  }

  public static void a(View paramView, PorterDuff.Mode paramMode)
  {
    kM.a(paramView, paramMode);
  }

  public static void a(View paramView, a parama)
  {
    kM.a(paramView, parama);
  }

  public static void a(View paramView, s params)
  {
    kM.a(paramView, params);
  }

  public static void a(View paramView, Runnable paramRunnable)
  {
    kM.a(paramView, paramRunnable);
  }

  public static void a(View paramView, Runnable paramRunnable, long paramLong)
  {
    kM.a(paramView, paramRunnable, paramLong);
  }

  public static void a(View paramView, boolean paramBoolean)
  {
    kM.a(paramView, paramBoolean);
  }

  public static void a(ViewGroup paramViewGroup)
  {
    kM.a(paramViewGroup, true);
  }

  public static boolean a(View paramView, int paramInt)
  {
    return kM.a(paramView, paramInt);
  }

  public static ao b(View paramView, ao paramao)
  {
    return kM.b(paramView, paramao);
  }

  public static void b(View paramView, float paramFloat)
  {
    kM.b(paramView, paramFloat);
  }

  public static boolean b(View paramView, int paramInt)
  {
    return kM.b(paramView, paramInt);
  }

  public static void c(View paramView, float paramFloat)
  {
    kM.c(paramView, paramFloat);
  }

  public static void c(View paramView, int paramInt)
  {
    kM.c(paramView, paramInt);
  }

  public static void d(View paramView, float paramFloat)
  {
    kM.d(paramView, paramFloat);
  }

  public static void d(View paramView, int paramInt)
  {
    kM.d(paramView, paramInt);
  }

  public static void e(View paramView, float paramFloat)
  {
    kM.e(paramView, paramFloat);
  }

  public static void e(View paramView, int paramInt)
  {
    kM.e(paramView, paramInt);
  }

  public static int g(View paramView)
  {
    return kM.g(paramView);
  }

  public static void h(View paramView)
  {
    kM.h(paramView);
  }

  public static int i(View paramView)
  {
    return kM.i(paramView);
  }

  public static int j(View paramView)
  {
    return kM.j(paramView);
  }

  public static int k(View paramView)
  {
    return kM.k(paramView);
  }

  public static ViewParent l(View paramView)
  {
    return kM.l(paramView);
  }

  public static boolean m(View paramView)
  {
    return kM.m(paramView);
  }

  public static int n(View paramView)
  {
    return kM.n(paramView);
  }

  public static int o(View paramView)
  {
    return kM.o(paramView);
  }

  public static float p(View paramView)
  {
    return kM.p(paramView);
  }

  public static int q(View paramView)
  {
    return kM.q(paramView);
  }

  public static ah r(View paramView)
  {
    return kM.r(paramView);
  }

  public static int resolveSizeAndState(int paramInt1, int paramInt2, int paramInt3)
  {
    return kM.resolveSizeAndState(paramInt1, paramInt2, paramInt3);
  }

  public static float s(View paramView)
  {
    return kM.s(paramView);
  }

  public static float t(View paramView)
  {
    return kM.t(paramView);
  }

  public static int u(View paramView)
  {
    return kM.u(paramView);
  }

  public static void v(View paramView)
  {
    kM.v(paramView);
  }

  public static boolean w(View paramView)
  {
    return kM.w(paramView);
  }

  public static void x(View paramView)
  {
    kM.x(paramView);
  }

  public static void y(View paramView)
  {
    kM.b(paramView, false);
  }

  public static boolean z(View paramView)
  {
    return kM.z(paramView);
  }

  static class a
    implements y.m
  {
    WeakHashMap<View, ah> kN = null;

    public ColorStateList A(View paramView)
    {
      if ((paramView instanceof w))
        return ((w)paramView).aC();
      return null;
    }

    public PorterDuff.Mode B(View paramView)
    {
      if ((paramView instanceof w))
        return ((w)paramView).aD();
      return null;
    }

    public boolean C(View paramView)
    {
      if ((paramView instanceof o))
        return ((o)paramView).isNestedScrollingEnabled();
      return false;
    }

    public void D(View paramView)
    {
      if ((paramView instanceof o))
        ((o)paramView).stopNestedScroll();
    }

    public boolean E(View paramView)
    {
      return (paramView.getWidth() > 0) && (paramView.getHeight() > 0);
    }

    public boolean F(View paramView)
    {
      return paramView.getWindowToken() != null;
    }

    public boolean G(View paramView)
    {
      return false;
    }

    public ao a(View paramView, ao paramao)
    {
      return paramao;
    }

    public void a(View paramView, float paramFloat)
    {
    }

    public void a(View paramView, int paramInt1, int paramInt2)
    {
    }

    public void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      paramView.invalidate(paramInt1, paramInt2, paramInt3, paramInt4);
    }

    public void a(View paramView, int paramInt, Paint paramPaint)
    {
    }

    public void a(View paramView, ColorStateList paramColorStateList)
    {
      if ((paramView instanceof w))
        ((w)paramView).b(paramColorStateList);
    }

    public void a(View paramView, Paint paramPaint)
    {
    }

    public void a(View paramView, PorterDuff.Mode paramMode)
    {
      if ((paramView instanceof w))
        ((w)paramView).b(paramMode);
    }

    public void a(View paramView, a parama)
    {
    }

    public void a(View paramView, s params)
    {
    }

    public void a(View paramView, Runnable paramRunnable)
    {
      paramView.postDelayed(paramRunnable, aE());
    }

    public void a(View paramView, Runnable paramRunnable, long paramLong)
    {
      paramView.postDelayed(paramRunnable, aE() + paramLong);
    }

    public void a(View paramView, boolean paramBoolean)
    {
    }

    public void a(ViewGroup paramViewGroup, boolean paramBoolean)
    {
    }

    public boolean a(View paramView, int paramInt)
    {
      if ((paramView instanceof v))
      {
        paramView = (v)paramView;
        int i = paramView.computeHorizontalScrollOffset();
        int j = paramView.computeHorizontalScrollRange() - paramView.computeHorizontalScrollExtent();
        if (j != 0)
          if (paramInt < 0)
            if (i > 0)
              paramInt = 1;
        while (paramInt != 0)
        {
          return true;
          paramInt = 0;
          continue;
          if (i < j - 1)
            paramInt = 1;
          else
            paramInt = 0;
        }
      }
      return false;
    }

    long aE()
    {
      return 10L;
    }

    public ao b(View paramView, ao paramao)
    {
      return paramao;
    }

    public void b(View paramView, float paramFloat)
    {
    }

    public void b(View paramView, boolean paramBoolean)
    {
    }

    public boolean b(View paramView, int paramInt)
    {
      if ((paramView instanceof v))
      {
        paramView = (v)paramView;
        int i = paramView.computeVerticalScrollOffset();
        int j = paramView.computeVerticalScrollRange() - paramView.computeVerticalScrollExtent();
        if (j != 0)
          if (paramInt < 0)
            if (i > 0)
              paramInt = 1;
        while (paramInt != 0)
        {
          return true;
          paramInt = 0;
          continue;
          if (i < j - 1)
            paramInt = 1;
          else
            paramInt = 0;
        }
      }
      return false;
    }

    public void c(View paramView, float paramFloat)
    {
    }

    public void c(View paramView, int paramInt)
    {
    }

    public void d(View paramView, float paramFloat)
    {
    }

    public void d(View paramView, int paramInt)
    {
      int i = paramView.getTop();
      paramView.offsetTopAndBottom(paramInt);
      if (paramInt != 0)
      {
        ViewParent localViewParent = paramView.getParent();
        if ((localViewParent instanceof View))
        {
          paramInt = Math.abs(paramInt);
          ((View)localViewParent).invalidate(paramView.getLeft(), i - paramInt, paramView.getRight(), i + paramView.getHeight() + paramInt);
        }
      }
      else
      {
        return;
      }
      paramView.invalidate();
    }

    public void e(View paramView, float paramFloat)
    {
    }

    public void e(View paramView, int paramInt)
    {
      int i = paramView.getLeft();
      paramView.offsetLeftAndRight(paramInt);
      if (paramInt != 0)
      {
        ViewParent localViewParent = paramView.getParent();
        if ((localViewParent instanceof View))
        {
          paramInt = Math.abs(paramInt);
          ((View)localViewParent).invalidate(i - paramInt, paramView.getTop(), i + paramView.getWidth() + paramInt, paramView.getBottom());
        }
      }
      else
      {
        return;
      }
      paramView.invalidate();
    }

    public int g(View paramView)
    {
      return 2;
    }

    public void h(View paramView)
    {
      paramView.invalidate();
    }

    public int i(View paramView)
    {
      return 0;
    }

    public int j(View paramView)
    {
      return 0;
    }

    public int k(View paramView)
    {
      return 0;
    }

    public ViewParent l(View paramView)
    {
      return paramView.getParent();
    }

    public boolean m(View paramView)
    {
      boolean bool2 = false;
      paramView = paramView.getBackground();
      boolean bool1 = bool2;
      if (paramView != null)
      {
        bool1 = bool2;
        if (paramView.getOpacity() == -1)
          bool1 = true;
      }
      return bool1;
    }

    public int n(View paramView)
    {
      return paramView.getMeasuredWidth();
    }

    public int o(View paramView)
    {
      return 0;
    }

    public float p(View paramView)
    {
      return 0.0F;
    }

    public int q(View paramView)
    {
      return z.q(paramView);
    }

    public ah r(View paramView)
    {
      return new ah(paramView);
    }

    public int resolveSizeAndState(int paramInt1, int paramInt2, int paramInt3)
    {
      return View.resolveSize(paramInt1, paramInt2);
    }

    public float s(View paramView)
    {
      return 0.0F;
    }

    public float t(View paramView)
    {
      return 0.0F;
    }

    public int u(View paramView)
    {
      return 0;
    }

    public void v(View paramView)
    {
    }

    public boolean w(View paramView)
    {
      return false;
    }

    public void x(View paramView)
    {
    }

    public boolean z(View paramView)
    {
      return true;
    }
  }

  static class b extends y.a
  {
    public final void a(ViewGroup paramViewGroup, boolean paramBoolean)
    {
      if (aa.kR == null);
      try
      {
        aa.kR = ViewGroup.class.getDeclaredMethod("setChildrenDrawingOrderEnabled", new Class[] { Boolean.TYPE });
        label26: aa.kR.setAccessible(true);
        try
        {
          aa.kR.invoke(paramViewGroup, new Object[] { Boolean.valueOf(true) });
          return;
        }
        catch (InvocationTargetException paramViewGroup)
        {
        }
        catch (IllegalArgumentException paramViewGroup)
        {
        }
        catch (IllegalAccessException paramViewGroup)
        {
        }
      }
      catch (NoSuchMethodException localNoSuchMethodException)
      {
        break label26;
      }
    }

    public final boolean m(View paramView)
    {
      return paramView.isOpaque();
    }
  }

  static class c extends y.b
  {
    public final int g(View paramView)
    {
      return paramView.getOverScrollMode();
    }
  }

  static class d extends y.c
  {
    public final void a(View paramView, float paramFloat)
    {
      paramView.setTranslationY(paramFloat);
    }

    public final void a(View paramView, int paramInt, Paint paramPaint)
    {
      paramView.setLayerType(paramInt, paramPaint);
    }

    public void a(View paramView, Paint paramPaint)
    {
      a(paramView, paramView.getLayerType(), paramPaint);
      paramView.invalidate();
    }

    public final void a(View paramView, boolean paramBoolean)
    {
      paramView.setActivated(paramBoolean);
    }

    final long aE()
    {
      return ValueAnimator.getFrameDelay();
    }

    public final void b(View paramView, float paramFloat)
    {
      paramView.setAlpha(paramFloat);
    }

    public final void b(View paramView, boolean paramBoolean)
    {
      paramView.setSaveFromParentEnabled(false);
    }

    public final void c(View paramView, float paramFloat)
    {
      paramView.setScaleX(paramFloat);
    }

    public final void d(View paramView, float paramFloat)
    {
      paramView.setScaleY(paramFloat);
    }

    public void d(View paramView, int paramInt)
    {
      ab.d(paramView, paramInt);
    }

    public void e(View paramView, int paramInt)
    {
      ab.e(paramView, paramInt);
    }

    public final int j(View paramView)
    {
      return paramView.getLayerType();
    }

    public final int n(View paramView)
    {
      return paramView.getMeasuredWidthAndState();
    }

    public final int o(View paramView)
    {
      return paramView.getMeasuredState();
    }

    public final float p(View paramView)
    {
      return paramView.getTranslationY();
    }

    public final int resolveSizeAndState(int paramInt1, int paramInt2, int paramInt3)
    {
      return View.resolveSizeAndState(paramInt1, paramInt2, paramInt3);
    }

    public final float s(View paramView)
    {
      return paramView.getScaleX();
    }

    public final void x(View paramView)
    {
      paramView.jumpDrawablesToCurrentState();
    }
  }

  static class e extends y.f
  {
    public final boolean G(View paramView)
    {
      return paramView.hasOnClickListeners();
    }
  }

  static class f extends y.d
  {
    static boolean kO = false;

    public final void a(View paramView, a parama)
    {
      if (parama == null);
      for (parama = null; ; parama = parama.jz)
      {
        paramView.setAccessibilityDelegate((View.AccessibilityDelegate)parama);
        return;
      }
    }

    public final boolean a(View paramView, int paramInt)
    {
      return paramView.canScrollHorizontally(paramInt);
    }

    public final boolean b(View paramView, int paramInt)
    {
      return paramView.canScrollVertically(paramInt);
    }

    public final ah r(View paramView)
    {
      if (this.kN == null)
        this.kN = new WeakHashMap();
      ah localah2 = (ah)this.kN.get(paramView);
      ah localah1 = localah2;
      if (localah2 == null)
      {
        localah1 = new ah(paramView);
        this.kN.put(paramView, localah1);
      }
      return localah1;
    }
  }

  static class g extends y.e
  {
    public final void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      paramView.postInvalidate(paramInt1, paramInt2, paramInt3, paramInt4);
    }

    public final void a(View paramView, Runnable paramRunnable)
    {
      paramView.postOnAnimation(paramRunnable);
    }

    public final void a(View paramView, Runnable paramRunnable, long paramLong)
    {
      paramView.postOnAnimationDelayed(paramRunnable, paramLong);
    }

    public void c(View paramView, int paramInt)
    {
      int i = paramInt;
      if (paramInt == 4)
        i = 2;
      paramView.setImportantForAccessibility(i);
    }

    public final void h(View paramView)
    {
      paramView.postInvalidateOnAnimation();
    }

    public final int i(View paramView)
    {
      return paramView.getImportantForAccessibility();
    }

    public final ViewParent l(View paramView)
    {
      return paramView.getParentForAccessibility();
    }

    public final int q(View paramView)
    {
      return paramView.getMinimumHeight();
    }

    public void v(View paramView)
    {
      paramView.requestFitSystemWindows();
    }

    public final boolean w(View paramView)
    {
      return paramView.getFitsSystemWindows();
    }

    public final boolean z(View paramView)
    {
      return paramView.hasOverlappingRendering();
    }
  }

  static class h extends y.g
  {
    public final void a(View paramView, Paint paramPaint)
    {
      paramView.setLayerPaint(paramPaint);
    }

    public final int k(View paramView)
    {
      return paramView.getLayoutDirection();
    }

    public final int u(View paramView)
    {
      return paramView.getWindowSystemUiVisibility();
    }
  }

  static class i extends y.h
  {
  }

  static class j extends y.i
  {
    public final boolean E(View paramView)
    {
      return paramView.isLaidOut();
    }

    public final boolean F(View paramView)
    {
      return paramView.isAttachedToWindow();
    }

    public final void c(View paramView, int paramInt)
    {
      paramView.setImportantForAccessibility(paramInt);
    }
  }

  static class k extends y.j
  {
    public final ColorStateList A(View paramView)
    {
      return paramView.getBackgroundTintList();
    }

    public final PorterDuff.Mode B(View paramView)
    {
      return paramView.getBackgroundTintMode();
    }

    public final boolean C(View paramView)
    {
      return paramView.isNestedScrollingEnabled();
    }

    public final void D(View paramView)
    {
      paramView.stopNestedScroll();
    }

    public final ao a(View paramView, ao paramao)
    {
      Object localObject = paramao;
      if ((paramao instanceof ap))
      {
        WindowInsets localWindowInsets = ((ap)paramao).mw;
        paramView = paramView.onApplyWindowInsets(localWindowInsets);
        localObject = paramao;
        if (paramView != localWindowInsets)
          localObject = new ap(paramView);
      }
      return localObject;
    }

    public final void a(View paramView, ColorStateList paramColorStateList)
    {
      paramView.setBackgroundTintList(paramColorStateList);
      if (Build.VERSION.SDK_INT == 21)
      {
        paramColorStateList = paramView.getBackground();
        if ((paramView.getBackgroundTintList() == null) || (paramView.getBackgroundTintMode() == null))
          break label64;
      }
      label64: for (int i = 1; ; i = 0)
      {
        if ((paramColorStateList != null) && (i != 0))
        {
          if (paramColorStateList.isStateful())
            paramColorStateList.setState(paramView.getDrawableState());
          paramView.setBackground(paramColorStateList);
        }
        return;
      }
    }

    public final void a(View paramView, PorterDuff.Mode paramMode)
    {
      paramView.setBackgroundTintMode(paramMode);
      if (Build.VERSION.SDK_INT == 21)
      {
        paramMode = paramView.getBackground();
        if ((paramView.getBackgroundTintList() == null) || (paramView.getBackgroundTintMode() == null))
          break label64;
      }
      label64: for (int i = 1; ; i = 0)
      {
        if ((paramMode != null) && (i != 0))
        {
          if (paramMode.isStateful())
            paramMode.setState(paramView.getDrawableState());
          paramView.setBackground(paramMode);
        }
        return;
      }
    }

    public final void a(View paramView, s params)
    {
      if (params == null)
      {
        paramView.setOnApplyWindowInsetsListener(null);
        return;
      }
      paramView.setOnApplyWindowInsetsListener(new ac.1(params));
    }

    public final ao b(View paramView, ao paramao)
    {
      Object localObject = paramao;
      if ((paramao instanceof ap))
      {
        WindowInsets localWindowInsets = ((ap)paramao).mw;
        paramView = paramView.dispatchApplyWindowInsets(localWindowInsets);
        localObject = paramao;
        if (paramView != localWindowInsets)
          localObject = new ap(paramView);
      }
      return localObject;
    }

    public void d(View paramView, int paramInt)
    {
      Rect localRect = ac.aF();
      ViewParent localViewParent = paramView.getParent();
      int i;
      if ((localViewParent instanceof View))
      {
        View localView = (View)localViewParent;
        localRect.set(localView.getLeft(), localView.getTop(), localView.getRight(), localView.getBottom());
        if (!localRect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()))
          i = 1;
      }
      while (true)
      {
        ab.d(paramView, paramInt);
        if ((i != 0) && (localRect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom())))
          ((View)localViewParent).invalidate(localRect);
        return;
        i = 0;
        continue;
        i = 0;
      }
    }

    public final void e(View paramView, float paramFloat)
    {
      paramView.setElevation(paramFloat);
    }

    public void e(View paramView, int paramInt)
    {
      Rect localRect = ac.aF();
      ViewParent localViewParent = paramView.getParent();
      int i;
      if ((localViewParent instanceof View))
      {
        View localView = (View)localViewParent;
        localRect.set(localView.getLeft(), localView.getTop(), localView.getRight(), localView.getBottom());
        if (!localRect.intersects(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom()))
          i = 1;
      }
      while (true)
      {
        ab.e(paramView, paramInt);
        if ((i != 0) && (localRect.intersect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom())))
          ((View)localViewParent).invalidate(localRect);
        return;
        i = 0;
        continue;
        i = 0;
      }
    }

    public final float t(View paramView)
    {
      return paramView.getElevation();
    }

    public final void v(View paramView)
    {
      paramView.requestApplyInsets();
    }
  }

  static final class l extends y.k
  {
    public final void a(View paramView, int paramInt1, int paramInt2)
    {
      paramView.setScrollIndicators(paramInt1, paramInt2);
    }

    public final void d(View paramView, int paramInt)
    {
      paramView.offsetTopAndBottom(paramInt);
    }

    public final void e(View paramView, int paramInt)
    {
      paramView.offsetLeftAndRight(paramInt);
    }
  }

  static abstract interface m
  {
    public abstract ColorStateList A(View paramView);

    public abstract PorterDuff.Mode B(View paramView);

    public abstract boolean C(View paramView);

    public abstract void D(View paramView);

    public abstract boolean E(View paramView);

    public abstract boolean F(View paramView);

    public abstract boolean G(View paramView);

    public abstract ao a(View paramView, ao paramao);

    public abstract void a(View paramView, float paramFloat);

    public abstract void a(View paramView, int paramInt1, int paramInt2);

    public abstract void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

    public abstract void a(View paramView, int paramInt, Paint paramPaint);

    public abstract void a(View paramView, ColorStateList paramColorStateList);

    public abstract void a(View paramView, Paint paramPaint);

    public abstract void a(View paramView, PorterDuff.Mode paramMode);

    public abstract void a(View paramView, a parama);

    public abstract void a(View paramView, s params);

    public abstract void a(View paramView, Runnable paramRunnable);

    public abstract void a(View paramView, Runnable paramRunnable, long paramLong);

    public abstract void a(View paramView, boolean paramBoolean);

    public abstract void a(ViewGroup paramViewGroup, boolean paramBoolean);

    public abstract boolean a(View paramView, int paramInt);

    public abstract ao b(View paramView, ao paramao);

    public abstract void b(View paramView, float paramFloat);

    public abstract void b(View paramView, boolean paramBoolean);

    public abstract boolean b(View paramView, int paramInt);

    public abstract void c(View paramView, float paramFloat);

    public abstract void c(View paramView, int paramInt);

    public abstract void d(View paramView, float paramFloat);

    public abstract void d(View paramView, int paramInt);

    public abstract void e(View paramView, float paramFloat);

    public abstract void e(View paramView, int paramInt);

    public abstract int g(View paramView);

    public abstract void h(View paramView);

    public abstract int i(View paramView);

    public abstract int j(View paramView);

    public abstract int k(View paramView);

    public abstract ViewParent l(View paramView);

    public abstract boolean m(View paramView);

    public abstract int n(View paramView);

    public abstract int o(View paramView);

    public abstract float p(View paramView);

    public abstract int q(View paramView);

    public abstract ah r(View paramView);

    public abstract int resolveSizeAndState(int paramInt1, int paramInt2, int paramInt3);

    public abstract float s(View paramView);

    public abstract float t(View paramView);

    public abstract int u(View paramView);

    public abstract void v(View paramView);

    public abstract boolean w(View paramView);

    public abstract void x(View paramView);

    public abstract boolean z(View paramView);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.y
 * JD-Core Version:    0.6.2
 */