package android.support.v4.view;

public abstract interface o
{
  public abstract boolean isNestedScrollingEnabled();

  public abstract void stopNestedScroll();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.o
 * JD-Core Version:    0.6.2
 */