package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.ViewConfiguration;

public final class ad
{
  static final e kU = new a();

  static
  {
    if (Build.VERSION.SDK_INT >= 14)
    {
      kU = new d();
      return;
    }
    if (Build.VERSION.SDK_INT >= 11)
    {
      kU = new c();
      return;
    }
    if (Build.VERSION.SDK_INT >= 8)
    {
      kU = new b();
      return;
    }
  }

  public static int a(ViewConfiguration paramViewConfiguration)
  {
    return kU.a(paramViewConfiguration);
  }

  public static boolean b(ViewConfiguration paramViewConfiguration)
  {
    return kU.b(paramViewConfiguration);
  }

  static class a
    implements ad.e
  {
    public int a(ViewConfiguration paramViewConfiguration)
    {
      return paramViewConfiguration.getScaledTouchSlop();
    }

    public boolean b(ViewConfiguration paramViewConfiguration)
    {
      return true;
    }
  }

  static class b extends ad.a
  {
    public final int a(ViewConfiguration paramViewConfiguration)
    {
      return paramViewConfiguration.getScaledPagingTouchSlop();
    }
  }

  static class c extends ad.b
  {
    public boolean b(ViewConfiguration paramViewConfiguration)
    {
      return false;
    }
  }

  static final class d extends ad.c
  {
    public final boolean b(ViewConfiguration paramViewConfiguration)
    {
      return paramViewConfiguration.hasPermanentMenuKey();
    }
  }

  static abstract interface e
  {
    public abstract int a(ViewConfiguration paramViewConfiguration);

    public abstract boolean b(ViewConfiguration paramViewConfiguration);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ad
 * JD-Core Version:    0.6.2
 */