package android.support.v4.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater.Factory;
import android.view.View;

final class h
{
  static class a
    implements LayoutInflater.Factory
  {
    final j jK;

    a(j paramj)
    {
      this.jK = paramj;
    }

    public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet)
    {
      return this.jK.onCreateView(null, paramString, paramContext, paramAttributeSet);
    }

    public String toString()
    {
      return getClass().getName() + "{" + this.jK + "}";
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.h
 * JD-Core Version:    0.6.2
 */