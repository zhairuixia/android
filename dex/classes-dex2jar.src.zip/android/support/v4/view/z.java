package android.support.v4.view;

import android.view.View;
import java.lang.reflect.Field;

final class z
{
  private static Field kP;
  private static boolean kQ;

  static int q(View paramView)
  {
    if (!kQ);
    try
    {
      Field localField = View.class.getDeclaredField("mMinHeight");
      kP = localField;
      localField.setAccessible(true);
      label23: kQ = true;
      if (kP != null)
        try
        {
          int i = ((Integer)kP.get(paramView)).intValue();
          return i;
        }
        catch (Exception paramView)
        {
        }
      return 0;
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      break label23;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.z
 * JD-Core Version:    0.6.2
 */