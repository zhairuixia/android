package android.support.v4.view;

import android.view.ViewGroup;

public final class r
{
  private final ViewGroup jW;
  public int jX;

  public r(ViewGroup paramViewGroup)
  {
    this.jW = paramViewGroup;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.r
 * JD-Core Version:    0.6.2
 */