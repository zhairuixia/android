package android.support.v4.view;

import android.database.DataSetObservable;
import android.database.DataSetObserver;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;

public abstract class t
{
  private final DataSetObservable jY = new DataSetObservable();
  private DataSetObserver jZ;

  public void U()
  {
  }

  public Parcelable V()
  {
    return null;
  }

  public Object a(ViewGroup paramViewGroup, int paramInt)
  {
    throw new UnsupportedOperationException("Required method instantiateItem was not overridden");
  }

  final void a(DataSetObserver paramDataSetObserver)
  {
    try
    {
      this.jZ = paramDataSetObserver;
      return;
    }
    finally
    {
    }
    throw paramDataSetObserver;
  }

  public void a(Parcelable paramParcelable, ClassLoader paramClassLoader)
  {
  }

  public void a(ViewGroup paramViewGroup, int paramInt, Object paramObject)
  {
    throw new UnsupportedOperationException("Required method destroyItem was not overridden");
  }

  public abstract boolean a(View paramView, Object paramObject);

  public void d(Object paramObject)
  {
  }

  public abstract int getCount();

  public int i(Object paramObject)
  {
    return -1;
  }

  public void notifyDataSetChanged()
  {
    try
    {
      if (this.jZ != null)
        this.jZ.onChanged();
      this.jY.notifyChanged();
      return;
    }
    finally
    {
    }
  }

  public final void registerDataSetObserver(DataSetObserver paramDataSetObserver)
  {
    this.jY.registerObserver(paramDataSetObserver);
  }

  public final void unregisterDataSetObserver(DataSetObserver paramDataSetObserver)
  {
    this.jY.unregisterObserver(paramDataSetObserver);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.t
 * JD-Core Version:    0.6.2
 */