package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

public final class ah
{
  public static final g mm = new a();
  public WeakReference<View> mi;
  private Runnable mj = null;
  private Runnable mk = null;
  private int ml = -1;

  static
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 21)
    {
      mm = new f();
      return;
    }
    if (i >= 19)
    {
      mm = new e();
      return;
    }
    if (i >= 18)
    {
      mm = new c();
      return;
    }
    if (i >= 16)
    {
      mm = new d();
      return;
    }
    if (i >= 14)
    {
      mm = new b();
      return;
    }
  }

  ah(View paramView)
  {
    this.mi = new WeakReference(paramView);
  }

  public final ah a(al paramal)
  {
    View localView = (View)this.mi.get();
    if (localView != null)
      mm.a(this, localView, paramal);
    return this;
  }

  public final ah a(an paraman)
  {
    View localView = (View)this.mi.get();
    if (localView != null)
      mm.a(localView, paraman);
    return this;
  }

  public final void cancel()
  {
    View localView = (View)this.mi.get();
    if (localView != null)
      mm.a(this, localView);
  }

  public final ah d(long paramLong)
  {
    View localView = (View)this.mi.get();
    if (localView != null)
      mm.a(localView, paramLong);
    return this;
  }

  public final ah e(float paramFloat)
  {
    View localView = (View)this.mi.get();
    if (localView != null)
      mm.a(this, localView, paramFloat);
    return this;
  }

  public final ah f(float paramFloat)
  {
    View localView = (View)this.mi.get();
    if (localView != null)
      mm.b(this, localView, paramFloat);
    return this;
  }

  static class a
    implements ah.g
  {
    WeakHashMap<View, Runnable> mn = null;

    private void d(ah paramah, View paramView)
    {
      Runnable localRunnable = null;
      if (this.mn != null)
        localRunnable = (Runnable)this.mn.get(paramView);
      Object localObject = localRunnable;
      if (localRunnable == null)
      {
        localObject = new a(paramah, paramView, (byte)0);
        if (this.mn == null)
          this.mn = new WeakHashMap();
        this.mn.put(paramView, localObject);
      }
      paramView.removeCallbacks((Runnable)localObject);
      paramView.post((Runnable)localObject);
    }

    public long K(View paramView)
    {
      return 0L;
    }

    public void a(ah paramah, View paramView)
    {
      d(paramah, paramView);
    }

    public void a(ah paramah, View paramView, float paramFloat)
    {
      d(paramah, paramView);
    }

    public void a(ah paramah, View paramView, al paramal)
    {
      paramView.setTag(2113929216, paramal);
    }

    public void a(View paramView, long paramLong)
    {
    }

    public void a(View paramView, an paraman)
    {
    }

    public void a(View paramView, Interpolator paramInterpolator)
    {
    }

    public void b(ah paramah, View paramView)
    {
      if (this.mn != null)
      {
        Runnable localRunnable = (Runnable)this.mn.get(paramView);
        if (localRunnable != null)
          paramView.removeCallbacks(localRunnable);
      }
      c(paramah, paramView);
    }

    public void b(ah paramah, View paramView, float paramFloat)
    {
      d(paramah, paramView);
    }

    public void b(View paramView, long paramLong)
    {
    }

    final void c(ah paramah, View paramView)
    {
      Object localObject = paramView.getTag(2113929216);
      if ((localObject instanceof al));
      for (localObject = (al)localObject; ; localObject = null)
      {
        Runnable localRunnable1 = ah.c(paramah);
        Runnable localRunnable2 = ah.d(paramah);
        ah.b(paramah);
        ah.a(paramah);
        if (localRunnable1 != null)
          localRunnable1.run();
        if (localObject != null)
        {
          ((al)localObject).L(paramView);
          ((al)localObject).M(paramView);
        }
        if (localRunnable2 != null)
          localRunnable2.run();
        if (this.mn != null)
          this.mn.remove(paramView);
        return;
      }
    }

    final class a
      implements Runnable
    {
      WeakReference<View> mo;
      ah mp;

      private a(ah paramView, View arg3)
      {
        Object localObject;
        this.mo = new WeakReference(localObject);
        this.mp = paramView;
      }

      public final void run()
      {
        View localView = (View)this.mo.get();
        if (localView != null)
          ah.a.this.c(this.mp, localView);
      }
    }
  }

  static class b extends ah.a
  {
    WeakHashMap<View, Integer> mr = null;

    public final long K(View paramView)
    {
      return paramView.animate().getDuration();
    }

    public final void a(ah paramah, View paramView)
    {
      paramView.animate().cancel();
    }

    public final void a(ah paramah, View paramView, float paramFloat)
    {
      paramView.animate().alpha(paramFloat);
    }

    public void a(ah paramah, View paramView, al paramal)
    {
      paramView.setTag(2113929216, paramal);
      paramah = new a(paramah);
      paramView.animate().setListener(new ai.1(paramah, paramView));
    }

    public final void a(View paramView, long paramLong)
    {
      paramView.animate().setDuration(paramLong);
    }

    public final void a(View paramView, Interpolator paramInterpolator)
    {
      paramView.animate().setInterpolator(paramInterpolator);
    }

    public final void b(ah paramah, View paramView)
    {
      paramView.animate().start();
    }

    public final void b(ah paramah, View paramView, float paramFloat)
    {
      paramView.animate().translationY(paramFloat);
    }

    public final void b(View paramView, long paramLong)
    {
      paramView.animate().setStartDelay(paramLong);
    }

    static final class a
      implements al
    {
      ah mp;
      boolean ms;

      a(ah paramah)
      {
        this.mp = paramah;
      }

      public final void L(View paramView)
      {
        this.ms = false;
        if (ah.f(this.mp) >= 0)
          y.a(paramView, 2, null);
        if (ah.c(this.mp) != null)
        {
          localObject = ah.c(this.mp);
          ah.b(this.mp);
          ((Runnable)localObject).run();
        }
        Object localObject = paramView.getTag(2113929216);
        if ((localObject instanceof al));
        for (localObject = (al)localObject; ; localObject = null)
        {
          if (localObject != null)
            ((al)localObject).L(paramView);
          return;
        }
      }

      public final void M(View paramView)
      {
        if (ah.f(this.mp) >= 0)
        {
          y.a(paramView, ah.f(this.mp), null);
          ah.e(this.mp);
        }
        if ((Build.VERSION.SDK_INT >= 16) || (!this.ms))
        {
          if (ah.d(this.mp) != null)
          {
            localObject = ah.d(this.mp);
            ah.a(this.mp);
            ((Runnable)localObject).run();
          }
          localObject = paramView.getTag(2113929216);
          if (!(localObject instanceof al))
            break label113;
        }
        label113: for (Object localObject = (al)localObject; ; localObject = null)
        {
          if (localObject != null)
            ((al)localObject).M(paramView);
          this.ms = true;
          return;
        }
      }

      public final void N(View paramView)
      {
        Object localObject = paramView.getTag(2113929216);
        if ((localObject instanceof al));
        for (localObject = (al)localObject; ; localObject = null)
        {
          if (localObject != null)
            ((al)localObject).N(paramView);
          return;
        }
      }
    }
  }

  static class c extends ah.d
  {
  }

  static class d extends ah.b
  {
    public final void a(ah paramah, View paramView, al paramal)
    {
      if (paramal != null)
      {
        paramView.animate().setListener(new aj.1(paramal, paramView));
        return;
      }
      paramView.animate().setListener(null);
    }
  }

  static class e extends ah.c
  {
    public final void a(View paramView, an paraman)
    {
      ak.1 local1 = null;
      if (paraman != null)
        local1 = new ak.1(paraman, paramView);
      paramView.animate().setUpdateListener(local1);
    }
  }

  static final class f extends ah.e
  {
  }

  public static abstract interface g
  {
    public abstract long K(View paramView);

    public abstract void a(ah paramah, View paramView);

    public abstract void a(ah paramah, View paramView, float paramFloat);

    public abstract void a(ah paramah, View paramView, al paramal);

    public abstract void a(View paramView, long paramLong);

    public abstract void a(View paramView, an paraman);

    public abstract void a(View paramView, Interpolator paramInterpolator);

    public abstract void b(ah paramah, View paramView);

    public abstract void b(ah paramah, View paramView, float paramFloat);

    public abstract void b(View paramView, long paramLong);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ah
 * JD-Core Version:    0.6.2
 */