package android.support.v4.view;

import android.view.View;

final class ab
{
  private static void H(View paramView)
  {
    float f = paramView.getTranslationY();
    paramView.setTranslationY(1.0F + f);
    paramView.setTranslationY(f);
  }

  static void d(View paramView, int paramInt)
  {
    paramView.offsetTopAndBottom(paramInt);
    paramView = paramView.getParent();
    if ((paramView instanceof View))
      H((View)paramView);
  }

  static void e(View paramView, int paramInt)
  {
    paramView.offsetLeftAndRight(paramInt);
    paramView = paramView.getParent();
    if ((paramView instanceof View))
      H((View)paramView);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ab
 * JD-Core Version:    0.6.2
 */