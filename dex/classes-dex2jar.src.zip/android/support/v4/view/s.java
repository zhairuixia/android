package android.support.v4.view;

import android.view.View;

public abstract interface s
{
  public abstract ao a(View paramView, ao paramao);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.s
 * JD-Core Version:    0.6.2
 */