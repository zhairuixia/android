package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.Gravity;

public final class e
{
  static final a jH = new b();

  static
  {
    if (Build.VERSION.SDK_INT >= 17)
    {
      jH = new c();
      return;
    }
  }

  public static int getAbsoluteGravity(int paramInt1, int paramInt2)
  {
    return jH.getAbsoluteGravity(paramInt1, paramInt2);
  }

  static abstract interface a
  {
    public abstract int getAbsoluteGravity(int paramInt1, int paramInt2);
  }

  static final class b
    implements e.a
  {
    public final int getAbsoluteGravity(int paramInt1, int paramInt2)
    {
      return 0xFF7FFFFF & paramInt1;
    }
  }

  static final class c
    implements e.a
  {
    public final int getAbsoluteGravity(int paramInt1, int paramInt2)
    {
      return Gravity.getAbsoluteGravity(paramInt1, paramInt2);
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.e
 * JD-Core Version:    0.6.2
 */