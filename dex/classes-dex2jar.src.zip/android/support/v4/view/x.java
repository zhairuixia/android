package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.VelocityTracker;

public final class x
{
  static final c kL = new a();

  static
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      kL = new b();
      return;
    }
  }

  public static float a(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return kL.a(paramVelocityTracker, paramInt);
  }

  public static float b(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return kL.b(paramVelocityTracker, paramInt);
  }

  static final class a
    implements x.c
  {
    public final float a(VelocityTracker paramVelocityTracker, int paramInt)
    {
      return paramVelocityTracker.getXVelocity();
    }

    public final float b(VelocityTracker paramVelocityTracker, int paramInt)
    {
      return paramVelocityTracker.getYVelocity();
    }
  }

  static final class b
    implements x.c
  {
    public final float a(VelocityTracker paramVelocityTracker, int paramInt)
    {
      return paramVelocityTracker.getXVelocity(paramInt);
    }

    public final float b(VelocityTracker paramVelocityTracker, int paramInt)
    {
      return paramVelocityTracker.getYVelocity(paramInt);
    }
  }

  static abstract interface c
  {
    public abstract float a(VelocityTracker paramVelocityTracker, int paramInt);

    public abstract float b(VelocityTracker paramVelocityTracker, int paramInt);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.x
 * JD-Core Version:    0.6.2
 */