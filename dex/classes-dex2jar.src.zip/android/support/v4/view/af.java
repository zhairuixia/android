package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.View;
import android.view.ViewParent;

public final class af
{
  static final b mh = new e();

  static
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 21)
    {
      mh = new d();
      return;
    }
    if (i >= 19)
    {
      mh = new c();
      return;
    }
    if (i >= 14)
    {
      mh = new a();
      return;
    }
  }

  public static void a(ViewParent paramViewParent, View paramView)
  {
    mh.a(paramViewParent, paramView);
  }

  public static void a(ViewParent paramViewParent, View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    mh.a(paramViewParent, paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }

  public static void a(ViewParent paramViewParent, View paramView, int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    mh.a(paramViewParent, paramView, paramInt1, paramInt2, paramArrayOfInt);
  }

  public static boolean a(ViewParent paramViewParent, View paramView, float paramFloat1, float paramFloat2)
  {
    return mh.a(paramViewParent, paramView, paramFloat1, paramFloat2);
  }

  public static boolean a(ViewParent paramViewParent, View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean)
  {
    return mh.a(paramViewParent, paramView, paramFloat1, paramFloat2, paramBoolean);
  }

  public static boolean a(ViewParent paramViewParent, View paramView1, View paramView2, int paramInt)
  {
    return mh.a(paramViewParent, paramView1, paramView2, paramInt);
  }

  public static void b(ViewParent paramViewParent, View paramView1, View paramView2, int paramInt)
  {
    mh.b(paramViewParent, paramView1, paramView2, paramInt);
  }

  static class a extends af.e
  {
  }

  static abstract interface b
  {
    public abstract void a(ViewParent paramViewParent, View paramView);

    public abstract void a(ViewParent paramViewParent, View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

    public abstract void a(ViewParent paramViewParent, View paramView, int paramInt1, int paramInt2, int[] paramArrayOfInt);

    public abstract boolean a(ViewParent paramViewParent, View paramView, float paramFloat1, float paramFloat2);

    public abstract boolean a(ViewParent paramViewParent, View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean);

    public abstract boolean a(ViewParent paramViewParent, View paramView1, View paramView2, int paramInt);

    public abstract void b(ViewParent paramViewParent, View paramView1, View paramView2, int paramInt);
  }

  static class c extends af.a
  {
  }

  static final class d extends af.c
  {
    public final void a(ViewParent paramViewParent, View paramView)
    {
      try
      {
        paramViewParent.onStopNestedScroll(paramView);
        return;
      }
      catch (AbstractMethodError paramView)
      {
        new StringBuilder("ViewParent ").append(paramViewParent).append(" does not implement interface method onStopNestedScroll");
      }
    }

    public final void a(ViewParent paramViewParent, View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      try
      {
        paramViewParent.onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
        return;
      }
      catch (AbstractMethodError paramView)
      {
        new StringBuilder("ViewParent ").append(paramViewParent).append(" does not implement interface method onNestedScroll");
      }
    }

    public final void a(ViewParent paramViewParent, View paramView, int paramInt1, int paramInt2, int[] paramArrayOfInt)
    {
      try
      {
        paramViewParent.onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfInt);
        return;
      }
      catch (AbstractMethodError paramView)
      {
        new StringBuilder("ViewParent ").append(paramViewParent).append(" does not implement interface method onNestedPreScroll");
      }
    }

    public final boolean a(ViewParent paramViewParent, View paramView, float paramFloat1, float paramFloat2)
    {
      return ag.a(paramViewParent, paramView, paramFloat1, paramFloat2);
    }

    public final boolean a(ViewParent paramViewParent, View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean)
    {
      return ag.a(paramViewParent, paramView, paramFloat1, paramFloat2, paramBoolean);
    }

    public final boolean a(ViewParent paramViewParent, View paramView1, View paramView2, int paramInt)
    {
      return ag.a(paramViewParent, paramView1, paramView2, paramInt);
    }

    public final void b(ViewParent paramViewParent, View paramView1, View paramView2, int paramInt)
    {
      try
      {
        paramViewParent.onNestedScrollAccepted(paramView1, paramView2, paramInt);
        return;
      }
      catch (AbstractMethodError paramView1)
      {
        new StringBuilder("ViewParent ").append(paramViewParent).append(" does not implement interface method onNestedScrollAccepted");
      }
    }
  }

  static class e
    implements af.b
  {
    public void a(ViewParent paramViewParent, View paramView)
    {
      if ((paramViewParent instanceof q))
        ((q)paramViewParent).onStopNestedScroll(paramView);
    }

    public void a(ViewParent paramViewParent, View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    {
      if ((paramViewParent instanceof q))
        ((q)paramViewParent).onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
    }

    public void a(ViewParent paramViewParent, View paramView, int paramInt1, int paramInt2, int[] paramArrayOfInt)
    {
      if ((paramViewParent instanceof q))
        ((q)paramViewParent).onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfInt);
    }

    public boolean a(ViewParent paramViewParent, View paramView, float paramFloat1, float paramFloat2)
    {
      if ((paramViewParent instanceof q))
        return ((q)paramViewParent).onNestedPreFling(paramView, paramFloat1, paramFloat2);
      return false;
    }

    public boolean a(ViewParent paramViewParent, View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean)
    {
      if ((paramViewParent instanceof q))
        return ((q)paramViewParent).onNestedFling(paramView, paramFloat1, paramFloat2, paramBoolean);
      return false;
    }

    public boolean a(ViewParent paramViewParent, View paramView1, View paramView2, int paramInt)
    {
      if ((paramViewParent instanceof q))
        return ((q)paramViewParent).onStartNestedScroll(paramView1, paramView2, paramInt);
      return false;
    }

    public void b(ViewParent paramViewParent, View paramView1, View paramView2, int paramInt)
    {
      if ((paramViewParent instanceof q))
        ((q)paramViewParent).onNestedScrollAccepted(paramView1, paramView2, paramInt);
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.af
 * JD-Core Version:    0.6.2
 */