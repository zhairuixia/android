package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.ViewGroup.MarginLayoutParams;

public final class k
{
  static final a jN = new b();

  static
  {
    if (Build.VERSION.SDK_INT >= 17)
    {
      jN = new c();
      return;
    }
  }

  public static int a(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    return jN.a(paramMarginLayoutParams);
  }

  public static int b(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    return jN.b(paramMarginLayoutParams);
  }

  static abstract interface a
  {
    public abstract int a(ViewGroup.MarginLayoutParams paramMarginLayoutParams);

    public abstract int b(ViewGroup.MarginLayoutParams paramMarginLayoutParams);
  }

  static final class b
    implements k.a
  {
    public final int a(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      return paramMarginLayoutParams.leftMargin;
    }

    public final int b(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      return paramMarginLayoutParams.rightMargin;
    }
  }

  static final class c
    implements k.a
  {
    public final int a(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      return paramMarginLayoutParams.getMarginStart();
    }

    public final int b(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
    {
      return paramMarginLayoutParams.getMarginEnd();
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.k
 * JD-Core Version:    0.6.2
 */