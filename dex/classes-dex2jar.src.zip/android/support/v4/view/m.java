package android.support.v4.view;

import android.view.MenuItem;
import android.view.MenuItem.OnActionExpandListener;

final class m
{
  public static MenuItem a(MenuItem paramMenuItem, b paramb)
  {
    return paramMenuItem.setOnActionExpandListener(new a(paramb));
  }

  static final class a
    implements MenuItem.OnActionExpandListener
  {
    private m.b jR;

    public a(m.b paramb)
    {
      this.jR = paramb;
    }

    public final boolean onMenuItemActionCollapse(MenuItem paramMenuItem)
    {
      return this.jR.onMenuItemActionCollapse(paramMenuItem);
    }

    public final boolean onMenuItemActionExpand(MenuItem paramMenuItem)
    {
      return this.jR.onMenuItemActionExpand(paramMenuItem);
    }
  }

  static abstract interface b
  {
    public abstract boolean onMenuItemActionCollapse(MenuItem paramMenuItem);

    public abstract boolean onMenuItemActionExpand(MenuItem paramMenuItem);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.m
 * JD-Core Version:    0.6.2
 */