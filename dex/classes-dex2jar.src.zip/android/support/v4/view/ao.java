package android.support.v4.view;

public class ao
{
  public ao a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return this;
  }

  public int getSystemWindowInsetBottom()
  {
    return 0;
  }

  public int getSystemWindowInsetLeft()
  {
    return 0;
  }

  public int getSystemWindowInsetRight()
  {
    return 0;
  }

  public int getSystemWindowInsetTop()
  {
    return 0;
  }

  public boolean isConsumed()
  {
    return false;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ao
 * JD-Core Version:    0.6.2
 */