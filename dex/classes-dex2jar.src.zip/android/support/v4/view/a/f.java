package android.support.v4.view.a;

import android.os.Build.VERSION;
import android.view.accessibility.AccessibilityRecord;

public final class f
{
  public static final c ne = new e();
  public final Object nf;

  static
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      ne = new d();
      return;
    }
    if (Build.VERSION.SDK_INT >= 15)
    {
      ne = new b();
      return;
    }
    if (Build.VERSION.SDK_INT >= 14)
    {
      ne = new a();
      return;
    }
  }

  public f(Object paramObject)
  {
    this.nf = paramObject;
  }

  public static f aY()
  {
    return new f(ne.aZ());
  }

  public final boolean equals(Object paramObject)
  {
    if (this == paramObject);
    do
    {
      do
      {
        return true;
        if (paramObject == null)
          return false;
        if (getClass() != paramObject.getClass())
          return false;
        paramObject = (f)paramObject;
        if (this.nf != null)
          break;
      }
      while (paramObject.nf == null);
      return false;
    }
    while (this.nf.equals(paramObject.nf));
    return false;
  }

  public final int hashCode()
  {
    if (this.nf == null)
      return 0;
    return this.nf.hashCode();
  }

  public final void setFromIndex(int paramInt)
  {
    ne.e(this.nf, paramInt);
  }

  public final void setItemCount(int paramInt)
  {
    ne.f(this.nf, paramInt);
  }

  public final void setScrollable(boolean paramBoolean)
  {
    ne.f(this.nf, paramBoolean);
  }

  public final void setToIndex(int paramInt)
  {
    ne.i(this.nf, paramInt);
  }

  static class a extends f.e
  {
    public final Object aZ()
    {
      return AccessibilityRecord.obtain();
    }

    public final void e(Object paramObject, int paramInt)
    {
      ((AccessibilityRecord)paramObject).setFromIndex(paramInt);
    }

    public final void f(Object paramObject, int paramInt)
    {
      ((AccessibilityRecord)paramObject).setItemCount(paramInt);
    }

    public final void f(Object paramObject, boolean paramBoolean)
    {
      ((AccessibilityRecord)paramObject).setScrollable(paramBoolean);
    }

    public final void g(Object paramObject, int paramInt)
    {
      ((AccessibilityRecord)paramObject).setScrollX(paramInt);
    }

    public final void h(Object paramObject, int paramInt)
    {
      ((AccessibilityRecord)paramObject).setScrollY(paramInt);
    }

    public final void i(Object paramObject, int paramInt)
    {
      ((AccessibilityRecord)paramObject).setToIndex(paramInt);
    }
  }

  static class b extends f.a
  {
    public final void j(Object paramObject, int paramInt)
    {
      ((AccessibilityRecord)paramObject).setMaxScrollX(paramInt);
    }

    public final void k(Object paramObject, int paramInt)
    {
      ((AccessibilityRecord)paramObject).setMaxScrollY(paramInt);
    }
  }

  public static abstract interface c
  {
    public abstract Object aZ();

    public abstract void e(Object paramObject, int paramInt);

    public abstract void f(Object paramObject, int paramInt);

    public abstract void f(Object paramObject, boolean paramBoolean);

    public abstract void g(Object paramObject, int paramInt);

    public abstract void h(Object paramObject, int paramInt);

    public abstract void i(Object paramObject, int paramInt);

    public abstract void j(Object paramObject, int paramInt);

    public abstract void k(Object paramObject, int paramInt);
  }

  static final class d extends f.b
  {
  }

  static class e
    implements f.c
  {
    public Object aZ()
    {
      return null;
    }

    public void e(Object paramObject, int paramInt)
    {
    }

    public void f(Object paramObject, int paramInt)
    {
    }

    public void f(Object paramObject, boolean paramBoolean)
    {
    }

    public void g(Object paramObject, int paramInt)
    {
    }

    public void h(Object paramObject, int paramInt)
    {
    }

    public void i(Object paramObject, int paramInt)
    {
    }

    public void j(Object paramObject, int paramInt)
    {
    }

    public void k(Object paramObject, int paramInt)
    {
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.f
 * JD-Core Version:    0.6.2
 */