package android.support.v4.view.a;

import android.os.Build.VERSION;
import android.view.accessibility.AccessibilityEvent;

public final class a
{
  private static final d mx = new c();

  static
  {
    if (Build.VERSION.SDK_INT >= 19)
    {
      mx = new b();
      return;
    }
    if (Build.VERSION.SDK_INT >= 14)
    {
      mx = new a();
      return;
    }
  }

  public static f a(AccessibilityEvent paramAccessibilityEvent)
  {
    return new f(paramAccessibilityEvent);
  }

  static class a extends a.c
  {
  }

  static final class b extends a.a
  {
  }

  static class c
    implements a.d
  {
  }

  static abstract interface d
  {
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.a
 * JD-Core Version:    0.6.2
 */