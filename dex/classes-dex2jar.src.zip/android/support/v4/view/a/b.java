package android.support.v4.view.a;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction;

public final class b
{
  public static final e my = new j();
  public final Object mz;

  static
  {
    if (Build.VERSION.SDK_INT >= 22)
    {
      my = new c();
      return;
    }
    if (Build.VERSION.SDK_INT >= 21)
    {
      my = new b();
      return;
    }
    if (Build.VERSION.SDK_INT >= 19)
    {
      my = new i();
      return;
    }
    if (Build.VERSION.SDK_INT >= 18)
    {
      my = new h();
      return;
    }
    if (Build.VERSION.SDK_INT >= 17)
    {
      my = new g();
      return;
    }
    if (Build.VERSION.SDK_INT >= 16)
    {
      my = new f();
      return;
    }
    if (Build.VERSION.SDK_INT >= 14)
    {
      my = new d();
      return;
    }
  }

  public b(Object paramObject)
  {
    this.mz = paramObject;
  }

  public static b a(b paramb)
  {
    paramb = my.j(paramb.mz);
    if (paramb != null)
      return new b(paramb);
    return null;
  }

  public final boolean a(a parama)
  {
    return my.d(this.mz, a.b(parama));
  }

  public final void addAction(int paramInt)
  {
    my.c(this.mz, paramInt);
  }

  public final void addChild(View paramView)
  {
    my.c(this.mz, paramView);
  }

  public final boolean equals(Object paramObject)
  {
    if (this == paramObject);
    do
    {
      do
      {
        return true;
        if (paramObject == null)
          return false;
        if (getClass() != paramObject.getClass())
          return false;
        paramObject = (b)paramObject;
        if (this.mz != null)
          break;
      }
      while (paramObject.mz == null);
      return false;
    }
    while (this.mz.equals(paramObject.mz));
    return false;
  }

  public final int getActions()
  {
    return my.k(this.mz);
  }

  public final void getBoundsInParent(Rect paramRect)
  {
    my.a(this.mz, paramRect);
  }

  public final void getBoundsInScreen(Rect paramRect)
  {
    my.b(this.mz, paramRect);
  }

  public final CharSequence getClassName()
  {
    return my.l(this.mz);
  }

  public final CharSequence getContentDescription()
  {
    return my.m(this.mz);
  }

  public final CharSequence getPackageName()
  {
    return my.n(this.mz);
  }

  public final int hashCode()
  {
    if (this.mz == null)
      return 0;
    return this.mz.hashCode();
  }

  public final boolean isAccessibilityFocused()
  {
    return my.C(this.mz);
  }

  public final boolean isClickable()
  {
    return my.r(this.mz);
  }

  public final boolean isEnabled()
  {
    return my.s(this.mz);
  }

  public final boolean isFocusable()
  {
    return my.t(this.mz);
  }

  public final boolean isFocused()
  {
    return my.u(this.mz);
  }

  public final boolean isLongClickable()
  {
    return my.v(this.mz);
  }

  public final boolean isSelected()
  {
    return my.y(this.mz);
  }

  public final boolean isVisibleToUser()
  {
    return my.B(this.mz);
  }

  public final void recycle()
  {
    my.z(this.mz);
  }

  public final void setAccessibilityFocused(boolean paramBoolean)
  {
    my.i(this.mz, paramBoolean);
  }

  public final void setBoundsInParent(Rect paramRect)
  {
    my.c(this.mz, paramRect);
  }

  public final void setBoundsInScreen(Rect paramRect)
  {
    my.d(this.mz, paramRect);
  }

  public final void setClassName(CharSequence paramCharSequence)
  {
    my.a(this.mz, paramCharSequence);
  }

  public final void setClickable(boolean paramBoolean)
  {
    my.a(this.mz, paramBoolean);
  }

  public final void setContentDescription(CharSequence paramCharSequence)
  {
    my.b(this.mz, paramCharSequence);
  }

  public final void setEnabled(boolean paramBoolean)
  {
    my.b(this.mz, paramBoolean);
  }

  public final void setFocusable(boolean paramBoolean)
  {
    my.c(this.mz, paramBoolean);
  }

  public final void setFocused(boolean paramBoolean)
  {
    my.d(this.mz, paramBoolean);
  }

  public final void setLongClickable(boolean paramBoolean)
  {
    my.e(this.mz, paramBoolean);
  }

  public final void setPackageName(CharSequence paramCharSequence)
  {
    my.c(this.mz, paramCharSequence);
  }

  public final void setParent(View paramView)
  {
    my.d(this.mz, paramView);
  }

  public final void setScrollable(boolean paramBoolean)
  {
    my.f(this.mz, paramBoolean);
  }

  public final void setSelected(boolean paramBoolean)
  {
    my.g(this.mz, paramBoolean);
  }

  public final void setSource(View paramView)
  {
    my.e(this.mz, paramView);
  }

  public final void setVisibleToUser(boolean paramBoolean)
  {
    my.h(this.mz, paramBoolean);
  }

  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(super.toString());
    Object localObject = new Rect();
    getBoundsInParent((Rect)localObject);
    localStringBuilder.append("; boundsInParent: " + localObject);
    getBoundsInScreen((Rect)localObject);
    localStringBuilder.append("; boundsInScreen: " + localObject);
    localStringBuilder.append("; packageName: ").append(getPackageName());
    localStringBuilder.append("; className: ").append(getClassName());
    localStringBuilder.append("; text: ").append(my.o(this.mz));
    localStringBuilder.append("; contentDescription: ").append(getContentDescription());
    localStringBuilder.append("; viewId: ").append(my.D(this.mz));
    localStringBuilder.append("; checkable: ").append(my.p(this.mz));
    localStringBuilder.append("; checked: ").append(my.q(this.mz));
    localStringBuilder.append("; focusable: ").append(isFocusable());
    localStringBuilder.append("; focused: ").append(isFocused());
    localStringBuilder.append("; selected: ").append(isSelected());
    localStringBuilder.append("; clickable: ").append(isClickable());
    localStringBuilder.append("; longClickable: ").append(isLongClickable());
    localStringBuilder.append("; enabled: ").append(isEnabled());
    localStringBuilder.append("; password: ").append(my.w(this.mz));
    localStringBuilder.append("; scrollable: " + my.x(this.mz));
    localStringBuilder.append("; [");
    int i = getActions();
    if (i != 0)
    {
      int j = 1 << Integer.numberOfTrailingZeros(i);
      i = (j ^ 0xFFFFFFFF) & i;
      switch (j)
      {
      default:
        localObject = "ACTION_UNKNOWN";
      case 1:
      case 2:
      case 4:
      case 8:
      case 16:
      case 32:
      case 64:
      case 128:
      case 256:
      case 512:
      case 1024:
      case 2048:
      case 4096:
      case 8192:
      case 65536:
      case 16384:
      case 32768:
      case 131072:
      }
      while (true)
      {
        localStringBuilder.append((String)localObject);
        if (i != 0)
          localStringBuilder.append(", ");
        break;
        localObject = "ACTION_FOCUS";
        continue;
        localObject = "ACTION_CLEAR_FOCUS";
        continue;
        localObject = "ACTION_SELECT";
        continue;
        localObject = "ACTION_CLEAR_SELECTION";
        continue;
        localObject = "ACTION_CLICK";
        continue;
        localObject = "ACTION_LONG_CLICK";
        continue;
        localObject = "ACTION_ACCESSIBILITY_FOCUS";
        continue;
        localObject = "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
        continue;
        localObject = "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
        continue;
        localObject = "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
        continue;
        localObject = "ACTION_NEXT_HTML_ELEMENT";
        continue;
        localObject = "ACTION_PREVIOUS_HTML_ELEMENT";
        continue;
        localObject = "ACTION_SCROLL_FORWARD";
        continue;
        localObject = "ACTION_SCROLL_BACKWARD";
        continue;
        localObject = "ACTION_CUT";
        continue;
        localObject = "ACTION_COPY";
        continue;
        localObject = "ACTION_PASTE";
        continue;
        localObject = "ACTION_SET_SELECTION";
      }
    }
    localStringBuilder.append("]");
    return localStringBuilder.toString();
  }

  public static final class a
  {
    public static final a mA = new a(1);
    public static final a mB = new a(2);
    public static final a mC = new a(4);
    public static final a mD = new a(8);
    public static final a mE = new a(16);
    public static final a mF = new a(32);
    public static final a mG = new a(64);
    public static final a mH = new a(128);
    public static final a mI = new a(256);
    public static final a mJ = new a(512);
    public static final a mK = new a(1024);
    public static final a mL = new a(2048);
    public static final a mM = new a(4096);
    public static final a mN = new a(8192);
    public static final a mO = new a(16384);
    public static final a mP = new a(32768);
    public static final a mQ = new a(65536);
    public static final a mR = new a(131072);
    public static final a mS = new a(262144);
    public static final a mT = new a(524288);
    public static final a mU = new a(1048576);
    public static final a mV = new a(2097152);
    private final Object mW;

    private a(int paramInt)
    {
      this(b.aR().a(paramInt, null));
    }

    private a(Object paramObject)
    {
      this.mW = paramObject;
    }
  }

  static class b extends b.i
  {
    public final Object a(int paramInt, CharSequence paramCharSequence)
    {
      return new AccessibilityNodeInfo.AccessibilityAction(paramInt, null);
    }

    public final boolean d(Object paramObject1, Object paramObject2)
    {
      return ((AccessibilityNodeInfo)paramObject1).removeAction((AccessibilityNodeInfo.AccessibilityAction)paramObject2);
    }
  }

  static final class c extends b.b
  {
  }

  static class d extends b.j
  {
    public final void a(Object paramObject, Rect paramRect)
    {
      ((AccessibilityNodeInfo)paramObject).getBoundsInParent(paramRect);
    }

    public final void a(Object paramObject, CharSequence paramCharSequence)
    {
      ((AccessibilityNodeInfo)paramObject).setClassName(paramCharSequence);
    }

    public final void a(Object paramObject, boolean paramBoolean)
    {
      ((AccessibilityNodeInfo)paramObject).setClickable(paramBoolean);
    }

    public final void b(Object paramObject, Rect paramRect)
    {
      ((AccessibilityNodeInfo)paramObject).getBoundsInScreen(paramRect);
    }

    public final void b(Object paramObject, CharSequence paramCharSequence)
    {
      ((AccessibilityNodeInfo)paramObject).setContentDescription(paramCharSequence);
    }

    public final void b(Object paramObject, boolean paramBoolean)
    {
      ((AccessibilityNodeInfo)paramObject).setEnabled(paramBoolean);
    }

    public final void c(Object paramObject, int paramInt)
    {
      ((AccessibilityNodeInfo)paramObject).addAction(paramInt);
    }

    public final void c(Object paramObject, Rect paramRect)
    {
      ((AccessibilityNodeInfo)paramObject).setBoundsInParent(paramRect);
    }

    public final void c(Object paramObject, View paramView)
    {
      ((AccessibilityNodeInfo)paramObject).addChild(paramView);
    }

    public final void c(Object paramObject, CharSequence paramCharSequence)
    {
      ((AccessibilityNodeInfo)paramObject).setPackageName(paramCharSequence);
    }

    public final void c(Object paramObject, boolean paramBoolean)
    {
      ((AccessibilityNodeInfo)paramObject).setFocusable(paramBoolean);
    }

    public final void d(Object paramObject, Rect paramRect)
    {
      ((AccessibilityNodeInfo)paramObject).setBoundsInScreen(paramRect);
    }

    public final void d(Object paramObject, View paramView)
    {
      ((AccessibilityNodeInfo)paramObject).setParent(paramView);
    }

    public final void d(Object paramObject, CharSequence paramCharSequence)
    {
      ((AccessibilityNodeInfo)paramObject).setText(paramCharSequence);
    }

    public final void d(Object paramObject, boolean paramBoolean)
    {
      ((AccessibilityNodeInfo)paramObject).setFocused(paramBoolean);
    }

    public final void e(Object paramObject, View paramView)
    {
      ((AccessibilityNodeInfo)paramObject).setSource(paramView);
    }

    public final void e(Object paramObject, boolean paramBoolean)
    {
      ((AccessibilityNodeInfo)paramObject).setLongClickable(paramBoolean);
    }

    public final void f(Object paramObject, boolean paramBoolean)
    {
      ((AccessibilityNodeInfo)paramObject).setScrollable(paramBoolean);
    }

    public final void g(Object paramObject, boolean paramBoolean)
    {
      ((AccessibilityNodeInfo)paramObject).setSelected(paramBoolean);
    }

    public final Object j(Object paramObject)
    {
      return AccessibilityNodeInfo.obtain((AccessibilityNodeInfo)paramObject);
    }

    public final int k(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).getActions();
    }

    public final CharSequence l(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).getClassName();
    }

    public final CharSequence m(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).getContentDescription();
    }

    public final CharSequence n(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).getPackageName();
    }

    public final CharSequence o(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).getText();
    }

    public final boolean p(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).isCheckable();
    }

    public final boolean q(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).isChecked();
    }

    public final boolean r(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).isClickable();
    }

    public final boolean s(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).isEnabled();
    }

    public final boolean t(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).isFocusable();
    }

    public final boolean u(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).isFocused();
    }

    public final boolean v(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).isLongClickable();
    }

    public final boolean w(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).isPassword();
    }

    public final boolean x(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).isScrollable();
    }

    public final boolean y(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).isSelected();
    }

    public final void z(Object paramObject)
    {
      ((AccessibilityNodeInfo)paramObject).recycle();
    }
  }

  public static abstract interface e
  {
    public abstract int A(Object paramObject);

    public abstract boolean B(Object paramObject);

    public abstract boolean C(Object paramObject);

    public abstract String D(Object paramObject);

    public abstract Object a(int paramInt, CharSequence paramCharSequence);

    public abstract void a(Object paramObject, Rect paramRect);

    public abstract void a(Object paramObject, CharSequence paramCharSequence);

    public abstract void a(Object paramObject, boolean paramBoolean);

    public abstract void b(Object paramObject, Rect paramRect);

    public abstract void b(Object paramObject, CharSequence paramCharSequence);

    public abstract void b(Object paramObject, boolean paramBoolean);

    public abstract void c(Object paramObject, int paramInt);

    public abstract void c(Object paramObject, Rect paramRect);

    public abstract void c(Object paramObject, View paramView);

    public abstract void c(Object paramObject, CharSequence paramCharSequence);

    public abstract void c(Object paramObject, boolean paramBoolean);

    public abstract void d(Object paramObject, int paramInt);

    public abstract void d(Object paramObject, Rect paramRect);

    public abstract void d(Object paramObject, View paramView);

    public abstract void d(Object paramObject, CharSequence paramCharSequence);

    public abstract void d(Object paramObject, boolean paramBoolean);

    public abstract boolean d(Object paramObject1, Object paramObject2);

    public abstract void e(Object paramObject, View paramView);

    public abstract void e(Object paramObject, boolean paramBoolean);

    public abstract void f(Object paramObject, boolean paramBoolean);

    public abstract void g(Object paramObject, boolean paramBoolean);

    public abstract void h(Object paramObject, boolean paramBoolean);

    public abstract void i(Object paramObject, boolean paramBoolean);

    public abstract Object j(Object paramObject);

    public abstract int k(Object paramObject);

    public abstract CharSequence l(Object paramObject);

    public abstract CharSequence m(Object paramObject);

    public abstract CharSequence n(Object paramObject);

    public abstract CharSequence o(Object paramObject);

    public abstract boolean p(Object paramObject);

    public abstract boolean q(Object paramObject);

    public abstract boolean r(Object paramObject);

    public abstract boolean s(Object paramObject);

    public abstract boolean t(Object paramObject);

    public abstract boolean u(Object paramObject);

    public abstract boolean v(Object paramObject);

    public abstract boolean w(Object paramObject);

    public abstract boolean x(Object paramObject);

    public abstract boolean y(Object paramObject);

    public abstract void z(Object paramObject);
  }

  static class f extends b.d
  {
    public final int A(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).getMovementGranularities();
    }

    public final boolean B(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).isVisibleToUser();
    }

    public final boolean C(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).isAccessibilityFocused();
    }

    public final void d(Object paramObject, int paramInt)
    {
      ((AccessibilityNodeInfo)paramObject).setMovementGranularities(paramInt);
    }

    public final void h(Object paramObject, boolean paramBoolean)
    {
      ((AccessibilityNodeInfo)paramObject).setVisibleToUser(paramBoolean);
    }

    public final void i(Object paramObject, boolean paramBoolean)
    {
      ((AccessibilityNodeInfo)paramObject).setAccessibilityFocused(paramBoolean);
    }
  }

  static class g extends b.f
  {
  }

  static class h extends b.g
  {
    public final String D(Object paramObject)
    {
      return ((AccessibilityNodeInfo)paramObject).getViewIdResourceName();
    }
  }

  static class i extends b.h
  {
  }

  static class j
    implements b.e
  {
    public int A(Object paramObject)
    {
      return 0;
    }

    public boolean B(Object paramObject)
    {
      return false;
    }

    public boolean C(Object paramObject)
    {
      return false;
    }

    public String D(Object paramObject)
    {
      return null;
    }

    public Object a(int paramInt, CharSequence paramCharSequence)
    {
      return null;
    }

    public void a(Object paramObject, Rect paramRect)
    {
    }

    public void a(Object paramObject, CharSequence paramCharSequence)
    {
    }

    public void a(Object paramObject, boolean paramBoolean)
    {
    }

    public void b(Object paramObject, Rect paramRect)
    {
    }

    public void b(Object paramObject, CharSequence paramCharSequence)
    {
    }

    public void b(Object paramObject, boolean paramBoolean)
    {
    }

    public void c(Object paramObject, int paramInt)
    {
    }

    public void c(Object paramObject, Rect paramRect)
    {
    }

    public void c(Object paramObject, View paramView)
    {
    }

    public void c(Object paramObject, CharSequence paramCharSequence)
    {
    }

    public void c(Object paramObject, boolean paramBoolean)
    {
    }

    public void d(Object paramObject, int paramInt)
    {
    }

    public void d(Object paramObject, Rect paramRect)
    {
    }

    public void d(Object paramObject, View paramView)
    {
    }

    public void d(Object paramObject, CharSequence paramCharSequence)
    {
    }

    public void d(Object paramObject, boolean paramBoolean)
    {
    }

    public boolean d(Object paramObject1, Object paramObject2)
    {
      return false;
    }

    public void e(Object paramObject, View paramView)
    {
    }

    public void e(Object paramObject, boolean paramBoolean)
    {
    }

    public void f(Object paramObject, boolean paramBoolean)
    {
    }

    public void g(Object paramObject, boolean paramBoolean)
    {
    }

    public void h(Object paramObject, boolean paramBoolean)
    {
    }

    public void i(Object paramObject, boolean paramBoolean)
    {
    }

    public Object j(Object paramObject)
    {
      return null;
    }

    public int k(Object paramObject)
    {
      return 0;
    }

    public CharSequence l(Object paramObject)
    {
      return null;
    }

    public CharSequence m(Object paramObject)
    {
      return null;
    }

    public CharSequence n(Object paramObject)
    {
      return null;
    }

    public CharSequence o(Object paramObject)
    {
      return null;
    }

    public boolean p(Object paramObject)
    {
      return false;
    }

    public boolean q(Object paramObject)
    {
      return false;
    }

    public boolean r(Object paramObject)
    {
      return false;
    }

    public boolean s(Object paramObject)
    {
      return false;
    }

    public boolean t(Object paramObject)
    {
      return false;
    }

    public boolean u(Object paramObject)
    {
      return false;
    }

    public boolean v(Object paramObject)
    {
      return false;
    }

    public boolean w(Object paramObject)
    {
      return false;
    }

    public boolean x(Object paramObject)
    {
      return false;
    }

    public boolean y(Object paramObject)
    {
      return false;
    }

    public void z(Object paramObject)
    {
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.b
 * JD-Core Version:    0.6.2
 */