package android.support.v4.view.a;

import android.os.Build.VERSION;
import java.util.ArrayList;
import java.util.List;

public final class c
{
  private static final a mX = new d();
  public final Object mY;

  static
  {
    if (Build.VERSION.SDK_INT >= 19)
    {
      mX = new c();
      return;
    }
    if (Build.VERSION.SDK_INT >= 16)
    {
      mX = new b();
      return;
    }
  }

  public c()
  {
    this.mY = mX.a(this);
  }

  public c(Object paramObject)
  {
    this.mY = paramObject;
  }

  public static b aS()
  {
    return null;
  }

  public static boolean aT()
  {
    return false;
  }

  public static List<b> aU()
  {
    return null;
  }

  public static b aV()
  {
    return null;
  }

  static abstract interface a
  {
    public abstract Object a(c paramc);
  }

  static final class b extends c.d
  {
    public final Object a(final c paramc)
    {
      return new d.1(new d.a()
      {
        public final boolean aT()
        {
          return c.aT();
        }

        public final List<Object> aU()
        {
          c.aU();
          new ArrayList();
          throw new NullPointerException();
        }

        public final Object aW()
        {
          c.aS();
          return null;
        }
      });
    }
  }

  static final class c extends c.d
  {
    public final Object a(final c paramc)
    {
      return new e.1(new e.a()
      {
        public final boolean aT()
        {
          return c.aT();
        }

        public final List<Object> aU()
        {
          c.aU();
          new ArrayList();
          throw new NullPointerException();
        }

        public final Object aW()
        {
          c.aS();
          return null;
        }

        public final Object aX()
        {
          c.aV();
          return null;
        }
      });
    }
  }

  static class d
    implements c.a
  {
    public Object a(c paramc)
    {
      return null;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.c
 * JD-Core Version:    0.6.2
 */