package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory;
import android.view.LayoutInflater.Factory2;

public final class g
{
  static final a jJ = new b();

  static
  {
    int i = Build.VERSION.SDK_INT;
    if (i >= 21)
    {
      jJ = new d();
      return;
    }
    if (i >= 11)
    {
      jJ = new c();
      return;
    }
  }

  public static j a(LayoutInflater paramLayoutInflater)
  {
    return jJ.a(paramLayoutInflater);
  }

  public static void a(LayoutInflater paramLayoutInflater, j paramj)
  {
    jJ.a(paramLayoutInflater, paramj);
  }

  static abstract interface a
  {
    public abstract j a(LayoutInflater paramLayoutInflater);

    public abstract void a(LayoutInflater paramLayoutInflater, j paramj);
  }

  static class b
    implements g.a
  {
    public final j a(LayoutInflater paramLayoutInflater)
    {
      paramLayoutInflater = paramLayoutInflater.getFactory();
      if ((paramLayoutInflater instanceof h.a))
        return ((h.a)paramLayoutInflater).jK;
      return null;
    }

    public void a(LayoutInflater paramLayoutInflater, j paramj)
    {
      if (paramj != null);
      for (paramj = new h.a(paramj); ; paramj = null)
      {
        paramLayoutInflater.setFactory(paramj);
        return;
      }
    }
  }

  static class c extends g.b
  {
    public void a(LayoutInflater paramLayoutInflater, j paramj)
    {
      if (paramj != null);
      for (paramj = new i.a(paramj); ; paramj = null)
      {
        paramLayoutInflater.setFactory2(paramj);
        LayoutInflater.Factory localFactory = paramLayoutInflater.getFactory();
        if (!(localFactory instanceof LayoutInflater.Factory2))
          break;
        i.a(paramLayoutInflater, (LayoutInflater.Factory2)localFactory);
        return;
      }
      i.a(paramLayoutInflater, paramj);
    }
  }

  static final class d extends g.c
  {
    public final void a(LayoutInflater paramLayoutInflater, j paramj)
    {
      if (paramj != null);
      for (paramj = new i.a(paramj); ; paramj = null)
      {
        paramLayoutInflater.setFactory2(paramj);
        return;
      }
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.g
 * JD-Core Version:    0.6.2
 */