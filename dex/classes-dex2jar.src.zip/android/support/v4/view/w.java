package android.support.v4.view;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

public abstract interface w
{
  public abstract ColorStateList aC();

  public abstract PorterDuff.Mode aD();

  public abstract void b(ColorStateList paramColorStateList);

  public abstract void b(PorterDuff.Mode paramMode);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.w
 * JD-Core Version:    0.6.2
 */