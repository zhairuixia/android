package android.support.v4.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory2;
import android.view.View;
import java.lang.reflect.Field;

final class i
{
  private static Field jL;
  private static boolean jM;

  static void a(LayoutInflater paramLayoutInflater, LayoutInflater.Factory2 paramFactory2)
  {
    if (!jM);
    try
    {
      Field localField = LayoutInflater.class.getDeclaredField("mFactory2");
      jL = localField;
      localField.setAccessible(true);
      jM = true;
      if (jL == null);
    }
    catch (NoSuchFieldException localNoSuchFieldException)
    {
      try
      {
        jL.set(paramLayoutInflater, paramFactory2);
        return;
        localNoSuchFieldException = localNoSuchFieldException;
        new StringBuilder("forceSetFactory2 Could not find field 'mFactory2' on class ").append(LayoutInflater.class.getName()).append("; inflation may have unexpected results.");
      }
      catch (IllegalAccessException paramFactory2)
      {
        new StringBuilder("forceSetFactory2 could not set the Factory2 on LayoutInflater ").append(paramLayoutInflater).append("; inflation may have unexpected results.");
      }
    }
  }

  static final class a extends h.a
    implements LayoutInflater.Factory2
  {
    a(j paramj)
    {
      super();
    }

    public final View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet)
    {
      return this.jK.onCreateView(paramView, paramString, paramContext, paramAttributeSet);
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.i
 * JD-Core Version:    0.6.2
 */