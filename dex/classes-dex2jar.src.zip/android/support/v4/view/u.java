package android.support.v4.view;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.text.method.SingleLineTransformationMethod;
import android.view.View;
import java.util.Locale;

final class u
{
  private static final class a extends SingleLineTransformationMethod
  {
    private Locale kK;

    public a(Context paramContext)
    {
      this.kK = paramContext.getResources().getConfiguration().locale;
    }

    public final CharSequence getTransformation(CharSequence paramCharSequence, View paramView)
    {
      paramCharSequence = super.getTransformation(paramCharSequence, paramView);
      if (paramCharSequence != null)
        return paramCharSequence.toString().toUpperCase(this.kK);
      return null;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     android.support.v4.view.u
 * JD-Core Version:    0.6.2
 */