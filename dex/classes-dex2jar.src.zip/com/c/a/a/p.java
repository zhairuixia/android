package com.c.a.a;

import android.os.SystemClock;

class p
{
  final long atb;
  final long atc;
  final int what;

  p(int paramInt)
  {
    this(paramInt, System.currentTimeMillis(), SystemClock.elapsedRealtime());
  }

  private p(int paramInt, long paramLong1, long paramLong2)
  {
    this.what = paramInt;
    this.atb = paramLong1;
    this.atc = paramLong2;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.p
 * JD-Core Version:    0.6.2
 */