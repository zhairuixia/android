package com.c.a.a;

import android.content.Context;
import android.os.Handler;
import java.lang.ref.WeakReference;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

abstract class d
{
  boolean aqf;
  boolean aqg;
  private Context aqh;
  private Collection<WeakReference<m>> aqi;
  private a aqj;
  private Handler mHandler;

  private void b(Context paramContext, m[] paramArrayOfm)
  {
    this.aqh = paramContext;
    if (paramArrayOfm == null)
      this.aqi = null;
    while (true)
    {
      M(paramContext);
      return;
      this.aqi = new LinkedList();
      int j = paramArrayOfm.length;
      int i = 0;
      while (i < j)
      {
        m localm = paramArrayOfm[i];
        this.aqi.add(new WeakReference(localm));
        i += 1;
      }
    }
  }

  abstract void M(Context paramContext);

  abstract void N(Context paramContext);

  abstract void a(Context paramContext, Handler paramHandler, a parama);

  final void a(Context paramContext, m[] paramArrayOfm)
  {
    if (paramContext == null)
      try
      {
        throw new Exception("Module: context cannot be null");
      }
      finally
      {
      }
    jV();
    b(paramContext.getApplicationContext(), paramArrayOfm);
    this.aqf = true;
  }

  void a(Handler paramHandler, a parama)
  {
    try
    {
      stop();
      this.mHandler = paramHandler;
      this.aqj = parama;
      a(this.aqh, this.mHandler, this.aqj);
      this.aqg = true;
      return;
    }
    finally
    {
      paramHandler = finally;
    }
    throw paramHandler;
  }

  final void c(p paramp)
  {
    if (!this.aqg);
    while (true)
    {
      return;
      if (this.aqi != null)
      {
        Iterator localIterator = this.aqi.iterator();
        while (localIterator.hasNext())
        {
          m localm = (m)((WeakReference)localIterator.next()).get();
          if (localm != null)
            localm.a(paramp);
        }
      }
    }
  }

  abstract void jS();

  final void jV()
  {
    try
    {
      if (this.aqf)
      {
        stop();
        jS();
        this.aqf = false;
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  void stop()
  {
    try
    {
      if (this.aqg)
      {
        N(this.aqh);
        this.mHandler = null;
        this.aqj = null;
        this.aqg = false;
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  static class a
  {
    final long aqk;

    a(long paramLong)
    {
      this.aqk = Math.max(paramLong, 0L);
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.d
 * JD-Core Version:    0.6.2
 */