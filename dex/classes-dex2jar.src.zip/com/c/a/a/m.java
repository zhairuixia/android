package com.c.a.a;

abstract interface m
{
  public abstract void a(p paramp);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.m
 * JD-Core Version:    0.6.2
 */