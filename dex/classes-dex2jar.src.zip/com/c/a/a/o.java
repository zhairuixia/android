package com.c.a.a;

import android.os.Environment;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class o
{
  private static String asY;
  private static final SimpleDateFormat asZ = new SimpleDateFormat("yyyy-MM-dd,HH:mm:ss", Locale.US);
  private static final SimpleDateFormat ata = new SimpleDateFormat("yyyMMddHHmmss", Locale.US);

  protected static String kc()
  {
    return ata.format(new Date());
  }

  protected static boolean l(String paramString1, String paramString2)
  {
    String str = null;
    if (asY == null)
    {
      boolean bool1;
      if (Environment.getExternalStorageState().equals("mounted"))
      {
        File localFile = new File(Environment.getExternalStorageDirectory() + "/" + y.aws);
        boolean bool2 = localFile.exists();
        bool1 = bool2;
        if (!bool2)
          bool1 = localFile.mkdir();
        if (bool1)
          str = localFile.toString();
        asY = str;
      }
      while (!bool1)
      {
        return false;
        asY = null;
        bool1 = false;
      }
    }
    try
    {
      paramString1 = new FileWriter(asY + "/" + paramString1 + ".txt", true);
      paramString1.write("\n" + asZ.format(new Date()) + ',' + paramString2);
      paramString1.flush();
      paramString1.close();
      return true;
    }
    catch (Exception paramString1)
    {
    }
    return false;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.o
 * JD-Core Version:    0.6.2
 */