package com.c.a.a;

import android.os.Handler;

abstract class e
{
  private a aql;
  long aqm;
  final Handler handler;

  e(Handler paramHandler)
  {
    if (paramHandler != null);
    while (true)
    {
      this.handler = paramHandler;
      return;
      paramHandler = new Handler();
    }
  }

  final void b(long paramLong1, long paramLong2)
  {
    stop();
    this.aqm = paramLong1;
    this.aql = new a((byte)0);
    a.a(this.aql, paramLong2);
  }

  abstract void jW();

  final void stop()
  {
    if (this.aql != null)
      a.a(this.aql);
  }

  private final class a
    implements Runnable
  {
    private boolean aqn;
    private boolean started;

    private a()
    {
    }

    public final void run()
    {
      if (this.aqn)
        return;
      e.this.jW();
      e.this.handler.postDelayed(this, e.this.aqm);
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.e
 * JD-Core Version:    0.6.2
 */