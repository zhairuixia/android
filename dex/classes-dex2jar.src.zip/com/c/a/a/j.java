package com.c.a.a;

import java.lang.reflect.Array;

final class j
{
  private double[] aqY = new double[4];
  final b aqZ = new b((byte)0);
  private final b ara = new b((byte)0);

  private void a(double paramDouble, boolean paramBoolean)
  {
    double d3 = paramDouble - this.aqZ.arb;
    double d4 = d3 * d3;
    double d2;
    double d1;
    label97: Object localObject;
    if (paramBoolean)
    {
      this.aqZ.arL[2][2] = this.aqZ.arF;
      this.aqZ.arL[2][3] = 0L;
      this.aqZ.arL[3][2] = 0L;
      this.aqZ.arL[3][3] = this.aqZ.arF;
      if (d3 > 0.5D)
      {
        d2 = 1.0D;
        d1 = 0.0D;
        if (d1 < d3)
          break label500;
        localObject = this.aqZ;
        ((b)localObject).arN = (d2 * ((b)localObject).arN);
      }
      this.aqZ.arK[0] += this.aqZ.arK[2] * d3;
      this.aqZ.arK[1] += this.aqZ.arK[3] * d3;
      if (!this.aqZ.arP)
        break label521;
      this.aqZ.arL[0][0] += this.aqZ.arL[2][2] * d4;
      this.aqZ.arL[0][1] += this.aqZ.arL[2][3] * d4;
      this.aqZ.arL[1][0] += this.aqZ.arL[3][2] * d4;
      this.aqZ.arL[1][1] += this.aqZ.arL[3][3] * d4;
    }
    while (true)
    {
      this.aqZ.arb = paramDouble;
      return;
      d1 = 1.0D;
      d2 = d1;
      if (d3 > 0.5D)
        d2 = 0.0D;
      while (true)
      {
        if (d2 >= d3)
        {
          d2 = d1;
          localObject = this.aqZ.arL[2];
          localObject[2] *= d2;
          localObject = this.aqZ.arL[2];
          localObject[3] *= d2;
          localObject = this.aqZ.arL[3];
          localObject[2] *= d2;
          localObject = this.aqZ.arL[3];
          localObject[3] = (d2 * localObject[3]);
          break;
        }
        double d5 = this.aqZ.aro;
        d2 = 1.0D + d2;
        d1 = d5 * d1;
      }
      label500: d2 *= this.aqZ.arO;
      d1 += 1.0D;
      break label97;
      label521: this.aqZ.arL[0][0] = (this.aqZ.arL[0][0] + (this.aqZ.arL[0][2] + this.aqZ.arL[2][0]) * d3 + this.aqZ.arL[2][2] * d4);
      this.aqZ.arL[1][1] = (this.aqZ.arL[1][1] + (this.aqZ.arL[1][3] + this.aqZ.arL[3][1]) * d3 + this.aqZ.arL[3][3] * d4);
      this.aqZ.arL[0][2] += this.aqZ.arL[2][2] * d3;
      this.aqZ.arL[2][0] += this.aqZ.arL[2][2] * d3;
      this.aqZ.arL[1][3] += this.aqZ.arL[3][3] * d3;
      this.aqZ.arL[3][1] += this.aqZ.arL[3][3] * d3;
    }
  }

  private void a(double[] paramArrayOfDouble)
  {
    double d3;
    double d1;
    double d4;
    int i;
    if ((this.aqZ.arI) && (this.aqZ.ars))
    {
      Object localObject = new double[2];
      double[] arrayOfDouble = new double[2];
      double d5 = this.aqZ.arU;
      localObject[0] = (this.aqZ.arK[0] - this.aqZ.art[0]);
      localObject[1] = (this.aqZ.arK[1] - this.aqZ.art[1]);
      paramArrayOfDouble[0] -= this.aqZ.art[0];
      paramArrayOfDouble[1] -= this.aqZ.art[1];
      double d2 = Math.sqrt(localObject[0] * localObject[0] + localObject[1] * localObject[1]);
      d3 = Math.sqrt(arrayOfDouble[0] * arrayOfDouble[0] + arrayOfDouble[1] * arrayOfDouble[1]);
      if ((d2 > this.aqZ.arA) && (d3 > this.aqZ.arA))
      {
        d1 = Math.atan2(localObject[1], localObject[0]);
        d4 = Math.atan2(arrayOfDouble[1], arrayOfDouble[0]) - d1;
        if (d4 <= 3.141592653589793D)
          break label370;
        d1 = d4 - 6.283185307179586D;
        localObject = this.aqZ;
        ((b)localObject).arM = (d5 * d1 + ((b)localObject).arM);
        if (d1 * d1 <= 4.0D * this.aqZ.arN)
          break label392;
        i = 1;
        label278: d4 = Math.sqrt(this.aqZ.arL[0][0] + this.aqZ.arL[1][1]);
        if (d2 >= d3)
          break label398;
        d1 = d2;
        label317: d1 = d4 / d1;
        if (i == 0)
          break label404;
      }
    }
    label392: label398: label404: for (this.aqZ.arN = (d1 * d1); ; this.aqZ.arN = (1.0D / (1.0D / (d1 * d1) + 1.0D / this.aqZ.arN)))
    {
      this.aqZ.art[0] = paramArrayOfDouble[0];
      this.aqZ.art[1] = paramArrayOfDouble[1];
      this.aqZ.ars = true;
      return;
      label370: d1 = d4;
      if (d4 >= -3.141592653589793D)
        break;
      d1 = d4 + 6.283185307179586D;
      break;
      i = 0;
      break label278;
      d1 = d3;
      break label317;
    }
  }

  private static void a(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2)
  {
    double d = 1.0D / (paramArrayOfDouble1[0] * paramArrayOfDouble1[3] - paramArrayOfDouble1[1] * paramArrayOfDouble1[2]);
    paramArrayOfDouble2[0] = (paramArrayOfDouble1[3] * d);
    paramArrayOfDouble2[3] = (paramArrayOfDouble1[0] * d);
    paramArrayOfDouble2[1] = (-paramArrayOfDouble1[1] * d);
    paramArrayOfDouble2[2] = (d * -paramArrayOfDouble1[2]);
  }

  private static boolean a(double[][] paramArrayOfDouble1, double[][] paramArrayOfDouble2)
  {
    double[][] arrayOfDouble = (double[][])Array.newInstance(Double.TYPE, new int[] { 4, 4 });
    arrayOfDouble[0][0] = (paramArrayOfDouble1[1][1] * paramArrayOfDouble1[2][2] * paramArrayOfDouble1[3][3] - paramArrayOfDouble1[1][1] * paramArrayOfDouble1[2][3] * paramArrayOfDouble1[3][2] - paramArrayOfDouble1[2][1] * paramArrayOfDouble1[1][2] * paramArrayOfDouble1[3][3] + paramArrayOfDouble1[2][1] * paramArrayOfDouble1[1][3] * paramArrayOfDouble1[3][2] + paramArrayOfDouble1[3][1] * paramArrayOfDouble1[1][2] * paramArrayOfDouble1[2][3] - paramArrayOfDouble1[3][1] * paramArrayOfDouble1[1][3] * paramArrayOfDouble1[2][2]);
    arrayOfDouble[1][0] = (-paramArrayOfDouble1[1][0] * paramArrayOfDouble1[2][2] * paramArrayOfDouble1[3][3] + paramArrayOfDouble1[1][0] * paramArrayOfDouble1[2][3] * paramArrayOfDouble1[3][2] + paramArrayOfDouble1[2][0] * paramArrayOfDouble1[1][2] * paramArrayOfDouble1[3][3] - paramArrayOfDouble1[2][0] * paramArrayOfDouble1[1][3] * paramArrayOfDouble1[3][2] - paramArrayOfDouble1[3][0] * paramArrayOfDouble1[1][2] * paramArrayOfDouble1[2][3] + paramArrayOfDouble1[3][0] * paramArrayOfDouble1[1][3] * paramArrayOfDouble1[2][2]);
    arrayOfDouble[2][0] = (paramArrayOfDouble1[1][0] * paramArrayOfDouble1[2][1] * paramArrayOfDouble1[3][3] - paramArrayOfDouble1[1][0] * paramArrayOfDouble1[2][3] * paramArrayOfDouble1[3][1] - paramArrayOfDouble1[2][0] * paramArrayOfDouble1[1][1] * paramArrayOfDouble1[3][3] + paramArrayOfDouble1[2][0] * paramArrayOfDouble1[1][3] * paramArrayOfDouble1[3][1] + paramArrayOfDouble1[3][0] * paramArrayOfDouble1[1][1] * paramArrayOfDouble1[2][3] - paramArrayOfDouble1[3][0] * paramArrayOfDouble1[1][3] * paramArrayOfDouble1[2][1]);
    arrayOfDouble[3][0] = (-paramArrayOfDouble1[1][0] * paramArrayOfDouble1[2][1] * paramArrayOfDouble1[3][2] + paramArrayOfDouble1[1][0] * paramArrayOfDouble1[2][2] * paramArrayOfDouble1[3][1] + paramArrayOfDouble1[2][0] * paramArrayOfDouble1[1][1] * paramArrayOfDouble1[3][2] - paramArrayOfDouble1[2][0] * paramArrayOfDouble1[1][2] * paramArrayOfDouble1[3][1] - paramArrayOfDouble1[3][0] * paramArrayOfDouble1[1][1] * paramArrayOfDouble1[2][2] + paramArrayOfDouble1[3][0] * paramArrayOfDouble1[1][2] * paramArrayOfDouble1[2][1]);
    arrayOfDouble[0][1] = (-paramArrayOfDouble1[0][1] * paramArrayOfDouble1[2][2] * paramArrayOfDouble1[3][3] + paramArrayOfDouble1[0][1] * paramArrayOfDouble1[2][3] * paramArrayOfDouble1[3][2] + paramArrayOfDouble1[2][1] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[3][3] - paramArrayOfDouble1[2][1] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[3][2] - paramArrayOfDouble1[3][1] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[2][3] + paramArrayOfDouble1[3][1] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[2][2]);
    arrayOfDouble[1][1] = (paramArrayOfDouble1[0][0] * paramArrayOfDouble1[2][2] * paramArrayOfDouble1[3][3] - paramArrayOfDouble1[0][0] * paramArrayOfDouble1[2][3] * paramArrayOfDouble1[3][2] - paramArrayOfDouble1[2][0] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[3][3] + paramArrayOfDouble1[2][0] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[3][2] + paramArrayOfDouble1[3][0] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[2][3] - paramArrayOfDouble1[3][0] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[2][2]);
    arrayOfDouble[2][1] = (-paramArrayOfDouble1[0][0] * paramArrayOfDouble1[2][1] * paramArrayOfDouble1[3][3] + paramArrayOfDouble1[0][0] * paramArrayOfDouble1[2][3] * paramArrayOfDouble1[3][1] + paramArrayOfDouble1[2][0] * paramArrayOfDouble1[0][1] * paramArrayOfDouble1[3][3] - paramArrayOfDouble1[2][0] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[3][1] - paramArrayOfDouble1[3][0] * paramArrayOfDouble1[0][1] * paramArrayOfDouble1[2][3] + paramArrayOfDouble1[3][0] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[2][1]);
    arrayOfDouble[3][1] = (paramArrayOfDouble1[0][0] * paramArrayOfDouble1[2][1] * paramArrayOfDouble1[3][2] - paramArrayOfDouble1[0][0] * paramArrayOfDouble1[2][2] * paramArrayOfDouble1[3][1] - paramArrayOfDouble1[2][0] * paramArrayOfDouble1[0][1] * paramArrayOfDouble1[3][2] + paramArrayOfDouble1[2][0] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[3][1] + paramArrayOfDouble1[3][0] * paramArrayOfDouble1[0][1] * paramArrayOfDouble1[2][2] - paramArrayOfDouble1[3][0] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[2][1]);
    arrayOfDouble[0][2] = (paramArrayOfDouble1[0][1] * paramArrayOfDouble1[1][2] * paramArrayOfDouble1[3][3] - paramArrayOfDouble1[0][1] * paramArrayOfDouble1[1][3] * paramArrayOfDouble1[3][2] - paramArrayOfDouble1[1][1] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[3][3] + paramArrayOfDouble1[1][1] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[3][2] + paramArrayOfDouble1[3][1] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[1][3] - paramArrayOfDouble1[3][1] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[1][2]);
    arrayOfDouble[1][2] = (-paramArrayOfDouble1[0][0] * paramArrayOfDouble1[1][2] * paramArrayOfDouble1[3][3] + paramArrayOfDouble1[0][0] * paramArrayOfDouble1[1][3] * paramArrayOfDouble1[3][2] + paramArrayOfDouble1[1][0] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[3][3] - paramArrayOfDouble1[1][0] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[3][2] - paramArrayOfDouble1[3][0] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[1][3] + paramArrayOfDouble1[3][0] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[1][2]);
    arrayOfDouble[2][2] = (paramArrayOfDouble1[0][0] * paramArrayOfDouble1[1][1] * paramArrayOfDouble1[3][3] - paramArrayOfDouble1[0][0] * paramArrayOfDouble1[1][3] * paramArrayOfDouble1[3][1] - paramArrayOfDouble1[1][0] * paramArrayOfDouble1[0][1] * paramArrayOfDouble1[3][3] + paramArrayOfDouble1[1][0] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[3][1] + paramArrayOfDouble1[3][0] * paramArrayOfDouble1[0][1] * paramArrayOfDouble1[1][3] - paramArrayOfDouble1[3][0] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[1][1]);
    arrayOfDouble[3][2] = (-paramArrayOfDouble1[0][0] * paramArrayOfDouble1[1][1] * paramArrayOfDouble1[3][2] + paramArrayOfDouble1[0][0] * paramArrayOfDouble1[1][2] * paramArrayOfDouble1[3][1] + paramArrayOfDouble1[1][0] * paramArrayOfDouble1[0][1] * paramArrayOfDouble1[3][2] - paramArrayOfDouble1[1][0] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[3][1] - paramArrayOfDouble1[3][0] * paramArrayOfDouble1[0][1] * paramArrayOfDouble1[1][2] + paramArrayOfDouble1[3][0] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[1][1]);
    arrayOfDouble[0][3] = (-paramArrayOfDouble1[0][1] * paramArrayOfDouble1[1][2] * paramArrayOfDouble1[2][3] + paramArrayOfDouble1[0][1] * paramArrayOfDouble1[1][3] * paramArrayOfDouble1[2][2] + paramArrayOfDouble1[1][1] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[2][3] - paramArrayOfDouble1[1][1] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[2][2] - paramArrayOfDouble1[2][1] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[1][3] + paramArrayOfDouble1[2][1] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[1][2]);
    arrayOfDouble[1][3] = (paramArrayOfDouble1[0][0] * paramArrayOfDouble1[1][2] * paramArrayOfDouble1[2][3] - paramArrayOfDouble1[0][0] * paramArrayOfDouble1[1][3] * paramArrayOfDouble1[2][2] - paramArrayOfDouble1[1][0] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[2][3] + paramArrayOfDouble1[1][0] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[2][2] + paramArrayOfDouble1[2][0] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[1][3] - paramArrayOfDouble1[2][0] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[1][2]);
    arrayOfDouble[2][3] = (-paramArrayOfDouble1[0][0] * paramArrayOfDouble1[1][1] * paramArrayOfDouble1[2][3] + paramArrayOfDouble1[0][0] * paramArrayOfDouble1[1][3] * paramArrayOfDouble1[2][1] + paramArrayOfDouble1[1][0] * paramArrayOfDouble1[0][1] * paramArrayOfDouble1[2][3] - paramArrayOfDouble1[1][0] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[2][1] - paramArrayOfDouble1[2][0] * paramArrayOfDouble1[0][1] * paramArrayOfDouble1[1][3] + paramArrayOfDouble1[2][0] * paramArrayOfDouble1[0][3] * paramArrayOfDouble1[1][1]);
    arrayOfDouble[3][3] = (paramArrayOfDouble1[0][0] * paramArrayOfDouble1[1][1] * paramArrayOfDouble1[2][2] - paramArrayOfDouble1[0][0] * paramArrayOfDouble1[1][2] * paramArrayOfDouble1[2][1] - paramArrayOfDouble1[1][0] * paramArrayOfDouble1[0][1] * paramArrayOfDouble1[2][2] + paramArrayOfDouble1[1][0] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[2][1] + paramArrayOfDouble1[2][0] * paramArrayOfDouble1[0][1] * paramArrayOfDouble1[1][2] - paramArrayOfDouble1[2][0] * paramArrayOfDouble1[0][2] * paramArrayOfDouble1[1][1]);
    double d = paramArrayOfDouble1[0][0] * arrayOfDouble[0][0] + paramArrayOfDouble1[0][1] * arrayOfDouble[1][0] + paramArrayOfDouble1[0][2] * arrayOfDouble[2][0] + paramArrayOfDouble1[0][3] * arrayOfDouble[3][0];
    if (d == 0.0D)
      return false;
    d = 1.0D / d;
    int i = 0;
    if (i >= 4)
      return true;
    int j = 0;
    while (true)
    {
      if (j >= 4)
      {
        i += 1;
        break;
      }
      arrayOfDouble[i][j] *= d;
      j += 1;
    }
  }

  private void b(double paramDouble, boolean paramBoolean)
  {
    double d3 = paramDouble - this.ara.arb;
    double d4 = d3 * d3;
    double d2;
    double d1;
    label97: Object localObject;
    if (paramBoolean)
    {
      this.ara.arL[2][2] = this.ara.arF;
      this.ara.arL[2][3] = 0L;
      this.ara.arL[3][2] = 0L;
      this.ara.arL[3][3] = this.ara.arF;
      if (d3 > 0.5D)
      {
        d2 = 1.0D;
        d1 = 0.0D;
        if (d1 < d3)
          break label500;
        localObject = this.ara;
        ((b)localObject).arN = (d2 * ((b)localObject).arN);
      }
      this.ara.arK[0] += this.ara.arK[2] * d3;
      this.ara.arK[1] += this.ara.arK[3] * d3;
      if (!this.ara.arP)
        break label521;
      this.ara.arL[0][0] += this.ara.arL[2][2] * d4;
      this.ara.arL[0][1] += this.ara.arL[2][3] * d4;
      this.ara.arL[1][0] += this.ara.arL[3][2] * d4;
      this.ara.arL[1][1] += this.ara.arL[3][3] * d4;
    }
    while (true)
    {
      this.ara.arb = paramDouble;
      return;
      d1 = 1.0D;
      d2 = d1;
      if (d3 > 0.5D)
        d2 = 0.0D;
      while (true)
      {
        if (d2 >= d3)
        {
          d2 = d1;
          localObject = this.ara.arL[2];
          localObject[2] *= d2;
          localObject = this.ara.arL[2];
          localObject[3] *= d2;
          localObject = this.ara.arL[3];
          localObject[2] *= d2;
          localObject = this.ara.arL[3];
          localObject[3] = (d2 * localObject[3]);
          break;
        }
        double d5 = this.ara.aro;
        d2 = 1.0D + d2;
        d1 = d5 * d1;
      }
      label500: d2 *= this.ara.arO;
      d1 += 1.0D;
      break label97;
      label521: this.ara.arL[0][0] = (this.ara.arL[0][0] + (this.ara.arL[0][2] + this.ara.arL[2][0]) * d3 + this.ara.arL[2][2] * d4);
      this.ara.arL[1][1] = (this.ara.arL[1][1] + (this.ara.arL[1][3] + this.ara.arL[3][1]) * d3 + this.ara.arL[3][3] * d4);
      this.ara.arL[0][2] += this.ara.arL[2][2] * d3;
      this.ara.arL[2][0] += this.ara.arL[2][2] * d3;
      this.ara.arL[1][3] += this.ara.arL[3][3] * d3;
      this.ara.arL[3][1] += this.ara.arL[3][3] * d3;
    }
  }

  protected final void U(boolean paramBoolean)
  {
    if (paramBoolean);
    for (paramBoolean = false; ; paramBoolean = true)
    {
      if (this.aqZ.arP != paramBoolean)
      {
        this.aqZ.arP = paramBoolean;
        if (!paramBoolean)
          break;
        this.aqZ.aro = this.aqZ.arW[1];
        this.aqZ.arF = this.aqZ.arV[1];
        a(this.aqZ.arb, true);
      }
      return;
    }
    this.aqZ.aro = this.aqZ.arW[0];
    this.aqZ.arF = this.aqZ.arV[0];
    a(this.aqZ.arb, true);
  }

  void a(int paramInt, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2)
  {
    switch (paramInt)
    {
    default:
      return;
    case 0:
      paramArrayOfDouble2[0] = ((paramArrayOfDouble1[1] - this.aqZ.arG[1]) * 6378137.0D * Math.cos(this.aqZ.arG[0]));
      paramArrayOfDouble2[1] = ((paramArrayOfDouble1[0] - this.aqZ.arG[0]) * 6378137.0D);
      return;
    case 1:
    }
    paramArrayOfDouble2[0] = (paramArrayOfDouble1[1] / 6378137.0D + this.aqZ.arG[0]);
    paramArrayOfDouble2[1] = (paramArrayOfDouble1[0] / (Math.cos(this.aqZ.arG[0]) * 6378137.0D) + this.aqZ.arG[1]);
  }

  protected final void a(long paramLong, double paramDouble1, double paramDouble2, float paramFloat, boolean paramBoolean1, boolean paramBoolean2)
  {
    double d1 = paramLong;
    double d2 = paramFloat * paramFloat;
    double[] arrayOfDouble1 = new double[2];
    double[] tmp19_17 = arrayOfDouble1;
    tmp19_17[0] = 0.0D;
    double[] tmp23_19 = tmp19_17;
    tmp23_19[1] = 0.0D;
    tmp23_19;
    if (paramBoolean1);
    for (int i = 3; ; i = 5)
    {
      double[] arrayOfDouble2 = new double[2];
      arrayOfDouble2[0] = paramDouble1;
      arrayOfDouble2[1] = paramDouble2;
      this.aqZ.arP = true;
      this.aqZ.arW[0] = 3.0D;
      this.aqZ.arW[1] = 1.2D;
      this.aqZ.arU = 0.5D;
      this.aqZ.aro = 1.2D;
      this.aqZ.aru = 4.0D;
      this.aqZ.arv = 0;
      this.aqZ.arx = true;
      this.aqZ.arw = i;
      this.aqZ.arp = false;
      this.aqZ.ars = false;
      this.aqZ.arD = 40.0D;
      this.aqZ.arE = 0.1570796326794897D;
      this.aqZ.arF = 1.0D;
      this.aqZ.arV[0] = 400.0D;
      this.aqZ.arV[1] = 1.0D;
      this.aqZ.arI = paramBoolean2;
      this.aqZ.arJ = false;
      this.aqZ.ary = true;
      this.aqZ.arz = 0.3333333333333333D;
      this.aqZ.arA = 5.0D;
      this.aqZ.arB = 0.5D;
      this.aqZ.arC = 1.0D;
      this.aqZ.arQ = 0.5D;
      this.aqZ.arR = 1.0D;
      this.aqZ.arS = 0;
      this.aqZ.arT = 2;
      this.aqZ.arX = false;
      this.aqZ.arG[0] = arrayOfDouble2[0];
      this.aqZ.arG[1] = arrayOfDouble2[1];
      arrayOfDouble2 = new double[2];
      a(0, new double[] { paramDouble1, paramDouble2 }, arrayOfDouble2);
      this.aqZ.arb = d1;
      this.aqZ.arK[0] = arrayOfDouble2[0];
      this.aqZ.arK[1] = arrayOfDouble2[1];
      this.aqZ.arK[2] = arrayOfDouble1[0];
      this.aqZ.arK[3] = arrayOfDouble1[1];
      this.aqZ.arM = 0.0D;
      this.aqZ.arN = 1.0D;
      this.aqZ.arO = 1.005D;
      this.aqZ.arL[0][0] = tmp19_17;
      this.aqZ.arL[0][1] = 0L;
      this.aqZ.arL[0][2] = 0L;
      this.aqZ.arL[0][3] = 0L;
      this.aqZ.arL[1][0] = 0L;
      this.aqZ.arL[1][1] = tmp19_17;
      this.aqZ.arL[1][2] = 0L;
      this.aqZ.arL[1][3] = 0L;
      this.aqZ.arL[2][0] = 0L;
      this.aqZ.arL[2][1] = 0L;
      this.aqZ.arL[2][2] = 4607182418800017408L;
      this.aqZ.arL[2][3] = 0L;
      this.aqZ.arL[3][0] = 0L;
      this.aqZ.arL[3][1] = 0L;
      this.aqZ.arL[3][2] = 0L;
      this.aqZ.arL[3][3] = 4607182418800017408L;
      U(paramBoolean1);
      return;
    }
  }

  protected final void a(a parama)
  {
    if (parama.arg <= 0.0D);
    double[] arrayOfDouble1;
    Object localObject1;
    label1101: int i;
    while (true)
    {
      return;
      if (this.aqZ.arp)
      {
        d1 = parama.arb - this.aqZ.arr;
        if (d1 >= -10.0D)
          if (d1 <= 0.0D)
            parama.arb = (this.aqZ.arr + 0.5D);
      }
      else
      {
        arrayOfDouble1 = new double[2];
        a(0, new double[] { parama.arc, parama.ard }, arrayOfDouble1);
        parama.are[0] = arrayOfDouble1[0];
        parama.are[1] = arrayOfDouble1[1];
        if (this.aqZ.arP)
        {
          double d5;
          if ((parama.mType != 3) || (this.aqZ.arp))
          {
            if (parama.mType != 3)
              break label1171;
            d5 = parama.arb - this.aqZ.arr;
            if (d5 > 0.0D)
            {
              localObject2 = (double[][])Array.newInstance(Double.TYPE, new int[] { 2, 2 });
              localObject1 = new double[2];
              d4 = arrayOfDouble1[0] - this.aqZ.arq[0];
              d3 = arrayOfDouble1[1] - this.aqZ.arq[1];
              d1 = d3;
              d2 = d4;
              if (this.aqZ.arI)
              {
                d2 = d4 * Math.cos(this.aqZ.arM) - Math.sin(this.aqZ.arM) * d3;
                d1 = Math.sin(this.aqZ.arM);
                d1 = d3 * Math.cos(this.aqZ.arM) + d1 * d2;
              }
              d4 = Math.sqrt(d2 * d2 + d1 * d1);
              d3 = d4 / this.aqZ.arD;
              d3 *= d3;
              if (d3 <= 0.0625D)
                break label1155;
              d4 *= this.aqZ.arE;
              d4 *= d4;
              if (d4 <= 0.0625D)
                break label1163;
            }
          }
          while (true)
          {
            d3 = (d3 + d4) / d5;
            d4 = this.aqZ.arL[2][2];
            double d6 = this.aqZ.arL[2][3];
            double d7 = this.aqZ.arL[3][2];
            double d8 = this.aqZ.arL[3][3];
            localObject3 = this.aqY;
            a(new double[] { d4, d6, d7, d8 }, (double[])localObject3);
            localObject2[0][0] = this.aqY[0];
            localObject2[0][1] = this.aqY[1];
            localObject2[1][0] = this.aqY[2];
            localObject2[1][1] = this.aqY[3];
            d4 = d2 / d5 - this.aqZ.arK[2];
            d6 = d1 / d5 - this.aqZ.arK[3];
            d7 = localObject2[0][0];
            d8 = localObject2[0][1];
            if (Math.sqrt(d4 * d6 * localObject2[1][0] + (d4 * d4 * d7 + d4 * d6 * d8) + d6 * d6 * localObject2[1][1]) > 2.0D)
            {
              this.aqZ.arL[2][2] = this.aqZ.arF;
              this.aqZ.arL[2][3] = 0L;
              this.aqZ.arL[3][2] = 0L;
              this.aqZ.arL[3][3] = this.aqZ.arF;
              localObject2[0][0] = (1.0D / this.aqZ.arF);
              localObject2[0][1] = 0L;
              localObject2[1][0] = 0L;
              localObject2[1][1] = (1.0D / this.aqZ.arF);
            }
            localObject1[0] = (localObject2[0][0] * this.aqZ.arK[2] + localObject2[0][1] * this.aqZ.arK[3]);
            localObject1[1] = (localObject2[1][0] * this.aqZ.arK[2] + localObject2[1][1] * this.aqZ.arK[3]);
            localObject3 = localObject2[0];
            localObject3[0] += 1.0D / d3;
            localObject3 = localObject2[1];
            localObject3[1] += 1.0D / d3;
            d4 = localObject1[0];
            localObject1[0] = (d2 / (d5 * d3) + d4);
            d2 = localObject1[1];
            localObject1[1] = (d1 / (d3 * d5) + d2);
            d1 = localObject2[0][0];
            d2 = localObject2[0][1];
            d3 = localObject2[1][0];
            d4 = localObject2[1][1];
            localObject2 = this.aqY;
            a(new double[] { d1, d2, d3, d4 }, (double[])localObject2);
            this.aqZ.arL[2][2] = this.aqY[0];
            this.aqZ.arL[2][3] = this.aqY[1];
            this.aqZ.arL[3][2] = this.aqY[2];
            this.aqZ.arL[3][3] = this.aqY[3];
            this.aqZ.arK[2] = (this.aqZ.arL[2][2] * localObject1[0] + this.aqZ.arL[2][3] * localObject1[1]);
            this.aqZ.arK[3] = (this.aqZ.arL[3][2] * localObject1[0] + this.aqZ.arL[3][3] * localObject1[1]);
            a(parama.arb, false);
            if (parama.mType != 3)
              break label2450;
            this.aqZ.arq[0] = arrayOfDouble1[0];
            this.aqZ.arq[1] = arrayOfDouble1[1];
            this.aqZ.arr = parama.arb;
            this.aqZ.arp = true;
            return;
            label1155: d3 = 0.0625D;
            break;
            label1163: d4 = 0.0625D;
          }
          label1171: localObject2 = new double[2];
          localObject1 = new double[2];
          a(parama.arb, false);
          if (this.aqZ.ary)
          {
            if (!this.aqZ.ars)
            {
              d2 = 0.0D;
              d1 = 0.0D;
              j = 1;
              i = 1;
              label1221: if (i == 0)
                break label2022;
              if (this.aqZ.ars)
              {
                if (d2 >= d1)
                  break label2024;
                d3 = this.aqZ.arB;
                label1252: d1 = d3 + d1 / d2 * (1.0D - d3);
                arrayOfDouble1[0] = (this.aqZ.art[0] + localObject1[0] * d1);
                d2 = this.aqZ.art[1];
                arrayOfDouble1[1] = (d1 * localObject1[1] + d2);
              }
              if (j == 0)
                break label2036;
              a(arrayOfDouble1);
            }
            while (true)
            {
              this.aqZ.arK[0] = arrayOfDouble1[0];
              this.aqZ.arK[1] = arrayOfDouble1[1];
              this.aqZ.arL[0][0] = (parama.arg * parama.arg);
              this.aqZ.arL[0][1] = 0L;
              this.aqZ.arL[1][0] = 0L;
              this.aqZ.arL[1][1] = (parama.arg * parama.arg);
              break;
              localObject2[0] = (this.aqZ.arK[0] - this.aqZ.art[0]);
              localObject2[1] = (this.aqZ.arK[1] - this.aqZ.art[1]);
              arrayOfDouble1[0] -= this.aqZ.art[0];
              arrayOfDouble1[1] -= this.aqZ.art[1];
              d4 = Math.sqrt(localObject2[0] * localObject2[0] + localObject2[1] * localObject2[1]);
              d3 = Math.sqrt(localObject1[0] * localObject1[0] + localObject1[1] * localObject1[1]);
              if ((d3 > this.aqZ.arA) && (d4 > this.aqZ.arA))
              {
                d1 = d3 / d4;
                d2 = d3 - d4;
                d5 = Math.sqrt(this.aqZ.arL[0][0] + this.aqZ.arL[1][1]);
                if (d4 > 3.0D * this.aqZ.arA)
                {
                  d1 = d2;
                  if (d2 < 0.0D)
                    d1 = -d2;
                  d5 = d1 / d5;
                  d1 = Math.atan2(localObject2[1], localObject2[0]);
                  d2 = Math.atan2(localObject1[1], localObject1[0]) - d1;
                  if (d2 > 3.141592653589793D)
                  {
                    d1 = d2 - 6.283185307179586D;
                    label1690: d2 = d1;
                    if (d1 < 0.0D)
                      d2 = -d1;
                    d1 = d2 / Math.sqrt(this.aqZ.arN);
                    d2 = Math.sqrt(d1 * d1 + d5 * d5);
                    if (d2 >= this.aqZ.aru)
                      break label1805;
                    this.aqZ.arS = 0;
                    d1 = d2;
                  }
                  while (true)
                  {
                    if (d1 <= this.aqZ.aru)
                      break label1872;
                    j = 0;
                    i = 0;
                    d1 = d4;
                    d2 = d3;
                    break;
                    d1 = d2;
                    if (d2 >= -3.141592653589793D)
                      break label1690;
                    d1 = d2 + 6.283185307179586D;
                    break label1690;
                    label1805: d1 = d2;
                    if (d5 < this.aqZ.aru)
                    {
                      localObject2 = this.aqZ;
                      i = ((b)localObject2).arS + 1;
                      ((b)localObject2).arS = i;
                      d1 = d2;
                      if (i >= this.aqZ.arT)
                      {
                        this.aqZ.arS = 0;
                        d1 = d5;
                      }
                    }
                  }
                  label1872: j = 1;
                  i = 1;
                  d1 = d4;
                  d2 = d3;
                  break label1221;
                }
                if ((d1 < this.aqZ.arz) || (1.0D / d1 < this.aqZ.arz))
                {
                  j = 0;
                  i = 0;
                  d1 = d4;
                  d2 = d3;
                  break label1221;
                }
                j = 0;
                i = 1;
                d1 = d4;
                d2 = d3;
                break label1221;
              }
              if (((d3 < this.aqZ.arA) && (parama.mType == 2)) || ((d3 < this.aqZ.arA * 0.5D) && (parama.mType == 1)))
              {
                j = 0;
                i = 0;
                d1 = d4;
                d2 = d3;
                break label1221;
              }
              j = 0;
              i = 1;
              d1 = d4;
              d2 = d3;
              break label1221;
              label2022: break;
              label2024: d3 = this.aqZ.arC;
              break label1252;
              label2036: this.aqZ.art[0] = arrayOfDouble1[0];
              this.aqZ.art[1] = arrayOfDouble1[1];
            }
          }
          b.a(this.ara, this.aqZ);
          b(parama.arb, false);
          if (this.ara.arx)
            if (!this.aqZ.ars)
            {
              d1 = 0.0D;
              label2107: if (d1 <= this.aqZ.aru)
                break label3150;
              b.a(this.ara, this.aqZ);
              b(parama.arb, true);
              if (!this.aqZ.arx)
                break label2860;
              d3 = this.aqZ.art[0] - this.ara.arK[0];
              d4 = this.aqZ.art[1] - this.ara.arK[1];
              d1 = this.aqZ.art[0] - arrayOfDouble1[0];
              d2 = this.aqZ.art[1] - arrayOfDouble1[1];
              d3 = Math.sqrt(d3 * d3 + d4 * d4);
              d1 = Math.sqrt(d1 * d1 + d2 * d2);
              d2 = Math.sqrt(this.ara.arL[0][0] * this.ara.arL[0][0] + this.ara.arL[1][1] * this.ara.arL[1][1]);
              d1 = Math.abs(d3 - d1) / d2;
              label2314: if (d1 <= this.ara.aru)
                break label3122;
              if (this.aqZ.arv >= this.aqZ.arw)
                break label3100;
              this.aqZ.arv += 1;
            }
          while (true)
          {
            this.aqZ.arK[0] = arrayOfDouble1[0];
            this.aqZ.arK[1] = arrayOfDouble1[1];
            this.aqZ.arL[0][0] = (parama.arg * parama.arg);
            this.aqZ.arL[0][1] = 0L;
            this.aqZ.arL[1][0] = 0L;
            this.aqZ.arL[1][1] = (parama.arg * parama.arg);
            break label1101;
            label2450: break;
            d3 = this.aqZ.art[0] - this.ara.arK[0];
            d4 = this.aqZ.art[1] - this.ara.arK[1];
            d1 = this.aqZ.art[0] - arrayOfDouble1[0];
            d2 = this.aqZ.art[1] - arrayOfDouble1[1];
            d3 = Math.sqrt(d3 * d3 + d4 * d4);
            d1 = Math.sqrt(d1 * d1 + d2 * d2);
            d2 = Math.sqrt(this.aqZ.arL[0][0] * this.aqZ.arL[0][0] + this.aqZ.arL[1][1] * this.aqZ.arL[1][1]);
            d1 = Math.abs(d3 - d1) / d2;
            break label2107;
            d1 = arrayOfDouble1[0] - this.ara.arK[0];
            d2 = arrayOfDouble1[1] - this.ara.arK[1];
            localObject1 = (double[][])Array.newInstance(Double.TYPE, new int[] { 2, 2 });
            d3 = 1.0D / (this.ara.arL[0][0] * this.ara.arL[1][1] - this.ara.arL[0][1] * this.ara.arL[1][0]);
            localObject1[0][0] = (this.ara.arL[1][1] * d3);
            localObject1[1][1] = (this.ara.arL[0][0] * d3);
            localObject1[0][1] = (-this.ara.arL[0][1] * d3);
            localObject1[1][0] = (d3 * -this.ara.arL[1][0]);
            d3 = localObject1[0][0];
            d4 = localObject1[1][0];
            d1 = Math.sqrt(localObject1[1][1] * (d2 * d2) + (d1 * 2.0D * d2 * d4 + d1 * d1 * d3));
            break label2107;
            label2860: d1 = arrayOfDouble1[0] - this.ara.arK[0];
            d2 = arrayOfDouble1[1] - this.ara.arK[1];
            localObject1 = (double[][])Array.newInstance(Double.TYPE, new int[] { 2, 2 });
            d3 = 1.0D / (this.ara.arL[0][0] * this.ara.arL[1][1] - this.ara.arL[0][1] * this.ara.arL[1][0]);
            localObject1[0][0] = (this.ara.arL[1][1] * d3);
            localObject1[1][1] = (this.ara.arL[0][0] * d3);
            localObject1[0][1] = (-this.ara.arL[0][1] * d3);
            localObject1[1][0] = (d3 * -this.ara.arL[1][0]);
            d3 = localObject1[0][0];
            d4 = localObject1[1][0];
            d1 = Math.sqrt(localObject1[1][1] * (d2 * d2) + (d1 * 2.0D * d2 * d4 + d1 * d1 * d3));
            break label2314;
            label3100: b.a(this.aqZ, this.ara);
            this.aqZ.arv = 0;
            continue;
            label3122: b.a(this.aqZ, this.ara);
            this.aqZ.arv = 0;
            a(arrayOfDouble1);
            continue;
            label3150: b.a(this.aqZ, this.ara);
            this.aqZ.arv = 0;
            a(arrayOfDouble1);
          }
        }
        if (parama.mType != 3)
        {
          localObject2 = new double[2];
          localObject1 = new double[2];
          arrayOfDouble1 = new double[2];
          a(parama.arb, false);
          if (!this.aqZ.ars)
          {
            j = 1;
            i = 0;
            this.aqZ.arv = 0;
          }
          while (j != 0)
          {
            if (i != 0)
              break label3894;
            this.aqZ.arK[0] = parama.are[0];
            this.aqZ.arK[1] = parama.are[1];
            this.aqZ.arK[2] = 0.0D;
            this.aqZ.arK[3] = 0.0D;
            this.aqZ.arL[0][0] = (parama.arg * parama.arg);
            this.aqZ.arL[0][1] = 0L;
            this.aqZ.arL[0][2] = 0L;
            this.aqZ.arL[0][3] = 0L;
            this.aqZ.arL[1][0] = 0L;
            this.aqZ.arL[1][1] = this.aqZ.arL[0][0];
            this.aqZ.arL[1][2] = 0L;
            this.aqZ.arL[1][2] = 0L;
            this.aqZ.arL[2][0] = 0L;
            this.aqZ.arL[2][1] = 0L;
            this.aqZ.arL[2][2] = this.aqZ.arF;
            this.aqZ.arL[2][3] = 0L;
            this.aqZ.arL[3][0] = 0L;
            this.aqZ.arL[3][1] = 0L;
            this.aqZ.arL[3][2] = 0L;
            this.aqZ.arL[3][3] = this.aqZ.arF;
            this.aqZ.art[0] = parama.are[0];
            this.aqZ.art[1] = parama.are[1];
            this.aqZ.ars = true;
            return;
            localObject3 = (double[][])Array.newInstance(Double.TYPE, new int[] { 2, 2 });
            localObject2[0] = (parama.are[0] - this.aqZ.arK[0]);
            localObject2[1] = (parama.are[1] - this.aqZ.arK[1]);
            d1 = this.aqZ.arL[0][0];
            d2 = this.aqZ.arL[0][1];
            d3 = this.aqZ.arL[1][0];
            d4 = this.aqZ.arL[1][1];
            double[] arrayOfDouble2 = this.aqY;
            a(new double[] { d1, d2, d3, d4 }, arrayOfDouble2);
            localObject3[0][0] = this.aqY[0];
            localObject3[0][1] = this.aqY[1];
            localObject3[1][0] = this.aqY[2];
            localObject3[1][1] = this.aqY[3];
            if (Math.sqrt(localObject2[0] * localObject2[0] * localObject3[0][0] + 2.0D * localObject2[0] * localObject2[1] * localObject3[1][0] + localObject2[1] * localObject2[1] * localObject3[1][1]) > this.aqZ.aru)
            {
              localObject2 = this.aqZ;
              i = ((b)localObject2).arv + 1;
              ((b)localObject2).arv = i;
              if (i >= this.aqZ.arw)
              {
                j = 1;
                i = 0;
                this.aqZ.arv = 0;
              }
              else
              {
                j = 0;
                i = 0;
              }
            }
            else
            {
              this.aqZ.arv = 0;
              j = 1;
              i = 1;
            }
          }
        }
      }
    }
    label3894: Object localObject3 = (double[][])Array.newInstance(Double.TYPE, new int[] { 4, 4 });
    Object localObject2 = new double[2];
    localObject1[0] = (this.aqZ.arK[0] - this.aqZ.art[0]);
    localObject1[1] = (this.aqZ.arK[1] - this.aqZ.art[1]);
    arrayOfDouble1[0] = (parama.are[0] - this.aqZ.art[0]);
    arrayOfDouble1[1] = (parama.are[1] - this.aqZ.art[1]);
    double d2 = Math.sqrt(arrayOfDouble1[0] * arrayOfDouble1[0] + arrayOfDouble1[1] * arrayOfDouble1[1]);
    double d1 = localObject1[0];
    double d3 = localObject1[0];
    double d4 = localObject1[1];
    d4 = Math.sqrt(localObject1[1] * d4 + d1 * d3);
    if (d2 < d4)
    {
      d1 = this.aqZ.arQ;
      label4081: if (!a(this.aqZ.arL, (double[][])localObject3))
        break label4309;
      d3 = 1.0D / (parama.arg * parama.arg);
      localObject1 = new double[4];
      if (!this.aqZ.arX)
        break label4311;
      d1 += d4 / d2 * (1.0D - d1);
      localObject2[0] = (this.aqZ.art[0] + arrayOfDouble1[0] * d1);
      d2 = this.aqZ.art[1];
      localObject2[1] = (d1 * arrayOfDouble1[1] + d2);
    }
    while (true)
    {
      i = 0;
      if (i < 4)
        break label4370;
      parama = localObject3[0];
      parama[0] += d3;
      parama = localObject3[1];
      parama[1] += d3;
      if (!a((double[][])localObject3, this.aqZ.arL))
        break;
      localObject1[0] += localObject2[0] * d3;
      localObject1[1] += localObject2[1] * d3;
      i = 0;
      if (i < 4)
        break label4433;
      this.aqZ.art[0] = localObject2[0];
      this.aqZ.art[1] = localObject2[1];
      return;
      d1 = this.aqZ.arR;
      break label4081;
      label4309: break;
      label4311: localObject2[0] = (this.aqZ.arK[0] * (1.0D - d1) + parama.are[0] * d1);
      d2 = this.aqZ.arK[1];
      localObject2[1] = (d1 * parama.are[1] + d2 * (1.0D - d1));
    }
    label4370: localObject1[i] = 0.0D;
    int j = 0;
    while (true)
    {
      if (j >= 4)
      {
        i += 1;
        break;
      }
      localObject1[i] += localObject3[i][j] * this.aqZ.arK[j];
      j += 1;
    }
    label4433: this.aqZ.arK[i] = 0.0D;
    j = 0;
    while (true)
    {
      if (j >= 4)
      {
        i += 1;
        break;
      }
      parama = this.aqZ.arK;
      parama[i] += this.aqZ.arL[i][j] * localObject1[j];
      j += 1;
    }
  }

  protected static final class a
  {
    double arb;
    double arc;
    double ard;
    double[] are = new double[2];
    double arf;
    double arg;
    int arh;
    double ari;
    double arj;
    int ark;
    double arl;
    double arm;
    double arn;
    int mType;

    protected a(int paramInt1, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, int paramInt2, double paramDouble6, int paramInt3, double paramDouble7, double paramDouble8)
    {
      this.mType = paramInt1;
      this.arb = paramDouble1;
      this.arc = paramDouble2;
      this.ard = paramDouble3;
      this.arf = paramDouble4;
      this.arg = paramDouble5;
      this.arh = paramInt2;
      this.ari = paramDouble6;
      this.arj = 0.0D;
      this.ark = paramInt3;
      this.arl = 0.0D;
      this.arm = paramDouble7;
      this.arn = paramDouble8;
    }

    public final String toString()
    {
      return String.valueOf(this.mType) + ',' + this.arb + ',' + this.arc + ',' + this.ard + ',' + this.arf + ',' + this.arg + ',' + this.arh + ',' + this.ari + ',' + this.arj + ',' + this.ark + ',' + this.arm + ',' + this.arn;
    }
  }

  private static final class b
  {
    double arA;
    double arB;
    double arC;
    double arD;
    double arE;
    double arF;
    double[] arG = new double[2];
    private boolean arH;
    boolean arI;
    boolean arJ;
    double[] arK = new double[4];
    double[][] arL = (double[][])Array.newInstance(Double.TYPE, new int[] { 4, 4 });
    double arM;
    double arN;
    double arO;
    boolean arP;
    double arQ;
    double arR;
    int arS;
    int arT;
    double arU;
    double[] arV = new double[2];
    double[] arW = new double[2];
    boolean arX;
    double arb;
    double aro;
    boolean arp;
    double[] arq = new double[2];
    double arr;
    boolean ars;
    double[] art = new double[2];
    double aru;
    int arv;
    int arw;
    boolean arx;
    boolean ary;
    double arz;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.j
 * JD-Core Version:    0.6.2
 */