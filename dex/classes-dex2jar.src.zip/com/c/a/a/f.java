package com.c.a.a;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.hardware.SensorManager;
import android.location.LocationManager;
import android.net.wifi.WifiManager;
import android.os.Build.VERSION;
import android.util.Base64;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

public final class f
{
  int aqA = 0;
  int aqB = 0;
  int aqC = 0;
  private String aqD = "203";
  private final WifiManager aqp;
  private final LocationManager aqq;
  final SensorManager aqr;
  final PackageManager aqs;
  PackageInfo aqt;
  String aqu;
  String aqv;
  String aqw;
  private int aqx = 0;
  private int aqy = 0;
  int aqz = 0;
  String imei;
  final Context mContext;
  private String version = "2.0.1";
  String versionName;

  public f(Context paramContext)
  {
    this.mContext = paramContext;
    this.aqp = ((WifiManager)this.mContext.getSystemService("wifi"));
    this.aqq = ((LocationManager)this.mContext.getSystemService("location"));
    this.aqr = ((SensorManager)this.mContext.getSystemService("sensor"));
    this.aqs = this.mContext.getPackageManager();
    this.aqt = new PackageInfo();
    try
    {
      this.aqt = this.aqs.getPackageInfo(this.mContext.getPackageName(), 0);
      return;
    }
    catch (PackageManager.NameNotFoundException paramContext)
    {
    }
  }

  private static String aw(String paramString)
  {
    String str = paramString;
    if (paramString == null)
      str = "";
    return str;
  }

  private boolean jX()
  {
    try
    {
      boolean bool = this.aqq.isProviderEnabled("gps");
      return bool;
    }
    catch (Exception localException)
    {
    }
    return false;
  }

  @SuppressLint({"NewApi"})
  private boolean jY()
  {
    boolean bool1 = false;
    boolean bool2;
    if (this.aqp != null)
    {
      bool2 = this.aqp.isWifiEnabled();
      bool1 = bool2;
      if (!bool2)
        bool1 = bool2;
    }
    try
    {
      if (Build.VERSION.SDK_INT >= 18)
        bool1 = this.aqp.isScanAlwaysAvailable();
      return bool1;
    }
    catch (Error localError)
    {
      return bool2;
    }
    catch (Exception localException)
    {
    }
    return bool2;
  }

  public final String j(byte[] paramArrayOfByte)
  {
    int j = 1;
    HashMap localHashMap = new HashMap();
    localHashMap.put("version", this.version);
    localHashMap.put("app_name", aw(this.versionName));
    if (this.aqu != null)
      localHashMap.put("app_label", aw(Base64.encodeToString(this.aqu.getBytes(), 0)));
    while (true)
    {
      int i;
      if (jX())
      {
        i = 1;
        label76: this.aqy = i;
        if ((this.aqp == null) || (!this.aqp.isWifiEnabled()))
          break label306;
        i = 1;
        label100: if ((i | jY()) == 0)
          break label311;
        i = j;
        this.aqx = i;
        localHashMap.put("chips", Integer.toBinaryString(this.aqC | 0x0 | this.aqB << 1 | this.aqA << 2 | this.aqz << 3 | this.aqy << 4 | this.aqx << 5));
        localHashMap.put("source", this.aqD);
        localHashMap.put("query", new String(paramArrayOfByte));
      }
      try
      {
        paramArrayOfByte = new JSONObject(localHashMap);
        localHashMap = new HashMap();
        localHashMap.put("model", aw(Base64.encodeToString(this.aqv.getBytes(), 0)));
        localHashMap.put("version", aw(this.aqw));
        localHashMap.put("imei", aw(this.imei));
        paramArrayOfByte = paramArrayOfByte.put("attribute", new JSONObject(localHashMap)).toString();
        return paramArrayOfByte;
        localHashMap.put("app_label", "");
        continue;
        i = 0;
        break label76;
        label306: i = 0;
        break label100;
        label311: i = 0;
      }
      catch (JSONException paramArrayOfByte)
      {
      }
    }
    return null;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.f
 * JD-Core Version:    0.6.2
 */