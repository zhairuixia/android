package com.c.a.a;

import android.os.Handler;
import android.util.SparseArray;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class z
{
  private static z awD;
  private static final SparseArray<z> awE = new SparseArray();
  private final ExecutorService awF;
  private final Handler handler;

  private z(Handler paramHandler)
  {
    if (paramHandler != null);
    for (this.awF = null; ; this.awF = Executors.newSingleThreadExecutor())
    {
      this.handler = paramHandler;
      return;
    }
  }

  static z b(Handler paramHandler)
  {
    if (paramHandler != null)
    {
      int i = paramHandler.getLooper().hashCode();
      z localz2 = (z)awE.get(i);
      z localz1 = localz2;
      if (localz2 == null)
      {
        localz1 = new z(paramHandler);
        awE.put(i, localz1);
      }
      return localz1;
    }
    if (awD == null)
      awD = new z(null);
    return awD;
  }

  final void execute(Runnable paramRunnable)
  {
    if (this.handler != null)
    {
      this.handler.post(paramRunnable);
      return;
    }
    this.awF.execute(paramRunnable);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.z
 * JD-Core Version:    0.6.2
 */