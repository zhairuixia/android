package com.c.a.a;

import java.io.UnsupportedEncodingException;

public final class h
{
  static final int aqE = 5;
  static final int aqF = 7;
  static final byte[] aqG;
  static final int aqH;
  static final int aqI;
  static final byte[] aqJ;
  static final byte[] aqK;
  static final String aqL;
  static final String aqM;
  static final String aqN;

  static
  {
    try
    {
      arrayOfByte1 = "$UEC,".getBytes("UTF-8");
      aqG = arrayOfByte1;
      aqH = 4;
      aqI = 6;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException1)
    {
      try
      {
        byte[] arrayOfByte1 = "$UP,".getBytes("UTF-8");
        aqJ = arrayOfByte1;
        aqK = new byte[] { -75, -5, -12, 112, -40, -44, -7, -71 };
        aqL = "/" + y.PROTOCOL + "/c.php";
        aqM = "/" + y.PROTOCOL + "/d.php";
        aqN = "_" + y.awk + "_list.sensewhere-sdk.com";
        return;
        localUnsupportedEncodingException1 = localUnsupportedEncodingException1;
        byte[] arrayOfByte2 = "$UEC,".getBytes();
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException2)
      {
        while (true)
          byte[] arrayOfByte3 = "$UP,".getBytes();
      }
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.h
 * JD-Core Version:    0.6.2
 */