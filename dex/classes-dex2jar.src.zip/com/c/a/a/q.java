package com.c.a.a;

public abstract interface q
{
  public abstract byte[] l(byte[] paramArrayOfByte);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.q
 * JD-Core Version:    0.6.2
 */