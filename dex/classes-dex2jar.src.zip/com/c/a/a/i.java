package com.c.a.a;

import android.location.Location;

final class i
{
  static i aqO;
  double aqP;
  double aqQ;
  float aqR;
  float aqS;
  float aqT;
  float aqU;
  float aqV;
  float aqW;
  boolean aqX = false;

  final void a(double paramDouble1, double paramDouble2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    float[] arrayOfFloat = new float[1];
    if (paramDouble2 > 179.0D)
    {
      d = -1.E-05D;
      Location.distanceBetween(paramDouble1, paramDouble2, paramDouble1, paramDouble2 + d, arrayOfFloat);
      this.aqW = arrayOfFloat[0];
      if (paramDouble1 <= 89.0D)
        break label119;
    }
    label119: for (double d = -1.E-05D; ; d = 1.E-05D)
    {
      Location.distanceBetween(d + paramDouble1, paramDouble2, paramDouble1, paramDouble2, arrayOfFloat);
      this.aqV = arrayOfFloat[0];
      this.aqP = paramDouble1;
      this.aqQ = paramDouble2;
      this.aqR = paramFloat2;
      this.aqS = paramFloat3;
      this.aqU = paramFloat1;
      this.aqT = paramFloat4;
      this.aqX = true;
      return;
      d = 1.E-05D;
      break;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.i
 * JD-Core Version:    0.6.2
 */