package com.c.a.a;

import android.content.Context;
import java.lang.ref.WeakReference;

public final class t
{
  private static boolean aqg = false;
  private static Context atX;
  private static WeakReference<b> atY;
  private static WeakReference<d> atZ;
  private static WeakReference<c> aua;
  private static WeakReference<e> aub;
  private static final a auc = new a((byte)0);
  private static String imei;

  public static void a(Context paramContext, q paramq)
  {
    atX = paramContext.getApplicationContext();
    try
    {
      w.kz().a(paramContext, new m[] { auc });
      r.kd().atq = paramq;
      r.kd().atr = imei;
      return;
    }
    catch (Exception paramContext)
    {
    }
  }

  // ERROR //
  public static boolean a(android.os.Handler paramHandler, long paramLong, b paramb, d paramd)
  {
    // Byte code:
    //   0: getstatic 58	com/c/a/a/t:atX	Landroid/content/Context;
    //   3: ifnonnull +5 -> 8
    //   6: iconst_0
    //   7: ireturn
    //   8: getstatic 40	com/c/a/a/t:aqg	Z
    //   11: ifeq +5 -> 16
    //   14: iconst_1
    //   15: ireturn
    //   16: new 89	java/lang/ref/WeakReference
    //   19: dup
    //   20: aload_3
    //   21: invokespecial 92	java/lang/ref/WeakReference:<init>	(Ljava/lang/Object;)V
    //   24: putstatic 94	com/c/a/a/t:atY	Ljava/lang/ref/WeakReference;
    //   27: new 89	java/lang/ref/WeakReference
    //   30: dup
    //   31: aload 4
    //   33: invokespecial 92	java/lang/ref/WeakReference:<init>	(Ljava/lang/Object;)V
    //   36: putstatic 96	com/c/a/a/t:atZ	Ljava/lang/ref/WeakReference;
    //   39: new 89	java/lang/ref/WeakReference
    //   42: dup
    //   43: aconst_null
    //   44: invokespecial 92	java/lang/ref/WeakReference:<init>	(Ljava/lang/Object;)V
    //   47: putstatic 98	com/c/a/a/t:aua	Ljava/lang/ref/WeakReference;
    //   50: invokestatic 64	com/c/a/a/w:kz	()Lcom/c/a/a/w;
    //   53: astore_3
    //   54: aload_0
    //   55: ifnull +183 -> 238
    //   58: aload_3
    //   59: aload_0
    //   60: new 100	com/c/a/a/n$c
    //   63: dup
    //   64: lload_1
    //   65: ldc2_w 101
    //   68: invokespecial 105	com/c/a/a/n$c:<init>	(JJ)V
    //   71: invokevirtual 108	com/c/a/a/w:a	(Landroid/os/Handler;Lcom/c/a/a/d$a;)V
    //   74: getstatic 113	com/c/a/a/y:awq	Z
    //   77: ifeq +105 -> 182
    //   80: invokestatic 119	com/c/a/a/o:kc	()Ljava/lang/String;
    //   83: putstatic 122	com/c/a/a/y:awx	Ljava/lang/String;
    //   86: new 124	java/lang/StringBuilder
    //   89: dup
    //   90: ldc 126
    //   92: invokespecial 129	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   95: getstatic 122	com/c/a/a/y:awx	Ljava/lang/String;
    //   98: invokevirtual 133	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   101: invokevirtual 136	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   104: ldc 138
    //   106: invokestatic 142	com/c/a/a/o:l	(Ljava/lang/String;Ljava/lang/String;)Z
    //   109: pop
    //   110: new 124	java/lang/StringBuilder
    //   113: dup
    //   114: ldc 144
    //   116: invokespecial 129	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   119: getstatic 122	com/c/a/a/y:awx	Ljava/lang/String;
    //   122: invokevirtual 133	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   125: invokevirtual 136	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   128: ldc 146
    //   130: invokestatic 142	com/c/a/a/o:l	(Ljava/lang/String;Ljava/lang/String;)Z
    //   133: pop
    //   134: new 124	java/lang/StringBuilder
    //   137: dup
    //   138: ldc 148
    //   140: invokespecial 129	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   143: getstatic 122	com/c/a/a/y:awx	Ljava/lang/String;
    //   146: invokevirtual 133	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   149: invokevirtual 136	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   152: ldc 150
    //   154: invokestatic 142	com/c/a/a/o:l	(Ljava/lang/String;Ljava/lang/String;)Z
    //   157: pop
    //   158: new 124	java/lang/StringBuilder
    //   161: dup
    //   162: ldc 152
    //   164: invokespecial 129	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   167: getstatic 122	com/c/a/a/y:awx	Ljava/lang/String;
    //   170: invokevirtual 133	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   173: invokevirtual 136	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   176: ldc 154
    //   178: invokestatic 142	com/c/a/a/o:l	(Ljava/lang/String;Ljava/lang/String;)Z
    //   181: pop
    //   182: getstatic 156	com/c/a/a/t:aub	Ljava/lang/ref/WeakReference;
    //   185: ifnull +47 -> 232
    //   188: getstatic 156	com/c/a/a/t:aub	Ljava/lang/ref/WeakReference;
    //   191: invokevirtual 160	java/lang/ref/WeakReference:get	()Ljava/lang/Object;
    //   194: checkcast 18	com/c/a/a/t$e
    //   197: ifnull +35 -> 232
    //   200: getstatic 58	com/c/a/a/t:atX	Landroid/content/Context;
    //   203: ldc 162
    //   205: invokevirtual 166	android/content/Context:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   208: checkcast 168	android/location/LocationManager
    //   211: astore_0
    //   212: aload_0
    //   213: ldc 170
    //   215: invokevirtual 174	android/location/LocationManager:isProviderEnabled	(Ljava/lang/String;)Z
    //   218: istore 5
    //   220: iload 5
    //   222: ifne +10 -> 232
    //   225: aload_0
    //   226: ldc 176
    //   228: invokevirtual 174	android/location/LocationManager:isProviderEnabled	(Ljava/lang/String;)Z
    //   231: pop
    //   232: iconst_1
    //   233: putstatic 40	com/c/a/a/t:aqg	Z
    //   236: iconst_1
    //   237: ireturn
    //   238: new 178	android/os/Handler
    //   241: dup
    //   242: getstatic 58	com/c/a/a/t:atX	Landroid/content/Context;
    //   245: invokevirtual 182	android/content/Context:getMainLooper	()Landroid/os/Looper;
    //   248: invokespecial 185	android/os/Handler:<init>	(Landroid/os/Looper;)V
    //   251: astore_0
    //   252: goto -194 -> 58
    //   255: astore_0
    //   256: iconst_0
    //   257: putstatic 40	com/c/a/a/t:aqg	Z
    //   260: iconst_0
    //   261: ireturn
    //   262: astore_3
    //   263: iconst_0
    //   264: istore 5
    //   266: goto -46 -> 220
    //   269: astore_0
    //   270: goto -38 -> 232
    //
    // Exception table:
    //   from	to	target	type
    //   50	54	255	java/lang/Exception
    //   58	182	255	java/lang/Exception
    //   182	212	255	java/lang/Exception
    //   212	220	255	java/lang/Exception
    //   225	232	255	java/lang/Exception
    //   232	236	255	java/lang/Exception
    //   238	252	255	java/lang/Exception
    //   212	220	262	java/lang/SecurityException
    //   225	232	269	java/lang/SecurityException
  }

  public static void finish()
  {
    try
    {
      w.kz().jV();
      return;
    }
    catch (Exception localException)
    {
    }
  }

  // ERROR //
  public static void kq()
  {
    // Byte code:
    //   0: invokestatic 64	com/c/a/a/w:kz	()Lcom/c/a/a/w;
    //   3: invokevirtual 193	com/c/a/a/w:stop	()V
    //   6: iconst_0
    //   7: putstatic 40	com/c/a/a/t:aqg	Z
    //   10: return
    //   11: astore_0
    //   12: iconst_0
    //   13: putstatic 40	com/c/a/a/t:aqg	Z
    //   16: return
    //   17: astore_0
    //   18: iconst_0
    //   19: putstatic 40	com/c/a/a/t:aqg	Z
    //   22: aload_0
    //   23: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   0	6	11	java/lang/Exception
    //   0	6	17	finally
  }

  public static void setImei(String paramString)
  {
    imei = paramString;
  }

  private static final class a
    implements m
  {
    public final void a(p paramp)
    {
      switch (paramp.what)
      {
      default:
      case 9901:
      case 9902:
      case 8901:
      case 8902:
      }
      do
      {
        do
        {
          Object localObject;
          do
          {
            do
            {
              do
              {
                do
                  return;
                while (t.kr() == null);
                localObject = (t.b)t.kr().get();
              }
              while (localObject == null);
              paramp = (n.a)paramp;
              ((t.b)localObject).a(paramp.lat, paramp.lng, paramp.asK, paramp.asL, paramp.asM);
              return;
            }
            while (t.ks() == null);
            localObject = (t.d)t.ks().get();
          }
          while (localObject == null);
          paramp = (n.b)paramp;
          ((t.d)localObject).g(paramp.asN, paramp.asO);
          return;
        }
        while ((t.kt() == null) || ((t.c)t.kt().get() == null));
        return;
      }
      while (t.kt() == null);
      t.kt().get();
    }
  }

  public static abstract interface b
  {
    public abstract void a(double paramDouble1, double paramDouble2, int paramInt1, int paramInt2, long paramLong);
  }

  public static abstract interface c
  {
  }

  public static abstract interface d
  {
    public abstract void g(int paramInt, String paramString);
  }

  public static abstract interface e
  {
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.t
 * JD-Core Version:    0.6.2
 */