package com.c.a.a;

import java.util.Arrays;

final class l
{
  float asi;
  long asm;
  private final float[] asn = new float[3];
  private int aso;
  private long asp;
  long asq;

  final void a(float paramFloat, int paramInt, long paramLong)
  {
    long l = paramLong - this.asp;
    if (l > this.asm)
    {
      Arrays.fill(this.asn, 0.0F);
      this.aso = 0;
      this.asp = 0L;
      this.asq = 0L;
      this.asi = 0.0F;
      this.asn[0] = this.asn[1];
      this.asn[1] = this.asn[2];
      this.asn[2] = paramFloat;
      if (this.asn[2] != 0.0F)
      {
        if (this.asn[0] == 0.0F)
          break label196;
        paramFloat = (this.asn[0] + this.asn[1] + this.asn[2]) / 3.0F;
      }
    }
    while (true)
    {
      float f = y.awt;
      this.asi = (paramInt / (paramFloat + this.asn[2] * 3.0F) * f + y.awu * (paramInt - this.aso) / (this.aso + paramInt + 1));
      this.aso = paramInt;
      this.asp = paramLong;
      return;
      this.asq = (l + this.asq);
      break;
      label196: if (this.asn[1] != 0.0F)
        paramFloat = (this.asn[1] + this.asn[2]) / 2.0F;
      else
        paramFloat = this.asn[2];
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.l
 * JD-Core Version:    0.6.2
 */