package com.c.a.a;

import android.location.Location;
import android.os.Handler;
import java.util.ArrayList;
import java.util.List;

final class s
{
  private long atE;
  float atF;
  private ArrayList<String> atG = new ArrayList();
  private ArrayList<float[]> atH = new ArrayList();
  private ArrayList<double[]> atI = new ArrayList();
  final d atJ;
  Handler atK;

  public s(d paramd)
  {
    this.atJ = paramd;
  }

  // ERROR //
  private void V(boolean paramBoolean)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 52	com/c/a/a/s:atH	Ljava/util/ArrayList;
    //   6: invokevirtual 65	java/util/ArrayList:isEmpty	()Z
    //   9: ifne +122 -> 131
    //   12: aload_0
    //   13: getfield 54	com/c/a/a/s:atI	Ljava/util/ArrayList;
    //   16: invokevirtual 65	java/util/ArrayList:isEmpty	()Z
    //   19: ifne +112 -> 131
    //   22: iload_1
    //   23: ifeq +111 -> 134
    //   26: aload_0
    //   27: getfield 54	com/c/a/a/s:atI	Ljava/util/ArrayList;
    //   30: invokevirtual 69	java/util/ArrayList:size	()I
    //   33: istore 23
    //   35: aload_0
    //   36: getfield 52	com/c/a/a/s:atH	Ljava/util/ArrayList;
    //   39: invokevirtual 69	java/util/ArrayList:size	()I
    //   42: istore 27
    //   44: iload 23
    //   46: iconst_1
    //   47: if_icmple +84 -> 131
    //   50: iconst_0
    //   51: istore 20
    //   53: iconst_1
    //   54: istore 24
    //   56: iload 24
    //   58: iload 23
    //   60: if_icmplt +88 -> 148
    //   63: aload_0
    //   64: getfield 50	com/c/a/a/s:atG	Ljava/util/ArrayList;
    //   67: iconst_0
    //   68: iload 20
    //   70: invokevirtual 73	java/util/ArrayList:subList	(II)Ljava/util/List;
    //   73: invokeinterface 78 1 0
    //   78: aload_0
    //   79: getfield 50	com/c/a/a/s:atG	Ljava/util/ArrayList;
    //   82: invokevirtual 81	java/util/ArrayList:trimToSize	()V
    //   85: aload_0
    //   86: getfield 52	com/c/a/a/s:atH	Ljava/util/ArrayList;
    //   89: iconst_0
    //   90: iload 20
    //   92: invokevirtual 73	java/util/ArrayList:subList	(II)Ljava/util/List;
    //   95: invokeinterface 78 1 0
    //   100: aload_0
    //   101: getfield 52	com/c/a/a/s:atH	Ljava/util/ArrayList;
    //   104: invokevirtual 81	java/util/ArrayList:trimToSize	()V
    //   107: aload_0
    //   108: getfield 54	com/c/a/a/s:atI	Ljava/util/ArrayList;
    //   111: iconst_0
    //   112: iload 23
    //   114: iconst_1
    //   115: isub
    //   116: invokevirtual 73	java/util/ArrayList:subList	(II)Ljava/util/List;
    //   119: invokeinterface 78 1 0
    //   124: aload_0
    //   125: getfield 54	com/c/a/a/s:atI	Ljava/util/ArrayList;
    //   128: invokevirtual 81	java/util/ArrayList:trimToSize	()V
    //   131: aload_0
    //   132: monitorexit
    //   133: return
    //   134: aload_0
    //   135: getfield 54	com/c/a/a/s:atI	Ljava/util/ArrayList;
    //   138: invokevirtual 69	java/util/ArrayList:size	()I
    //   141: iconst_1
    //   142: isub
    //   143: istore 23
    //   145: goto -110 -> 35
    //   148: aload_0
    //   149: getfield 54	com/c/a/a/s:atI	Ljava/util/ArrayList;
    //   152: iload 24
    //   154: iconst_1
    //   155: isub
    //   156: invokevirtual 85	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   159: checkcast 87	[D
    //   162: astore 29
    //   164: aload_0
    //   165: getfield 54	com/c/a/a/s:atI	Ljava/util/ArrayList;
    //   168: iload 24
    //   170: invokevirtual 85	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   173: checkcast 87	[D
    //   176: astore 30
    //   178: iconst_1
    //   179: newarray float
    //   181: astore 28
    //   183: aload 29
    //   185: iconst_0
    //   186: daload
    //   187: dstore 4
    //   189: aload 29
    //   191: iconst_1
    //   192: daload
    //   193: dstore 6
    //   195: aload 29
    //   197: iconst_0
    //   198: daload
    //   199: dstore 8
    //   201: aload 29
    //   203: iconst_1
    //   204: daload
    //   205: dstore 10
    //   207: aload 29
    //   209: iconst_1
    //   210: daload
    //   211: ldc2_w 88
    //   214: dcmpg
    //   215: ifgt +1261 -> 1476
    //   218: ldc2_w 90
    //   221: dstore_2
    //   222: dload 4
    //   224: dload 6
    //   226: dload 8
    //   228: dload_2
    //   229: dload 10
    //   231: dadd
    //   232: aload 28
    //   234: invokestatic 97	android/location/Location:distanceBetween	(DDDD[F)V
    //   237: aload 28
    //   239: iconst_0
    //   240: faload
    //   241: f2d
    //   242: dstore 6
    //   244: aload 29
    //   246: iconst_0
    //   247: daload
    //   248: dstore 4
    //   250: aload 29
    //   252: iconst_1
    //   253: daload
    //   254: dstore 8
    //   256: aload 29
    //   258: iconst_0
    //   259: daload
    //   260: dstore 10
    //   262: aload 29
    //   264: iconst_0
    //   265: daload
    //   266: ldc2_w 98
    //   269: dcmpg
    //   270: ifgt +1213 -> 1483
    //   273: ldc2_w 90
    //   276: dstore_2
    //   277: dload 4
    //   279: dload 8
    //   281: dload_2
    //   282: dload 10
    //   284: dadd
    //   285: aload 29
    //   287: iconst_1
    //   288: daload
    //   289: aload 28
    //   291: invokestatic 97	android/location/Location:distanceBetween	(DDDD[F)V
    //   294: aload 28
    //   296: iconst_0
    //   297: faload
    //   298: f2d
    //   299: dstore 8
    //   301: aload 30
    //   303: iconst_0
    //   304: daload
    //   305: dstore 10
    //   307: aload 29
    //   309: iconst_0
    //   310: daload
    //   311: dstore 12
    //   313: aload 30
    //   315: iconst_1
    //   316: daload
    //   317: aload 29
    //   319: iconst_1
    //   320: daload
    //   321: dsub
    //   322: dstore 4
    //   324: dload 4
    //   326: ldc2_w 100
    //   329: dcmpl
    //   330: ifle +1160 -> 1490
    //   333: dload 4
    //   335: ldc2_w 102
    //   338: dsub
    //   339: dstore_2
    //   340: dload_2
    //   341: ldc2_w 90
    //   344: ddiv
    //   345: dload 6
    //   347: dmul
    //   348: dstore_2
    //   349: dload 10
    //   351: dload 12
    //   353: dsub
    //   354: ldc2_w 90
    //   357: ddiv
    //   358: dload 8
    //   360: dmul
    //   361: dstore 10
    //   363: aload 30
    //   365: iconst_4
    //   366: daload
    //   367: aload 29
    //   369: iconst_4
    //   370: daload
    //   371: dsub
    //   372: dstore 12
    //   374: aload 30
    //   376: iconst_5
    //   377: daload
    //   378: aload 29
    //   380: iconst_5
    //   381: daload
    //   382: dsub
    //   383: dstore 14
    //   385: dload_2
    //   386: dload_2
    //   387: dmul
    //   388: dload 10
    //   390: dload 10
    //   392: dmul
    //   393: dadd
    //   394: dload 12
    //   396: dload 12
    //   398: dmul
    //   399: dload 14
    //   401: dload 14
    //   403: dmul
    //   404: dadd
    //   405: ddiv
    //   406: invokestatic 109	java/lang/Math:sqrt	(D)D
    //   409: dstore 4
    //   411: dload 4
    //   413: fconst_1
    //   414: getstatic 114	com/c/a/a/y:awA	F
    //   417: fdiv
    //   418: f2d
    //   419: dcmpl
    //   420: iflt +1034 -> 1454
    //   423: dload 4
    //   425: getstatic 114	com/c/a/a/y:awA	F
    //   428: f2d
    //   429: dcmpg
    //   430: ifgt +1024 -> 1454
    //   433: dload 10
    //   435: dload_2
    //   436: invokestatic 118	java/lang/Math:atan2	(DD)D
    //   439: dload 14
    //   441: dload 12
    //   443: invokestatic 118	java/lang/Math:atan2	(DD)D
    //   446: dsub
    //   447: dstore 10
    //   449: dload 10
    //   451: invokestatic 121	java/lang/Math:cos	(D)D
    //   454: dstore_2
    //   455: dload 10
    //   457: invokestatic 124	java/lang/Math:sin	(D)D
    //   460: dstore 10
    //   462: iconst_4
    //   463: newarray double
    //   465: astore 31
    //   467: aload 31
    //   469: iconst_0
    //   470: dload_2
    //   471: dastore
    //   472: aload 31
    //   474: iconst_1
    //   475: dload 10
    //   477: dneg
    //   478: dastore
    //   479: aload 31
    //   481: iconst_2
    //   482: dload 10
    //   484: dastore
    //   485: aload 31
    //   487: iconst_3
    //   488: dload_2
    //   489: dastore
    //   490: dload 4
    //   492: dconst_1
    //   493: dcmpg
    //   494: ifge +273 -> 767
    //   497: dload 4
    //   499: dstore_2
    //   500: dload_2
    //   501: ldc2_w 125
    //   504: dmul
    //   505: dstore_2
    //   506: dconst_1
    //   507: dload 10
    //   509: invokestatic 129	java/lang/Math:abs	(D)D
    //   512: dadd
    //   513: dstore 10
    //   515: new 131	java/lang/StringBuilder
    //   518: dup
    //   519: invokespecial 132	java/lang/StringBuilder:<init>	()V
    //   522: astore 32
    //   524: fconst_0
    //   525: fstore 19
    //   527: getstatic 136	com/c/a/a/y:awq	Z
    //   530: ifeq +906 -> 1436
    //   533: new 131	java/lang/StringBuilder
    //   536: dup
    //   537: ldc 138
    //   539: invokespecial 141	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   542: aload 29
    //   544: iconst_0
    //   545: daload
    //   546: invokevirtual 145	java/lang/StringBuilder:append	(D)Ljava/lang/StringBuilder;
    //   549: bipush 44
    //   551: invokevirtual 148	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   554: aload 29
    //   556: iconst_1
    //   557: daload
    //   558: invokevirtual 145	java/lang/StringBuilder:append	(D)Ljava/lang/StringBuilder;
    //   561: bipush 44
    //   563: invokevirtual 148	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   566: aload 29
    //   568: iconst_2
    //   569: daload
    //   570: invokevirtual 145	java/lang/StringBuilder:append	(D)Ljava/lang/StringBuilder;
    //   573: bipush 44
    //   575: invokevirtual 148	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   578: aload 29
    //   580: bipush 8
    //   582: daload
    //   583: invokevirtual 145	java/lang/StringBuilder:append	(D)Ljava/lang/StringBuilder;
    //   586: invokevirtual 152	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   589: invokestatic 155	com/c/a/a/s:aA	(Ljava/lang/String;)V
    //   592: fconst_0
    //   593: fstore 16
    //   595: fconst_0
    //   596: fstore 17
    //   598: fconst_0
    //   599: fstore 18
    //   601: iconst_0
    //   602: istore 22
    //   604: iconst_1
    //   605: istore 21
    //   607: goto +850 -> 1457
    //   610: getstatic 136	com/c/a/a/y:awq	Z
    //   613: ifeq +62 -> 675
    //   616: new 131	java/lang/StringBuilder
    //   619: dup
    //   620: ldc 138
    //   622: invokespecial 141	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   625: aload 30
    //   627: iconst_0
    //   628: daload
    //   629: invokevirtual 145	java/lang/StringBuilder:append	(D)Ljava/lang/StringBuilder;
    //   632: bipush 44
    //   634: invokevirtual 148	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   637: aload 30
    //   639: iconst_1
    //   640: daload
    //   641: invokevirtual 145	java/lang/StringBuilder:append	(D)Ljava/lang/StringBuilder;
    //   644: bipush 44
    //   646: invokevirtual 148	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   649: aload 30
    //   651: iconst_2
    //   652: daload
    //   653: invokevirtual 145	java/lang/StringBuilder:append	(D)Ljava/lang/StringBuilder;
    //   656: bipush 44
    //   658: invokevirtual 148	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   661: aload 30
    //   663: bipush 8
    //   665: daload
    //   666: invokevirtual 145	java/lang/StringBuilder:append	(D)Ljava/lang/StringBuilder;
    //   669: invokevirtual 152	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   672: invokestatic 155	com/c/a/a/s:aA	(Ljava/lang/String;)V
    //   675: iload 22
    //   677: i2f
    //   678: getstatic 158	com/c/a/a/y:awy	F
    //   681: fcmpg
    //   682: ifgt +746 -> 1428
    //   685: fload 18
    //   687: fload 17
    //   689: fsub
    //   690: fstore 17
    //   692: fload 17
    //   694: fconst_0
    //   695: fcmpl
    //   696: ifle +732 -> 1428
    //   699: fload 19
    //   701: fload 16
    //   703: fsub
    //   704: f2d
    //   705: dload 4
    //   707: dmul
    //   708: fload 17
    //   710: f2d
    //   711: ddiv
    //   712: getstatic 161	com/c/a/a/y:awz	F
    //   715: f2d
    //   716: dcmpg
    //   717: ifgt +711 -> 1428
    //   720: invokestatic 167	com/c/a/a/r:kd	()Lcom/c/a/a/r;
    //   723: aload 32
    //   725: invokevirtual 152	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   728: invokevirtual 170	com/c/a/a/r:ax	(Ljava/lang/String;)V
    //   731: iconst_1
    //   732: istore_1
    //   733: getstatic 136	com/c/a/a/y:awq	Z
    //   736: ifeq +16 -> 752
    //   739: iload_1
    //   740: ifeq +630 -> 1370
    //   743: ldc 172
    //   745: astore 28
    //   747: aload 28
    //   749: invokestatic 155	com/c/a/a/s:aA	(Ljava/lang/String;)V
    //   752: aload_0
    //   753: new 24	com/c/a/a/s$g
    //   756: dup
    //   757: iload_1
    //   758: invokespecial 174	com/c/a/a/s$g:<init>	(Z)V
    //   761: invokespecial 177	com/c/a/a/s:d	(Lcom/c/a/a/p;)V
    //   764: goto +703 -> 1467
    //   767: dconst_1
    //   768: dload 4
    //   770: ddiv
    //   771: dstore_2
    //   772: goto -272 -> 500
    //   775: aload_0
    //   776: getfield 52	com/c/a/a/s:atH	Ljava/util/ArrayList;
    //   779: iload 20
    //   781: invokevirtual 85	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   784: checkcast 179	[F
    //   787: astore 33
    //   789: aload 33
    //   791: iconst_2
    //   792: faload
    //   793: f2d
    //   794: aload 30
    //   796: bipush 6
    //   798: daload
    //   799: dcmpl
    //   800: ifgt -190 -> 610
    //   803: aload 33
    //   805: iconst_3
    //   806: ldc2_w 180
    //   809: aload 33
    //   811: iconst_2
    //   812: faload
    //   813: f2d
    //   814: aload 29
    //   816: bipush 6
    //   818: daload
    //   819: dsub
    //   820: dload_2
    //   821: ddiv
    //   822: invokestatic 129	java/lang/Math:abs	(D)D
    //   825: dload 10
    //   827: dmul
    //   828: aload 29
    //   830: iconst_2
    //   831: daload
    //   832: dadd
    //   833: aload 33
    //   835: iconst_2
    //   836: faload
    //   837: f2d
    //   838: aload 30
    //   840: bipush 6
    //   842: daload
    //   843: dsub
    //   844: dload_2
    //   845: ddiv
    //   846: invokestatic 129	java/lang/Math:abs	(D)D
    //   849: dload 10
    //   851: dmul
    //   852: aload 30
    //   854: iconst_2
    //   855: daload
    //   856: dadd
    //   857: invokestatic 184	java/lang/Math:min	(DD)D
    //   860: invokestatic 187	java/lang/Math:max	(DD)D
    //   863: invokestatic 193	java/lang/Double:valueOf	(D)Ljava/lang/Double;
    //   866: invokevirtual 197	java/lang/Double:floatValue	()F
    //   869: fastore
    //   870: iconst_2
    //   871: newarray double
    //   873: astore 34
    //   875: aload 34
    //   877: iconst_0
    //   878: aload 33
    //   880: iconst_0
    //   881: faload
    //   882: f2d
    //   883: aload 29
    //   885: iconst_4
    //   886: daload
    //   887: dsub
    //   888: dastore
    //   889: aload 34
    //   891: iconst_1
    //   892: aload 33
    //   894: iconst_1
    //   895: faload
    //   896: f2d
    //   897: aload 29
    //   899: iconst_5
    //   900: daload
    //   901: dsub
    //   902: dastore
    //   903: iconst_2
    //   904: newarray double
    //   906: astore 28
    //   908: aload 28
    //   910: iconst_0
    //   911: aload 34
    //   913: iconst_0
    //   914: daload
    //   915: dload 4
    //   917: dmul
    //   918: dastore
    //   919: aload 28
    //   921: iconst_1
    //   922: aload 34
    //   924: iconst_1
    //   925: daload
    //   926: dload 4
    //   928: dmul
    //   929: dastore
    //   930: iconst_2
    //   931: newarray double
    //   933: astore 34
    //   935: aload 34
    //   937: iconst_0
    //   938: aload 28
    //   940: iconst_0
    //   941: daload
    //   942: aload 31
    //   944: iconst_0
    //   945: daload
    //   946: dmul
    //   947: aload 28
    //   949: iconst_1
    //   950: daload
    //   951: aload 31
    //   953: iconst_1
    //   954: daload
    //   955: dmul
    //   956: dadd
    //   957: dastore
    //   958: aload 34
    //   960: iconst_1
    //   961: aload 28
    //   963: iconst_0
    //   964: daload
    //   965: aload 31
    //   967: iconst_2
    //   968: daload
    //   969: dmul
    //   970: aload 28
    //   972: iconst_1
    //   973: daload
    //   974: aload 31
    //   976: iconst_3
    //   977: daload
    //   978: dmul
    //   979: dadd
    //   980: dastore
    //   981: iconst_2
    //   982: newarray double
    //   984: astore 28
    //   986: aload 28
    //   988: iconst_0
    //   989: aload 34
    //   991: iconst_0
    //   992: daload
    //   993: dconst_0
    //   994: dadd
    //   995: dastore
    //   996: aload 28
    //   998: iconst_1
    //   999: aload 34
    //   1001: iconst_1
    //   1002: daload
    //   1003: dconst_0
    //   1004: dadd
    //   1005: dastore
    //   1006: iconst_2
    //   1007: newarray double
    //   1009: astore 34
    //   1011: aload 34
    //   1013: iconst_0
    //   1014: ldc2_w 90
    //   1017: aload 28
    //   1019: iconst_1
    //   1020: daload
    //   1021: dmul
    //   1022: dload 8
    //   1024: ddiv
    //   1025: aload 29
    //   1027: iconst_0
    //   1028: daload
    //   1029: dadd
    //   1030: dastore
    //   1031: aload 34
    //   1033: iconst_1
    //   1034: ldc2_w 90
    //   1037: aload 28
    //   1039: iconst_0
    //   1040: daload
    //   1041: dmul
    //   1042: dload 6
    //   1044: ddiv
    //   1045: aload 29
    //   1047: iconst_1
    //   1048: daload
    //   1049: dadd
    //   1050: dastore
    //   1051: aload 34
    //   1053: iconst_0
    //   1054: daload
    //   1055: ldc2_w 198
    //   1058: dcmpl
    //   1059: ifle +187 -> 1246
    //   1062: aload 34
    //   1064: iconst_0
    //   1065: ldc2_w 100
    //   1068: aload 34
    //   1070: iconst_0
    //   1071: daload
    //   1072: dsub
    //   1073: dastore
    //   1074: goto +438 -> 1512
    //   1077: getstatic 136	com/c/a/a/y:awq	Z
    //   1080: ifeq +49 -> 1129
    //   1083: new 131	java/lang/StringBuilder
    //   1086: dup
    //   1087: ldc 201
    //   1089: invokespecial 141	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   1092: aload 34
    //   1094: iconst_0
    //   1095: daload
    //   1096: invokevirtual 145	java/lang/StringBuilder:append	(D)Ljava/lang/StringBuilder;
    //   1099: bipush 44
    //   1101: invokevirtual 148	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   1104: aload 34
    //   1106: iconst_1
    //   1107: daload
    //   1108: invokevirtual 145	java/lang/StringBuilder:append	(D)Ljava/lang/StringBuilder;
    //   1111: bipush 44
    //   1113: invokevirtual 148	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   1116: aload 33
    //   1118: iconst_3
    //   1119: faload
    //   1120: invokevirtual 204	java/lang/StringBuilder:append	(F)Ljava/lang/StringBuilder;
    //   1123: invokevirtual 152	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1126: invokestatic 155	com/c/a/a/s:aA	(Ljava/lang/String;)V
    //   1129: aload_0
    //   1130: getfield 50	com/c/a/a/s:atG	Ljava/util/ArrayList;
    //   1133: iload 20
    //   1135: invokevirtual 85	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   1138: checkcast 206	java/lang/String
    //   1141: astore 28
    //   1143: aload 33
    //   1145: iconst_3
    //   1146: faload
    //   1147: invokestatic 210	java/lang/Math:round	(F)I
    //   1150: istore 26
    //   1152: iload 22
    //   1154: istore 25
    //   1156: iload 26
    //   1158: iload 22
    //   1160: if_icmple +7 -> 1167
    //   1163: iload 26
    //   1165: istore 25
    //   1167: aload 33
    //   1169: iconst_4
    //   1170: faload
    //   1171: invokestatic 210	java/lang/Math:round	(F)I
    //   1174: istore 22
    //   1176: aload 28
    //   1178: ifnull +45 -> 1223
    //   1181: aload 32
    //   1183: aload 28
    //   1185: invokevirtual 213	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1188: pop
    //   1189: aload 34
    //   1191: iconst_0
    //   1192: daload
    //   1193: dstore 12
    //   1195: aload 34
    //   1197: iconst_1
    //   1198: daload
    //   1199: dstore 14
    //   1201: dload 12
    //   1203: dload 14
    //   1205: invokestatic 218	com/c/a/a/v:c	(DD)Z
    //   1208: ifne +97 -> 1305
    //   1211: ldc 220
    //   1213: astore 28
    //   1215: aload 32
    //   1217: aload 28
    //   1219: invokevirtual 213	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1222: pop
    //   1223: iload 21
    //   1225: ifeq +208 -> 1433
    //   1228: aload 33
    //   1230: iconst_5
    //   1231: faload
    //   1232: fstore 17
    //   1234: aload 33
    //   1236: iconst_2
    //   1237: faload
    //   1238: fstore 16
    //   1240: iconst_0
    //   1241: istore 21
    //   1243: goto +295 -> 1538
    //   1246: aload 34
    //   1248: iconst_0
    //   1249: daload
    //   1250: ldc2_w 221
    //   1253: dcmpg
    //   1254: ifge +258 -> 1512
    //   1257: aload 34
    //   1259: iconst_0
    //   1260: ldc2_w 223
    //   1263: aload 34
    //   1265: iconst_0
    //   1266: daload
    //   1267: dsub
    //   1268: dastore
    //   1269: goto +243 -> 1512
    //   1272: astore 28
    //   1274: aload_0
    //   1275: monitorexit
    //   1276: aload 28
    //   1278: athrow
    //   1279: aload 34
    //   1281: iconst_1
    //   1282: daload
    //   1283: ldc2_w 223
    //   1286: dcmpg
    //   1287: ifge -210 -> 1077
    //   1290: aload 34
    //   1292: iconst_1
    //   1293: aload 34
    //   1295: iconst_1
    //   1296: daload
    //   1297: ldc2_w 102
    //   1300: dadd
    //   1301: dastore
    //   1302: goto -225 -> 1077
    //   1305: new 131	java/lang/StringBuilder
    //   1308: dup
    //   1309: ldc 226
    //   1311: invokestatic 229	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   1314: invokespecial 141	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   1317: dload 12
    //   1319: invokevirtual 145	java/lang/StringBuilder:append	(D)Ljava/lang/StringBuilder;
    //   1322: bipush 44
    //   1324: invokevirtual 148	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   1327: dload 14
    //   1329: invokevirtual 145	java/lang/StringBuilder:append	(D)Ljava/lang/StringBuilder;
    //   1332: bipush 44
    //   1334: invokevirtual 148	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   1337: iload 26
    //   1339: invokevirtual 232	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   1342: bipush 44
    //   1344: invokevirtual 148	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   1347: iload 22
    //   1349: invokevirtual 232	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   1352: bipush 44
    //   1354: invokevirtual 148	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   1357: ldc 220
    //   1359: invokevirtual 213	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1362: invokevirtual 152	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   1365: astore 28
    //   1367: goto -152 -> 1215
    //   1370: ldc 234
    //   1372: astore 28
    //   1374: goto -627 -> 747
    //   1377: aload_0
    //   1378: getfield 52	com/c/a/a/s:atH	Ljava/util/ArrayList;
    //   1381: iload 20
    //   1383: invokevirtual 85	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   1386: checkcast 179	[F
    //   1389: iconst_2
    //   1390: faload
    //   1391: f2d
    //   1392: dstore_2
    //   1393: aload 30
    //   1395: bipush 6
    //   1397: daload
    //   1398: dstore 4
    //   1400: dload_2
    //   1401: dload 4
    //   1403: dcmpl
    //   1404: ifgt +16 -> 1420
    //   1407: iload 20
    //   1409: iconst_1
    //   1410: iadd
    //   1411: istore 20
    //   1413: iload 20
    //   1415: iload 27
    //   1417: if_icmplt -40 -> 1377
    //   1420: goto +47 -> 1467
    //   1423: astore 28
    //   1425: goto -202 -> 1223
    //   1428: iconst_0
    //   1429: istore_1
    //   1430: goto -697 -> 733
    //   1433: goto +105 -> 1538
    //   1436: fconst_0
    //   1437: fstore 16
    //   1439: fconst_0
    //   1440: fstore 17
    //   1442: fconst_0
    //   1443: fstore 18
    //   1445: iconst_0
    //   1446: istore 22
    //   1448: iconst_1
    //   1449: istore 21
    //   1451: goto +6 -> 1457
    //   1454: goto -41 -> 1413
    //   1457: iload 20
    //   1459: iload 27
    //   1461: if_icmplt -686 -> 775
    //   1464: goto -854 -> 610
    //   1467: iload 24
    //   1469: iconst_1
    //   1470: iadd
    //   1471: istore 24
    //   1473: goto -1417 -> 56
    //   1476: ldc2_w 235
    //   1479: dstore_2
    //   1480: goto -1258 -> 222
    //   1483: ldc2_w 235
    //   1486: dstore_2
    //   1487: goto -1210 -> 277
    //   1490: dload 4
    //   1492: dstore_2
    //   1493: dload 4
    //   1495: ldc2_w 223
    //   1498: dcmpg
    //   1499: ifge -1159 -> 340
    //   1502: dload 4
    //   1504: ldc2_w 102
    //   1507: dadd
    //   1508: dstore_2
    //   1509: goto -1169 -> 340
    //   1512: aload 34
    //   1514: iconst_1
    //   1515: daload
    //   1516: ldc2_w 100
    //   1519: dcmpl
    //   1520: ifle -241 -> 1279
    //   1523: aload 34
    //   1525: iconst_1
    //   1526: aload 34
    //   1528: iconst_1
    //   1529: daload
    //   1530: ldc2_w 102
    //   1533: dsub
    //   1534: dastore
    //   1535: goto -458 -> 1077
    //   1538: aload 33
    //   1540: iconst_5
    //   1541: faload
    //   1542: fstore 18
    //   1544: aload 33
    //   1546: iconst_2
    //   1547: faload
    //   1548: fstore 19
    //   1550: iload 20
    //   1552: iconst_1
    //   1553: iadd
    //   1554: istore 20
    //   1556: iload 25
    //   1558: istore 22
    //   1560: goto -103 -> 1457
    //
    // Exception table:
    //   from	to	target	type
    //   2	22	1272	finally
    //   26	35	1272	finally
    //   35	44	1272	finally
    //   63	131	1272	finally
    //   134	145	1272	finally
    //   148	183	1272	finally
    //   222	237	1272	finally
    //   277	294	1272	finally
    //   340	363	1272	finally
    //   385	467	1272	finally
    //   506	524	1272	finally
    //   527	592	1272	finally
    //   610	675	1272	finally
    //   675	685	1272	finally
    //   699	731	1272	finally
    //   733	739	1272	finally
    //   747	752	1272	finally
    //   752	764	1272	finally
    //   767	772	1272	finally
    //   775	789	1272	finally
    //   803	875	1272	finally
    //   903	908	1272	finally
    //   930	935	1272	finally
    //   981	986	1272	finally
    //   1006	1051	1272	finally
    //   1077	1129	1272	finally
    //   1129	1152	1272	finally
    //   1167	1176	1272	finally
    //   1181	1189	1272	finally
    //   1201	1211	1272	finally
    //   1215	1223	1272	finally
    //   1305	1367	1272	finally
    //   1377	1393	1272	finally
    //   1181	1189	1423	java/lang/Error
    //   1201	1211	1423	java/lang/Error
    //   1215	1223	1423	java/lang/Error
    //   1305	1367	1423	java/lang/Error
  }

  private static void aA(String paramString)
  {
    o.l("post_processing_log_" + y.awx, paramString);
  }

  private void d(p paramp)
  {
    if (this.atK != null)
      this.atK.post(new d(paramp, (byte)0));
  }

  private void ko()
  {
    try
    {
      this.atI.clear();
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  private void kp()
  {
    try
    {
      this.atG.clear();
      this.atH.clear();
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  final void a(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8)
  {
    while (true)
    {
      try
      {
        int j = this.atI.size();
        i = this.atG.size();
        if (j <= 0)
        {
          this.atI.add(new double[] { paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, i, paramDouble8 });
          i = 1;
          if (i != 0)
          {
            i = this.atI.size();
            d(new e(i));
            if (i == 1)
              kp();
          }
          return;
        }
        double[] arrayOfDouble1 = (double[])this.atI.get(j - 1);
        if (paramDouble8 - arrayOfDouble1[8] < 30000.0D)
        {
          if (paramDouble4 < arrayOfDouble1[3])
            break label444;
          arrayOfFloat = new float[1];
          arrayOfFloat[0] = 30.0F;
          if (j > 1)
          {
            double[] arrayOfDouble2 = (double[])this.atI.get(j - 2);
            Location.distanceBetween(arrayOfDouble2[0], arrayOfDouble2[1], paramDouble1, paramDouble2, arrayOfFloat);
          }
          if (arrayOfFloat[0] < 30.0F)
            break label444;
          double d = i;
          i = arrayOfDouble1.length;
          System.arraycopy(new double[] { paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, d, paramDouble8 }, 0, arrayOfDouble1, 0, i);
          i = 1;
          continue;
        }
        float[] arrayOfFloat = new float[1];
        Location.distanceBetween(arrayOfDouble1[0], arrayOfDouble1[1], paramDouble1, paramDouble2, arrayOfFloat);
        if (arrayOfFloat[0] >= 30.0F)
        {
          this.atI.add(new double[] { paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6, paramDouble7, i, paramDouble8 });
          i = 1;
          if (j >= 8)
          {
            this.atI.subList(0, 1).clear();
            this.atI.trimToSize();
          }
          try
          {
            V(false);
          }
          catch (Exception localException)
          {
          }
          continue;
        }
      }
      finally
      {
      }
      label444: int i = 0;
    }
  }

  final void a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, int paramInt, String paramString)
  {
    try
    {
      this.atG.add(paramString);
      this.atH.add(new float[] { paramFloat1, paramFloat2, paramFloat3, 0.0F, paramInt, paramFloat4 });
      if (this.atG.size() > 256)
      {
        this.atG.subList(0, 1).clear();
        this.atG.trimToSize();
        if (this.atH.size() > 256)
        {
          this.atH.subList(0, 1).clear();
          this.atH.trimToSize();
        }
      }
      return;
    }
    finally
    {
      paramString = finally;
    }
    throw paramString;
  }

  final boolean a(double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat, double paramDouble4, double paramDouble5, double paramDouble6, long paramLong)
  {
    if (paramFloat < y.awB)
      return false;
    if ((paramLong - this.atE < 1000L) && (paramFloat <= this.atF))
      return false;
    z.b(null).execute(new b(paramDouble1, paramDouble2, paramDouble3, paramFloat, paramDouble4, paramDouble5, paramDouble6, paramLong, (byte)0));
    this.atE = paramLong;
    this.atF = paramFloat;
    return true;
  }

  final void kl()
  {
    z.b(null).execute(new c((byte)0));
  }

  // ERROR //
  final void km()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_1
    //   4: invokespecial 285	com/c/a/a/s:V	(Z)V
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_1
    //   11: goto -4 -> 7
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   2	7	10	java/lang/Exception
    //   2	7	14	finally
  }

  final void kn()
  {
    this.atE = 0L;
    this.atF = 0.0F;
    z.b(null).execute(new f((byte)0));
  }

  final void reset()
  {
    try
    {
      ko();
      kp();
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  private final class a
    implements Runnable
  {
    final int asL;
    final float atL;
    final float atM;
    final String atN;
    final float x;
    final float y;

    private a(float paramFloat1, float paramFloat2, float paramFloat3, float paramInt, int paramString, String arg7)
    {
      this.x = paramFloat1;
      this.y = paramFloat2;
      this.atL = paramFloat3;
      this.atM = paramInt;
      this.asL = paramString;
      Object localObject;
      this.atN = localObject;
    }

    public final void run()
    {
      s.this.a(this.x, this.y, this.atL, this.atM, this.asL, this.atN);
    }
  }

  private final class b
    implements Runnable
  {
    final double atP;
    final double atQ;
    final double atR;
    final double atS;
    final double atT;
    final double atU;
    final double lat;
    final double lng;

    private b(double arg2, double arg4, double arg6, double arg8, double arg10, double arg12, double arg14, double arg16)
    {
      this.lat = ???;
      this.lng = ???;
      this.atP = ???;
      this.atQ = ???;
      Object localObject1;
      this.atR = localObject1;
      Object localObject2;
      this.atS = localObject2;
      Object localObject3;
      this.atT = localObject3;
      Object localObject4;
      this.atU = localObject4;
    }

    public final void run()
    {
      s.this.a(this.lat, this.lng, this.atP, this.atQ, this.atR, this.atS, this.atT, this.atU);
    }
  }

  private final class c
    implements Runnable
  {
    private c()
    {
    }

    public final void run()
    {
      s.this.km();
    }
  }

  private final class d
    implements Runnable
  {
    private final p aqd;

    private d(p arg2)
    {
      Object localObject;
      this.aqd = localObject;
    }

    public final void run()
    {
      s.this.atJ.c(this.aqd);
    }
  }

  static final class e extends p
  {
    final int atV;

    e(int paramInt)
    {
      super();
      this.atV = paramInt;
    }
  }

  private final class f
    implements Runnable
  {
    private f()
    {
    }

    public final void run()
    {
      s.this.reset();
    }
  }

  static final class g extends p
  {
    final boolean atW;

    g(boolean paramBoolean)
    {
      super();
      this.atW = paramBoolean;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.s
 * JD-Core Version:    0.6.2
 */