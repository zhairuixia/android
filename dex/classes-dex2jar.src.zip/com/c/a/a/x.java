package com.c.a.a;

final class x
{
  double altitude;
  long asM;
  float asg;
  float ash;
  long atz;
  String awa;
  String awb;
  long awc;
  long awd;
  a awe = null;
  int awf;
  int awg = 0;
  double latitude;
  int level;
  double longitude;

  static final class a
  {
    float awh = 0.0F;
    private int awi = 0;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.x
 * JD-Core Version:    0.6.2
 */