package com.c.a.a;

import java.util.TimeZone;

final class aa
{
  static long p(long paramLong)
  {
    return (TimeZone.getDefault().getOffset(paramLong) + paramLong) / 1000L;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.c.a.a.aa
 * JD-Core Version:    0.6.2
 */