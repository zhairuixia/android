package com.qq.wx.voice.embed.recognizer;

import android.os.Handler;

public final class e
{
  public Grammar apT = null;
  g apU = new g();
  byte[] apV = null;
  public boolean d = false;
  public boolean e = false;

  public final int a(c paramc, byte[] paramArrayOfByte)
  {
    int i = -302;
    if (!this.d)
      i = -304;
    while (!this.e)
      return i;
    this.apU.apW = paramc;
    this.apV = paramArrayOfByte;
    if (this.apV == null)
      return -301;
    try
    {
      new Thread(new a((byte)0)).start();
      return 0;
    }
    catch (Exception paramc)
    {
    }
    return -302;
  }

  private final class a
    implements Runnable
  {
    private a()
    {
    }

    public final void run()
    {
      if (e.this.apT.begin() != 0)
      {
        e.this.apU.a(-102);
        return;
      }
      if (e.this.apT.recognize(e.this.apV, e.this.apV.length) != 0)
      {
        e.this.apU.a(-103);
        return;
      }
      if (e.this.apT.end() != 0)
      {
        e.this.apU.a(-104);
        return;
      }
      a locala = new a();
      if (e.this.apT.getResult(locala) != 0)
        e.this.apU.a(-105);
      g localg = e.this.apU;
      localg.apX.sendMessage(localg.apX.obtainMessage(200, locala));
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.qq.wx.voice.embed.recognizer.e
 * JD-Core Version:    0.6.2
 */