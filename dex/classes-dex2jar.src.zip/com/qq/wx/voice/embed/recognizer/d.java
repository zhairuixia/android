package com.qq.wx.voice.embed.recognizer;

public final class d
{
  public String apN;
  public String apO;
  public String apP;
  public String apQ;
  public String apR;
  public String apS;

  public d(String paramString1, String paramString2, String paramString3)
  {
    this.apN = paramString1;
    this.apO = paramString2;
    this.apP = paramString3;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.qq.wx.voice.embed.recognizer.d
 * JD-Core Version:    0.6.2
 */