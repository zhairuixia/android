package com.qq.wx.voice.embed.recognizer;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

final class h extends Handler
{
  h(g paramg)
  {
  }

  public final void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
      return;
    case 100:
      int i = paramMessage.getData().getInt("errorCode");
      this.apU.apW.br(i);
      return;
    case 200:
    }
    paramMessage = (a)paramMessage.obj;
    this.apU.apW.a(paramMessage);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.qq.wx.voice.embed.recognizer.h
 * JD-Core Version:    0.6.2
 */