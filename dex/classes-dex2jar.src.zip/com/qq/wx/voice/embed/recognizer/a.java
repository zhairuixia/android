package com.qq.wx.voice.embed.recognizer;

public final class a
{
  public String name;
  public String text;
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.qq.wx.voice.embed.recognizer.a
 * JD-Core Version:    0.6.2
 */