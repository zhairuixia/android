package com.qq.wx.voice.embed.recognizer;

import android.content.Context;
import android.os.Build.VERSION;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

public class Grammar
{
  public static String mData = null;
  public static String mDataPath = null;
  public static String mSo = null;
  private f a = null;
  private a b = new a();
  private boolean c = false;
  private boolean d = false;
  private ArrayList e = null;

  private String a()
  {
    int j = 0;
    int i = 0;
    StringBuffer localStringBuffer;
    if (i >= this.e.size())
    {
      localStringBuffer = new StringBuffer("");
      i = j;
    }
    while (true)
    {
      if (i >= this.e.size())
      {
        return localStringBuffer.toString();
        ((d)this.e.get(i)).apQ = a(((d)this.e.get(i)).apN);
        ((d)this.e.get(i)).apR = a(((d)this.e.get(i)).apO);
        ((d)this.e.get(i)).apS = a(((d)this.e.get(i)).apP);
        i += 1;
        break;
      }
      String str = ((d)this.e.get(i)).apQ;
      if (!str.isEmpty())
      {
        if (localStringBuffer.length() > 0)
          localStringBuffer.append("\n");
        localStringBuffer.append(str);
      }
      str = ((d)this.e.get(i)).apR;
      if (!str.isEmpty())
      {
        if (localStringBuffer.length() > 0)
          localStringBuffer.append("\n");
        localStringBuffer.append(str);
      }
      str = ((d)this.e.get(i)).apS;
      if (!str.isEmpty())
      {
        if (localStringBuffer.length() > 0)
          localStringBuffer.append("\n");
        localStringBuffer.append(str);
      }
      i += 1;
    }
  }

  private static String a(String paramString)
  {
    return new String(paramString).replaceAll("[^(a-zA-Z0-9\\u4e00-\\u9fa5)]", "").replaceAll("0", "零").replaceAll("1", "一").replaceAll("2", "二").replaceAll("3", "三").replaceAll("4", "四").replaceAll("5", "五").replaceAll("6", "六").replaceAll("7", "七").replaceAll("8", "八").replaceAll("9", "九");
  }

  public int begin()
  {
    return GrammarNative.begin();
  }

  public int checkFiles(Context paramContext, String paramString1, String paramString2, String paramString3)
  {
    if (this.c)
      return 0;
    if ((paramContext == null) || (paramString1 == null) || (paramString2 == null) || (paramString3 == null))
      return -303;
    if (Build.VERSION.SDK_INT >= 24)
    {
      int j = this.a.e("/vendor/lib/", paramString2, paramString3);
      i = j;
      if (j >= 0);
    }
    for (int i = this.a.b(paramContext, paramString1, paramString2, paramString3); ; i = this.a.e(paramString1, paramString2, paramString3))
    {
      if (i >= 0)
        break label117;
      return i;
      if ((paramString1.compareTo("/system/lib") != 0) && (paramString1.compareTo("/system/lib/") != 0))
        break;
    }
    label117: mDataPath = this.a.b;
    mData = "libwxvoiceembed.bin";
    mSo = "libwxvoiceembed.so";
    this.c = true;
    return 0;
  }

  public int end()
  {
    return GrammarNative.end();
  }

  public int getResult(a parama)
  {
    int k = 0;
    int i = GrammarNative.getResult(this);
    if (i < 0)
      return i;
    parama.text = this.b.text;
    if (this.b.name == null)
    {
      parama.name = null;
      return 0;
    }
    int j = 0;
    while (true)
    {
      i = k;
      if (j >= this.e.size())
        break;
      if (((d)this.e.get(j)).apQ.compareTo(this.b.name) == 0)
      {
        parama.name = ((d)this.e.get(j)).apN;
        return 0;
      }
      if (((d)this.e.get(j)).apR.compareTo(this.b.name) == 0)
      {
        parama.name = ((d)this.e.get(j)).apN;
        return 0;
      }
      if (((d)this.e.get(j)).apS.compareTo(this.b.name) == 0)
      {
        parama.name = ((d)this.e.get(j)).apN;
        return 0;
      }
      j += 1;
    }
  }

  // ERROR //
  public int init(ArrayList paramArrayList)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 40	com/qq/wx/voice/embed/recognizer/Grammar:d	Z
    //   4: ifeq +5 -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: aload_1
    //   10: ifnonnull +7 -> 17
    //   13: sipush -303
    //   16: ireturn
    //   17: new 207	java/lang/StringBuilder
    //   20: dup
    //   21: getstatic 21	com/qq/wx/voice/embed/recognizer/Grammar:mDataPath	Ljava/lang/String;
    //   24: invokestatic 211	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   27: invokespecial 212	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   30: ldc 214
    //   32: invokevirtual 217	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   35: getstatic 25	com/qq/wx/voice/embed/recognizer/Grammar:mSo	Ljava/lang/String;
    //   38: invokevirtual 217	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   41: invokevirtual 218	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   44: invokestatic 223	java/lang/System:load	(Ljava/lang/String;)V
    //   47: aload_0
    //   48: aload_1
    //   49: putfield 42	com/qq/wx/voice/embed/recognizer/Grammar:e	Ljava/util/ArrayList;
    //   52: aload_0
    //   53: invokespecial 225	com/qq/wx/voice/embed/recognizer/Grammar:a	()Ljava/lang/String;
    //   56: astore_1
    //   57: getstatic 21	com/qq/wx/voice/embed/recognizer/Grammar:mDataPath	Ljava/lang/String;
    //   60: invokevirtual 229	java/lang/String:getBytes	()[B
    //   63: getstatic 23	com/qq/wx/voice/embed/recognizer/Grammar:mData	Ljava/lang/String;
    //   66: invokevirtual 229	java/lang/String:getBytes	()[B
    //   69: aload_1
    //   70: invokevirtual 230	java/lang/String:toString	()Ljava/lang/String;
    //   73: ldc 232
    //   75: invokevirtual 235	java/lang/String:getBytes	(Ljava/lang/String;)[B
    //   78: invokestatic 238	com/qq/wx/voice/embed/recognizer/GrammarNative:init	([B[B[B)I
    //   81: ifge +83 -> 164
    //   84: new 207	java/lang/StringBuilder
    //   87: dup
    //   88: getstatic 21	com/qq/wx/voice/embed/recognizer/Grammar:mDataPath	Ljava/lang/String;
    //   91: invokestatic 211	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   94: invokespecial 212	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   97: ldc 240
    //   99: invokevirtual 217	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   102: getstatic 23	com/qq/wx/voice/embed/recognizer/Grammar:mData	Ljava/lang/String;
    //   105: invokevirtual 217	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   108: ldc 240
    //   110: invokevirtual 217	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   113: aload_1
    //   114: invokevirtual 217	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   117: pop
    //   118: bipush 155
    //   120: ireturn
    //   121: astore_1
    //   122: sipush -205
    //   125: ireturn
    //   126: astore_2
    //   127: new 207	java/lang/StringBuilder
    //   130: dup
    //   131: getstatic 21	com/qq/wx/voice/embed/recognizer/Grammar:mDataPath	Ljava/lang/String;
    //   134: invokestatic 211	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   137: invokespecial 212	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   140: ldc 240
    //   142: invokevirtual 217	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: getstatic 23	com/qq/wx/voice/embed/recognizer/Grammar:mData	Ljava/lang/String;
    //   148: invokevirtual 217	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   151: ldc 240
    //   153: invokevirtual 217	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: aload_1
    //   157: invokevirtual 217	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: pop
    //   161: bipush 155
    //   163: ireturn
    //   164: aload_0
    //   165: iconst_1
    //   166: putfield 40	com/qq/wx/voice/embed/recognizer/Grammar:d	Z
    //   169: iconst_0
    //   170: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   17	47	121	java/lang/Exception
    //   57	118	126	java/io/UnsupportedEncodingException
  }

  public void onGetResult(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    if (paramArrayOfByte1 != null);
    try
    {
      for (this.b.text = new String(paramArrayOfByte1, "GBK"); paramArrayOfByte3 != null; this.b.text = null)
      {
        this.b.name = new String(paramArrayOfByte3, "GBK");
        return;
      }
      this.b.name = null;
      return;
    }
    catch (UnsupportedEncodingException paramArrayOfByte1)
    {
    }
  }

  public int recognize(byte[] paramArrayOfByte, int paramInt)
  {
    return GrammarNative.recognize(paramArrayOfByte, paramInt);
  }

  public int update(ArrayList paramArrayList)
  {
    int i = -106;
    if (paramArrayList == null)
      i = -303;
    while (true)
    {
      return i;
      this.e = paramArrayList;
      paramArrayList = a();
      try
      {
        int j = GrammarNative.update(paramArrayList.getBytes("GBK"));
        if (j >= 0)
          return 0;
      }
      catch (UnsupportedEncodingException paramArrayList)
      {
      }
    }
    return -106;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.qq.wx.voice.embed.recognizer.Grammar
 * JD-Core Version:    0.6.2
 */