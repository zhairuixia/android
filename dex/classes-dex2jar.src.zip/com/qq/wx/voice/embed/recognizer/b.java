package com.qq.wx.voice.embed.recognizer;

public final class b
{
  public e apL = new e();

  private static final class a
  {
    public static b apM = new b();
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.qq.wx.voice.embed.recognizer.b
 * JD-Core Version:    0.6.2
 */