package com.qq.wx.voice.embed.recognizer;

public abstract interface c
{
  public abstract void a(a parama);

  public abstract void br(int paramInt);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.qq.wx.voice.embed.recognizer.c
 * JD-Core Version:    0.6.2
 */