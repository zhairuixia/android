package com.samsung.android.sdk.look.smartclip;

import java.util.ArrayList;

public abstract class SlookSmartClipMetaTagArray extends ArrayList<SlookSmartClipMetaTag>
{
  public abstract SlookSmartClipMetaTagArray getTag(String paramString);

  public abstract void removeTag(String paramString);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.samsung.android.sdk.look.smartclip.SlookSmartClipMetaTagArray
 * JD-Core Version:    0.6.2
 */