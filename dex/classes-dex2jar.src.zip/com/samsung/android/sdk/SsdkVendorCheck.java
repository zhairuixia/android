package com.samsung.android.sdk;

import android.os.Build;

public class SsdkVendorCheck
{
  private static String strBrand = Build.BRAND;
  private static String strManufacturer = Build.MANUFACTURER;

  public static boolean isSamsungDevice()
  {
    if ((strBrand == null) || (strManufacturer == null));
    while ((strBrand.compareToIgnoreCase("Samsung") != 0) && (strManufacturer.compareToIgnoreCase("Samsung") != 0))
      return false;
    return true;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.samsung.android.sdk.SsdkVendorCheck
 * JD-Core Version:    0.6.2
 */