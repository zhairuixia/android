package com.google.android.gms.iid;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.util.Base64;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.util.HashMap;
import java.util.Map;

public final class a
{
  static Map<String, a> aas = new HashMap();
  public static e aat;
  private static d aau;
  public static String aay;
  KeyPair aav;
  public String aaw = "";
  long aax;
  Context mContext;

  private a(Context paramContext, String paramString)
  {
    this.mContext = paramContext.getApplicationContext();
    this.aaw = paramString;
  }

  static int D(Context paramContext)
  {
    try
    {
      int i = paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0).versionCode;
      return i;
    }
    catch (PackageManager.NameNotFoundException paramContext)
    {
      new StringBuilder("Never happens: can't find own package ").append(paramContext);
    }
    return 0;
  }

  public static a E(Context paramContext)
  {
    return a(paramContext, null);
  }

  public static a a(Context paramContext, Bundle paramBundle)
  {
    if (paramBundle == null)
      paramBundle = "";
    while (true)
    {
      try
      {
        Context localContext = paramContext.getApplicationContext();
        if (aat == null)
        {
          aat = new e(localContext);
          aau = new d(localContext);
        }
        aay = Integer.toString(D(localContext));
        a locala = (a)aas.get(paramBundle);
        paramContext = locala;
        if (locala == null)
        {
          paramContext = new a(localContext, paramBundle);
          aas.put(paramBundle, paramContext);
        }
        return paramContext;
        paramBundle = paramBundle.getString("subtype");
      }
      finally
      {
      }
      while (paramBundle != null)
        break;
      paramBundle = "";
    }
  }

  static String a(KeyPair paramKeyPair)
  {
    paramKeyPair = paramKeyPair.getPublic().getEncoded();
    try
    {
      paramKeyPair = MessageDigest.getInstance("SHA1").digest(paramKeyPair);
      paramKeyPair[0] = ((byte)((paramKeyPair[0] & 0xF) + 112 & 0xFF));
      paramKeyPair = Base64.encodeToString(paramKeyPair, 0, 8, 11);
      return paramKeyPair;
    }
    catch (NoSuchAlgorithmException paramKeyPair)
    {
    }
    return null;
  }

  static String c(byte[] paramArrayOfByte)
  {
    return Base64.encodeToString(paramArrayOfByte, 11);
  }

  static e hq()
  {
    return aat;
  }

  static d hr()
  {
    return aau;
  }

  public static boolean hs()
  {
    String str = aat.get("appVersion");
    if ((str == null) || (!str.equals(aay)));
    long l;
    do
    {
      do
      {
        return true;
        str = aat.get("lastToken");
      }
      while (str == null);
      l = Long.parseLong(str);
    }
    while (System.currentTimeMillis() / 1000L - Long.valueOf(l).longValue() > 604800L);
    return false;
  }

  public final String b(String paramString1, String paramString2, Bundle paramBundle)
  {
    paramBundle.putString("scope", paramString2);
    paramBundle.putString("sender", paramString1);
    if ("".equals(this.aaw));
    for (paramString2 = paramString1; ; paramString2 = this.aaw)
    {
      if (!paramBundle.containsKey("legacy.register"))
      {
        paramBundle.putString("subscription", paramString1);
        paramBundle.putString("subtype", paramString2);
        paramBundle.putString("X-subscription", paramString1);
        paramBundle.putString("X-subtype", paramString2);
      }
      d locald = aau;
      if (this.aav == null)
        this.aav = aat.ab(this.aaw);
      if (this.aav == null)
      {
        this.aax = System.currentTimeMillis();
        this.aav = aat.a(this.aaw, this.aax);
      }
      KeyPair localKeyPair = this.aav;
      paramString2 = locald.a(paramBundle, localKeyPair);
      paramString1 = paramString2;
      if (paramString2 != null)
      {
        paramString1 = paramString2;
        if (paramString2.hasExtra("google.messenger"))
          paramString1 = locald.a(paramBundle, localKeyPair);
      }
      return d.f(paramString1);
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.iid.a
 * JD-Core Version:    0.6.2
 */