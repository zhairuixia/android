package com.google.android.gms.iid;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.gcm.GcmReceiver;
import java.io.IOException;

public class InstanceIDListenerService extends Service
{
  static String ACTION = "action";
  private static String ZX = "gcm.googleapis.com/refresh";
  private static String aaB = "google.com/iid";
  private static String aaC = "CMD";
  BroadcastReceiver aaA = new BroadcastReceiver()
  {
    public final void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
    {
      if (Log.isLoggable("InstanceID", 3))
      {
        paramAnonymousIntent.getStringExtra("registration_id");
        new StringBuilder("Received GSF callback using dynamic receiver: ").append(paramAnonymousIntent.getExtras());
      }
      InstanceIDListenerService.this.d(paramAnonymousIntent);
      InstanceIDListenerService.this.stop();
    }
  };
  int aaD;
  int aaE;
  MessengerCompat aaz = new MessengerCompat(new Handler(Looper.getMainLooper())
  {
    public final void handleMessage(Message paramAnonymousMessage)
    {
      InstanceIDListenerService.a(InstanceIDListenerService.this, paramAnonymousMessage, MessengerCompat.c(paramAnonymousMessage));
    }
  });

  static void F(Context paramContext)
  {
    Intent localIntent = new Intent("com.google.android.gms.iid.InstanceID");
    localIntent.setPackage(paramContext.getPackageName());
    localIntent.putExtra(aaC, "SYNC");
    paramContext.startService(localIntent);
  }

  static void a(Context paramContext, e parame)
  {
    parame.hv();
    parame = new Intent("com.google.android.gms.iid.InstanceID");
    parame.putExtra(aaC, "RST");
    parame.setPackage(paramContext.getPackageName());
    paramContext.startService(parame);
  }

  public final void d(Intent paramIntent)
  {
    String str = paramIntent.getStringExtra("subtype");
    Object localObject1;
    Object localObject2;
    if (str == null)
    {
      localObject1 = a.E(this);
      localObject2 = paramIntent.getStringExtra(aaC);
      if ((paramIntent.getStringExtra("error") == null) && (paramIntent.getStringExtra("registration_id") == null))
        break label84;
      if (Log.isLoggable("InstanceID", 3));
      a.hr().g(paramIntent);
    }
    label84: 
    do
    {
      do
      {
        return;
        localObject1 = new Bundle();
        ((Bundle)localObject1).putString("subtype", str);
        localObject1 = a.a(this, (Bundle)localObject1);
        break;
        if (Log.isLoggable("InstanceID", 3))
          new StringBuilder("Service command ").append(str).append(" ").append((String)localObject2).append(" ").append(paramIntent.getExtras());
        if (paramIntent.getStringExtra("unregistered") != null)
        {
          localObject2 = a.hq();
          if (str == null);
          for (localObject1 = ""; ; localObject1 = str)
          {
            ((e)localObject2).aa((String)localObject1);
            a.hr().g(paramIntent);
            return;
          }
        }
        if (ZX.equals(paramIntent.getStringExtra("from")))
        {
          a.hq().aa(str);
          return;
        }
        if ("RST".equals(localObject2))
        {
          ((a)localObject1).aax = 0L;
          paramIntent = a.aat;
          str = ((a)localObject1).aaw;
          paramIntent.Z(str + "|");
          ((a)localObject1).aav = null;
          return;
        }
        if (!"RST_FULL".equals(localObject2))
          break label271;
      }
      while (a.hq().isEmpty());
      a.hq().hv();
      return;
      if ("SYNC".equals(localObject2))
      {
        a.hq().aa(str);
        return;
      }
    }
    while (!"PING".equals(localObject2));
    try
    {
      label271: com.google.android.gms.gcm.a.B(this).a(aaB, d.hu(), paramIntent.getExtras());
      return;
    }
    catch (IOException paramIntent)
    {
    }
  }

  public IBinder onBind(Intent paramIntent)
  {
    if ((paramIntent != null) && ("com.google.android.gms.iid.InstanceID".equals(paramIntent.getAction())))
      return this.aaz.getBinder();
    return null;
  }

  public void onCreate()
  {
    IntentFilter localIntentFilter = new IntentFilter("com.google.android.c2dm.intent.REGISTRATION");
    localIntentFilter.addCategory(getPackageName());
    registerReceiver(this.aaA, localIntentFilter, "com.google.android.c2dm.permission.RECEIVE", null);
  }

  public void onDestroy()
  {
    unregisterReceiver(this.aaA);
  }

  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    try
    {
      this.aaD += 1;
      if (paramInt2 > this.aaE)
        this.aaE = paramInt2;
      if (paramIntent == null)
      {
        stop();
        return 2;
      }
    }
    finally
    {
    }
    try
    {
      if ("com.google.android.gms.iid.InstanceID".equals(paramIntent.getAction()))
      {
        if (Build.VERSION.SDK_INT <= 18)
        {
          Intent localIntent = (Intent)paramIntent.getParcelableExtra("GSF");
          if (localIntent != null)
          {
            startService(localIntent);
            return 1;
          }
        }
        d(paramIntent);
      }
      stop();
      if (paramIntent.getStringExtra("from") != null)
        GcmReceiver.a(paramIntent);
      return 2;
    }
    finally
    {
      stop();
    }
    throw paramIntent;
  }

  final void stop()
  {
    try
    {
      this.aaD -= 1;
      if (this.aaD == 0)
        stopSelf(this.aaE);
      if (Log.isLoggable("InstanceID", 3))
        new StringBuilder("Stop ").append(this.aaD).append(" ").append(this.aaE);
      return;
    }
    finally
    {
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.iid.InstanceIDListenerService
 * JD-Core Version:    0.6.2
 */