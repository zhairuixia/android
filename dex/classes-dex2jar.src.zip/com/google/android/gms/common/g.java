package com.google.android.gms.common;

import android.content.Intent;

public class g extends Exception
{
  public final Intent mIntent;

  public g(String paramString, Intent paramIntent)
  {
    super(paramString);
    this.mIntent = paramIntent;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.g
 * JD-Core Version:    0.6.2
 */