package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class j
  implements Parcelable.Creator<GetServiceRequest>
{
  static void a(GetServiceRequest paramGetServiceRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramGetServiceRequest.version);
    b.c(paramParcel, 2, paramGetServiceRequest.WC);
    b.c(paramParcel, 3, paramGetServiceRequest.WD);
    b.a(paramParcel, 4, paramGetServiceRequest.WE);
    b.a(paramParcel, 5, paramGetServiceRequest.WF);
    b.a(paramParcel, 6, paramGetServiceRequest.WG, paramInt);
    b.a(paramParcel, 7, paramGetServiceRequest.WH);
    b.a(paramParcel, 8, paramGetServiceRequest.WI, paramInt);
    b.u(paramParcel, i);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.internal.j
 * JD-Core Version:    0.6.2
 */