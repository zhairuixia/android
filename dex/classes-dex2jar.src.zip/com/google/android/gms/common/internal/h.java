package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.view.View;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.a;
import com.google.android.gms.signin.e;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class h
{
  public final Account RZ;
  public final Set<Scope> Tu;
  private final int Tv;
  private final View Tw;
  public final String Tx;
  final String Ty;
  final Set<Scope> Xo;
  public final Map<a<?>, a> Xp;
  public final e Xq;
  public Integer Xr;

  public h(Account paramAccount, Set<Scope> paramSet, Map<a<?>, a> paramMap, int paramInt, View paramView, String paramString1, String paramString2, e parame)
  {
    this.RZ = paramAccount;
    if (paramSet == null);
    for (paramAccount = Collections.EMPTY_SET; ; paramAccount = Collections.unmodifiableSet(paramSet))
    {
      this.Tu = paramAccount;
      paramAccount = paramMap;
      if (paramMap == null)
        paramAccount = Collections.EMPTY_MAP;
      this.Xp = paramAccount;
      this.Tw = paramView;
      this.Tv = paramInt;
      this.Tx = paramString1;
      this.Ty = paramString2;
      this.Xq = parame;
      paramAccount = new HashSet(this.Tu);
      paramSet = this.Xp.values().iterator();
      while (paramSet.hasNext())
        paramAccount.addAll(((a)paramSet.next()).TO);
    }
    this.Xo = Collections.unmodifiableSet(paramAccount);
  }

  public static final class a
  {
    public final Set<Scope> TO;
    public final boolean Xs;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.internal.h
 * JD-Core Version:    0.6.2
 */