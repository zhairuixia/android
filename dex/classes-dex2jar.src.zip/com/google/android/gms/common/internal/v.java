package com.google.android.gms.common.internal;

import java.util.ArrayList;
import java.util.List;

public final class v
{
  public static a V(Object paramObject)
  {
    return new a(paramObject, (byte)0);
  }

  public static boolean c(Object paramObject1, Object paramObject2)
  {
    return (paramObject1 == paramObject2) || ((paramObject1 != null) && (paramObject1.equals(paramObject2)));
  }

  public static final class a
  {
    private final List<String> Yl;
    private final Object Ym;

    private a(Object paramObject)
    {
      this.Ym = w.W(paramObject);
      this.Yl = new ArrayList();
    }

    public final a h(String paramString, Object paramObject)
    {
      this.Yl.add((String)w.W(paramString) + "=" + String.valueOf(paramObject));
      return this;
    }

    public final String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder(100).append(this.Ym.getClass().getSimpleName()).append('{');
      int j = this.Yl.size();
      int i = 0;
      while (i < j)
      {
        localStringBuilder.append((String)this.Yl.get(i));
        if (i < j - 1)
          localStringBuilder.append(", ");
        i += 1;
      }
      return '}';
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.internal.v
 * JD-Core Version:    0.6.2
 */