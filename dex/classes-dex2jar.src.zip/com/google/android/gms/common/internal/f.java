package com.google.android.gms.common.internal;

public final class f
{
  public static final boolean WR = false;
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.internal.f
 * JD-Core Version:    0.6.2
 */