package com.google.android.gms.common.internal;

import android.os.IInterface;

public abstract interface q extends IInterface
{
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.internal.q
 * JD-Core Version:    0.6.2
 */