package com.google.android.gms.common.internal;

import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.api.c.b;
import com.google.android.gms.common.api.c.c;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicInteger;

public final class l
  implements Handler.Callback
{
  public final a XO;
  public final ArrayList<c.b> XP = new ArrayList();
  public final ArrayList<c.b> XQ = new ArrayList();
  public final ArrayList<c.c> XR = new ArrayList();
  public volatile boolean XS = false;
  public final AtomicInteger XT = new AtomicInteger(0);
  public boolean XU = false;
  public final Object Xw = new Object();
  public final Handler mHandler;

  public l(Looper paramLooper, a parama)
  {
    this.XO = parama;
    this.mHandler = new Handler(paramLooper, this);
  }

  public final void a(c.b paramb)
  {
    w.W(paramb);
    synchronized (this.Xw)
    {
      if (this.XP.contains(paramb))
      {
        new StringBuilder("registerConnectionCallbacks(): listener ").append(paramb).append(" is already registered");
        if (this.XO.isConnected())
          this.mHandler.sendMessage(this.mHandler.obtainMessage(1, paramb));
        return;
      }
      this.XP.add(paramb);
    }
  }

  public final void a(c.c paramc)
  {
    w.W(paramc);
    synchronized (this.Xw)
    {
      if (this.XR.contains(paramc))
      {
        new StringBuilder("registerConnectionFailedListener(): listener ").append(paramc).append(" is already registered");
        return;
      }
      this.XR.add(paramc);
    }
  }

  public final void aB(int paramInt)
  {
    boolean bool = false;
    if (Looper.myLooper() == this.mHandler.getLooper())
      bool = true;
    w.a(bool, "onUnintentionalDisconnection must only be called on the Handler thread");
    this.mHandler.removeMessages(1);
    synchronized (this.Xw)
    {
      this.XU = true;
      Object localObject2 = new ArrayList(this.XP);
      int i = this.XT.get();
      localObject2 = ((ArrayList)localObject2).iterator();
      while (((Iterator)localObject2).hasNext())
      {
        c.b localb = (c.b)((Iterator)localObject2).next();
        if ((this.XS) && (this.XT.get() == i))
          if (this.XP.contains(localb))
            localb.av(paramInt);
      }
    }
    this.XQ.clear();
    this.XU = false;
  }

  public final void gP()
  {
    this.XS = false;
    this.XT.incrementAndGet();
  }

  public final boolean handleMessage(Message arg1)
  {
    if (???.what == 1)
    {
      c.b localb = (c.b)???.obj;
      synchronized (this.Xw)
      {
        if ((this.XS) && (this.XO.isConnected()) && (this.XP.contains(localb)))
          localb.g(null);
        return true;
      }
    }
    Log.wtf("GmsClientEvents", "Don't know how to handle this message.");
    return false;
  }

  public static abstract interface a
  {
    public abstract boolean isConnected();
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.internal.l
 * JD-Core Version:    0.6.2
 */