package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class y
  implements Parcelable.Creator<ResolveAccountResponse>
{
  static void a(ResolveAccountResponse paramResolveAccountResponse, Parcel paramParcel, int paramInt)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramResolveAccountResponse.mVersionCode);
    b.a(paramParcel, 2, paramResolveAccountResponse.Wv);
    b.a(paramParcel, 3, paramResolveAccountResponse.VA, paramInt);
    b.a(paramParcel, 4, paramResolveAccountResponse.Uw);
    b.a(paramParcel, 5, paramResolveAccountResponse.WK);
    b.u(paramParcel, i);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.internal.y
 * JD-Core Version:    0.6.2
 */