package com.google.android.gms.common.internal;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.support.v4.app.Fragment;

public final class i
  implements DialogInterface.OnClickListener
{
  private final Fragment Xt;
  private final int Xu;
  private final Activity dL;
  private final Intent mIntent;

  public i(Activity paramActivity, Intent paramIntent, int paramInt)
  {
    this.dL = paramActivity;
    this.Xt = null;
    this.mIntent = paramIntent;
    this.Xu = 2;
  }

  public i(Fragment paramFragment, Intent paramIntent, int paramInt)
  {
    this.dL = null;
    this.Xt = paramFragment;
    this.mIntent = paramIntent;
    this.Xu = 2;
  }

  public final void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    try
    {
      if ((this.mIntent != null) && (this.Xt != null))
        this.Xt.startActivityForResult(this.mIntent, this.Xu);
      while (true)
      {
        paramDialogInterface.dismiss();
        return;
        if (this.mIntent != null)
          this.dL.startActivityForResult(this.mIntent, this.Xu);
      }
    }
    catch (ActivityNotFoundException paramDialogInterface)
    {
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.internal.i
 * JD-Core Version:    0.6.2
 */