package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class d
  implements Parcelable.Creator<ValidateAccountRequest>
{
  static void a(ValidateAccountRequest paramValidateAccountRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramValidateAccountRequest.mVersionCode);
    b.c(paramParcel, 2, paramValidateAccountRequest.WL);
    b.a(paramParcel, 3, paramValidateAccountRequest.Wv);
    b.a(paramParcel, 4, paramValidateAccountRequest.Ww, paramInt);
    b.a(paramParcel, 5, paramValidateAccountRequest.WM);
    b.a(paramParcel, 6, paramValidateAccountRequest.WN);
    b.u(paramParcel, i);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.internal.d
 * JD-Core Version:    0.6.2
 */