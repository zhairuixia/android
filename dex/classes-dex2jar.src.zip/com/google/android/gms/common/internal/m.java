package com.google.android.gms.common.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;

public abstract class m
{
  private static final Object XV = new Object();
  private static m XW;

  public static m z(Context paramContext)
  {
    synchronized (XV)
    {
      if (XW == null)
        XW = new n(paramContext.getApplicationContext());
      return XW;
    }
  }

  public abstract boolean a(ComponentName paramComponentName, ServiceConnection paramServiceConnection, String paramString);

  public abstract boolean a(String paramString1, String paramString2, ServiceConnection paramServiceConnection, String paramString3);

  public abstract void b(ComponentName paramComponentName, ServiceConnection paramServiceConnection, String paramString);

  public abstract void b(String paramString1, String paramString2, ServiceConnection paramServiceConnection, String paramString3);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.internal.m
 * JD-Core Version:    0.6.2
 */