package com.google.android.gms.common;

import android.content.Context;
import android.content.Intent;

public final class b
{
  public static final int Tg = e.Tg;
  private static final b Th = new b();

  public static Intent ar(int paramInt)
  {
    return e.as(paramInt);
  }

  public static b fQ()
  {
    return Th;
  }

  public static boolean j(Context paramContext, int paramInt)
  {
    return e.j(paramContext, paramInt);
  }

  public static int u(Context paramContext)
  {
    int j = e.u(paramContext);
    int i = j;
    if (e.j(paramContext, j))
      i = 18;
    return i;
  }

  public static void v(Context paramContext)
  {
    e.v(paramContext);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.b
 * JD-Core Version:    0.6.2
 */