package com.google.android.gms.common.stats;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class a
  implements Parcelable.Creator<ConnectionEvent>
{
  static void a(ConnectionEvent paramConnectionEvent, Parcel paramParcel)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramConnectionEvent.mVersionCode);
    b.a(paramParcel, 2, paramConnectionEvent.YP);
    b.a(paramParcel, 4, paramConnectionEvent.YR);
    b.a(paramParcel, 5, paramConnectionEvent.YS);
    b.a(paramParcel, 6, paramConnectionEvent.YT);
    b.a(paramParcel, 7, paramConnectionEvent.YU);
    b.a(paramParcel, 8, paramConnectionEvent.YV);
    b.a(paramParcel, 10, paramConnectionEvent.YX);
    b.a(paramParcel, 11, paramConnectionEvent.YY);
    b.c(paramParcel, 12, paramConnectionEvent.YQ);
    b.a(paramParcel, 13, paramConnectionEvent.YW);
    b.u(paramParcel, i);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.stats.a
 * JD-Core Version:    0.6.2
 */