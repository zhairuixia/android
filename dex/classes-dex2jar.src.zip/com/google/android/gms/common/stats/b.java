package com.google.android.gms.common.stats;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Debug;
import android.os.Process;
import android.os.SystemClock;
import com.google.android.gms.c.aa;
import com.google.android.gms.c.j;
import com.google.android.gms.c.u;
import com.google.android.gms.common.internal.f;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class b
{
  private static final Object XV = new Object();
  private static b Zi;
  private static final ComponentName Zn = new ComponentName("com.google.android.gms", "com.google.android.gms.common.stats.GmsCoreStatsService");
  private static Integer Zp;
  private final List<String> Zj;
  private final List<String> Zk;
  private final List<String> Zl;
  private final List<String> Zm;
  private e Zo;

  private b()
  {
    if (getLogLevel() == d.LOG_LEVEL_OFF)
    {
      this.Zj = Collections.EMPTY_LIST;
      this.Zk = Collections.EMPTY_LIST;
      this.Zl = Collections.EMPTY_LIST;
      this.Zm = Collections.EMPTY_LIST;
      return;
    }
    Object localObject = (String)c.a.Zs.get();
    if (localObject == null)
    {
      localObject = Collections.EMPTY_LIST;
      this.Zj = ((List)localObject);
      localObject = (String)c.a.Zt.get();
      if (localObject != null)
        break label171;
      localObject = Collections.EMPTY_LIST;
      label83: this.Zk = ((List)localObject);
      localObject = (String)c.a.Zu.get();
      if (localObject != null)
        break label184;
      localObject = Collections.EMPTY_LIST;
      label106: this.Zl = ((List)localObject);
      localObject = (String)c.a.Zv.get();
      if (localObject != null)
        break label197;
    }
    label171: label184: label197: for (localObject = Collections.EMPTY_LIST; ; localObject = Arrays.asList(((String)localObject).split(",")))
    {
      this.Zm = ((List)localObject);
      this.Zo = new e(((Long)c.a.Zw.get()).longValue());
      return;
      localObject = Arrays.asList(((String)localObject).split(","));
      break;
      localObject = Arrays.asList(((String)localObject).split(","));
      break label83;
      localObject = Arrays.asList(((String)localObject).split(","));
      break label106;
    }
  }

  private static ServiceInfo b(Context paramContext, Intent paramIntent)
  {
    paramContext = paramContext.getPackageManager().queryIntentServices(paramIntent, 128);
    if ((paramContext == null) || (paramContext.size() == 0))
    {
      String.format("There are no handler of this intent: %s\n Stack trace: %s", new Object[] { paramIntent.toUri(0), aa.aG(20) });
      return null;
    }
    if (paramContext.size() > 1)
    {
      String.format("Multiple handlers found for this intent: %s\n Stack trace: %s", new Object[] { paramIntent.toUri(0), aa.aG(20) });
      paramIntent = paramContext.iterator();
      if (paramIntent.hasNext())
      {
        paramContext = ((ResolveInfo)paramIntent.next()).serviceInfo.name;
        return null;
      }
    }
    return ((ResolveInfo)paramContext.get(0)).serviceInfo;
  }

  private static int getLogLevel()
  {
    if (Zp == null);
    try
    {
      if (u.hH());
      for (int i = ((Integer)c.a.Zr.get()).intValue(); ; i = d.LOG_LEVEL_OFF)
      {
        Zp = Integer.valueOf(i);
        return Zp.intValue();
      }
    }
    catch (SecurityException localSecurityException)
    {
      while (true)
        Zp = Integer.valueOf(d.LOG_LEVEL_OFF);
    }
  }

  public static b hj()
  {
    synchronized (XV)
    {
      if (Zi == null)
        Zi = new b();
      return Zi;
    }
  }

  public final void a(Context paramContext, ServiceConnection paramServiceConnection)
  {
    paramContext.unbindService(paramServiceConnection);
    a(paramContext, paramServiceConnection, null, null, 1);
  }

  public final void a(Context paramContext, ServiceConnection paramServiceConnection, String paramString, Intent paramIntent, int paramInt)
  {
    if (!f.WR)
      return;
    String str1 = String.valueOf(Process.myPid() << 32 | System.identityHashCode(paramServiceConnection));
    int i = getLogLevel();
    label46: long l2;
    long l1;
    if ((i == d.LOG_LEVEL_OFF) || (this.Zo == null))
    {
      i = 0;
      if (i == 0)
        break label343;
      l2 = System.currentTimeMillis();
      paramServiceConnection = null;
      if ((getLogLevel() & d.ZA) != 0)
        paramServiceConnection = aa.aG(5);
      l1 = 0L;
      if ((getLogLevel() & d.ZC) != 0)
        l1 = Debug.getNativeHeapAllocatedSize();
      if ((paramInt != 1) && (paramInt != 4))
        break label345;
    }
    for (paramServiceConnection = new ConnectionEvent(l2, paramInt, null, null, null, null, paramServiceConnection, str1, SystemClock.elapsedRealtime(), l1); ; paramServiceConnection = new ConnectionEvent(l2, paramInt, aa.I(paramContext), paramString, paramIntent.processName, paramIntent.name, paramServiceConnection, str1, SystemClock.elapsedRealtime(), l1))
    {
      paramContext.startService(new Intent().setComponent(Zn).putExtra("com.google.android.gms.common.stats.EXTRA_LOG_EVENT", paramServiceConnection));
      return;
      if ((paramInt == 4) || (paramInt == 1))
      {
        if (this.Zo.X(str1))
        {
          i = 1;
          break label46;
        }
        i = 0;
        break label46;
      }
      Object localObject = b(paramContext, paramIntent);
      if (localObject == null)
      {
        String.format("Client %s made an invalid request %s", new Object[] { paramString, paramIntent.toUri(0) });
        i = 0;
        break label46;
      }
      paramServiceConnection = aa.I(paramContext);
      String str2 = ((ServiceInfo)localObject).processName;
      localObject = ((ServiceInfo)localObject).name;
      if ((this.Zj.contains(paramServiceConnection)) || (this.Zk.contains(paramString)) || (this.Zl.contains(str2)) || (this.Zm.contains(localObject)) || ((str2.equals(paramServiceConnection)) && ((i & d.ZB) != 0)))
      {
        i = 0;
        break label46;
      }
      this.Zo.W(str1);
      i = 1;
      break label46;
      label343: break;
      label345: paramIntent = b(paramContext, paramIntent);
    }
  }

  public final boolean a(Context paramContext, Intent paramIntent, ServiceConnection paramServiceConnection, int paramInt)
  {
    return a(paramContext, paramContext.getClass().getName(), paramIntent, paramServiceConnection, paramInt);
  }

  public final boolean a(Context paramContext, String paramString, Intent paramIntent, ServiceConnection paramServiceConnection, int paramInt)
  {
    ComponentName localComponentName = paramIntent.getComponent();
    if ((localComponentName == null) || ((f.WR) && ("com.google.android.gms".equals(localComponentName.getPackageName()))));
    for (boolean bool = false; bool; bool = u.h(paramContext, localComponentName.getPackageName()))
      return false;
    bool = paramContext.bindService(paramIntent, paramServiceConnection, paramInt);
    if (bool)
      a(paramContext, paramServiceConnection, paramString, paramIntent, 2);
    return bool;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.stats.b
 * JD-Core Version:    0.6.2
 */