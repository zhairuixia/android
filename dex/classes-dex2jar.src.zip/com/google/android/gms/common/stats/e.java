package com.google.android.gms.common.stats;

import android.os.SystemClock;
import android.support.v4.d.h;

public final class e
{
  private final long ZD;
  private final int ZE;
  private final h<String, Long> ZF;

  public e()
  {
    this.ZD = 60000L;
    this.ZE = 10;
    this.ZF = new h(10);
  }

  public e(long paramLong)
  {
    this.ZD = paramLong;
    this.ZE = 1024;
    this.ZF = new h();
  }

  public final Long W(String paramString)
  {
    long l2 = SystemClock.elapsedRealtime();
    long l1 = this.ZD;
    while (true)
    {
      int i;
      try
      {
        if (this.ZF.size() >= this.ZE)
        {
          i = this.ZF.size() - 1;
          if (i >= 0)
          {
            if (l2 - ((Long)this.ZF.valueAt(i)).longValue() <= l1)
              break label135;
            this.ZF.removeAt(i);
            break label135;
          }
          l1 /= 2L;
          new StringBuilder("The max capacity ").append(this.ZE).append(" is not enough. Current durationThreshold is: ").append(l1);
          continue;
        }
        paramString = (Long)this.ZF.put(paramString, Long.valueOf(l2));
        return paramString;
      }
      finally
      {
      }
      label135: i -= 1;
    }
  }

  public final boolean X(String paramString)
  {
    while (true)
    {
      try
      {
        if (this.ZF.remove(paramString) != null)
        {
          bool = true;
          return bool;
        }
      }
      finally
      {
      }
      boolean bool = false;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.stats.e
 * JD-Core Version:    0.6.2
 */