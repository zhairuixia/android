package com.google.android.gms.common;

import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import com.google.android.gms.common.internal.w;

public final class a extends DialogFragment
{
  private DialogInterface.OnCancelListener Tf = null;
  private Dialog ct = null;

  public static a a(Dialog paramDialog, DialogInterface.OnCancelListener paramOnCancelListener)
  {
    a locala = new a();
    paramDialog = (Dialog)w.e(paramDialog, "Cannot display null dialog");
    paramDialog.setOnCancelListener(null);
    paramDialog.setOnDismissListener(null);
    locala.ct = paramDialog;
    if (paramOnCancelListener != null)
      locala.Tf = paramOnCancelListener;
    return locala;
  }

  public final void onCancel(DialogInterface paramDialogInterface)
  {
    if (this.Tf != null)
      this.Tf.onCancel(paramDialogInterface);
  }

  public final Dialog onCreateDialog(Bundle paramBundle)
  {
    if (this.ct == null)
      setShowsDialog(false);
    return this.ct;
  }

  public final void show(FragmentManager paramFragmentManager, String paramString)
  {
    super.show(paramFragmentManager, paramString);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.a
 * JD-Core Version:    0.6.2
 */