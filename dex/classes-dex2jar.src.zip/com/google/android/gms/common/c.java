package com.google.android.gms.common;

public final class c extends Exception
{
  public final int errorCode;

  public c(int paramInt)
  {
    this.errorCode = paramInt;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.c
 * JD-Core Version:    0.6.2
 */