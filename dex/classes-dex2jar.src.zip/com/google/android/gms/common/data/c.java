package com.google.android.gms.common.data;

public abstract interface c<T>
{
  public abstract T gz();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.data.c
 * JD-Core Version:    0.6.2
 */