package com.google.android.gms.common.data;

import com.google.android.gms.common.internal.w;
import java.util.Iterator;
import java.util.NoSuchElementException;

public final class e<T>
  implements Iterator<T>
{
  protected final b<T> VW;
  protected int VX;

  public e(b<T> paramb)
  {
    this.VW = ((b)w.W(paramb));
    this.VX = -1;
  }

  public final boolean hasNext()
  {
    return this.VX < this.VW.getCount() - 1;
  }

  public final T next()
  {
    if (!hasNext())
      throw new NoSuchElementException("Cannot advance the iterator beyond " + this.VX);
    b localb = this.VW;
    int i = this.VX + 1;
    this.VX = i;
    return localb.get(i);
  }

  public final void remove()
  {
    throw new UnsupportedOperationException("Cannot remove elements from a DataBufferIterator");
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.data.e
 * JD-Core Version:    0.6.2
 */