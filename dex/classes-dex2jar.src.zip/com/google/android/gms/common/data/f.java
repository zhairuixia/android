package com.google.android.gms.common.data;

import android.database.CursorWindow;
import android.os.Bundle;
import com.google.android.gms.common.internal.v;
import com.google.android.gms.common.internal.w;
import java.util.Arrays;

public abstract class f
{
  public final DataHolder VC;
  public int VY;
  private int VZ;

  public f(DataHolder paramDataHolder, int paramInt)
  {
    this.VC = ((DataHolder)w.W(paramDataHolder));
    if ((paramInt >= 0) && (paramInt < this.VC.VN));
    for (boolean bool = true; ; bool = false)
    {
      w.P(bool);
      this.VY = paramInt;
      this.VZ = this.VC.az(this.VY);
      return;
    }
  }

  public boolean equals(Object paramObject)
  {
    boolean bool2 = false;
    boolean bool1 = bool2;
    if ((paramObject instanceof f))
    {
      paramObject = (f)paramObject;
      bool1 = bool2;
      if (v.c(Integer.valueOf(paramObject.VY), Integer.valueOf(this.VY)))
      {
        bool1 = bool2;
        if (v.c(Integer.valueOf(paramObject.VZ), Integer.valueOf(this.VZ)))
        {
          bool1 = bool2;
          if (paramObject.VC == this.VC)
            bool1 = true;
        }
      }
    }
    return bool1;
  }

  public final byte[] getByteArray(String paramString)
  {
    DataHolder localDataHolder = this.VC;
    int i = this.VY;
    int j = this.VZ;
    localDataHolder.f(paramString, i);
    return localDataHolder.VK[j].getBlob(i, localDataHolder.VJ.getInt(paramString));
  }

  public final int getInteger(String paramString)
  {
    DataHolder localDataHolder = this.VC;
    int i = this.VY;
    int j = this.VZ;
    localDataHolder.f(paramString, i);
    return localDataHolder.VK[j].getInt(i, localDataHolder.VJ.getInt(paramString));
  }

  public final String getString(String paramString)
  {
    return this.VC.b(paramString, this.VY, this.VZ);
  }

  public int hashCode()
  {
    return Arrays.hashCode(new Object[] { Integer.valueOf(this.VY), Integer.valueOf(this.VZ), this.VC });
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.data.f
 * JD-Core Version:    0.6.2
 */