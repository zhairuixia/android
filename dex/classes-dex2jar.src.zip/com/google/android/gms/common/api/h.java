package com.google.android.gms.common.api;

public abstract interface h<R extends g>
{
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.h
 * JD-Core Version:    0.6.2
 */