package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class t
  implements Parcelable.Creator<Status>
{
  static void a(Status paramStatus, Parcel paramParcel, int paramInt)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramStatus.Td);
    b.c(paramParcel, 1000, paramStatus.mVersionCode);
    b.a(paramParcel, 2, paramStatus.TV);
    b.a(paramParcel, 3, paramStatus.Te, paramInt);
    b.u(paramParcel, i);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.t
 * JD-Core Version:    0.6.2
 */