package com.google.android.gms.common.api;

import android.accounts.Account;
import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.k;
import android.util.SparseArray;
import android.view.View;
import com.google.android.gms.c.m;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.h;
import com.google.android.gms.common.internal.h.a;
import com.google.android.gms.common.internal.w;
import com.google.android.gms.signin.d;
import com.google.android.gms.signin.e;
import com.google.android.gms.signin.e.a;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public abstract interface c
{
  public abstract ConnectionResult a(TimeUnit paramTimeUnit);

  public abstract <A extends a.b, R extends g, T extends k.a<R, A>> T a(T paramT);

  public abstract void a(b paramb);

  public abstract void a(c paramc);

  public abstract void a(String paramString, PrintWriter paramPrintWriter);

  public abstract void b(b paramb);

  public abstract void b(c paramc);

  public abstract void connect();

  public abstract void disconnect();

  public abstract Looper getLooper();

  public abstract boolean isConnected();

  public abstract boolean isConnecting();

  public static final class a
  {
    private Account RZ;
    public final Map<a<?>, Object> TA = new m();
    public FragmentActivity TB;
    public int TC = -1;
    public int TD = -1;
    public c.c TE;
    public Looper TF;
    public com.google.android.gms.common.b TG = com.google.android.gms.common.b.fQ();
    public a.a<? extends d, e> TH = com.google.android.gms.signin.b.akv;
    public final ArrayList<c.b> TI = new ArrayList();
    public final ArrayList<c.c> TJ = new ArrayList();
    private e.a TK = new e.a();
    public final Set<Scope> Tu = new HashSet();
    private int Tv;
    private View Tw;
    private String Tx;
    private String Ty;
    private final Map<a<?>, h.a> Tz = new m();
    public final Context mContext;

    public a(Context paramContext)
    {
      this.mContext = paramContext;
      this.TF = paramContext.getMainLooper();
      this.Tx = paramContext.getPackageName();
      this.Ty = paramContext.getClass().getName();
    }

    public final void a(u paramu, c paramc)
    {
      int i = this.TC;
      Object localObject = this.TE;
      w.e(paramc, "GoogleApiClient instance cannot be null");
      if (paramu.Vs.indexOfKey(i) < 0);
      for (boolean bool = true; ; bool = false)
      {
        w.a(bool, "Already managing a GoogleApiClient with id " + i);
        localObject = new u.a(paramu, i, paramc, (c.c)localObject);
        paramu.Vs.put(i, localObject);
        if ((paramu.fi) && (!paramu.Vo))
          paramc.connect();
        return;
      }
    }

    public final h gb()
    {
      return new h(this.RZ, this.Tu, this.Tz, this.Tv, this.Tw, this.Tx, this.Ty, this.TK.iw());
    }
  }

  public static abstract interface b
  {
    public abstract void av(int paramInt);

    public abstract void g(Bundle paramBundle);
  }

  public static abstract interface c
  {
    public abstract void a(ConnectionResult paramConnectionResult);
  }

  public static abstract interface d
  {
    public abstract a gd();

    public abstract boolean ge();

    public static final class a
    {
      public boolean TN;
      public Set<Scope> TO;
    }
  }

  public static abstract interface e
  {
    public abstract void b(ConnectionResult paramConnectionResult);

    public abstract void c(ConnectionResult paramConnectionResult);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.c
 * JD-Core Version:    0.6.2
 */