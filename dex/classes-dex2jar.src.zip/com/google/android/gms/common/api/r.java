package com.google.android.gms.common.api;

public final class r<L>
{
  volatile L Vn;
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.r
 * JD-Core Version:    0.6.2
 */