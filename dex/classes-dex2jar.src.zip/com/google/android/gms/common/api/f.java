package com.google.android.gms.common.api;

public abstract interface f
{
  public abstract void release();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.f
 * JD-Core Version:    0.6.2
 */