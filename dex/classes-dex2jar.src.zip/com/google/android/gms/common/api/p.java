package com.google.android.gms.common.api;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;

public abstract interface p
{
  public abstract <A extends a.b, R extends g, T extends k.a<R, A>> T a(T paramT);

  public abstract void a(ConnectionResult paramConnectionResult, a<?> parama, int paramInt);

  public abstract void av(int paramInt);

  public abstract void begin();

  public abstract void connect();

  public abstract void disconnect();

  public abstract void g(Bundle paramBundle);

  public abstract String getName();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.p
 * JD-Core Version:    0.6.2
 */