package com.google.android.gms.common.api;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public abstract class q
{
  private static final ExecutorService Vm = Executors.newFixedThreadPool(2);

  public static ExecutorService gv()
  {
    return Vm;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.q
 * JD-Core Version:    0.6.2
 */