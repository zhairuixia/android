package com.google.android.gms.common.api;

public abstract interface g
{
  public abstract Status gg();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.g
 * JD-Core Version:    0.6.2
 */