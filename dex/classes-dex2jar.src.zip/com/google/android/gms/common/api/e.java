package com.google.android.gms.common.api;

import java.util.concurrent.TimeUnit;

public abstract interface e<R extends g>
{
  public abstract R b(TimeUnit paramTimeUnit);

  public abstract R gf();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.e
 * JD-Core Version:    0.6.2
 */