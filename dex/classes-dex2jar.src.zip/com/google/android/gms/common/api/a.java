package com.google.android.gms.common.api;

import android.content.Context;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.internal.h;
import com.google.android.gms.common.internal.p;
import com.google.android.gms.common.internal.w;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.List;
import java.util.Set;

public final class a<O>
{
  private final a<?, O> Tq;
  final e<?, O> Tr;
  private final c<?> Ts;
  final f<?> Tt;
  final String mName;

  public <C extends b> a(String paramString, a<C, O> parama, c<C> paramc)
  {
    w.e(parama, "Cannot construct an Api with a null ClientBuilder");
    w.e(paramc, "Cannot construct an Api with a null ClientKey");
    this.mName = paramString;
    this.Tq = parama;
    this.Tr = null;
    this.Ts = paramc;
    this.Tt = null;
  }

  public final a<?, O> fR()
  {
    if (this.Tq != null);
    for (boolean bool = true; ; bool = false)
    {
      w.a(bool, "This API was constructed with a SimpleClientBuilder. Use getSimpleClientBuilder");
      return this.Tq;
    }
  }

  public final c<?> fS()
  {
    if (this.Ts != null);
    for (boolean bool = true; ; bool = false)
    {
      w.a(bool, "This API was constructed with a SimpleClientKey. Use getSimpleClientKey");
      return this.Ts;
    }
  }

  public static abstract class a<T extends a.b, O>
  {
    public abstract T a(Context paramContext, Looper paramLooper, h paramh, O paramO, c.b paramb, c.c paramc);

    public List<Scope> fT()
    {
      return Collections.emptyList();
    }
  }

  public static abstract interface b
  {
    public abstract void a(c.e parame);

    public abstract void a(p paramp);

    public abstract void a(p paramp, Set<Scope> paramSet);

    public abstract void a(String paramString, PrintWriter paramPrintWriter);

    public abstract void disconnect();

    public abstract boolean fU();

    public abstract boolean fV();

    public abstract boolean isConnected();
  }

  public static final class c<C extends a.b>
  {
  }

  public static abstract interface d<T extends IInterface>
  {
    public abstract String fW();

    public abstract String fX();

    public abstract T fY();
  }

  public static abstract interface e<T extends a.d, O>
  {
    public abstract T fZ();

    public abstract int ga();
  }

  public static final class f<C extends a.d>
  {
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.a
 * JD-Core Version:    0.6.2
 */