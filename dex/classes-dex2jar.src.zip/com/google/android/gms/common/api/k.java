package com.google.android.gms.common.api;

import android.os.DeadObjectException;
import android.os.RemoteException;
import com.google.android.gms.common.internal.w;
import java.util.concurrent.atomic.AtomicReference;

public final class k
{
  public static abstract class a<R extends g, A extends a.b> extends i<R>
    implements k.b<R>, o.e<A>
  {
    final a.c<A> Ts;
    private AtomicReference<o.d> Ug = new AtomicReference();

    public a(a.c<A> paramc, c paramc1)
    {
      super();
      this.Ts = ((a.c)w.W(paramc));
    }

    private void a(RemoteException paramRemoteException)
    {
      c(new Status(paramRemoteException.getLocalizedMessage()));
    }

    public final void a(A paramA)
    {
      try
      {
        b(paramA);
        return;
      }
      catch (DeadObjectException paramA)
      {
        a(paramA);
        throw paramA;
      }
      catch (RemoteException paramA)
      {
        a(paramA);
      }
    }

    public final void a(o.d paramd)
    {
      this.Ug.set(paramd);
    }

    public abstract void b(A paramA);

    public final void c(Status paramStatus)
    {
      if (!paramStatus.fP());
      for (boolean bool = true; ; bool = false)
      {
        w.b(bool, "Failed result must not be success");
        a(b(paramStatus));
        return;
      }
    }

    public final a.c<A> fS()
    {
      return this.Ts;
    }

    protected final void gi()
    {
      o.d locald = (o.d)this.Ug.getAndSet(null);
      if (locald != null)
        locald.b(this);
    }
  }

  public static abstract interface b<R>
  {
    public abstract void S(R paramR);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.common.api.k
 * JD-Core Version:    0.6.2
 */