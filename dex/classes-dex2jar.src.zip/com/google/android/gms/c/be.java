package com.google.android.gms.c;

import java.io.IOException;
import java.nio.ByteBuffer;

public abstract class be
{
  protected volatile int ajK = -1;

  public static final <T extends be> T a(T paramT, byte[] paramArrayOfByte, int paramInt)
  {
    try
    {
      paramArrayOfByte = new aw(paramArrayOfByte, 0, paramInt);
      paramT.a(paramArrayOfByte);
      paramArrayOfByte.aH(0);
      return paramT;
    }
    catch (bd paramT)
    {
      throw paramT;
    }
    catch (IOException paramT)
    {
    }
    throw new RuntimeException("Reading from a byte array threw an IOException (should never happen).");
  }

  public static final byte[] c(be parambe)
  {
    byte[] arrayOfByte = new byte[parambe.iu()];
    int i = arrayOfByte.length;
    try
    {
      ax localax = ax.b(arrayOfByte, 0, i);
      parambe.a(localax);
      if (localax.ajy.remaining() != 0)
        throw new IllegalStateException("Did not write as much data as expected.");
    }
    catch (IOException parambe)
    {
      throw new RuntimeException("Serializing to a byte array threw an IOException (should never happen).", parambe);
    }
    return arrayOfByte;
  }

  public abstract be a(aw paramaw);

  public void a(ax paramax)
  {
  }

  protected int hx()
  {
    return 0;
  }

  public be ij()
  {
    return (be)super.clone();
  }

  public final int it()
  {
    if (this.ajK < 0)
      iu();
    return this.ajK;
  }

  public final int iu()
  {
    int i = hx();
    this.ajK = i;
    return i;
  }

  public String toString()
  {
    return bf.d(this);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.c.be
 * JD-Core Version:    0.6.2
 */