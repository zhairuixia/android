package com.google.android.gms.c;

public final class bh
{
  public static final int[] ajM = new int[0];
  public static final long[] ajN = new long[0];
  public static final float[] ajO = new float[0];
  public static final double[] ajP = new double[0];
  public static final boolean[] ajQ = new boolean[0];
  public static final String[] ajR = new String[0];
  public static final byte[][] ajS = new byte[0][];
  public static final byte[] ajT = new byte[0];

  static int aW(int paramInt)
  {
    return paramInt & 0x7;
  }

  public static int aX(int paramInt)
  {
    return paramInt >>> 3;
  }

  public static final int b(aw paramaw, int paramInt)
  {
    int i = 1;
    int j = paramaw.getPosition();
    paramaw.aI(paramInt);
    while (paramaw.hY() == paramInt)
    {
      paramaw.aI(paramInt);
      i += 1;
    }
    paramaw.aL(j);
    return i;
  }

  static int w(int paramInt1, int paramInt2)
  {
    return paramInt1 << 3 | paramInt2;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.c.bh
 * JD-Core Version:    0.6.2
 */