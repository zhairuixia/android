package com.google.android.gms.c;

import android.os.Binder;

public abstract class j<T>
{
  private static final Object NV = new Object();
  static a agT = null;
  private static int agU = 0;
  private static String agV = "com.google.android.providers.gsf.permission.READ_GSERVICES";
  private T RL = null;
  protected final String agW;
  protected final T agX;

  protected j(String paramString, T paramT)
  {
    this.agW = paramString;
    this.agX = paramT;
  }

  public static j<Float> a(String paramString, Float paramFloat)
  {
    return new j(paramString, paramFloat)
    {
    };
  }

  public static j<Integer> a(String paramString, Integer paramInteger)
  {
    return new j(paramString, paramInteger)
    {
    };
  }

  public static j<Long> a(String paramString, Long paramLong)
  {
    return new j(paramString, paramLong)
    {
    };
  }

  public static j<Boolean> d(String paramString, boolean paramBoolean)
  {
    return new j(paramString, Boolean.valueOf(paramBoolean))
    {
    };
  }

  public static j<String> h(String paramString1, String paramString2)
  {
    return new j(paramString1, paramString2)
    {
    };
  }

  public static int hy()
  {
    return agU;
  }

  public static boolean isInitialized()
  {
    return agT != null;
  }

  public final T get()
  {
    if (this.RL != null)
      return this.RL;
    return hz();
  }

  public final T hA()
  {
    long l = Binder.clearCallingIdentity();
    try
    {
      Object localObject1 = get();
      return localObject1;
    }
    finally
    {
      Binder.restoreCallingIdentity(l);
    }
  }

  protected abstract T hz();

  private static abstract interface a
  {
    public abstract Boolean hB();

    public abstract Long hC();

    public abstract Integer hD();

    public abstract Float hE();

    public abstract String hF();
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.c.j
 * JD-Core Version:    0.6.2
 */