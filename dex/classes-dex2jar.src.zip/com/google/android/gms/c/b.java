package com.google.android.gms.c;

public abstract interface b
{
  public static final class a extends ay<a>
  {
    private static volatile a[] afA;
    public String afB = "";
    public a[] afC = hw();
    public a[] afD = hw();
    public a[] afE = hw();
    public String afF = "";
    public String afG = "";
    public long afH = 0L;
    public boolean afI = false;
    public a[] afJ = hw();
    public int[] afK = bh.ajM;
    public boolean afL = false;
    public int type = 1;

    public a()
    {
      this.ajz = null;
      this.ajK = -1;
    }

    private static a[] hw()
    {
      if (afA == null);
      synchronized (bc.ajJ)
      {
        if (afA == null)
          afA = new a[0];
        return afA;
      }
    }

    public final void a(ax paramax)
    {
      int j = 0;
      paramax.t(1, this.type);
      if (!this.afB.equals(""))
        paramax.c(2, this.afB);
      int i;
      a locala;
      if ((this.afC != null) && (this.afC.length > 0))
      {
        i = 0;
        while (i < this.afC.length)
        {
          locala = this.afC[i];
          if (locala != null)
            paramax.a(3, locala);
          i += 1;
        }
      }
      if ((this.afD != null) && (this.afD.length > 0))
      {
        i = 0;
        while (i < this.afD.length)
        {
          locala = this.afD[i];
          if (locala != null)
            paramax.a(4, locala);
          i += 1;
        }
      }
      if ((this.afE != null) && (this.afE.length > 0))
      {
        i = 0;
        while (i < this.afE.length)
        {
          locala = this.afE[i];
          if (locala != null)
            paramax.a(5, locala);
          i += 1;
        }
      }
      if (!this.afF.equals(""))
        paramax.c(6, this.afF);
      if (!this.afG.equals(""))
        paramax.c(7, this.afG);
      if (this.afH != 0L)
        paramax.c(8, this.afH);
      if (this.afL)
        paramax.m(9, this.afL);
      if ((this.afK != null) && (this.afK.length > 0))
      {
        i = 0;
        while (i < this.afK.length)
        {
          paramax.t(10, this.afK[i]);
          i += 1;
        }
      }
      if ((this.afJ != null) && (this.afJ.length > 0))
      {
        i = j;
        while (i < this.afJ.length)
        {
          locala = this.afJ[i];
          if (locala != null)
            paramax.a(11, locala);
          i += 1;
        }
      }
      if (this.afI)
        paramax.m(12, this.afI);
      super.a(paramax);
    }

    public final boolean equals(Object paramObject)
    {
      boolean bool2 = false;
      boolean bool1;
      if (paramObject == this)
        bool1 = true;
      label54: label118: 
      do
      {
        do
        {
          do
          {
            do
            {
              do
              {
                do
                {
                  do
                  {
                    do
                    {
                      return bool1;
                      bool1 = bool2;
                    }
                    while (!(paramObject instanceof a));
                    paramObject = (a)paramObject;
                    bool1 = bool2;
                  }
                  while (this.type != paramObject.type);
                  if (this.afB != null)
                    break;
                  bool1 = bool2;
                }
                while (paramObject.afB != null);
                bool1 = bool2;
              }
              while (!bc.equals(this.afC, paramObject.afC));
              bool1 = bool2;
            }
            while (!bc.equals(this.afD, paramObject.afD));
            bool1 = bool2;
          }
          while (!bc.equals(this.afE, paramObject.afE));
          if (this.afF != null)
            break label228;
          bool1 = bool2;
        }
        while (paramObject.afF != null);
        if (this.afG != null)
          break label244;
        bool1 = bool2;
      }
      while (paramObject.afG != null);
      label228: label244: 
      while (this.afG.equals(paramObject.afG))
      {
        bool1 = bool2;
        if (this.afH != paramObject.afH)
          break;
        bool1 = bool2;
        if (this.afI != paramObject.afI)
          break;
        bool1 = bool2;
        if (!bc.equals(this.afJ, paramObject.afJ))
          break;
        bool1 = bool2;
        if (!bc.equals(this.afK, paramObject.afK))
          break;
        bool1 = bool2;
        if (this.afL != paramObject.afL)
          break;
        return a(paramObject);
        if (this.afB.equals(paramObject.afB))
          break label54;
        return false;
        if (this.afF.equals(paramObject.afF))
          break label118;
        return false;
      }
      return false;
    }

    public final int hashCode()
    {
      int n = 1231;
      int k = 0;
      int i1 = this.type;
      int i;
      int i2;
      int i3;
      int i4;
      int j;
      label58: label65: int i5;
      int m;
      label92: int i6;
      int i7;
      if (this.afB == null)
      {
        i = 0;
        i2 = bc.hashCode(this.afC);
        i3 = bc.hashCode(this.afD);
        i4 = bc.hashCode(this.afE);
        if (this.afF != null)
          break label206;
        j = 0;
        if (this.afG != null)
          break label217;
        i5 = (int)(this.afH ^ this.afH >>> 32);
        if (!this.afI)
          break label228;
        m = 1231;
        i6 = bc.hashCode(this.afJ);
        i7 = bc.hashCode(this.afK);
        if (!this.afL)
          break label236;
      }
      while (true)
      {
        return ((((m + (((j + ((((i + (i1 + 527) * 31) * 31 + i2) * 31 + i3) * 31 + i4) * 31) * 31 + k) * 31 + i5) * 31) * 31 + i6) * 31 + i7) * 31 + n) * 31 + ih();
        i = this.afB.hashCode();
        break;
        label206: j = this.afF.hashCode();
        break label58;
        label217: k = this.afG.hashCode();
        break label65;
        label228: m = 1237;
        break label92;
        label236: n = 1237;
      }
    }

    protected final int hx()
    {
      int m = 0;
      int j = super.hx() + ax.u(1, this.type);
      int i = j;
      if (!this.afB.equals(""))
        i = j + ax.d(2, this.afB);
      j = i;
      a locala;
      int k;
      if (this.afC != null)
      {
        j = i;
        if (this.afC.length > 0)
        {
          j = 0;
          while (j < this.afC.length)
          {
            locala = this.afC[j];
            k = i;
            if (locala != null)
              k = i + ax.b(3, locala);
            j += 1;
            i = k;
          }
          j = i;
        }
      }
      i = j;
      if (this.afD != null)
      {
        i = j;
        if (this.afD.length > 0)
        {
          i = j;
          j = 0;
          while (j < this.afD.length)
          {
            locala = this.afD[j];
            k = i;
            if (locala != null)
              k = i + ax.b(4, locala);
            j += 1;
            i = k;
          }
        }
      }
      j = i;
      if (this.afE != null)
      {
        j = i;
        if (this.afE.length > 0)
        {
          j = 0;
          while (j < this.afE.length)
          {
            locala = this.afE[j];
            k = i;
            if (locala != null)
              k = i + ax.b(5, locala);
            j += 1;
            i = k;
          }
          j = i;
        }
      }
      i = j;
      if (!this.afF.equals(""))
        i = j + ax.d(6, this.afF);
      j = i;
      if (!this.afG.equals(""))
        j = i + ax.d(7, this.afG);
      i = j;
      if (this.afH != 0L)
        i = j + ax.d(8, this.afH);
      j = i;
      if (this.afL)
        j = i + (ax.aQ(9) + 1);
      i = j;
      if (this.afK != null)
      {
        i = j;
        if (this.afK.length > 0)
        {
          i = 0;
          k = 0;
          while (i < this.afK.length)
          {
            k += ax.aO(this.afK[i]);
            i += 1;
          }
          i = j + k + this.afK.length * 1;
        }
      }
      j = i;
      if (this.afJ != null)
      {
        j = i;
        if (this.afJ.length > 0)
        {
          k = m;
          while (true)
          {
            j = i;
            if (k >= this.afJ.length)
              break;
            locala = this.afJ[k];
            j = i;
            if (locala != null)
              j = i + ax.b(11, locala);
            k += 1;
            i = j;
          }
        }
      }
      i = j;
      if (this.afI)
        i = j + (ax.aQ(12) + 1);
      return i;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.c.b
 * JD-Core Version:    0.6.2
 */