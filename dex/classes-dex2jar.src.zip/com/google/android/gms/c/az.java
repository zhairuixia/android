package com.google.android.gms.c;

import java.io.IOException;
import java.lang.reflect.Array;

public final class az<M extends ay<M>, T>
{
  protected final Class<T> ajA;
  protected final boolean ajB;
  public final int tag;
  protected final int type;

  private int ab(Object paramObject)
  {
    int i = bh.aX(this.tag);
    switch (this.type)
    {
    default:
      throw new IllegalArgumentException("Unknown type " + this.type);
    case 10:
      paramObject = (be)paramObject;
      return ax.aQ(i) * 2 + paramObject.iu();
    case 11:
    }
    return ax.b(i, (be)paramObject);
  }

  private void b(Object paramObject, ax paramax)
  {
    while (true)
    {
      try
      {
        paramax.aR(this.tag);
        switch (this.type)
        {
        case 10:
          throw new IllegalArgumentException("Unknown type " + this.type);
        case 11:
        }
      }
      catch (IOException paramObject)
      {
        throw new IllegalStateException(paramObject);
      }
      paramObject = (be)paramObject;
      int i = bh.aX(this.tag);
      paramObject.a(paramax);
      paramax.v(i, 4);
      return;
      paramax.b((be)paramObject);
      return;
    }
  }

  final void a(Object paramObject, ax paramax)
  {
    if (this.ajB)
    {
      int j = Array.getLength(paramObject);
      int i = 0;
      while (i < j)
      {
        Object localObject = Array.get(paramObject, i);
        if (localObject != null)
          b(localObject, paramax);
        i += 1;
      }
    }
    b(paramObject, paramax);
  }

  final int aa(Object paramObject)
  {
    int i = 0;
    if (this.ajB)
    {
      int m = Array.getLength(paramObject);
      int j = 0;
      while (true)
      {
        k = i;
        if (j >= m)
          break;
        k = i;
        if (Array.get(paramObject, j) != null)
          k = i + ab(Array.get(paramObject, j));
        j += 1;
        i = k;
      }
    }
    int k = ab(paramObject);
    return k;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.c.az
 * JD-Core Version:    0.6.2
 */