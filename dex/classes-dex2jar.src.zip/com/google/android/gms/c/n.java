package com.google.android.gms.c;

public final class n
{
  public static final int[] iZ = new int[0];
  public static final long[] ja = new long[0];
  public static final Object[] jb = new Object[0];

  public static int a(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    int i = paramInt1 - 1;
    paramInt1 = 0;
    while (paramInt1 <= i)
    {
      int j = paramInt1 + i >>> 1;
      int k = paramArrayOfInt[j];
      if (k < paramInt2)
      {
        paramInt1 = j + 1;
      }
      else
      {
        i = j;
        if (k <= paramInt2)
          break label59;
        i = j - 1;
      }
    }
    i = paramInt1 ^ 0xFFFFFFFF;
    label59: return i;
  }

  public static boolean c(Object paramObject1, Object paramObject2)
  {
    return (paramObject1 == paramObject2) || ((paramObject1 != null) && (paramObject1.equals(paramObject2)));
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.c.n
 * JD-Core Version:    0.6.2
 */