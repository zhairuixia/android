package com.google.android.gms.c;

import android.content.Context;
import android.content.pm.PackageManager;
import java.util.regex.Pattern;

public final class t
{
  private static Pattern ahm = null;

  public static boolean H(Context paramContext)
  {
    return paramContext.getPackageManager().hasSystemFeature("android.hardware.type.watch");
  }

  public static int aD(int paramInt)
  {
    return paramInt / 1000;
  }

  public static boolean aE(int paramInt)
  {
    return paramInt % 1000 / 100 == 3;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.c.t
 * JD-Core Version:    0.6.2
 */