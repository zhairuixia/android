package com.google.android.gms.c;

import android.os.Build.VERSION;

public final class z
{
  public static boolean aF(int paramInt)
  {
    return Build.VERSION.SDK_INT >= paramInt;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.c.z
 * JD-Core Version:    0.6.2
 */