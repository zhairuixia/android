package com.google.android.gms.c;

final class ba
  implements Cloneable
{
  static final bb ajC = new bb();
  boolean ajD = false;
  int[] ajE;
  bb[] ajF;
  int jh;

  public ba()
  {
    this(10);
  }

  private ba(int paramInt)
  {
    paramInt = q(paramInt);
    this.ajE = new int[paramInt];
    this.ajF = new bb[paramInt];
    this.jh = 0;
  }

  static int q(int paramInt)
  {
    int j = paramInt * 4;
    paramInt = 4;
    while (true)
    {
      int i = j;
      if (paramInt < 32)
      {
        if (j <= (1 << paramInt) - 12)
          i = (1 << paramInt) - 12;
      }
      else
        return i / 4;
      paramInt += 1;
    }
  }

  public final bb aU(int paramInt)
  {
    if (this.ajD)
      gc();
    return this.ajF[paramInt];
  }

  final int aV(int paramInt)
  {
    int j = this.jh;
    int i = 0;
    j -= 1;
    while (i <= j)
    {
      int k = i + j >>> 1;
      int m = this.ajE[k];
      if (m < paramInt)
      {
        i = k + 1;
      }
      else
      {
        j = k;
        if (m <= paramInt)
          break label67;
        j = k - 1;
      }
    }
    j = i ^ 0xFFFFFFFF;
    label67: return j;
  }

  public final boolean equals(Object paramObject)
  {
    if (paramObject == this);
    label131: label138: label141: 
    while (true)
    {
      return true;
      if (!(paramObject instanceof ba))
        return false;
      paramObject = (ba)paramObject;
      if (size() != paramObject.size())
        return false;
      Object localObject = this.ajE;
      int[] arrayOfInt = paramObject.ajE;
      int j = this.jh;
      int i = 0;
      if (i < j)
        if (localObject[i] != arrayOfInt[i])
        {
          i = 0;
          label71: if (i != 0)
          {
            localObject = this.ajF;
            paramObject = paramObject.ajF;
            j = this.jh;
            i = 0;
            label93: if (i >= j)
              break label138;
            if (localObject[i].equals(paramObject[i]))
              break label131;
          }
        }
      for (i = 0; ; i = 1)
      {
        if (i != 0)
          break label141;
        return false;
        i += 1;
        break;
        i = 1;
        break label71;
        i += 1;
        break label93;
      }
    }
  }

  final void gc()
  {
    int m = this.jh;
    int[] arrayOfInt = this.ajE;
    bb[] arrayOfbb = this.ajF;
    int i = 0;
    int k;
    for (int j = 0; i < m; j = k)
    {
      bb localbb = arrayOfbb[i];
      k = j;
      if (localbb != ajC)
      {
        if (i != j)
        {
          arrayOfInt[j] = arrayOfInt[i];
          arrayOfbb[j] = localbb;
          arrayOfbb[i] = null;
        }
        k = j + 1;
      }
      i += 1;
    }
    this.ajD = false;
    this.jh = j;
  }

  public final int hashCode()
  {
    if (this.ajD)
      gc();
    int j = 17;
    int i = 0;
    while (i < this.jh)
    {
      j = (j * 31 + this.ajE[i]) * 31 + this.ajF[i].hashCode();
      i += 1;
    }
    return j;
  }

  public final ba ik()
  {
    int i = 0;
    int j = size();
    ba localba = new ba(j);
    System.arraycopy(this.ajE, 0, localba.ajE, 0, j);
    while (i < j)
    {
      if (this.ajF[i] != null)
        localba.ajF[i] = this.ajF[i].il();
      i += 1;
    }
    localba.jh = j;
    return localba;
  }

  public final boolean isEmpty()
  {
    return size() == 0;
  }

  public final int size()
  {
    if (this.ajD)
      gc();
    return this.jh;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.c.ba
 * JD-Core Version:    0.6.2
 */