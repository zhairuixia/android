package com.google.android.gms.c;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

final class bb
  implements Cloneable
{
  private az<?, ?> ajG;
  private Object ajH;
  List<bg> ajI = new ArrayList();

  private byte[] toByteArray()
  {
    byte[] arrayOfByte = new byte[hx()];
    a(ax.b(arrayOfByte, 0, arrayOfByte.length));
    return arrayOfByte;
  }

  final void a(ax paramax)
  {
    if (this.ajH != null)
      this.ajG.a(this.ajH, paramax);
    while (true)
    {
      return;
      Iterator localIterator = this.ajI.iterator();
      while (localIterator.hasNext())
      {
        bg localbg = (bg)localIterator.next();
        paramax.aR(localbg.tag);
        paramax.f(localbg.ajL);
      }
    }
  }

  public final boolean equals(Object paramObject)
  {
    boolean bool2 = false;
    boolean bool1;
    if (paramObject == this)
      bool1 = true;
    do
    {
      do
      {
        return bool1;
        bool1 = bool2;
      }
      while (!(paramObject instanceof bb));
      paramObject = (bb)paramObject;
      if ((this.ajH == null) || (paramObject.ajH == null))
        break;
      bool1 = bool2;
    }
    while (this.ajG != paramObject.ajG);
    if (!this.ajG.ajA.isArray())
      return this.ajH.equals(paramObject.ajH);
    if ((this.ajH instanceof byte[]))
      return Arrays.equals((byte[])this.ajH, (byte[])paramObject.ajH);
    if ((this.ajH instanceof int[]))
      return Arrays.equals((int[])this.ajH, (int[])paramObject.ajH);
    if ((this.ajH instanceof long[]))
      return Arrays.equals((long[])this.ajH, (long[])paramObject.ajH);
    if ((this.ajH instanceof float[]))
      return Arrays.equals((float[])this.ajH, (float[])paramObject.ajH);
    if ((this.ajH instanceof double[]))
      return Arrays.equals((double[])this.ajH, (double[])paramObject.ajH);
    if ((this.ajH instanceof boolean[]))
      return Arrays.equals((boolean[])this.ajH, (boolean[])paramObject.ajH);
    return Arrays.deepEquals((Object[])this.ajH, (Object[])paramObject.ajH);
    if ((this.ajI != null) && (paramObject.ajI != null))
      return this.ajI.equals(paramObject.ajI);
    try
    {
      bool1 = Arrays.equals(toByteArray(), paramObject.toByteArray());
      return bool1;
    }
    catch (IOException paramObject)
    {
    }
    throw new IllegalStateException(paramObject);
  }

  public final int hashCode()
  {
    try
    {
      int i = Arrays.hashCode(toByteArray());
      return i + 527;
    }
    catch (IOException localIOException)
    {
      throw new IllegalStateException(localIOException);
    }
  }

  final int hx()
  {
    int j;
    if (this.ajH != null)
    {
      j = this.ajG.aa(this.ajH);
      return j;
    }
    Iterator localIterator = this.ajI.iterator();
    bg localbg;
    for (int i = 0; ; i = localbg.ajL.length + (j + 0) + i)
    {
      j = i;
      if (!localIterator.hasNext())
        break;
      localbg = (bg)localIterator.next();
      j = ax.aS(localbg.tag);
    }
  }

  public final bb il()
  {
    int i = 0;
    bb localbb = new bb();
    try
    {
      localbb.ajG = this.ajG;
      if (this.ajI == null)
        localbb.ajI = null;
      while (true)
      {
        if (this.ajH == null)
          break label383;
        if (!(this.ajH instanceof be))
          break;
        localbb.ajH = ((be)this.ajH).ij();
        return localbb;
        localbb.ajI.addAll(this.ajI);
      }
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      throw new AssertionError(localCloneNotSupportedException);
    }
    if ((this.ajH instanceof byte[]))
    {
      localCloneNotSupportedException.ajH = ((byte[])this.ajH).clone();
      return localCloneNotSupportedException;
    }
    Object localObject1;
    Object localObject2;
    if ((this.ajH instanceof byte[][]))
    {
      localObject1 = (byte[][])this.ajH;
      localObject2 = new byte[localObject1.length][];
      localCloneNotSupportedException.ajH = localObject2;
      i = 0;
      while (i < localObject1.length)
      {
        localObject2[i] = ((byte[])localObject1[i].clone());
        i += 1;
      }
    }
    if ((this.ajH instanceof boolean[]))
    {
      localCloneNotSupportedException.ajH = ((boolean[])this.ajH).clone();
      return localCloneNotSupportedException;
    }
    if ((this.ajH instanceof int[]))
    {
      localCloneNotSupportedException.ajH = ((int[])this.ajH).clone();
      return localCloneNotSupportedException;
    }
    if ((this.ajH instanceof long[]))
    {
      localCloneNotSupportedException.ajH = ((long[])this.ajH).clone();
      return localCloneNotSupportedException;
    }
    if ((this.ajH instanceof float[]))
    {
      localCloneNotSupportedException.ajH = ((float[])this.ajH).clone();
      return localCloneNotSupportedException;
    }
    if ((this.ajH instanceof double[]))
    {
      localCloneNotSupportedException.ajH = ((double[])this.ajH).clone();
      return localCloneNotSupportedException;
    }
    if ((this.ajH instanceof be[]))
    {
      localObject1 = (be[])this.ajH;
      localObject2 = new be[localObject1.length];
      localCloneNotSupportedException.ajH = localObject2;
      while (i < localObject1.length)
      {
        localObject2[i] = localObject1[i].ij();
        i += 1;
      }
    }
    label383: return localCloneNotSupportedException;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.c.bb
 * JD-Core Version:    0.6.2
 */