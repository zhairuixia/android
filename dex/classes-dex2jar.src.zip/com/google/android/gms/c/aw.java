package com.google.android.gms.c;

public final class aw
{
  int ajp;
  int ajq;
  private int ajr;
  int ajs;
  private int ajt;
  private int aju = 2147483647;
  private int ajv;
  private int ajw = 64;
  private int ajx = 67108864;
  final byte[] buffer;

  aw(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this.buffer = paramArrayOfByte;
    this.ajp = 0;
    this.ajq = (paramInt2 + 0);
    this.ajs = 0;
  }

  private void aN(int paramInt)
  {
    if (paramInt < 0)
      throw bd.in();
    if (this.ajs + paramInt > this.aju)
    {
      aN(this.aju - this.ajs);
      throw bd.im();
    }
    if (paramInt <= this.ajq - this.ajs)
    {
      this.ajs += paramInt;
      return;
    }
    throw bd.im();
  }

  private void ie()
  {
    this.ajq += this.ajr;
    int i = this.ajq;
    if (i > this.aju)
    {
      this.ajr = (i - this.aju);
      this.ajq -= this.ajr;
      return;
    }
    this.ajr = 0;
  }

  private byte ig()
  {
    if (this.ajs == this.ajq)
      throw bd.im();
    byte[] arrayOfByte = this.buffer;
    int i = this.ajs;
    this.ajs = (i + 1);
    return arrayOfByte[i];
  }

  public final void a(be parambe)
  {
    int i = ib();
    if (this.ajv >= this.ajw)
      throw bd.is();
    i = aJ(i);
    this.ajv += 1;
    parambe.a(this);
    aH(0);
    this.ajv -= 1;
    aK(i);
  }

  public final void aH(int paramInt)
  {
    if (this.ajt != paramInt)
      throw bd.iq();
  }

  public final boolean aI(int paramInt)
  {
    switch (bh.aW(paramInt))
    {
    default:
      throw bd.ir();
    case 0:
      ib();
      return true;
    case 1:
      id();
      return true;
    case 2:
      aN(ib());
      return true;
    case 3:
      int i;
      do
        i = hY();
      while ((i != 0) && (aI(i)));
      aH(bh.w(bh.aX(paramInt), 4));
      return true;
    case 4:
      return false;
    case 5:
    }
    ic();
    return true;
  }

  public final int aJ(int paramInt)
  {
    if (paramInt < 0)
      throw bd.in();
    paramInt = this.ajs + paramInt;
    int i = this.aju;
    if (paramInt > i)
      throw bd.im();
    this.aju = paramInt;
    ie();
    return i;
  }

  public final void aK(int paramInt)
  {
    this.aju = paramInt;
    ie();
  }

  public final void aL(int paramInt)
  {
    if (paramInt > this.ajs - this.ajp)
      throw new IllegalArgumentException("Position " + paramInt + " is beyond current " + (this.ajs - this.ajp));
    if (paramInt < 0)
      throw new IllegalArgumentException("Bad position " + paramInt);
    this.ajs = (this.ajp + paramInt);
  }

  public final byte[] aM(int paramInt)
  {
    if (paramInt < 0)
      throw bd.in();
    if (this.ajs + paramInt > this.aju)
    {
      aN(this.aju - this.ajs);
      throw bd.im();
    }
    if (paramInt <= this.ajq - this.ajs)
    {
      byte[] arrayOfByte = new byte[paramInt];
      System.arraycopy(this.buffer, this.ajs, arrayOfByte, 0, paramInt);
      this.ajs += paramInt;
      return arrayOfByte;
    }
    throw bd.im();
  }

  public final int getPosition()
  {
    return this.ajs - this.ajp;
  }

  public final int hY()
  {
    if (this.ajs == this.ajq);
    for (int i = 1; i != 0; i = 0)
    {
      this.ajt = 0;
      return 0;
    }
    this.ajt = ib();
    if (this.ajt == 0)
      throw bd.ip();
    return this.ajt;
  }

  public final long hZ()
  {
    int i = 0;
    long l = 0L;
    while (i < 64)
    {
      int j = ig();
      l |= (j & 0x7F) << i;
      if ((j & 0x80) == 0)
        return l;
      i += 7;
    }
    throw bd.io();
  }

  public final boolean ia()
  {
    return ib() != 0;
  }

  public final int ib()
  {
    int i = ig();
    if (i >= 0);
    int k;
    do
    {
      return i;
      i &= 127;
      j = ig();
      if (j >= 0)
        return i | j << 7;
      i |= (j & 0x7F) << 7;
      j = ig();
      if (j >= 0)
        return i | j << 14;
      i |= (j & 0x7F) << 14;
      k = ig();
      if (k >= 0)
        return i | k << 21;
      j = ig();
      k = i | (k & 0x7F) << 21 | j << 28;
      i = k;
    }
    while (j >= 0);
    int j = 0;
    while (true)
    {
      if (j >= 5)
        break label133;
      i = k;
      if (ig() >= 0)
        break;
      j += 1;
    }
    label133: throw bd.io();
  }

  public final int ic()
  {
    return ig() & 0xFF | (ig() & 0xFF) << 8 | (ig() & 0xFF) << 16 | (ig() & 0xFF) << 24;
  }

  public final long id()
  {
    int i = ig();
    int j = ig();
    int k = ig();
    int m = ig();
    int n = ig();
    int i1 = ig();
    int i2 = ig();
    int i3 = ig();
    long l = i;
    return (j & 0xFF) << 8 | l & 0xFF | (k & 0xFF) << 16 | (m & 0xFF) << 24 | (n & 0xFF) << 32 | (i1 & 0xFF) << 40 | (i2 & 0xFF) << 48 | (i3 & 0xFF) << 56;
  }

  public final int jdMethod_if()
  {
    if (this.aju == 2147483647)
      return -1;
    int i = this.ajs;
    return this.aju - i;
  }

  public final String readString()
  {
    int i = ib();
    if ((i <= this.ajq - this.ajs) && (i > 0))
    {
      String str = new String(this.buffer, this.ajs, i, "UTF-8");
      this.ajs = (i + this.ajs);
      return str;
    }
    return new String(aM(i), "UTF-8");
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.c.aw
 * JD-Core Version:    0.6.2
 */