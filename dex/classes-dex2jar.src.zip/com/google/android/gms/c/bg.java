package com.google.android.gms.c;

import java.util.Arrays;

final class bg
{
  final byte[] ajL;
  final int tag;

  bg(int paramInt, byte[] paramArrayOfByte)
  {
    this.tag = paramInt;
    this.ajL = paramArrayOfByte;
  }

  public final boolean equals(Object paramObject)
  {
    if (paramObject == this);
    do
    {
      return true;
      if (!(paramObject instanceof bg))
        return false;
      paramObject = (bg)paramObject;
    }
    while ((this.tag == paramObject.tag) && (Arrays.equals(this.ajL, paramObject.ajL)));
    return false;
  }

  public final int hashCode()
  {
    return (this.tag + 527) * 31 + Arrays.hashCode(this.ajL);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.c.bg
 * JD-Core Version:    0.6.2
 */