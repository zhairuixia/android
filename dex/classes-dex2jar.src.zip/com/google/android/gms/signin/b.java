package com.google.android.gms.signin;

import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.a;
import com.google.android.gms.common.api.a.a;
import com.google.android.gms.common.api.a.c;
import com.google.android.gms.signin.internal.h;
import com.google.android.gms.signin.internal.i;

public final class b
{
  public static final a<Object> akA = new a("SignIn.INTERNAL_API", akw, aku);
  public static final c akB = new h();
  public static final a.c<i> akt = new a.c();
  public static final a.c<i> aku = new a.c();
  public static final a.a<i, e> akv = new a.a()
  {
  };
  static final a.a<i, Object> akw = new a.a()
  {
  };
  public static final Scope akx = new Scope("profile");
  public static final Scope aky = new Scope("email");
  public static final a<e> akz = new a("SignIn.API", akv, akt);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.signin.b
 * JD-Core Version:    0.6.2
 */