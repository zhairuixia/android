package com.google.android.gms.signin;

public abstract interface c
{
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.signin.c
 * JD-Core Version:    0.6.2
 */