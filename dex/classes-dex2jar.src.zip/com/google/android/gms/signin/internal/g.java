package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class g
  implements Parcelable.Creator<RecordConsentRequest>
{
  static void a(RecordConsentRequest paramRecordConsentRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramRecordConsentRequest.mVersionCode);
    b.a(paramParcel, 2, paramRecordConsentRequest.RZ, paramInt);
    b.a(paramParcel, 3, paramRecordConsentRequest.akl, paramInt);
    b.a(paramParcel, 4, paramRecordConsentRequest.SX);
    b.u(paramParcel, i);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.signin.internal.g
 * JD-Core Version:    0.6.2
 */