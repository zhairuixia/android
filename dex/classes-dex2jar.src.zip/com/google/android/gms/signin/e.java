package com.google.android.gms.signin;

import com.google.android.gms.common.api.c.d;

public final class e
{
  public static final e akC = new a().iw();
  public final String SX;
  public final boolean akD;
  public final boolean akE;
  public final c.d akF;

  private e(boolean paramBoolean1, boolean paramBoolean2, String paramString, c.d paramd)
  {
    this.akD = paramBoolean1;
    this.akE = paramBoolean2;
    this.SX = paramString;
    this.akF = paramd;
  }

  public static final class a
  {
    private boolean akG;
    private boolean akH;
    private String akI;
    private c.d akJ;

    public final e iw()
    {
      return new e(this.akG, this.akH, this.akI, this.akJ, (byte)0);
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.signin.e
 * JD-Core Version:    0.6.2
 */