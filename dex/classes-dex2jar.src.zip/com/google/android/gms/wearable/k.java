package com.google.android.gms.wearable;

public abstract interface k
{
  public abstract byte[] getData();

  public abstract String getPath();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.k
 * JD-Core Version:    0.6.2
 */