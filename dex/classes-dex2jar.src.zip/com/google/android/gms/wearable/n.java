package com.google.android.gms.wearable;

public final class n
{
  public final h amQ;
  public final PutDataRequest amR;

  public n(PutDataRequest paramPutDataRequest)
  {
    this.amR = paramPutDataRequest;
    this.amQ = new h();
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.n
 * JD-Core Version:    0.6.2
 */