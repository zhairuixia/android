package com.google.android.gms.wearable;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class r
  implements Parcelable.Creator<Asset>
{
  static void a(Asset paramAsset, Parcel paramParcel, int paramInt)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramAsset.mVersionCode);
    b.a(paramParcel, 2, paramAsset.amG);
    b.a(paramParcel, 3, paramAsset.amH);
    b.a(paramParcel, 4, paramAsset.amI, paramInt);
    b.a(paramParcel, 5, paramAsset.uri, paramInt);
    b.u(paramParcel, i);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.r
 * JD-Core Version:    0.6.2
 */