package com.google.android.gms.wearable;

import android.net.Uri;
import android.util.Base64;
import com.google.android.gms.c.au;
import com.google.android.gms.c.au.a;
import com.google.android.gms.c.av;
import com.google.android.gms.c.bd;
import com.google.android.gms.c.be;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class i
{
  public final h amQ;
  private final Uri mUri;

  public i(f paramf)
  {
    this.mUri = paramf.getUri();
    this.amQ = a((f)paramf.gz());
  }

  private static h a(f paramf)
  {
    if ((paramf.getData() == null) && (paramf.jq().size() > 0))
      throw new IllegalArgumentException("Cannot create DataMapItem from a DataItem  that wasn't made with DataMapItem.");
    if (paramf.getData() == null)
      return new h();
    try
    {
      ArrayList localArrayList = new ArrayList();
      int j = paramf.jq().size();
      i = 0;
      if (i < j)
      {
        localObject = (g)paramf.jq().get(Integer.toString(i));
        if (localObject == null)
          throw new IllegalStateException("Cannot find DataItemAsset referenced in data at " + i + " for " + paramf);
      }
    }
    catch (bd localbd)
    {
      while (true)
      {
        int i;
        new StringBuilder("Unable to parse datamap from dataItem. uri=").append(paramf.getUri()).append(", data=").append(Base64.encodeToString(paramf.getData(), 0));
        throw new IllegalStateException("Unable to parse datamap from dataItem.  uri=" + paramf.getUri(), localbd);
        localbd.add(Asset.ap(((g)localObject).getId()));
        i += 1;
      }
      Object localObject = paramf.getData();
      h localh = au.a(new au.a((av)be.a(new av(), (byte[])localObject, localObject.length), localbd));
      return localh;
    }
    catch (NullPointerException localNullPointerException)
    {
      label136: break label136;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.i
 * JD-Core Version:    0.6.2
 */