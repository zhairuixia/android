package com.google.android.gms.wearable;

public abstract interface s
{
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.s
 * JD-Core Version:    0.6.2
 */