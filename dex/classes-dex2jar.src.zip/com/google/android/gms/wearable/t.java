package com.google.android.gms.wearable;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class t
  implements Parcelable.Creator<ConnectionConfiguration>
{
  static void a(ConnectionConfiguration paramConnectionConfiguration, Parcel paramParcel)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramConnectionConfiguration.mVersionCode);
    b.a(paramParcel, 2, paramConnectionConfiguration.mName);
    b.a(paramParcel, 3, paramConnectionConfiguration.amJ);
    b.c(paramParcel, 4, paramConnectionConfiguration.VE);
    b.c(paramParcel, 5, paramConnectionConfiguration.amK);
    b.a(paramParcel, 6, paramConnectionConfiguration.amL);
    b.a(paramParcel, 7, paramConnectionConfiguration.OQ);
    b.a(paramParcel, 8, paramConnectionConfiguration.amM);
    b.a(paramParcel, 9, paramConnectionConfiguration.amN);
    b.a(paramParcel, 10, paramConnectionConfiguration.amO);
    b.u(paramParcel, i);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.t
 * JD-Core Version:    0.6.2
 */