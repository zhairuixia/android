package com.google.android.gms.wearable;

public abstract interface l
{
  public abstract String getId();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.l
 * JD-Core Version:    0.6.2
 */