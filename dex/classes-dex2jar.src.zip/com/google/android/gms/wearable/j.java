package com.google.android.gms.wearable;

import com.google.android.gms.common.api.c;
import com.google.android.gms.common.api.e;
import com.google.android.gms.common.api.g;

public abstract interface j
{
  public abstract e<b> a(c paramc, String paramString1, String paramString2, byte[] paramArrayOfByte);

  public static abstract interface a
  {
    public abstract void a(k paramk);
  }

  public static abstract interface b extends g
  {
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.j
 * JD-Core Version:    0.6.2
 */