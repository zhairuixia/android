package com.google.android.gms.wearable;

import android.os.Parcelable;

public abstract interface Channel extends Parcelable
{
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.Channel
 * JD-Core Version:    0.6.2
 */