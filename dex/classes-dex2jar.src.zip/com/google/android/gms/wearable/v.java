package com.google.android.gms.wearable;

public abstract interface v
{
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.v
 * JD-Core Version:    0.6.2
 */