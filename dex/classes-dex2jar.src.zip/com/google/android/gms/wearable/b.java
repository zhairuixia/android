package com.google.android.gms.wearable;

public abstract interface b
{
  public static abstract interface a
  {
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.b
 * JD-Core Version:    0.6.2
 */