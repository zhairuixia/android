package com.google.android.gms.wearable;

public abstract interface q
{
  public static abstract interface a
  {
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.q
 * JD-Core Version:    0.6.2
 */