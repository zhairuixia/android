package com.google.android.gms.wearable;

import com.google.android.gms.common.api.c;
import com.google.android.gms.common.api.e;
import com.google.android.gms.common.api.g;
import java.util.List;

public abstract interface m
{
  public abstract e<a> a(c paramc);

  public static abstract interface a extends g
  {
    public abstract List<l> js();
  }

  public static abstract interface b
  {
    public abstract void a(l paraml);

    public abstract void b(l paraml);
  }

  public static abstract interface c
  {
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.m
 * JD-Core Version:    0.6.2
 */