package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class h
  implements Parcelable.Creator<GetAllCapabilitiesResponse>
{
  static void a(GetAllCapabilitiesResponse paramGetAllCapabilitiesResponse, Parcel paramParcel)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramGetAllCapabilitiesResponse.versionCode);
    b.c(paramParcel, 2, paramGetAllCapabilitiesResponse.statusCode);
    b.b(paramParcel, 3, paramGetAllCapabilitiesResponse.anR);
    b.u(paramParcel, i);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.internal.h
 * JD-Core Version:    0.6.2
 */