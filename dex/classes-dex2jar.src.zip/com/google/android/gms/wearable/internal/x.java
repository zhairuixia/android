package com.google.android.gms.wearable.internal;

import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable.Creator;
import com.google.android.gms.wearable.Asset;
import com.google.android.gms.wearable.ConnectionConfiguration;
import com.google.android.gms.wearable.PutDataRequest;

public abstract interface x extends IInterface
{
  public abstract void a(v paramv);

  public abstract void a(v paramv, byte paramByte);

  public abstract void a(v paramv, int paramInt);

  public abstract void a(v paramv, Uri paramUri);

  public abstract void a(v paramv, Uri paramUri, int paramInt);

  public abstract void a(v paramv, Asset paramAsset);

  public abstract void a(v paramv, ConnectionConfiguration paramConnectionConfiguration);

  public abstract void a(v paramv, PutDataRequest paramPutDataRequest);

  public abstract void a(v paramv, AddListenerRequest paramAddListenerRequest);

  public abstract void a(v paramv, AncsNotificationParcelable paramAncsNotificationParcelable);

  public abstract void a(v paramv, RemoveListenerRequest paramRemoveListenerRequest);

  public abstract void a(v paramv, u paramu, String paramString);

  public abstract void a(v paramv, String paramString);

  public abstract void a(v paramv, String paramString, int paramInt);

  public abstract void a(v paramv, String paramString, ParcelFileDescriptor paramParcelFileDescriptor);

  public abstract void a(v paramv, String paramString, ParcelFileDescriptor paramParcelFileDescriptor, long paramLong1, long paramLong2);

  public abstract void a(v paramv, String paramString1, String paramString2);

  public abstract void a(v paramv, String paramString1, String paramString2, byte[] paramArrayOfByte);

  public abstract void a(v paramv, boolean paramBoolean);

  public abstract void b(v paramv);

  public abstract void b(v paramv, int paramInt);

  public abstract void b(v paramv, Uri paramUri);

  public abstract void b(v paramv, Uri paramUri, int paramInt);

  public abstract void b(v paramv, ConnectionConfiguration paramConnectionConfiguration);

  public abstract void b(v paramv, u paramu, String paramString);

  public abstract void b(v paramv, String paramString);

  public abstract void b(v paramv, String paramString, int paramInt);

  public abstract void b(v paramv, boolean paramBoolean);

  public abstract void c(v paramv);

  public abstract void c(v paramv, int paramInt);

  public abstract void c(v paramv, Uri paramUri);

  public abstract void c(v paramv, String paramString);

  public abstract void d(v paramv);

  public abstract void d(v paramv, String paramString);

  public abstract void e(v paramv);

  public abstract void e(v paramv, String paramString);

  public abstract void f(v paramv);

  public abstract void f(v paramv, String paramString);

  public abstract void g(v paramv);

  public abstract void h(v paramv);

  public abstract void i(v paramv);

  public abstract void j(v paramv);

  public abstract void k(v paramv);

  public abstract void l(v paramv);

  public abstract void m(v paramv);

  public abstract void n(v paramv);

  public abstract void o(v paramv);

  public abstract void p(v paramv);

  public static abstract class a extends Binder
    implements x
  {
    public static x t(IBinder paramIBinder)
    {
      if (paramIBinder == null)
        return null;
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.wearable.internal.IWearableService");
      if ((localIInterface != null) && ((localIInterface instanceof x)))
        return (x)localIInterface;
      return new a(paramIBinder);
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
    {
      boolean bool = false;
      Object localObject2 = null;
      Object localObject3 = null;
      Object localObject4 = null;
      Object localObject5 = null;
      Object localObject6 = null;
      Object localObject7 = null;
      Object localObject8 = null;
      Object localObject9 = null;
      Object localObject10 = null;
      Object localObject11 = null;
      Object localObject1 = null;
      Object localObject12 = null;
      v localv = null;
      switch (paramInt1)
      {
      default:
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
        paramParcel2.writeString("com.google.android.gms.wearable.internal.IWearableService");
        return true;
      case 20:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localObject2 = v.a.r(paramParcel1.readStrongBinder());
        localObject1 = localv;
        if (paramParcel1.readInt() != 0)
          localObject1 = (ConnectionConfiguration)ConnectionConfiguration.CREATOR.createFromParcel(paramParcel1);
        a((v)localObject2, (ConnectionConfiguration)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 21:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        a(v.a.r(paramParcel1.readStrongBinder()), paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 22:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        a(v.a.r(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 23:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        b(v.a.r(paramParcel1.readStrongBinder()), paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 24:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        c(v.a.r(paramParcel1.readStrongBinder()), paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 6:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localv = v.a.r(paramParcel1.readStrongBinder());
        localObject1 = localObject2;
        if (paramParcel1.readInt() != 0)
          localObject1 = (PutDataRequest)PutDataRequest.CREATOR.createFromParcel(paramParcel1);
        a(localv, (PutDataRequest)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 7:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localv = v.a.r(paramParcel1.readStrongBinder());
        localObject1 = localObject3;
        if (paramParcel1.readInt() != 0)
          localObject1 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
        a(localv, (Uri)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 8:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        b(v.a.r(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 9:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localv = v.a.r(paramParcel1.readStrongBinder());
        localObject1 = localObject4;
        if (paramParcel1.readInt() != 0)
          localObject1 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
        b(localv, (Uri)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 40:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localv = v.a.r(paramParcel1.readStrongBinder());
        localObject1 = localObject5;
        if (paramParcel1.readInt() != 0)
          localObject1 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
        a(localv, (Uri)localObject1, paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 11:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localv = v.a.r(paramParcel1.readStrongBinder());
        localObject1 = localObject6;
        if (paramParcel1.readInt() != 0)
          localObject1 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
        c(localv, (Uri)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 41:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localv = v.a.r(paramParcel1.readStrongBinder());
        localObject1 = localObject7;
        if (paramParcel1.readInt() != 0)
          localObject1 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1);
        b(localv, (Uri)localObject1, paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 12:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        a(v.a.r(paramParcel1.readStrongBinder()), paramParcel1.readString(), paramParcel1.readString(), paramParcel1.createByteArray());
        paramParcel2.writeNoException();
        return true;
      case 13:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localv = v.a.r(paramParcel1.readStrongBinder());
        localObject1 = localObject8;
        if (paramParcel1.readInt() != 0)
          localObject1 = (Asset)Asset.CREATOR.createFromParcel(paramParcel1);
        a(localv, (Asset)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 14:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        c(v.a.r(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 15:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        d(v.a.r(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 42:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        a(v.a.r(paramParcel1.readStrongBinder()), paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 43:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        a(v.a.r(paramParcel1.readStrongBinder()), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 46:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        d(v.a.r(paramParcel1.readStrongBinder()), paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 47:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        e(v.a.r(paramParcel1.readStrongBinder()), paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 16:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localv = v.a.r(paramParcel1.readStrongBinder());
        localObject1 = localObject9;
        if (paramParcel1.readInt() != 0)
          localObject1 = (AddListenerRequest)AddListenerRequest.CREATOR.createFromParcel(paramParcel1);
        a(localv, (AddListenerRequest)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 17:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localv = v.a.r(paramParcel1.readStrongBinder());
        localObject1 = localObject10;
        if (paramParcel1.readInt() != 0)
          localObject1 = (RemoveListenerRequest)RemoveListenerRequest.CREATOR.createFromParcel(paramParcel1);
        a(localv, (RemoveListenerRequest)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 18:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        e(v.a.r(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 19:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        f(v.a.r(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 25:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        g(v.a.r(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 26:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        h(v.a.r(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 27:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localv = v.a.r(paramParcel1.readStrongBinder());
        localObject1 = localObject11;
        if (paramParcel1.readInt() != 0)
          localObject1 = (AncsNotificationParcelable)AncsNotificationParcelable.CREATOR.createFromParcel(paramParcel1);
        a(localv, (AncsNotificationParcelable)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 28:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        b(v.a.r(paramParcel1.readStrongBinder()), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 29:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        c(v.a.r(paramParcel1.readStrongBinder()), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 30:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        i(v.a.r(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 31:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        a(v.a.r(paramParcel1.readStrongBinder()), paramParcel1.readString(), paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 32:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        f(v.a.r(paramParcel1.readStrongBinder()), paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 33:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        b(v.a.r(paramParcel1.readStrongBinder()), paramParcel1.readString(), paramParcel1.readInt());
        paramParcel2.writeNoException();
        return true;
      case 34:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        a(v.a.r(paramParcel1.readStrongBinder()), u.a.q(paramParcel1.readStrongBinder()), paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 35:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        b(v.a.r(paramParcel1.readStrongBinder()), u.a.q(paramParcel1.readStrongBinder()), paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      case 38:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localv = v.a.r(paramParcel1.readStrongBinder());
        localObject2 = paramParcel1.readString();
        if (paramParcel1.readInt() != 0)
          localObject1 = (ParcelFileDescriptor)ParcelFileDescriptor.CREATOR.createFromParcel(paramParcel1);
        a(localv, (String)localObject2, (ParcelFileDescriptor)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 39:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localv = v.a.r(paramParcel1.readStrongBinder());
        localObject2 = paramParcel1.readString();
        if (paramParcel1.readInt() != 0);
        for (localObject1 = (ParcelFileDescriptor)ParcelFileDescriptor.CREATOR.createFromParcel(paramParcel1); ; localObject1 = null)
        {
          a(localv, (String)localObject2, (ParcelFileDescriptor)localObject1, paramParcel1.readLong(), paramParcel1.readLong());
          paramParcel2.writeNoException();
          return true;
        }
      case 37:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        j(v.a.r(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 48:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localObject1 = v.a.r(paramParcel1.readStrongBinder());
        if (paramParcel1.readInt() != 0);
        for (bool = true; ; bool = false)
        {
          a((v)localObject1, bool);
          paramParcel2.writeNoException();
          return true;
        }
      case 49:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        k(v.a.r(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 50:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localObject1 = v.a.r(paramParcel1.readStrongBinder());
        if (paramParcel1.readInt() != 0)
          bool = true;
        b((v)localObject1, bool);
        paramParcel2.writeNoException();
        return true;
      case 51:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        l(v.a.r(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 52:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        m(v.a.r(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 53:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        a(v.a.r(paramParcel1.readStrongBinder()), paramParcel1.readByte());
        paramParcel2.writeNoException();
        return true;
      case 2:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        localv = v.a.r(paramParcel1.readStrongBinder());
        localObject1 = localObject12;
        if (paramParcel1.readInt() != 0)
          localObject1 = (ConnectionConfiguration)ConnectionConfiguration.CREATOR.createFromParcel(paramParcel1);
        b(localv, (ConnectionConfiguration)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 3:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        n(v.a.r(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 4:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
        o(v.a.r(paramParcel1.readStrongBinder()));
        paramParcel2.writeNoException();
        return true;
      case 5:
      }
      paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableService");
      p(v.a.r(paramParcel1.readStrongBinder()));
      paramParcel2.writeNoException();
      return true;
    }

    private static final class a
      implements x
    {
      private IBinder OH;

      a(IBinder paramIBinder)
      {
        this.OH = paramIBinder;
      }

      public final void a(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(22, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, byte paramByte)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeByte(paramByte);
            this.OH.transact(53, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, int paramInt)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeInt(paramInt);
            this.OH.transact(43, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, Uri paramUri)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null)
          {
            paramv = paramv.asBinder();
            localParcel1.writeStrongBinder(paramv);
            if (paramUri == null)
              break label82;
            localParcel1.writeInt(1);
            paramUri.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(7, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            paramv = null;
            break;
            label82: localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, Uri paramUri, int paramInt)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null)
          {
            paramv = paramv.asBinder();
            localParcel1.writeStrongBinder(paramv);
            if (paramUri == null)
              break label95;
            localParcel1.writeInt(1);
            paramUri.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            localParcel1.writeInt(paramInt);
            this.OH.transact(40, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            paramv = null;
            break;
            label95: localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, Asset paramAsset)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null)
          {
            paramv = paramv.asBinder();
            localParcel1.writeStrongBinder(paramv);
            if (paramAsset == null)
              break label82;
            localParcel1.writeInt(1);
            paramAsset.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(13, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            paramv = null;
            break;
            label82: localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, ConnectionConfiguration paramConnectionConfiguration)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null)
          {
            paramv = paramv.asBinder();
            localParcel1.writeStrongBinder(paramv);
            if (paramConnectionConfiguration == null)
              break label82;
            localParcel1.writeInt(1);
            paramConnectionConfiguration.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(20, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            paramv = null;
            break;
            label82: localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, PutDataRequest paramPutDataRequest)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null)
          {
            paramv = paramv.asBinder();
            localParcel1.writeStrongBinder(paramv);
            if (paramPutDataRequest == null)
              break label82;
            localParcel1.writeInt(1);
            paramPutDataRequest.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(6, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            paramv = null;
            break;
            label82: localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, AddListenerRequest paramAddListenerRequest)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null)
          {
            paramv = paramv.asBinder();
            localParcel1.writeStrongBinder(paramv);
            if (paramAddListenerRequest == null)
              break label82;
            localParcel1.writeInt(1);
            paramAddListenerRequest.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(16, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            paramv = null;
            break;
            label82: localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, AncsNotificationParcelable paramAncsNotificationParcelable)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null)
          {
            paramv = paramv.asBinder();
            localParcel1.writeStrongBinder(paramv);
            if (paramAncsNotificationParcelable == null)
              break label82;
            localParcel1.writeInt(1);
            paramAncsNotificationParcelable.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(27, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            paramv = null;
            break;
            label82: localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, RemoveListenerRequest paramRemoveListenerRequest)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null)
          {
            paramv = paramv.asBinder();
            localParcel1.writeStrongBinder(paramv);
            if (paramRemoveListenerRequest == null)
              break label82;
            localParcel1.writeInt(1);
            paramRemoveListenerRequest.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(17, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            paramv = null;
            break;
            label82: localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, u paramu, String paramString)
      {
        Object localObject = null;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            paramv = localObject;
            if (paramu != null)
              paramv = paramu.asBinder();
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeString(paramString);
            this.OH.transact(34, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, String paramString)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeString(paramString);
            this.OH.transact(21, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, String paramString, int paramInt)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeString(paramString);
            localParcel1.writeInt(paramInt);
            this.OH.transact(42, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, String paramString, ParcelFileDescriptor paramParcelFileDescriptor)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null)
          {
            paramv = paramv.asBinder();
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeString(paramString);
            if (paramParcelFileDescriptor == null)
              break label95;
            localParcel1.writeInt(1);
            paramParcelFileDescriptor.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(38, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            paramv = null;
            break;
            label95: localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, String paramString, ParcelFileDescriptor paramParcelFileDescriptor, long paramLong1, long paramLong2)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null)
          {
            paramv = paramv.asBinder();
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeString(paramString);
            if (paramParcelFileDescriptor == null)
              break label109;
            localParcel1.writeInt(1);
            paramParcelFileDescriptor.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            localParcel1.writeLong(paramLong1);
            localParcel1.writeLong(paramLong2);
            this.OH.transact(39, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            paramv = null;
            break;
            label109: localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, String paramString1, String paramString2)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeString(paramString1);
            localParcel1.writeString(paramString2);
            this.OH.transact(31, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, String paramString1, String paramString2, byte[] paramArrayOfByte)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeString(paramString1);
            localParcel1.writeString(paramString2);
            localParcel1.writeByteArray(paramArrayOfByte);
            this.OH.transact(12, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void a(v paramv, boolean paramBoolean)
      {
        int i = 0;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            if (paramBoolean)
              i = 1;
            localParcel1.writeInt(i);
            this.OH.transact(48, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final IBinder asBinder()
      {
        return this.OH;
      }

      public final void b(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(8, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void b(v paramv, int paramInt)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeInt(paramInt);
            this.OH.transact(28, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void b(v paramv, Uri paramUri)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null)
          {
            paramv = paramv.asBinder();
            localParcel1.writeStrongBinder(paramv);
            if (paramUri == null)
              break label82;
            localParcel1.writeInt(1);
            paramUri.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(9, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            paramv = null;
            break;
            label82: localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void b(v paramv, Uri paramUri, int paramInt)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null)
          {
            paramv = paramv.asBinder();
            localParcel1.writeStrongBinder(paramv);
            if (paramUri == null)
              break label95;
            localParcel1.writeInt(1);
            paramUri.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            localParcel1.writeInt(paramInt);
            this.OH.transact(41, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            paramv = null;
            break;
            label95: localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void b(v paramv, ConnectionConfiguration paramConnectionConfiguration)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null)
          {
            paramv = paramv.asBinder();
            localParcel1.writeStrongBinder(paramv);
            if (paramConnectionConfiguration == null)
              break label81;
            localParcel1.writeInt(1);
            paramConnectionConfiguration.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(2, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            paramv = null;
            break;
            label81: localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void b(v paramv, u paramu, String paramString)
      {
        Object localObject = null;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            paramv = localObject;
            if (paramu != null)
              paramv = paramu.asBinder();
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeString(paramString);
            this.OH.transact(35, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void b(v paramv, String paramString)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeString(paramString);
            this.OH.transact(23, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void b(v paramv, String paramString, int paramInt)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeString(paramString);
            localParcel1.writeInt(paramInt);
            this.OH.transact(33, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void b(v paramv, boolean paramBoolean)
      {
        int i = 0;
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            if (paramBoolean)
              i = 1;
            localParcel1.writeInt(i);
            this.OH.transact(50, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void c(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(14, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void c(v paramv, int paramInt)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeInt(paramInt);
            this.OH.transact(29, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void c(v paramv, Uri paramUri)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null)
          {
            paramv = paramv.asBinder();
            localParcel1.writeStrongBinder(paramv);
            if (paramUri == null)
              break label82;
            localParcel1.writeInt(1);
            paramUri.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(11, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            paramv = null;
            break;
            label82: localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void c(v paramv, String paramString)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeString(paramString);
            this.OH.transact(24, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void d(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(15, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void d(v paramv, String paramString)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeString(paramString);
            this.OH.transact(46, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void e(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(18, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void e(v paramv, String paramString)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeString(paramString);
            this.OH.transact(47, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void f(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(19, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void f(v paramv, String paramString)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            localParcel1.writeString(paramString);
            this.OH.transact(32, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void g(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(25, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void h(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(26, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void i(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(30, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void j(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(37, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void k(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(49, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void l(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(51, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void m(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(52, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void n(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(3, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void o(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(4, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }

      public final void p(v paramv)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableService");
          if (paramv != null);
          for (paramv = paramv.asBinder(); ; paramv = null)
          {
            localParcel1.writeStrongBinder(paramv);
            this.OH.transact(5, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramv;
      }
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.internal.x
 * JD-Core Version:    0.6.2
 */