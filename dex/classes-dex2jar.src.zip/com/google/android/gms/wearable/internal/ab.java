package com.google.android.gms.wearable.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class ab
  implements Parcelable.Creator<AddListenerRequest>
{
  static void a(AddListenerRequest paramAddListenerRequest, Parcel paramParcel, int paramInt)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramAddListenerRequest.mVersionCode);
    if (paramAddListenerRequest.anu == null);
    for (IBinder localIBinder = null; ; localIBinder = paramAddListenerRequest.anu.asBinder())
    {
      b.a(paramParcel, 2, localIBinder);
      b.a(paramParcel, 3, paramAddListenerRequest.anv, paramInt);
      b.a(paramParcel, 4, paramAddListenerRequest.anw);
      b.a(paramParcel, 5, paramAddListenerRequest.anx);
      b.u(paramParcel, i);
      return;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.internal.ab
 * JD-Core Version:    0.6.2
 */