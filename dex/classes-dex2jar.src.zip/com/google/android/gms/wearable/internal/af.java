package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class af
  implements Parcelable.Creator<PackageStorageInfo>
{
  static void a(PackageStorageInfo paramPackageStorageInfo, Parcel paramParcel)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramPackageStorageInfo.versionCode);
    b.a(paramParcel, 2, paramPackageStorageInfo.packageName);
    b.a(paramParcel, 3, paramPackageStorageInfo.label);
    b.a(paramParcel, 4, paramPackageStorageInfo.aog);
    b.u(paramParcel, i);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.internal.af
 * JD-Core Version:    0.6.2
 */