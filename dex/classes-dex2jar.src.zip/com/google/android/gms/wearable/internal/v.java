package com.google.android.gms.wearable.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.data.g;

public abstract interface v extends IInterface
{
  public abstract void a(AddLocalCapabilityResponse paramAddLocalCapabilityResponse);

  public abstract void a(ChannelReceiveFileResponse paramChannelReceiveFileResponse);

  public abstract void a(ChannelSendFileResponse paramChannelSendFileResponse);

  public abstract void a(CloseChannelResponse paramCloseChannelResponse);

  public abstract void a(DeleteDataItemsResponse paramDeleteDataItemsResponse);

  public abstract void a(GetAllCapabilitiesResponse paramGetAllCapabilitiesResponse);

  public abstract void a(GetCapabilityResponse paramGetCapabilityResponse);

  public abstract void a(GetChannelInputStreamResponse paramGetChannelInputStreamResponse);

  public abstract void a(GetChannelOutputStreamResponse paramGetChannelOutputStreamResponse);

  public abstract void a(GetCloudSyncOptInOutDoneResponse paramGetCloudSyncOptInOutDoneResponse);

  public abstract void a(GetCloudSyncOptInStatusResponse paramGetCloudSyncOptInStatusResponse);

  public abstract void a(GetCloudSyncSettingResponse paramGetCloudSyncSettingResponse);

  public abstract void a(GetConfigResponse paramGetConfigResponse);

  public abstract void a(GetConfigsResponse paramGetConfigsResponse);

  public abstract void a(GetConnectedNodesResponse paramGetConnectedNodesResponse);

  public abstract void a(GetDataItemResponse paramGetDataItemResponse);

  public abstract void a(GetFdForAssetResponse paramGetFdForAssetResponse);

  public abstract void a(GetLocalNodeResponse paramGetLocalNodeResponse);

  public abstract void a(OpenChannelResponse paramOpenChannelResponse);

  public abstract void a(PutDataResponse paramPutDataResponse);

  public abstract void a(RemoveLocalCapabilityResponse paramRemoveLocalCapabilityResponse);

  public abstract void a(SendMessageResponse paramSendMessageResponse);

  public abstract void a(StorageInfoResponse paramStorageInfoResponse);

  public abstract void b(DataHolder paramDataHolder);

  public abstract void b(CloseChannelResponse paramCloseChannelResponse);

  public abstract void f(Status paramStatus);

  public static abstract class a extends Binder
    implements v
  {
    public a()
    {
      attachInterface(this, "com.google.android.gms.wearable.internal.IWearableCallbacks");
    }

    public static v r(IBinder paramIBinder)
    {
      if (paramIBinder == null)
        return null;
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
      if ((localIInterface != null) && ((localIInterface instanceof v)))
        return (v)localIInterface;
      return new a(paramIBinder);
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
    {
      Object localObject2 = null;
      Object localObject3 = null;
      Object localObject4 = null;
      Object localObject5 = null;
      Object localObject6 = null;
      Object localObject7 = null;
      Object localObject8 = null;
      Object localObject9 = null;
      Object localObject10 = null;
      Object localObject11 = null;
      Object localObject12 = null;
      Object localObject13 = null;
      Object localObject14 = null;
      Object localObject15 = null;
      Object localObject16 = null;
      Object localObject17 = null;
      Object localObject18 = null;
      Object localObject19 = null;
      Object localObject20 = null;
      Object localObject21 = null;
      Object localObject22 = null;
      Object localObject23 = null;
      Object localObject24 = null;
      Object localObject25 = null;
      Object localObject26 = null;
      Object localObject1 = null;
      switch (paramInt1)
      {
      default:
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
        paramParcel2.writeString("com.google.android.gms.wearable.internal.IWearableCallbacks");
        return true;
      case 2:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        if (paramParcel1.readInt() != 0)
          localObject1 = (GetConfigResponse)GetConfigResponse.CREATOR.createFromParcel(paramParcel1);
        a((GetConfigResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 13:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject2;
        if (paramParcel1.readInt() != 0)
          localObject1 = (GetConfigsResponse)GetConfigsResponse.CREATOR.createFromParcel(paramParcel1);
        a((GetConfigsResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 28:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject3;
        if (paramParcel1.readInt() != 0)
          localObject1 = (GetCloudSyncOptInOutDoneResponse)GetCloudSyncOptInOutDoneResponse.CREATOR.createFromParcel(paramParcel1);
        a((GetCloudSyncOptInOutDoneResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 29:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject4;
        if (paramParcel1.readInt() != 0)
          localObject1 = (GetCloudSyncSettingResponse)GetCloudSyncSettingResponse.CREATOR.createFromParcel(paramParcel1);
        a((GetCloudSyncSettingResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 30:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject5;
        if (paramParcel1.readInt() != 0)
          localObject1 = (GetCloudSyncOptInStatusResponse)GetCloudSyncOptInStatusResponse.CREATOR.createFromParcel(paramParcel1);
        a((GetCloudSyncOptInStatusResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 3:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject6;
        if (paramParcel1.readInt() != 0)
          localObject1 = (PutDataResponse)PutDataResponse.CREATOR.createFromParcel(paramParcel1);
        a((PutDataResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 4:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject7;
        if (paramParcel1.readInt() != 0)
          localObject1 = (GetDataItemResponse)GetDataItemResponse.CREATOR.createFromParcel(paramParcel1);
        a((GetDataItemResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 5:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject8;
        if (paramParcel1.readInt() != 0)
        {
          localObject1 = DataHolder.CREATOR;
          localObject1 = g.a(paramParcel1);
        }
        b((DataHolder)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 6:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject9;
        if (paramParcel1.readInt() != 0)
          localObject1 = (DeleteDataItemsResponse)DeleteDataItemsResponse.CREATOR.createFromParcel(paramParcel1);
        a((DeleteDataItemsResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 7:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject10;
        if (paramParcel1.readInt() != 0)
          localObject1 = (SendMessageResponse)SendMessageResponse.CREATOR.createFromParcel(paramParcel1);
        a((SendMessageResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 8:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject11;
        if (paramParcel1.readInt() != 0)
          localObject1 = (GetFdForAssetResponse)GetFdForAssetResponse.CREATOR.createFromParcel(paramParcel1);
        a((GetFdForAssetResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 9:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject12;
        if (paramParcel1.readInt() != 0)
          localObject1 = (GetLocalNodeResponse)GetLocalNodeResponse.CREATOR.createFromParcel(paramParcel1);
        a((GetLocalNodeResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 10:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject13;
        if (paramParcel1.readInt() != 0)
          localObject1 = (GetConnectedNodesResponse)GetConnectedNodesResponse.CREATOR.createFromParcel(paramParcel1);
        a((GetConnectedNodesResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 14:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject14;
        if (paramParcel1.readInt() != 0)
          localObject1 = (OpenChannelResponse)OpenChannelResponse.CREATOR.createFromParcel(paramParcel1);
        a((OpenChannelResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 15:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject15;
        if (paramParcel1.readInt() != 0)
          localObject1 = (CloseChannelResponse)CloseChannelResponse.CREATOR.createFromParcel(paramParcel1);
        a((CloseChannelResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 16:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject16;
        if (paramParcel1.readInt() != 0)
          localObject1 = (CloseChannelResponse)CloseChannelResponse.CREATOR.createFromParcel(paramParcel1);
        b((CloseChannelResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 17:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject17;
        if (paramParcel1.readInt() != 0)
          localObject1 = (GetChannelInputStreamResponse)GetChannelInputStreamResponse.CREATOR.createFromParcel(paramParcel1);
        a((GetChannelInputStreamResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 18:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject18;
        if (paramParcel1.readInt() != 0)
          localObject1 = (GetChannelOutputStreamResponse)GetChannelOutputStreamResponse.CREATOR.createFromParcel(paramParcel1);
        a((GetChannelOutputStreamResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 19:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject19;
        if (paramParcel1.readInt() != 0)
          localObject1 = (ChannelReceiveFileResponse)ChannelReceiveFileResponse.CREATOR.createFromParcel(paramParcel1);
        a((ChannelReceiveFileResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 20:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject20;
        if (paramParcel1.readInt() != 0)
          localObject1 = (ChannelSendFileResponse)ChannelSendFileResponse.CREATOR.createFromParcel(paramParcel1);
        a((ChannelSendFileResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 11:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject21;
        if (paramParcel1.readInt() != 0)
          localObject1 = (Status)Status.CREATOR.createFromParcel(paramParcel1);
        f((Status)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 12:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject22;
        if (paramParcel1.readInt() != 0)
          localObject1 = (StorageInfoResponse)StorageInfoResponse.CREATOR.createFromParcel(paramParcel1);
        a((StorageInfoResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 22:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject23;
        if (paramParcel1.readInt() != 0)
          localObject1 = (GetCapabilityResponse)GetCapabilityResponse.CREATOR.createFromParcel(paramParcel1);
        a((GetCapabilityResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 23:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject24;
        if (paramParcel1.readInt() != 0)
          localObject1 = (GetAllCapabilitiesResponse)GetAllCapabilitiesResponse.CREATOR.createFromParcel(paramParcel1);
        a((GetAllCapabilitiesResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 26:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
        localObject1 = localObject25;
        if (paramParcel1.readInt() != 0)
          localObject1 = (AddLocalCapabilityResponse)AddLocalCapabilityResponse.CREATOR.createFromParcel(paramParcel1);
        a((AddLocalCapabilityResponse)localObject1);
        paramParcel2.writeNoException();
        return true;
      case 27:
      }
      paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableCallbacks");
      localObject1 = localObject26;
      if (paramParcel1.readInt() != 0)
        localObject1 = (RemoveLocalCapabilityResponse)RemoveLocalCapabilityResponse.CREATOR.createFromParcel(paramParcel1);
      a((RemoveLocalCapabilityResponse)localObject1);
      paramParcel2.writeNoException();
      return true;
    }

    private static final class a
      implements v
    {
      private IBinder OH;

      a(IBinder paramIBinder)
      {
        this.OH = paramIBinder;
      }

      public final void a(AddLocalCapabilityResponse paramAddLocalCapabilityResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramAddLocalCapabilityResponse != null)
          {
            localParcel1.writeInt(1);
            paramAddLocalCapabilityResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(26, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramAddLocalCapabilityResponse;
      }

      public final void a(ChannelReceiveFileResponse paramChannelReceiveFileResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramChannelReceiveFileResponse != null)
          {
            localParcel1.writeInt(1);
            paramChannelReceiveFileResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(19, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramChannelReceiveFileResponse;
      }

      public final void a(ChannelSendFileResponse paramChannelSendFileResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramChannelSendFileResponse != null)
          {
            localParcel1.writeInt(1);
            paramChannelSendFileResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(20, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramChannelSendFileResponse;
      }

      public final void a(CloseChannelResponse paramCloseChannelResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramCloseChannelResponse != null)
          {
            localParcel1.writeInt(1);
            paramCloseChannelResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(15, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramCloseChannelResponse;
      }

      public final void a(DeleteDataItemsResponse paramDeleteDataItemsResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramDeleteDataItemsResponse != null)
          {
            localParcel1.writeInt(1);
            paramDeleteDataItemsResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(6, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramDeleteDataItemsResponse;
      }

      public final void a(GetAllCapabilitiesResponse paramGetAllCapabilitiesResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramGetAllCapabilitiesResponse != null)
          {
            localParcel1.writeInt(1);
            paramGetAllCapabilitiesResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(23, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramGetAllCapabilitiesResponse;
      }

      public final void a(GetCapabilityResponse paramGetCapabilityResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramGetCapabilityResponse != null)
          {
            localParcel1.writeInt(1);
            paramGetCapabilityResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(22, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramGetCapabilityResponse;
      }

      public final void a(GetChannelInputStreamResponse paramGetChannelInputStreamResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramGetChannelInputStreamResponse != null)
          {
            localParcel1.writeInt(1);
            paramGetChannelInputStreamResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(17, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramGetChannelInputStreamResponse;
      }

      public final void a(GetChannelOutputStreamResponse paramGetChannelOutputStreamResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramGetChannelOutputStreamResponse != null)
          {
            localParcel1.writeInt(1);
            paramGetChannelOutputStreamResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(18, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramGetChannelOutputStreamResponse;
      }

      public final void a(GetCloudSyncOptInOutDoneResponse paramGetCloudSyncOptInOutDoneResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramGetCloudSyncOptInOutDoneResponse != null)
          {
            localParcel1.writeInt(1);
            paramGetCloudSyncOptInOutDoneResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(28, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramGetCloudSyncOptInOutDoneResponse;
      }

      public final void a(GetCloudSyncOptInStatusResponse paramGetCloudSyncOptInStatusResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramGetCloudSyncOptInStatusResponse != null)
          {
            localParcel1.writeInt(1);
            paramGetCloudSyncOptInStatusResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(30, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramGetCloudSyncOptInStatusResponse;
      }

      public final void a(GetCloudSyncSettingResponse paramGetCloudSyncSettingResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramGetCloudSyncSettingResponse != null)
          {
            localParcel1.writeInt(1);
            paramGetCloudSyncSettingResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(29, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramGetCloudSyncSettingResponse;
      }

      public final void a(GetConfigResponse paramGetConfigResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramGetConfigResponse != null)
          {
            localParcel1.writeInt(1);
            paramGetConfigResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(2, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramGetConfigResponse;
      }

      public final void a(GetConfigsResponse paramGetConfigsResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramGetConfigsResponse != null)
          {
            localParcel1.writeInt(1);
            paramGetConfigsResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(13, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramGetConfigsResponse;
      }

      public final void a(GetConnectedNodesResponse paramGetConnectedNodesResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramGetConnectedNodesResponse != null)
          {
            localParcel1.writeInt(1);
            paramGetConnectedNodesResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(10, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramGetConnectedNodesResponse;
      }

      public final void a(GetDataItemResponse paramGetDataItemResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramGetDataItemResponse != null)
          {
            localParcel1.writeInt(1);
            paramGetDataItemResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(4, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramGetDataItemResponse;
      }

      public final void a(GetFdForAssetResponse paramGetFdForAssetResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramGetFdForAssetResponse != null)
          {
            localParcel1.writeInt(1);
            paramGetFdForAssetResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(8, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramGetFdForAssetResponse;
      }

      public final void a(GetLocalNodeResponse paramGetLocalNodeResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramGetLocalNodeResponse != null)
          {
            localParcel1.writeInt(1);
            paramGetLocalNodeResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(9, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramGetLocalNodeResponse;
      }

      public final void a(OpenChannelResponse paramOpenChannelResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramOpenChannelResponse != null)
          {
            localParcel1.writeInt(1);
            paramOpenChannelResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(14, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramOpenChannelResponse;
      }

      public final void a(PutDataResponse paramPutDataResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramPutDataResponse != null)
          {
            localParcel1.writeInt(1);
            paramPutDataResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(3, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramPutDataResponse;
      }

      public final void a(RemoveLocalCapabilityResponse paramRemoveLocalCapabilityResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramRemoveLocalCapabilityResponse != null)
          {
            localParcel1.writeInt(1);
            paramRemoveLocalCapabilityResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(27, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramRemoveLocalCapabilityResponse;
      }

      public final void a(SendMessageResponse paramSendMessageResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramSendMessageResponse != null)
          {
            localParcel1.writeInt(1);
            paramSendMessageResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(7, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramSendMessageResponse;
      }

      public final void a(StorageInfoResponse paramStorageInfoResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramStorageInfoResponse != null)
          {
            localParcel1.writeInt(1);
            paramStorageInfoResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(12, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramStorageInfoResponse;
      }

      public final IBinder asBinder()
      {
        return this.OH;
      }

      public final void b(DataHolder paramDataHolder)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramDataHolder != null)
          {
            localParcel1.writeInt(1);
            paramDataHolder.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(5, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramDataHolder;
      }

      public final void b(CloseChannelResponse paramCloseChannelResponse)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramCloseChannelResponse != null)
          {
            localParcel1.writeInt(1);
            paramCloseChannelResponse.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(16, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramCloseChannelResponse;
      }

      public final void f(Status paramStatus)
      {
        Parcel localParcel1 = Parcel.obtain();
        Parcel localParcel2 = Parcel.obtain();
        try
        {
          localParcel1.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableCallbacks");
          if (paramStatus != null)
          {
            localParcel1.writeInt(1);
            paramStatus.writeToParcel(localParcel1, 0);
          }
          while (true)
          {
            this.OH.transact(11, localParcel1, localParcel2, 0);
            localParcel2.readException();
            return;
            localParcel1.writeInt(0);
          }
        }
        finally
        {
          localParcel2.recycle();
          localParcel1.recycle();
        }
        throw paramStatus;
      }
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.internal.v
 * JD-Core Version:    0.6.2
 */