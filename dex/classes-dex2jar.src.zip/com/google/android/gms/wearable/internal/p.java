package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class p
  implements Parcelable.Creator<GetConfigsResponse>
{
  static void a(GetConfigsResponse paramGetConfigsResponse, Parcel paramParcel, int paramInt)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramGetConfigsResponse.versionCode);
    b.c(paramParcel, 2, paramGetConfigsResponse.statusCode);
    b.a(paramParcel, 3, paramGetConfigsResponse.anY, paramInt);
    b.u(paramParcel, i);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.internal.p
 * JD-Core Version:    0.6.2
 */