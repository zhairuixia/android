package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class ba
  implements Parcelable.Creator<ChannelEventParcelable>
{
  static void a(ChannelEventParcelable paramChannelEventParcelable, Parcel paramParcel, int paramInt)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramChannelEventParcelable.mVersionCode);
    b.a(paramParcel, 2, paramChannelEventParcelable.anK, paramInt);
    b.c(paramParcel, 3, paramChannelEventParcelable.type);
    b.c(paramParcel, 4, paramChannelEventParcelable.anL);
    b.c(paramParcel, 5, paramChannelEventParcelable.anM);
    b.u(paramParcel, i);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.internal.ba
 * JD-Core Version:    0.6.2
 */