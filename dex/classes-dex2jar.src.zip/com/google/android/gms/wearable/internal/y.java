package com.google.android.gms.wearable.internal;

import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

final class y<T>
{
  private final Map<T, ap<T>> aoj = new HashMap();

  public final void a(ao paramao)
  {
    synchronized (this.aoj)
    {
      an.e locale = new an.e();
      Iterator localIterator = this.aoj.entrySet().iterator();
      while (true)
        if (localIterator.hasNext())
        {
          Map.Entry localEntry = (Map.Entry)localIterator.next();
          ap localap = (ap)localEntry.getValue();
          if (localap == null)
            continue;
          localap.aoD = null;
          localap.aoE = null;
          localap.aoF = null;
          localap.aoG = null;
          localap.aoH = null;
          localap.aoI = null;
          localap.aoJ = null;
          localap.aoK = null;
          boolean bool = paramao.isConnected();
          if (!bool)
            continue;
          try
          {
            ((x)paramao.gL()).a(locale, new RemoveListenerRequest(localap));
            if (Log.isLoggable("WearableClient", 2))
              new StringBuilder("disconnect: removed: ").append(localEntry.getKey()).append("/").append(localap);
          }
          catch (RemoteException localRemoteException)
          {
            new StringBuilder("disconnect: Didn't remove: ").append(localEntry.getKey()).append("/").append(localap);
          }
        }
    }
    this.aoj.clear();
  }

  public final void u(IBinder paramIBinder)
  {
    synchronized (this.aoj)
    {
      paramIBinder = x.a.t(paramIBinder);
      an.e locale = new an.e();
      Iterator localIterator = this.aoj.entrySet().iterator();
      while (true)
        if (localIterator.hasNext())
        {
          Map.Entry localEntry = (Map.Entry)localIterator.next();
          ap localap = (ap)localEntry.getValue();
          try
          {
            paramIBinder.a(locale, new AddListenerRequest(localap));
            if (Log.isLoggable("WearableClient", 2))
              new StringBuilder("onPostInitHandler: added: ").append(localEntry.getKey()).append("/").append(localap);
          }
          catch (RemoteException localRemoteException)
          {
            new StringBuilder("onPostInitHandler: Didn't add: ").append(localEntry.getKey()).append("/").append(localap);
          }
        }
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.internal.y
 * JD-Core Version:    0.6.2
 */