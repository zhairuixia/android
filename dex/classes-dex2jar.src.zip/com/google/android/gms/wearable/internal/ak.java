package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.b;

public final class ak
{
  public static Status ba(int paramInt)
  {
    String str;
    switch (paramInt)
    {
    default:
      str = b.au(paramInt);
    case 4000:
    case 4001:
    case 4002:
    case 4003:
    case 4004:
    case 4005:
    }
    while (true)
    {
      return new Status(paramInt, str);
      str = "TARGET_NODE_NOT_CONNECTED";
      continue;
      str = "DUPLICATE_LISTENER";
      continue;
      str = "UNKNOWN_LISTENER";
      continue;
      str = "DATA_ITEM_TOO_LARGE";
      continue;
      str = "INVALID_TARGET_NODE";
      continue;
      str = "ASSET_UNAVAILABLE";
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.internal.ak
 * JD-Core Version:    0.6.2
 */