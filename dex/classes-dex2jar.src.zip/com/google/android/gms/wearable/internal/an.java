package com.google.android.gms.wearable.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.k.b;
import com.google.android.gms.wearable.c.a;
import com.google.android.gms.wearable.c.c;
import com.google.android.gms.wearable.c.d;
import com.google.android.gms.wearable.j.b;
import com.google.android.gms.wearable.m.a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.FutureTask;

final class an
{
  static abstract class a<T> extends a
  {
    private k.b<T> aoq;

    public a(k.b<T> paramb)
    {
      this.aoq = paramb;
    }

    public final void af(T paramT)
    {
      k.b localb = this.aoq;
      if (localb != null)
      {
        localb.S(paramT);
        this.aoq = null;
      }
    }
  }

  static final class b extends an.a<c.c>
  {
    public b(k.b<c.c> paramb)
    {
      super();
    }

    public final void a(DeleteDataItemsResponse paramDeleteDataItemsResponse)
    {
      af(new bg.b(ak.ba(paramDeleteDataItemsResponse.statusCode), paramDeleteDataItemsResponse.anQ));
    }
  }

  static final class c extends an.a<m.a>
  {
    public c(k.b<m.a> paramb)
    {
      super();
    }

    public final void a(GetConnectedNodesResponse paramGetConnectedNodesResponse)
    {
      ArrayList localArrayList = new ArrayList();
      localArrayList.addAll(paramGetConnectedNodesResponse.anZ);
      af(new ac.a(ak.ba(paramGetConnectedNodesResponse.statusCode), localArrayList));
    }
  }

  static final class d extends an.a<c.d>
  {
    public d(k.b<c.d> paramb)
    {
      super();
    }

    public final void a(GetFdForAssetResponse paramGetFdForAssetResponse)
    {
      af(new bg.c(ak.ba(paramGetFdForAssetResponse.statusCode), paramGetFdForAssetResponse.aob));
    }
  }

  static final class e extends a
  {
    public final void f(Status paramStatus)
    {
    }
  }

  static final class f extends an.a<c.a>
  {
    private final List<FutureTask<Boolean>> aor;

    f(k.b<c.a> paramb, List<FutureTask<Boolean>> paramList)
    {
      super();
      this.aor = paramList;
    }

    public final void a(PutDataResponse paramPutDataResponse)
    {
      af(new bg.a(ak.ba(paramPutDataResponse.statusCode), paramPutDataResponse.aoa));
      if (paramPutDataResponse.statusCode != 0)
      {
        paramPutDataResponse = this.aor.iterator();
        while (paramPutDataResponse.hasNext())
          ((FutureTask)paramPutDataResponse.next()).cancel(true);
      }
    }
  }

  static final class g extends an.a<j.b>
  {
    public g(k.b<j.b> paramb)
    {
      super();
    }

    public final void a(SendMessageResponse paramSendMessageResponse)
    {
      af(new z.a(ak.ba(paramSendMessageResponse.statusCode), paramSendMessageResponse.aaM));
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.internal.an
 * JD-Core Version:    0.6.2
 */