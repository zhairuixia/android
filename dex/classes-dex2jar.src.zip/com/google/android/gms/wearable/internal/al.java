package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class al
  implements Parcelable.Creator<StorageInfoResponse>
{
  static void a(StorageInfoResponse paramStorageInfoResponse, Parcel paramParcel)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramStorageInfoResponse.versionCode);
    b.c(paramParcel, 2, paramStorageInfoResponse.statusCode);
    b.a(paramParcel, 3, paramStorageInfoResponse.aog);
    b.b(paramParcel, 4, paramStorageInfoResponse.aoh);
    b.u(paramParcel, i);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.internal.al
 * JD-Core Version:    0.6.2
 */