package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class bd
  implements Parcelable.Creator<ChannelSendFileResponse>
{
  static void a(ChannelSendFileResponse paramChannelSendFileResponse, Parcel paramParcel)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramChannelSendFileResponse.versionCode);
    b.c(paramParcel, 2, paramChannelSendFileResponse.statusCode);
    b.u(paramParcel, i);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.internal.bd
 * JD-Core Version:    0.6.2
 */