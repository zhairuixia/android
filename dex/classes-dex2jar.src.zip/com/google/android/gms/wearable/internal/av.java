package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class av
  implements Parcelable.Creator<AncsNotificationParcelable>
{
  static void a(AncsNotificationParcelable paramAncsNotificationParcelable, Parcel paramParcel)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramAncsNotificationParcelable.mVersionCode);
    b.c(paramParcel, 2, paramAncsNotificationParcelable.fk);
    b.a(paramParcel, 3, paramAncsNotificationParcelable.ahV);
    b.a(paramParcel, 4, paramAncsNotificationParcelable.anA);
    b.a(paramParcel, 5, paramAncsNotificationParcelable.anB);
    b.a(paramParcel, 6, paramAncsNotificationParcelable.anC);
    b.a(paramParcel, 7, paramAncsNotificationParcelable.anD);
    if (paramAncsNotificationParcelable.akh == null);
    for (String str = paramAncsNotificationParcelable.ahV; ; str = paramAncsNotificationParcelable.akh)
    {
      b.a(paramParcel, 8, str);
      b.a(paramParcel, 9, paramAncsNotificationParcelable.anE);
      b.a(paramParcel, 10, paramAncsNotificationParcelable.anF);
      b.a(paramParcel, 11, paramAncsNotificationParcelable.anG);
      b.a(paramParcel, 12, paramAncsNotificationParcelable.anH);
      b.u(paramParcel, i);
      return;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.internal.av
 * JD-Core Version:    0.6.2
 */