package com.google.android.gms.wearable.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.b;

public final class aa
  implements Parcelable.Creator<MessageEventParcelable>
{
  static void a(MessageEventParcelable paramMessageEventParcelable, Parcel paramParcel)
  {
    int i = b.t(paramParcel, 20293);
    b.c(paramParcel, 1, paramMessageEventParcelable.mVersionCode);
    b.c(paramParcel, 2, paramMessageEventParcelable.aod);
    b.a(paramParcel, 3, paramMessageEventParcelable.anO);
    b.a(paramParcel, 4, paramMessageEventParcelable.amG);
    b.a(paramParcel, 5, paramMessageEventParcelable.ahX);
    b.u(paramParcel, i);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.internal.aa
 * JD-Core Version:    0.6.2
 */