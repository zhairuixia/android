package com.google.android.gms.wearable.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.data.g;
import java.util.List;

public abstract interface w extends IInterface
{
  public abstract void a(DataHolder paramDataHolder);

  public abstract void a(AmsEntityUpdateParcelable paramAmsEntityUpdateParcelable);

  public abstract void a(AncsNotificationParcelable paramAncsNotificationParcelable);

  public abstract void a(CapabilityInfoParcelable paramCapabilityInfoParcelable);

  public abstract void a(ChannelEventParcelable paramChannelEventParcelable);

  public abstract void a(MessageEventParcelable paramMessageEventParcelable);

  public abstract void a(NodeParcelable paramNodeParcelable);

  public abstract void b(NodeParcelable paramNodeParcelable);

  public abstract void j(List<NodeParcelable> paramList);

  public static abstract class a extends Binder
    implements w
  {
    public a()
    {
      attachInterface(this, "com.google.android.gms.wearable.internal.IWearableListener");
    }

    public static w s(IBinder paramIBinder)
    {
      if (paramIBinder == null)
        return null;
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.google.android.gms.wearable.internal.IWearableListener");
      if ((localIInterface != null) && ((localIInterface instanceof w)))
        return (w)localIInterface;
      return new a(paramIBinder);
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
    {
      Object localObject2 = null;
      Object localObject3 = null;
      Object localObject4 = null;
      Object localObject5 = null;
      Object localObject6 = null;
      Object localObject7 = null;
      Object localObject8 = null;
      Object localObject1 = null;
      switch (paramInt1)
      {
      default:
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
        paramParcel2.writeString("com.google.android.gms.wearable.internal.IWearableListener");
        return true;
      case 1:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
        paramParcel2 = localObject1;
        if (paramParcel1.readInt() != 0)
        {
          paramParcel2 = DataHolder.CREATOR;
          paramParcel2 = g.a(paramParcel1);
        }
        a(paramParcel2);
        return true;
      case 2:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
        paramParcel2 = localObject2;
        if (paramParcel1.readInt() != 0)
          paramParcel2 = (MessageEventParcelable)MessageEventParcelable.CREATOR.createFromParcel(paramParcel1);
        a(paramParcel2);
        return true;
      case 3:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
        paramParcel2 = localObject3;
        if (paramParcel1.readInt() != 0)
          paramParcel2 = (NodeParcelable)NodeParcelable.CREATOR.createFromParcel(paramParcel1);
        a(paramParcel2);
        return true;
      case 4:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
        paramParcel2 = localObject4;
        if (paramParcel1.readInt() != 0)
          paramParcel2 = (NodeParcelable)NodeParcelable.CREATOR.createFromParcel(paramParcel1);
        b(paramParcel2);
        return true;
      case 5:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
        j(paramParcel1.createTypedArrayList(NodeParcelable.CREATOR));
        return true;
      case 6:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
        paramParcel2 = localObject5;
        if (paramParcel1.readInt() != 0)
          paramParcel2 = (AncsNotificationParcelable)AncsNotificationParcelable.CREATOR.createFromParcel(paramParcel1);
        a(paramParcel2);
        return true;
      case 7:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
        paramParcel2 = localObject6;
        if (paramParcel1.readInt() != 0)
          paramParcel2 = (ChannelEventParcelable)ChannelEventParcelable.CREATOR.createFromParcel(paramParcel1);
        a(paramParcel2);
        return true;
      case 8:
        paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
        paramParcel2 = localObject7;
        if (paramParcel1.readInt() != 0)
          paramParcel2 = (CapabilityInfoParcelable)CapabilityInfoParcelable.CREATOR.createFromParcel(paramParcel1);
        a(paramParcel2);
        return true;
      case 9:
      }
      paramParcel1.enforceInterface("com.google.android.gms.wearable.internal.IWearableListener");
      paramParcel2 = localObject8;
      if (paramParcel1.readInt() != 0)
        paramParcel2 = (AmsEntityUpdateParcelable)AmsEntityUpdateParcelable.CREATOR.createFromParcel(paramParcel1);
      a(paramParcel2);
      return true;
    }

    private static final class a
      implements w
    {
      private IBinder OH;

      a(IBinder paramIBinder)
      {
        this.OH = paramIBinder;
      }

      public final void a(DataHolder paramDataHolder)
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
          if (paramDataHolder != null)
          {
            localParcel.writeInt(1);
            paramDataHolder.writeToParcel(localParcel, 0);
          }
          while (true)
          {
            this.OH.transact(1, localParcel, null, 1);
            return;
            localParcel.writeInt(0);
          }
        }
        finally
        {
          localParcel.recycle();
        }
        throw paramDataHolder;
      }

      public final void a(AmsEntityUpdateParcelable paramAmsEntityUpdateParcelable)
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
          if (paramAmsEntityUpdateParcelable != null)
          {
            localParcel.writeInt(1);
            paramAmsEntityUpdateParcelable.writeToParcel(localParcel, 0);
          }
          while (true)
          {
            this.OH.transact(9, localParcel, null, 1);
            return;
            localParcel.writeInt(0);
          }
        }
        finally
        {
          localParcel.recycle();
        }
        throw paramAmsEntityUpdateParcelable;
      }

      public final void a(AncsNotificationParcelable paramAncsNotificationParcelable)
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
          if (paramAncsNotificationParcelable != null)
          {
            localParcel.writeInt(1);
            paramAncsNotificationParcelable.writeToParcel(localParcel, 0);
          }
          while (true)
          {
            this.OH.transact(6, localParcel, null, 1);
            return;
            localParcel.writeInt(0);
          }
        }
        finally
        {
          localParcel.recycle();
        }
        throw paramAncsNotificationParcelable;
      }

      public final void a(CapabilityInfoParcelable paramCapabilityInfoParcelable)
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
          if (paramCapabilityInfoParcelable != null)
          {
            localParcel.writeInt(1);
            paramCapabilityInfoParcelable.writeToParcel(localParcel, 0);
          }
          while (true)
          {
            this.OH.transact(8, localParcel, null, 1);
            return;
            localParcel.writeInt(0);
          }
        }
        finally
        {
          localParcel.recycle();
        }
        throw paramCapabilityInfoParcelable;
      }

      public final void a(ChannelEventParcelable paramChannelEventParcelable)
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
          if (paramChannelEventParcelable != null)
          {
            localParcel.writeInt(1);
            paramChannelEventParcelable.writeToParcel(localParcel, 0);
          }
          while (true)
          {
            this.OH.transact(7, localParcel, null, 1);
            return;
            localParcel.writeInt(0);
          }
        }
        finally
        {
          localParcel.recycle();
        }
        throw paramChannelEventParcelable;
      }

      public final void a(MessageEventParcelable paramMessageEventParcelable)
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
          if (paramMessageEventParcelable != null)
          {
            localParcel.writeInt(1);
            paramMessageEventParcelable.writeToParcel(localParcel, 0);
          }
          while (true)
          {
            this.OH.transact(2, localParcel, null, 1);
            return;
            localParcel.writeInt(0);
          }
        }
        finally
        {
          localParcel.recycle();
        }
        throw paramMessageEventParcelable;
      }

      public final void a(NodeParcelable paramNodeParcelable)
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
          if (paramNodeParcelable != null)
          {
            localParcel.writeInt(1);
            paramNodeParcelable.writeToParcel(localParcel, 0);
          }
          while (true)
          {
            this.OH.transact(3, localParcel, null, 1);
            return;
            localParcel.writeInt(0);
          }
        }
        finally
        {
          localParcel.recycle();
        }
        throw paramNodeParcelable;
      }

      public final IBinder asBinder()
      {
        return this.OH;
      }

      public final void b(NodeParcelable paramNodeParcelable)
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
          if (paramNodeParcelable != null)
          {
            localParcel.writeInt(1);
            paramNodeParcelable.writeToParcel(localParcel, 0);
          }
          while (true)
          {
            this.OH.transact(4, localParcel, null, 1);
            return;
            localParcel.writeInt(0);
          }
        }
        finally
        {
          localParcel.recycle();
        }
        throw paramNodeParcelable;
      }

      public final void j(List<NodeParcelable> paramList)
      {
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.google.android.gms.wearable.internal.IWearableListener");
          localParcel.writeTypedList(paramList);
          this.OH.transact(5, localParcel, null, 1);
          return;
        }
        finally
        {
          localParcel.recycle();
        }
        throw paramList;
      }
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.google.android.gms.wearable.internal.w
 * JD-Core Version:    0.6.2
 */