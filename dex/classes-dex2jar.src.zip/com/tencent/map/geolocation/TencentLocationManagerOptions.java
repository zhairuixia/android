package com.tencent.map.geolocation;

public class TencentLocationManagerOptions
{
  private static boolean a = true;

  public static boolean isLoadLibraryEnabled()
  {
    return a;
  }

  public static void setLoadLibraryEnabled(boolean paramBoolean)
  {
    a = paramBoolean;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.map.geolocation.TencentLocationManagerOptions
 * JD-Core Version:    0.6.2
 */