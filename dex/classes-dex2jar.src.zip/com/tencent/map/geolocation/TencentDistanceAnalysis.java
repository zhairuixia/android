package com.tencent.map.geolocation;

public abstract interface TencentDistanceAnalysis
{
  public abstract double getConfidence();

  public abstract int getGpsCount();

  public abstract int getNetworkCount();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.map.geolocation.TencentDistanceAnalysis
 * JD-Core Version:    0.6.2
 */