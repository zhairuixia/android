package com.tencent.map.geolocation.internal;

import android.util.Pair;

public abstract interface TencentHttpClient
{
  public abstract Pair<byte[], String> postSync(String paramString, byte[] paramArrayOfByte);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.map.geolocation.internal.TencentHttpClient
 * JD-Core Version:    0.6.2
 */