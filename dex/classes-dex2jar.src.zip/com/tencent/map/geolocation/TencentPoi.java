package com.tencent.map.geolocation;

public abstract interface TencentPoi
{
  public abstract String getAddress();

  public abstract String getCatalog();

  public abstract String getDirection();

  public abstract double getDistance();

  public abstract double getLatitude();

  public abstract double getLongitude();

  public abstract String getName();

  public abstract String getUid();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.map.geolocation.TencentPoi
 * JD-Core Version:    0.6.2
 */