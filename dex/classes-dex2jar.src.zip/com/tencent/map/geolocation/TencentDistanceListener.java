package com.tencent.map.geolocation;

public abstract interface TencentDistanceListener
{
  public abstract void onDistanceChanged(TencentLocation paramTencentLocation, double paramDouble, int paramInt, String paramString);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.map.geolocation.TencentDistanceListener
 * JD-Core Version:    0.6.2
 */