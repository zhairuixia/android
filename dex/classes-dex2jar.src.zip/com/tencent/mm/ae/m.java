package com.tencent.mm.ae;

import android.graphics.Bitmap;
import android.os.HandlerThread;
import com.tencent.mm.a.b;
import com.tencent.mm.ba.a;
import com.tencent.mm.bd.g;
import com.tencent.mm.e.b.bl;
import com.tencent.mm.model.ah;
import com.tencent.mm.model.ar;
import com.tencent.mm.model.at;
import com.tencent.mm.model.c;
import com.tencent.mm.model.h;
import com.tencent.mm.model.i;
import com.tencent.mm.modelsfs.FileOp;
import com.tencent.mm.plugin.report.service.f.a;
import com.tencent.mm.pointers.PInt;
import com.tencent.mm.pointers.PString;
import com.tencent.mm.sdk.platformtools.aa;
import com.tencent.mm.sdk.platformtools.ac;
import com.tencent.mm.sdk.platformtools.be;
import com.tencent.mm.sdk.platformtools.o;
import com.tencent.mm.sdk.platformtools.v;
import com.tencent.mm.storage.al;
import com.tencent.mm.storage.j;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import junit.framework.Assert;

public class m
{
  private static m cnK;
  ConcurrentHashMap<Long, d> cnI = new ConcurrentHashMap();
  public c cnJ = new c();
  public ConcurrentHashMap<Long, e> cnL = new ConcurrentHashMap();
  public ArrayList<Long> cnM = new ArrayList();
  ArrayList<e> cnN = new ArrayList();

  public static m Co()
  {
    if (cnK == null);
    try
    {
      if (cnK == null)
        cnK = new m();
      return cnK;
    }
    finally
    {
    }
  }

  private boolean Cp()
  {
    if ((this.cnN.size() > 0) && (f.a.awo().gIS <= 2))
    {
      v.i("MicroMsg.SendImgSpeeder", "cpu core is low ,do not use multi mode");
      return false;
    }
    return true;
  }

  private static int c(String paramString1, String paramString2, boolean paramBoolean)
  {
    if (h.b(paramString1, paramString2, paramBoolean))
      return 1;
    return 0;
  }

  private boolean ix(String paramString)
  {
    Iterator localIterator = this.cnN.iterator();
    while (localIterator.hasNext())
      if (((e)localIterator.next()).cob.equals(paramString))
        return true;
    return false;
  }

  public final void a(int paramInt1, int paramInt2, String paramString1, String paramString2, boolean paramBoolean, int paramInt3)
  {
    if (ix(paramString1))
      return;
    paramInt3 = c(paramString1, paramString2, paramBoolean);
    PString localPString = new PString();
    PInt localPInt1 = new PInt();
    PInt localPInt2 = new PInt();
    Object localObject1;
    b localb2;
    b localb1;
    if (Cp())
    {
      localObject1 = this.cnJ.ez(1);
      paramString2 = this.cnJ.ez(2);
      localb2 = ((b)localObject1).cnV;
      localb1 = paramString2.cnV;
      paramString2 = paramString2.cnW;
    }
    for (String str1 = ((b)localObject1).cnW; ; str1 = null)
    {
      f localf = n.Cx();
      if (!FileOp.aO(paramString1))
      {
        v.e("MicroMsg.ImgInfoStorage", "file not exit:%s", new Object[] { paramString1 });
        localObject1 = new e();
        ((e)localObject1).cob = paramString1;
        ((e)localObject1).clF = paramInt3;
        ((e)localObject1).aJJ = paramInt1;
        ((e)localObject1).aOy = paramInt2;
        ((e)localObject1).coc = paramString2;
        ((e)localObject1).cof = localPString;
        ((e)localObject1).coh = localPInt2;
        ((e)localObject1).cog = localPInt1;
        ((e)localObject1).cod = str1;
        ((e)localObject1).coj = localb1;
        ((e)localObject1).coi = localb2;
        if (cnK.Cp())
          a.a((e)localObject1);
        this.cnN.add(localObject1);
        v.i("MicroMsg.SendImgSpeeder", "summersafecdn img path %s has prebuild", new Object[] { paramString1 });
        return;
      }
      if (be.ky(paramString2));
      for (localObject1 = f.Cj(); ; localObject1 = paramString2)
      {
        localObject1 = "THUMBNAIL_DIRPATH://th_" + (String)localObject1;
        String str2 = localf.a((String)localObject1, "th_", "", false);
        localPString.value = ((String)localObject1);
        long l = be.ID();
        Bitmap localBitmap = localf.a(paramString1, paramInt3, paramInt2, localPInt1, localPInt2, false, null, null);
        localObject1 = (String)localf.cmg.get(paramString1);
        if (localObject1 != null);
        for (localObject1 = (Bitmap)localf.cmf.get(localObject1); ; localObject1 = null)
        {
          Object localObject2;
          if (localObject1 != null)
          {
            localObject2 = localObject1;
            if (!((Bitmap)localObject1).isRecycled());
          }
          else
          {
            localObject2 = localf.a(paramString1, true, a.getDensity(aa.getContext()), false, false, true, 2130837946, true, localBitmap);
            localf.cmg.put(paramString1, str2);
          }
          if (localObject2 != null)
            localf.cmf.h(str2, localObject2);
          v.i("MicroMsg.ImgInfoStorage", "test decode thumb img:%d", new Object[] { Long.valueOf(be.aA(l)) });
          break;
        }
      }
      localb1 = null;
      localb2 = null;
      paramString2 = null;
    }
  }

  public final void a(ArrayList<String> paramArrayList, boolean paramBoolean, int paramInt1, int paramInt2, String paramString)
  {
    v.d("MicroMsg.SendImgSpeeder", "summersafecdn sendThumbImg compressImg[%b], source[%d], stack[%s]", new Object[] { Boolean.valueOf(paramBoolean), Integer.valueOf(paramInt1), be.bdR() });
    Object localObject1 = this.cnN.iterator();
    Object localObject2;
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (e)((Iterator)localObject1).next();
      if (!paramArrayList.contains(((e)localObject2).cob))
        ((Iterator)localObject1).remove();
      else
        ((e)localObject2).clF = c(((e)localObject2).cob, paramString, paramBoolean);
    }
    localObject1 = new ArrayList();
    if (paramArrayList.size() == 9)
    {
      com.tencent.mm.plugin.report.service.f.lW(18);
      paramArrayList = paramArrayList.iterator();
    }
    while (true)
    {
      if (!paramArrayList.hasNext())
        break label312;
      localObject2 = (String)paramArrayList.next();
      if ((localObject2 == null) || (((String)localObject2).equals("")) || (!com.tencent.mm.a.e.aO((String)localObject2)))
      {
        v.d("MicroMsg.SendImgSpeeder", " doSendImage : filePath is null or empty");
        continue;
        if (paramArrayList.size() == 1)
        {
          boolean bool = com.tencent.mm.sdk.platformtools.ak.dJ(aa.getContext());
          com.tencent.mm.plugin.report.service.f.lW(25);
          if (!bool)
            break;
          if (h.b((String)paramArrayList.get(0), paramString, paramBoolean))
          {
            com.tencent.mm.plugin.report.service.f.lW(23);
            break;
          }
          com.tencent.mm.plugin.report.service.f.lW(21);
          break;
        }
        com.tencent.mm.plugin.report.service.f.lW(24);
        break;
      }
      if ((o.Fr((String)localObject2)) && (com.tencent.mm.a.e.aN((String)localObject2) < 524288))
        v.i("MicroMsg.SendImgSpeeder", "[cpan] is gif coutinue. did not add filePath:%s", new Object[] { localObject2 });
      else if (!ix((String)localObject2))
        ((ArrayList)localObject1).add(localObject2);
    }
    label312: paramArrayList = ((ArrayList)localObject1).iterator();
    while (paramArrayList.hasNext())
      a(paramInt1, paramInt2, (String)paramArrayList.next(), paramString, paramBoolean, 2130837946);
    paramArrayList = new ArrayList();
    long l1 = ah.vE().bUr.ec(Thread.currentThread().getId());
    ah.vE().tt().HM("SendImgSpeeder");
    paramInt1 = 0;
    while (paramInt1 < this.cnN.size())
    {
      localObject1 = (e)this.cnN.get(paramInt1);
      if ((o.Fr(((e)localObject1).cob)) && (com.tencent.mm.a.e.aN(((e)localObject1).cob) < 524288))
      {
        v.i("MicroMsg.SendImgSpeeder", "[cpan] is gif coutinue. did not add to msg table");
        paramInt1 += 1;
      }
      else
      {
        localObject2 = new com.tencent.mm.storage.ak();
        ((com.tencent.mm.storage.ak)localObject2).setType(i.fj(paramString));
        ((com.tencent.mm.storage.ak)localObject2).cE(paramString);
        ((com.tencent.mm.storage.ak)localObject2).bW(1);
        ((com.tencent.mm.storage.ak)localObject2).bV(1);
        ((com.tencent.mm.storage.ak)localObject2).cF(((e)localObject1).cof.value);
        ((com.tencent.mm.storage.ak)localObject2).cg(((e)localObject1).cog.value);
        ((com.tencent.mm.storage.ak)localObject2).ch(((e)localObject1).coh.value);
        String str = at.wl();
        if (((str != null) && (!str.equals(((bl)localObject2).brU))) || ((str == null) && (((bl)localObject2).brU != null)))
          ((com.tencent.mm.storage.ak)localObject2).cK(str);
        if (com.tencent.mm.v.f.hj(((bl)localObject2).field_talker))
          ((com.tencent.mm.storage.ak)localObject2).cK(com.tencent.mm.v.a.e.wl());
        ((com.tencent.mm.storage.ak)localObject2).z(ar.fK(((bl)localObject2).field_talker));
        paramArrayList.add(localObject2);
        long l2 = ah.vE().tt().I((com.tencent.mm.storage.ak)localObject2);
        if (l2 >= 0L);
        for (paramBoolean = true; ; paramBoolean = false)
        {
          Assert.assertTrue(paramBoolean);
          ((e)localObject1).aIe = l2;
          this.cnL.put(Long.valueOf(((e)localObject1).aIe), localObject1);
          this.cnM.add(Long.valueOf(((e)localObject1).aIe));
          break;
        }
      }
    }
    this.cnN.clear();
    if (l1 > 0L)
      ah.vE().bUr.ed(l1);
  }

  public final boolean al(long paramLong)
  {
    return this.cnI.containsKey(Long.valueOf(paramLong));
  }

  public final d am(long paramLong)
  {
    return (d)this.cnI.get(Long.valueOf(paramLong));
  }

  public static class a
  {
    static ac ayw;
    private ReentrantLock ayu = new ReentrantLock();
    private Condition ayv = this.ayu.newCondition();
    int clF;
    a cnO;

    public static a a(final m.e parame)
    {
      try
      {
        if (ayw == null)
        {
          localObject = new HandlerThread("big file gen Worker");
          ((HandlerThread)localObject).start();
          ayw = new ac(((HandlerThread)localObject).getLooper());
        }
        Object localObject = new a();
        parame.cok = ((a)localObject);
        a locala = parame.cok;
        ayw.post(new Runnable()
        {
          public final void run()
          {
            long l = System.currentTimeMillis();
            m.a.a locala = new m.a.a();
            locala.cnR = new PString();
            locala.cnS = new PString();
            locala.cnT = new PString();
            locala.cnU = new PString();
            String str = FileOp.jz(parame.cob);
            locala.clL = n.Cx().a(parame.cob, str, parame.clF, true, locala.cnR, locala.cnS, locala.cnT, locala.cnU, parame.cod, parame.coi);
            m.a.a(m.a.this).lock();
            try
            {
              m.a.this.cnO = locala;
              m.a.b(m.a.this).signal();
              v.i("MicroMsg.SendImgSpeeder", "notify big file gen prepared %s last %d", new Object[] { parame.cob, Long.valueOf(System.currentTimeMillis() - Long.valueOf(l).longValue()) });
              return;
            }
            finally
            {
              m.a.a(m.a.this).unlock();
            }
          }
        });
        ((a)localObject).clF = parame.clF;
        return localObject;
      }
      finally
      {
      }
      throw parame;
    }

    // ERROR //
    public final a Cq()
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 30	com/tencent/mm/ae/m$a:ayu	Ljava/util/concurrent/locks/ReentrantLock;
      //   4: invokevirtual 86	java/util/concurrent/locks/ReentrantLock:lock	()V
      //   7: aload_0
      //   8: getfield 88	com/tencent/mm/ae/m$a:cnO	Lcom/tencent/mm/ae/m$a$a;
      //   11: ifnonnull +35 -> 46
      //   14: ldc 90
      //   16: ldc 92
      //   18: invokestatic 98	com/tencent/mm/sdk/platformtools/v:i	(Ljava/lang/String;Ljava/lang/String;)V
      //   21: aload_0
      //   22: getfield 36	com/tencent/mm/ae/m$a:ayv	Ljava/util/concurrent/locks/Condition;
      //   25: invokeinterface 103 1 0
      //   30: goto -23 -> 7
      //   33: astore_1
      //   34: aload_0
      //   35: getfield 30	com/tencent/mm/ae/m$a:ayu	Ljava/util/concurrent/locks/ReentrantLock;
      //   38: invokevirtual 106	java/util/concurrent/locks/ReentrantLock:unlock	()V
      //   41: aload_0
      //   42: getfield 88	com/tencent/mm/ae/m$a:cnO	Lcom/tencent/mm/ae/m$a$a;
      //   45: areturn
      //   46: aload_0
      //   47: getfield 30	com/tencent/mm/ae/m$a:ayu	Ljava/util/concurrent/locks/ReentrantLock;
      //   50: invokevirtual 106	java/util/concurrent/locks/ReentrantLock:unlock	()V
      //   53: goto -12 -> 41
      //   56: astore_1
      //   57: aload_0
      //   58: getfield 30	com/tencent/mm/ae/m$a:ayu	Ljava/util/concurrent/locks/ReentrantLock;
      //   61: invokevirtual 106	java/util/concurrent/locks/ReentrantLock:unlock	()V
      //   64: aload_1
      //   65: athrow
      //
      // Exception table:
      //   from	to	target	type
      //   7	30	33	java/lang/Exception
      //   7	30	56	finally
    }

    public static final class a
    {
      String clL;
      PString cnR;
      PString cnS;
      PString cnT;
      PString cnU;
    }
  }

  private static final class b
  {
    b cnV;
    String cnW;
  }

  public static final class c
  {
    public LinkedList<m.b> cnX = new LinkedList();
    public LinkedList<m.b> cnY = new LinkedList();

    private void Cs()
    {
      while (true)
      {
        int i;
        try
        {
          StringBuilder localStringBuilder = new StringBuilder();
          i = 0;
          if (i < this.cnX.size())
          {
            localStringBuilder.append(((m.b)this.cnX.get(i)).cnW);
            if (i != this.cnX.size() - 1)
              localStringBuilder.append("-");
          }
          else
          {
            v.d("MicroMsg.SendImgSpeeder", "sync big des to file %s ", new Object[] { localStringBuilder.toString() });
            ah.vE().to().set(348176, localStringBuilder.toString());
            return;
          }
        }
        finally
        {
        }
        i += 1;
      }
    }

    private void Ct()
    {
      while (true)
      {
        int i;
        try
        {
          StringBuilder localStringBuilder = new StringBuilder();
          i = 0;
          if (i < this.cnY.size())
          {
            localStringBuilder.append(((m.b)this.cnY.get(i)).cnW);
            if (i != this.cnY.size() - 1)
              localStringBuilder.append("-");
          }
          else
          {
            v.d("MicroMsg.SendImgSpeeder", "sync thumb des to file %s ", new Object[] { localStringBuilder.toString() });
            ah.vE().to().set(348177, localStringBuilder.toString());
            return;
          }
        }
        finally
        {
        }
        i += 1;
      }
    }

    private static boolean iA(String paramString)
    {
      if (FileOp.js(paramString) > 0L)
      {
        v.e("MicroMsg.SendImgSpeeder", "file has exist %s", new Object[] { paramString });
        return false;
      }
      return true;
    }

    public static m.b iy(String paramString)
    {
      m.b localb = new m.b((byte)0);
      if (be.ky(paramString));
      for (localb.cnW = f.Cj(); ; localb.cnW = paramString)
      {
        paramString = n.Cx().a(localb.cnW, "", ".jpg", false);
        if (iA(paramString))
          break;
        return null;
      }
      localb.cnV = new b(paramString);
      return localb;
    }

    public static m.b iz(String paramString)
    {
      m.b localb = new m.b((byte)0);
      if (be.ky(paramString));
      for (localb.cnW = f.Cj(); ; localb.cnW = paramString)
      {
        paramString = n.Cx();
        String str = localb.cnW;
        paramString = paramString.a("THUMBNAIL_DIRPATH://th_" + str, "th_", "", false);
        if (iA(paramString))
          break;
        return null;
      }
      localb.cnV = new b(paramString);
      return localb;
    }

    public final void Cr()
    {
      int j = 0;
      try
      {
        int i = this.cnX.size();
        int k;
        m.b localb;
        if (i <= 0)
        {
          k = 5 - i;
          i = 0;
          while (i < k)
          {
            localb = iy(null);
            this.cnX.add(localb);
            i += 1;
          }
          v.i("MicroMsg.SendImgSpeeder", "add big File pool added size %d , all size %d", new Object[] { Integer.valueOf(k), Integer.valueOf(this.cnX.size()) });
          Cs();
        }
        i = this.cnY.size();
        if (i <= 0)
        {
          k = 5 - i;
          i = j;
          while (i < k)
          {
            localb = iz(null);
            this.cnY.add(localb);
            i += 1;
          }
          Ct();
          v.i("MicroMsg.SendImgSpeeder", "add big thumb pool added size %d , all size %d", new Object[] { Integer.valueOf(k), Integer.valueOf(this.cnY.size()) });
        }
        return;
      }
      finally
      {
      }
    }

    public final m.b ez(int paramInt)
    {
      m.b localb1 = null;
      if (paramInt == 1);
      while (true)
      {
        try
        {
          if (this.cnX.size() > 0)
          {
            localb1 = (m.b)this.cnX.remove();
            Cs();
            Cr();
            return localb1;
          }
          localb1 = iy(null);
          continue;
          if (paramInt != 2)
            continue;
          if (this.cnY.size() > 0)
          {
            localb1 = (m.b)this.cnY.remove();
            Ct();
            continue;
          }
        }
        finally
        {
        }
        m.b localb2 = iz(null);
      }
    }
  }

  public static final class d
  {
    public long cnZ;
    public long coa;
  }

  public static final class e
  {
    public long aIe;
    public int aJJ;
    public int aOy;
    public int clF;
    public String cob;
    public String coc;
    public String cod;
    public long coe;
    PString cof;
    PInt cog;
    PInt coh;
    public b coi;
    public b coj;
    public m.a cok;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.m
 * JD-Core Version:    0.6.2
 */