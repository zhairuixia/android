package com.tencent.mm.ae;

import android.graphics.Bitmap;
import com.tencent.mm.cache.a.a;
import com.tencent.mm.sdk.i.e;
import com.tencent.mm.sdk.platformtools.ad;
import com.tencent.mm.sdk.platformtools.be;
import com.tencent.mm.sdk.platformtools.d;
import com.tencent.mm.sdk.platformtools.v;
import java.util.HashMap;

public final class b
{
  private HashMap<String, c> cll = new HashMap();

  public static void e(String paramString, Bitmap paramBitmap)
  {
    if ((paramString == null) || (paramString.length() == 0))
    {
      v.e("MicroMsg.CdnImageService", "push fail, key is null");
      return;
    }
    a.a.a("local_cdn_img_cache", paramString, paramBitmap);
  }

  public static Bitmap im(String paramString)
  {
    if ((paramString == null) || (paramString.length() == 0))
    {
      v.e("MicroMsg.CdnImageService", "get fail, key is null");
      return null;
    }
    return (Bitmap)a.a.u("local_cdn_img_cache", paramString);
  }

  public final void a(String paramString, c paramc)
  {
    if (be.ky(paramString))
      v.w("MicroMsg.CdnImageService", "do load fail, url is empty");
    Bitmap localBitmap;
    do
    {
      return;
      localBitmap = im(paramString);
      if ((localBitmap == null) || (localBitmap.isRecycled()))
        break;
      v.i("MicroMsg.CdnImageService", "do load ok, url[%s], bitmap exists", new Object[] { paramString });
    }
    while (paramc == null);
    paramc.h(localBitmap);
    return;
    if (localBitmap == null);
    for (boolean bool = true; ; bool = false)
    {
      v.w("MicroMsg.CdnImageService", "try to download: url[%s], src bitmap is null[%B]", new Object[] { paramString, Boolean.valueOf(bool) });
      if (!this.cll.containsKey(paramString))
        break;
      v.w("MicroMsg.CdnImageService", "contains url[%s]", new Object[] { paramString });
      return;
    }
    this.cll.put(paramString, paramc);
    e.a(new b(paramString, this.cll), "CdnImageService_download");
  }

  protected final void finalize()
  {
    super.finalize();
  }

  public final void in(String paramString)
  {
    if (be.ky(paramString))
    {
      v.w("MicroMsg.CdnImageService", "stop load fail, url is empty");
      return;
    }
    this.cll.remove(paramString);
  }

  static final class a
    implements Runnable
  {
    private HashMap<String, b.c> cll;
    private Bitmap clm;
    private String url;

    public a(String paramString, Bitmap paramBitmap, HashMap<String, b.c> paramHashMap)
    {
      this.url = paramString;
      this.clm = paramBitmap;
      this.cll = paramHashMap;
    }

    public final void run()
    {
      n.Cw();
      b.e(this.url, this.clm);
      if (this.cll != null)
      {
        localObject = (b.c)this.cll.remove(this.url);
        if (localObject != null)
          ((b.c)localObject).h(this.clm);
      }
      if (this.url == null);
      for (Object localObject = "null"; ; localObject = this.url)
      {
        v.i("MicroMsg.CdnImageService", "finish download post job, url[%s]", new Object[] { localObject });
        return;
      }
    }
  }

  static final class b
    implements Runnable
  {
    private HashMap<String, b.c> cll;
    private String url;

    b(String paramString, HashMap<String, b.c> paramHashMap)
    {
      this.url = paramString;
      this.cll = paramHashMap;
    }

    public final void run()
    {
      Object localObject1 = be.Gh(this.url);
      if (localObject1 == null)
      {
        v.w("MicroMsg.CdnImageService", "download fail: url[%s] data is null", new Object[] { this.url });
        return;
      }
      try
      {
        localObject1 = d.ba((byte[])localObject1);
        v.i("MicroMsg.CdnImageService", "download finish, url[%s], do post job", new Object[] { this.url });
        ad.l(new b.a(this.url, (Bitmap)localObject1, this.cll));
        return;
      }
      catch (Exception localException)
      {
        while (true)
        {
          v.w("MicroMsg.CdnImageService", "download fail: url[%s] decode bitmap error[%s]", new Object[] { this.url, localException.getLocalizedMessage() });
          Object localObject2 = null;
        }
      }
    }
  }

  public static abstract interface c
  {
    public abstract void h(Bitmap paramBitmap);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.b
 * JD-Core Version:    0.6.2
 */