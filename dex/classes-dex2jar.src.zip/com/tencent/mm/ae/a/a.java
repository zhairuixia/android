package com.tencent.mm.ae.a;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Looper;
import android.widget.ImageView;
import com.tencent.mm.ae.a.c.e;
import com.tencent.mm.ae.a.c.h;
import com.tencent.mm.ae.a.c.i;
import com.tencent.mm.ae.a.c.j;
import com.tencent.mm.ae.a.c.l;
import com.tencent.mm.sdk.platformtools.ac;
import com.tencent.mm.sdk.platformtools.be;
import com.tencent.mm.sdk.platformtools.v;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

public final class a
{
  public b coE;
  private com.tencent.mm.ae.a.a.b coF;
  private final i coG = new com.tencent.mm.ae.a.b.g();

  public a(Context paramContext)
  {
    a(com.tencent.mm.ae.a.a.b.aP(paramContext));
  }

  public a(com.tencent.mm.ae.a.a.b paramb)
  {
    a(paramb);
  }

  private void a(ImageView paramImageView, com.tencent.mm.ae.a.a.c paramc)
  {
    if ((paramImageView == null) || (paramc == null))
      v.w("MicroMsg.imageloader.ImageLoader", "[cpan] should show default image view or options is null.");
    label70: label76: label92: 
    do
    {
      return;
      int i;
      Object localObject;
      if ((paramc.cpE > 0) || (paramc.cpF != null))
      {
        i = 1;
        if (i == 0)
          break label160;
        if (paramc.cpE != 0)
          break label149;
        localObject = this.coF.coX;
        if (paramc.cpE == 0)
          break label140;
        localObject = ((Resources)localObject).getDrawable(paramc.cpE);
        paramImageView.setBackgroundDrawable((Drawable)localObject);
        if ((paramc.cpA <= 0) && (paramc.cpB == null))
          break label168;
        i = 1;
        if (i == 0)
          continue;
        if (paramc.cpA != 0)
          break label181;
        localObject = this.coF.coX;
        if (paramc.cpA == 0)
          break label173;
      }
      for (paramc = ((Resources)localObject).getDrawable(paramc.cpA); ; paramc = paramc.cpB)
      {
        paramImageView.setImageDrawable(paramc);
        return;
        i = 0;
        break;
        localObject = paramc.cpF;
        break label70;
        paramImageView.setBackgroundResource(paramc.cpE);
        break label76;
        paramImageView.setBackgroundDrawable(null);
        break label76;
        i = 0;
        break label92;
      }
      paramImageView.setImageResource(paramc.cpA);
      return;
    }
    while (!paramc.cpH);
    label140: label149: label160: label168: label173: label181: paramImageView.setImageDrawable(null);
  }

  private void a(com.tencent.mm.ae.a.a.b paramb)
  {
    if (paramb == null)
      try
      {
        throw new IllegalArgumentException("[cpan] image loader configuration is null.");
      }
      finally
      {
      }
    if (this.coF == null)
    {
      this.coE = new b(paramb);
      this.coF = paramb;
    }
    while (true)
    {
      return;
      v.w("MicroMsg.imageloader.ImageLoader", "[cpan] image loader had init.");
    }
  }

  public final void a(String paramString, ImageView paramImageView)
  {
    a(paramString, paramImageView, null, null, null, null, null, null);
  }

  public final void a(String paramString, ImageView paramImageView, com.tencent.mm.ae.a.a.c paramc)
  {
    a(paramString, paramImageView, paramc, null, null, null, null, null);
  }

  public final void a(String paramString, ImageView paramImageView, com.tencent.mm.ae.a.a.c paramc, e parame, com.tencent.mm.ae.a.c.d paramd)
  {
    a(paramString, paramImageView, paramc, null, null, null, parame, paramd);
  }

  public final void a(String paramString, ImageView paramImageView, com.tencent.mm.ae.a.a.c paramc, com.tencent.mm.ae.a.c.g paramg)
  {
    a(paramString, paramImageView, paramc, null, null, paramg, null, null);
  }

  public final void a(String paramString, ImageView paramImageView, com.tencent.mm.ae.a.a.c paramc, i parami)
  {
    a(paramString, paramImageView, paramc, parami, null, null, null, null);
  }

  public final void a(String paramString, ImageView paramImageView, com.tencent.mm.ae.a.a.c paramc, i parami, j paramj, com.tencent.mm.ae.a.c.g paramg, e parame, com.tencent.mm.ae.a.c.d paramd)
  {
    if (paramc == null)
      paramc = this.coF.cpa;
    while (true)
    {
      if (parami == null)
        parami = this.coG;
      while (true)
      {
        c localc = new c(paramImageView, paramString);
        if (be.ky(paramString))
        {
          v.w("MicroMsg.imageloader.ImageLoader", "[cpan load image url is null.]");
          a(paramImageView, paramc);
          this.coE.a(localc);
          parami.a(paramString, null, paramc.cpM);
        }
        label561: 
        while (true)
        {
          return;
          ac localac = paramc.handler;
          if ((localac == null) || (Looper.myLooper() == Looper.getMainLooper()))
            localac = new ac();
          parami = new com.tencent.mm.ae.a.f.b(paramString, localc, localac, paramc, parami, paramj, this.coE, paramg, parame, paramd);
          paramj = parami.iM(paramString);
          parame = this.coE.iG(paramj);
          if ((paramImageView != null) && (parame != null) && (!parame.isRecycled()))
          {
            v.d("MicroMsg.imageloader.ImageLoader", "[cpan] load from cache. not need to load:%s", new Object[] { paramj });
            paramImageView.setImageBitmap(parame);
            parami.an(0L);
            if (paramg != null)
              paramg.a(paramString, paramImageView, new com.tencent.mm.ae.a.d.b(parame));
            this.coE.a(localc);
            return;
          }
          if (paramImageView != null)
            a(paramImageView, paramc);
          if ((parami.cpa.cpo) || (!this.coE.coI.lU()))
          {
            paramImageView = this.coE;
            if (!be.ky(paramString))
            {
              paramj = (String)paramImageView.coK.get(Integer.valueOf(localc.CJ()));
              if ((be.ky(paramj)) || (!paramString.equals(paramj)))
                paramImageView.coK.put(Integer.valueOf(localc.CJ()), paramString);
            }
            for (int i = 1; ; i = 0)
            {
              if (i == 0)
                break label561;
              paramString = this.coE;
              if ((paramString.coL != null) && (parami.cpU != null))
              {
                paramImageView = (com.tencent.mm.ae.a.f.b)paramString.coL.get(Integer.valueOf(parami.cpU.CJ()));
                if ((paramImageView != null) && (paramImageView.cpU != null) && (parami.cpU.CJ() == paramImageView.cpU.CJ()))
                {
                  paramString.coI.remove(paramImageView);
                  v.d("MicroMsg.imageloader.ImageLoaderManager", "remove taks url:%s", new Object[] { paramImageView.url });
                }
                paramString.coL.put(Integer.valueOf(parami.cpU.CJ()), parami);
              }
              paramString = this.coE;
              boolean bool = paramc.cpm;
              if (((ExecutorService)paramString.coH.cpi).isShutdown())
                paramString.coI = com.tencent.mm.ae.a.a.a.X(paramString.coH.coY, paramString.coH.coZ);
              paramString.coI.execute(parami);
              if ((!bool) || (!com.tencent.mm.ae.a.g.b.CP()))
                break;
              paramString.coJ.execute(new com.tencent.mm.ae.a.f.d());
              return;
            }
          }
        }
      }
    }
  }

  public final void a(String paramString, ImageView paramImageView, com.tencent.mm.ae.a.c.g paramg)
  {
    a(paramString, paramImageView, null, null, null, paramg, null, null);
  }

  public final void a(String paramString, com.tencent.mm.ae.a.a.c paramc, com.tencent.mm.ae.a.c.c paramc1)
  {
    paramString = new com.tencent.mm.ae.a.f.a(paramString, paramc, this.coE, paramc1);
    this.coE.coI.execute(paramString);
  }

  public final void b(String paramString, ImageView paramImageView, com.tencent.mm.ae.a.a.c paramc, com.tencent.mm.ae.a.c.g paramg)
  {
    a(paramString, paramImageView, paramc, null, null, paramg, null, null);
  }

  public final void detach()
  {
    if (this.coE != null)
    {
      b localb = this.coE;
      if (localb.coH != null)
      {
        localb.coH.cpb.clear();
        localb.coH.cpc.CN();
      }
    }
  }

  public final void eC(int paramInt)
  {
    v.d("MicroMsg.imageloader.ImageLoader", "[cpan] on scroll state changed :%d", new Object[] { Integer.valueOf(paramInt) });
    if ((paramInt == 0) || (paramInt == 1))
    {
      v.d("MicroMsg.imageloader.ImageLoader", "[cpan] resume");
      this.coE.coI.resume();
      return;
    }
    v.d("MicroMsg.imageloader.ImageLoader", "[cpan] pause");
    this.coE.coI.pause();
  }

  public final void f(String paramString, Bitmap paramBitmap)
  {
    if (this.coE != null)
    {
      b localb = this.coE;
      if (localb.coH != null)
        localb.coH.cpb.g(paramString, paramBitmap);
    }
  }

  public final Bitmap iG(String paramString)
  {
    if (this.coE != null)
      return this.coE.iG(paramString);
    return null;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.a
 * JD-Core Version:    0.6.2
 */