package com.tencent.mm.ae.a.a;

import android.graphics.drawable.Drawable;
import com.tencent.mm.ae.a.c.b;
import com.tencent.mm.modelsfs.SFSContext;
import com.tencent.mm.sdk.platformtools.ac;

public final class c
{
  public final String aHq;
  public final String aLL;
  public final float alpha;
  public final int cpA;
  public final Drawable cpB;
  private final int cpC;
  private final Drawable cpD;
  public final int cpE;
  public final Drawable cpF;
  public final SFSContext cpG;
  public final boolean cpH;
  public final boolean cpI;
  public final float cpJ;
  public final boolean cpK;
  public final boolean cpL;
  public final Object[] cpM;
  public final b cpd;
  public final boolean cpl;
  public final boolean cpm;
  public final boolean cpn;
  public final boolean cpo;
  public final String cpp;
  public final String cpq;
  public final String cpr;
  public final int cps;
  public final int cpt;
  public final int cpu;
  public final boolean cpv;
  public final boolean cpw;
  public final boolean cpx;
  public final boolean cpy;
  public final boolean cpz;
  public final int density;
  public final ac handler;

  private c(a parama)
  {
    this.cpl = parama.cpl;
    this.cpn = parama.cpn;
    this.cpm = parama.cpm;
    this.cpo = parama.cpo;
    this.cpp = parama.cpp;
    this.cpq = parama.cpq;
    this.cpr = parama.cpr;
    this.cps = parama.cps;
    this.cpt = parama.cpt;
    this.cpu = parama.cpu;
    this.cpv = parama.cpv;
    this.aHq = parama.aHq;
    this.density = parama.density;
    this.alpha = parama.alpha;
    this.cpw = parama.cpw;
    this.aLL = parama.aLL;
    this.cpx = parama.cpx;
    this.cpy = parama.cpy;
    this.cpz = parama.cpz;
    this.cpA = parama.cpA;
    this.cpB = parama.cpB;
    this.cpC = parama.cpC;
    this.cpD = parama.cpD;
    this.cpE = parama.cpE;
    this.cpF = parama.cpF;
    this.cpH = parama.cpH;
    this.cpI = parama.cpI;
    this.cpJ = parama.cpJ;
    this.cpK = parama.cpK;
    this.cpL = parama.cpL;
    this.cpG = parama.cpG;
    this.handler = parama.handler;
    this.cpM = parama.cpM;
    this.cpd = parama.cpd;
  }

  public static final class a
  {
    public String aHq = "";
    public String aLL;
    float alpha = 0.0F;
    public int cpA = 0;
    public Drawable cpB = null;
    int cpC = 0;
    Drawable cpD = null;
    public int cpE = 0;
    Drawable cpF = null;
    public SFSContext cpG = null;
    public boolean cpH = true;
    public boolean cpI = false;
    public float cpJ = 0.0F;
    public boolean cpK = false;
    public boolean cpL = true;
    public Object[] cpM = null;
    public b cpd = null;
    public boolean cpl = true;
    public boolean cpm = false;
    public boolean cpn = false;
    public boolean cpo = true;
    public String cpp = "";
    public String cpq = "";
    String cpr = "";
    public int cps = 5;
    public int cpt = 0;
    public int cpu = 0;
    public boolean cpv = false;
    public boolean cpw = false;
    public boolean cpx;
    public boolean cpy = false;
    public boolean cpz = false;
    int density = 0;
    ac handler = null;

    public final a CL()
    {
      this.cpm = true;
      return this;
    }

    public final c CM()
    {
      return new c(this, (byte)0);
    }

    public final a Y(int paramInt1, int paramInt2)
    {
      this.cpt = paramInt1;
      this.cpu = paramInt2;
      return this;
    }

    public final a a(SFSContext paramSFSContext)
    {
      this.cpG = paramSFSContext;
      return this;
    }

    public final a aO(boolean paramBoolean)
    {
      this.cpl = true;
      return this;
    }

    public final a aP(boolean paramBoolean)
    {
      this.cpn = true;
      return this;
    }

    public final a aQ(boolean paramBoolean)
    {
      this.cpI = paramBoolean;
      return this;
    }

    public final a iH(String paramString)
    {
      this.cpp = paramString;
      return this;
    }

    public final a iI(String paramString)
    {
      this.cpq = paramString;
      return this;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.a.c
 * JD-Core Version:    0.6.2
 */