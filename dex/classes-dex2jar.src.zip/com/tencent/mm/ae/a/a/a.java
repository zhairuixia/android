package com.tencent.mm.ae.a.a;

import com.tencent.mm.ae.a.c.h;
import com.tencent.mm.sdk.platformtools.v;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public final class a
{
  public static h X(int paramInt1, int paramInt2)
  {
    com.tencent.mm.ae.a.e.a locala = new com.tencent.mm.ae.a.e.a();
    return new a(paramInt1, paramInt1, TimeUnit.MILLISECONDS, locala, new b(paramInt2, "image_loader_"));
  }

  private static final class a extends ThreadPoolExecutor
    implements h
  {
    private boolean coN;
    private ReentrantLock coO = new ReentrantLock();
    private Condition coP = this.coO.newCondition();
    private BlockingQueue<Runnable> coQ;

    public a(int paramInt1, int paramInt2, TimeUnit paramTimeUnit, BlockingQueue<Runnable> paramBlockingQueue, ThreadFactory paramThreadFactory)
    {
      super(paramInt2, 0L, paramTimeUnit, paramBlockingQueue, paramThreadFactory);
      this.coQ = paramBlockingQueue;
    }

    protected final void beforeExecute(Thread paramThread, Runnable paramRunnable)
    {
      super.beforeExecute(paramThread, paramRunnable);
      this.coO.lock();
      try
      {
        while (this.coN)
          this.coP.await();
      }
      catch (Exception paramRunnable)
      {
        paramThread.interrupt();
        v.w("MicroMsg.imageloader.DefalutThreadPoolExecutor", "[cpan] before execute exception:%s", new Object[] { paramRunnable.toString() });
        return;
        return;
      }
      finally
      {
        this.coO.unlock();
      }
      throw paramThread;
    }

    public final void execute(Runnable paramRunnable)
    {
      super.execute(paramRunnable);
    }

    public final boolean lU()
    {
      return this.coN;
    }

    public final void pause()
    {
      this.coO.lock();
      try
      {
        this.coN = true;
        return;
      }
      finally
      {
        this.coO.unlock();
      }
    }

    public final void remove(Object paramObject)
    {
      if (this.coQ != null)
        this.coQ.remove(paramObject);
    }

    public final void resume()
    {
      this.coO.lock();
      try
      {
        this.coN = false;
        this.coP.signalAll();
        return;
      }
      finally
      {
        this.coO.unlock();
      }
    }
  }

  private static final class b
    implements ThreadFactory
  {
    private static final AtomicInteger coR = new AtomicInteger(1);
    private final ThreadGroup coS;
    private final AtomicInteger coT = new AtomicInteger(1);
    private final String coU;
    private final int coV;

    b(int paramInt, String paramString)
    {
      this.coV = paramInt;
      Object localObject = System.getSecurityManager();
      if (localObject != null);
      for (localObject = ((SecurityManager)localObject).getThreadGroup(); ; localObject = Thread.currentThread().getThreadGroup())
      {
        this.coS = ((ThreadGroup)localObject);
        this.coU = (paramString + coR.getAndIncrement() + "-thread-");
        return;
      }
    }

    public final Thread newThread(Runnable paramRunnable)
    {
      paramRunnable = new Thread(this.coS, paramRunnable, this.coU + this.coT.getAndIncrement(), 0L);
      if (paramRunnable.isDaemon())
        paramRunnable.setDaemon(false);
      paramRunnable.setPriority(this.coV);
      return paramRunnable;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.a.a
 * JD-Core Version:    0.6.2
 */