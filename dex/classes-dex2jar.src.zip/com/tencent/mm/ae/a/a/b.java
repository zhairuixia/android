package com.tencent.mm.ae.a.a;

import android.content.Context;
import android.content.res.Resources;
import com.tencent.mm.ae.a.b.d;
import com.tencent.mm.ae.a.c.j;
import com.tencent.mm.ae.a.c.k;
import com.tencent.mm.ae.a.c.l;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public final class b
{
  public static final int coW = Runtime.getRuntime().availableProcessors();
  public final Resources coX;
  public final int coY;
  public final int coZ;
  public final c cpa;
  public final l cpb;
  public final com.tencent.mm.ae.a.c.a cpc;
  public final com.tencent.mm.ae.a.c.b cpd;
  public final com.tencent.mm.ae.a.c.f cpe;
  public final j cpf;
  public final k cpg;
  public final com.tencent.mm.ae.a.c.e cph;
  public final com.tencent.mm.ae.a.c.h cpi;
  public final Executor cpj;
  public final String packageName;

  public b(a parama)
  {
    this.packageName = parama.context.getPackageName();
    this.coX = parama.context.getResources();
    this.coY = parama.coY;
    this.coZ = parama.coZ;
    this.cpa = parama.cpa;
    this.cpb = parama.cpb;
    this.cpc = parama.cpc;
    this.cpd = parama.cpd;
    this.cpe = parama.cpe;
    this.cpf = parama.cpf;
    this.cpi = parama.cpi;
    this.cpj = parama.cpj;
    this.cpg = parama.cpk;
    this.cph = parama.cph;
  }

  public static b aP(Context paramContext)
  {
    return new a(paramContext).CK();
  }

  public static final class a
  {
    int coY = b.coW;
    int coZ = 5;
    Context context;
    c cpa = null;
    public l cpb = null;
    com.tencent.mm.ae.a.c.a cpc = null;
    public com.tencent.mm.ae.a.c.b cpd = null;
    com.tencent.mm.ae.a.c.f cpe = null;
    j cpf = null;
    com.tencent.mm.ae.a.c.e cph = null;
    com.tencent.mm.ae.a.c.h cpi = null;
    Executor cpj;
    k cpk = null;

    public a(Context paramContext)
    {
      this.context = paramContext.getApplicationContext();
    }

    public final b CK()
    {
      if (this.cpa == null)
        this.cpa = new c.a().CM();
      if (this.cpb == null)
        this.cpb = new com.tencent.mm.ae.a.b.f();
      if (this.cpc == null)
        this.cpc = new com.tencent.mm.ae.a.b.a();
      if (this.cpd == null)
        this.cpd = new com.tencent.mm.ae.a.b.b();
      if (this.cpe == null)
        this.cpe = new d();
      if (this.cpf == null)
        this.cpf = new com.tencent.mm.ae.a.b.h();
      if (this.cpi == null)
        this.cpi = a.X(this.coY, this.coZ);
      if (this.cpj == null)
        this.cpj = Executors.newSingleThreadExecutor();
      if (this.cpk == null)
        this.cpk = new com.tencent.mm.ae.a.b.e();
      if (this.cph == null)
        this.cph = new com.tencent.mm.ae.a.b.c();
      return new b(this);
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.a.b
 * JD-Core Version:    0.6.2
 */