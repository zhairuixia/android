package com.tencent.mm.ae.a.e;

import java.util.concurrent.LinkedBlockingDeque;

public final class a<E> extends LinkedBlockingDeque<E>
{
  public final boolean offer(E paramE)
  {
    return super.offerFirst(paramE);
  }

  public final E remove()
  {
    return super.removeFirst();
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.e.a
 * JD-Core Version:    0.6.2
 */