package com.tencent.mm.ae.a.d;

import com.tencent.mm.a.f;
import java.util.Map;

public final class a<K, V>
{
  private f<K, V> cpQ;

  public a(int paramInt)
  {
    this.cpQ = new f(paramInt);
  }

  public final void clear()
  {
    if (this.cpQ == null)
      throw new NullPointerException("mData == null");
    this.cpQ.trimToSize(-1);
  }

  public final V get(K paramK)
  {
    if (this.cpQ == null)
      throw new NullPointerException("mData == null");
    return this.cpQ.get(paramK);
  }

  public final V put(K paramK, V paramV)
  {
    if (this.cpQ == null)
      throw new NullPointerException("mData == null");
    return this.cpQ.put(paramK, paramV);
  }

  public final Map<K, V> snapshot()
  {
    try
    {
      if (this.cpQ == null)
        throw new NullPointerException("mData == null");
    }
    finally
    {
    }
    Map localMap = this.cpQ.snapshot();
    return localMap;
  }

  public final String toString()
  {
    try
    {
      if (this.cpQ == null)
        throw new NullPointerException("mData == null");
    }
    finally
    {
    }
    String str = this.cpQ.toString();
    return str;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.d.a
 * JD-Core Version:    0.6.2
 */