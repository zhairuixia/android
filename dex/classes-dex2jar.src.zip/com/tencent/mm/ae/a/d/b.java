package com.tencent.mm.ae.a.d;

import android.graphics.Bitmap;

public final class b
{
  public String aYU;
  public Bitmap bitmap;
  public int cpR;
  public byte[] data;
  public int status;

  public b()
  {
    this.status = -1;
  }

  public b(Bitmap paramBitmap)
  {
    this.status = 0;
    this.cpR = 0;
    this.bitmap = paramBitmap;
  }

  public b(byte[] paramArrayOfByte, String paramString)
  {
    this.data = paramArrayOfByte;
    this.aYU = paramString;
  }

  public b(byte[] paramArrayOfByte, String paramString, byte paramByte)
  {
    this.data = paramArrayOfByte;
    this.cpR = 2;
    this.aYU = paramString;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.d.b
 * JD-Core Version:    0.6.2
 */