package com.tencent.mm.ae.a;

import android.graphics.Bitmap;
import com.tencent.mm.ae.a.c.a;
import com.tencent.mm.ae.a.c.h;
import com.tencent.mm.ae.a.c.l;
import com.tencent.mm.sdk.platformtools.v;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;

public final class b
{
  public com.tencent.mm.ae.a.a.b coH;
  h coI;
  Executor coJ;
  public final Map<Integer, String> coK = Collections.synchronizedMap(new HashMap());
  public HashMap<Integer, com.tencent.mm.ae.a.f.b> coL = new HashMap();

  public b(com.tencent.mm.ae.a.a.b paramb)
  {
    this.coH = paramb;
    this.coI = paramb.cpi;
    this.coJ = paramb.cpj;
    this.coH.cpc.a(this.coH.cpe);
  }

  public final void a(c paramc)
  {
    this.coK.remove(Integer.valueOf(paramc.CJ()));
    v.d("MicroMsg.imageloader.ImageLoaderManager", "[cpan] remove image weak holder size:%d viewcode:%s", new Object[] { Integer.valueOf(this.coK.size()), Integer.valueOf(paramc.CJ()) });
  }

  public final Bitmap iG(String paramString)
  {
    if (this.coH != null)
      return this.coH.cpb.im(paramString);
    return null;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.b
 * JD-Core Version:    0.6.2
 */