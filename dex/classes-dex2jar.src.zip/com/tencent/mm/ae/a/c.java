package com.tencent.mm.ae.a;

import android.view.View;
import android.widget.ImageView;
import java.lang.ref.WeakReference;

public final class c
{
  public WeakReference<ImageView> coM;
  public int height = 0;
  private String url = "";
  public int width = 0;

  public c(ImageView paramImageView, String paramString)
  {
    this.coM = new WeakReference(paramImageView);
    this.url = paramString;
  }

  public final ImageView CI()
  {
    if (this.coM != null)
    {
      ImageView localImageView = (ImageView)this.coM.get();
      if (localImageView != null)
        return localImageView;
    }
    return null;
  }

  public final int CJ()
  {
    View localView = null;
    if (this.coM != null)
      localView = (View)this.coM.get();
    if (localView == null)
      return super.hashCode();
    return localView.hashCode();
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.c
 * JD-Core Version:    0.6.2
 */