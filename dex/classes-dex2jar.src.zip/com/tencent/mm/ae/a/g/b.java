package com.tencent.mm.ae.a.g;

import com.tencent.mm.compatible.util.h;
import com.tencent.mm.sdk.platformtools.v;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public final class b
{
  public static final String bQW = h.getExternalStorageDirectory().getAbsolutePath();
  public static final String bQX = bQW + "/tencent/MicroMsg/";
  public static final String cqa = bQX + ".tmp";
  public static long cqb = 0L;

  public static String CO()
  {
    Object localObject = new StringBuilder().append(cqa).append("/");
    long l = System.currentTimeMillis();
    localObject = new SimpleDateFormat("yyyyMMdd").format(new Date(l));
    v.d("MicroMsg.imageloader.ImageTmpFilehUtils", "[cpan] get tmp file path:%s", new Object[] { localObject });
    File localFile = new File(cqa);
    if (!localFile.exists())
      localFile.mkdirs();
    return localObject;
  }

  public static boolean CP()
  {
    long l = System.currentTimeMillis();
    if (l - cqb > 86400000L)
    {
      v.d("MicroMsg.imageloader.ImageTmpFilehUtils", "[cpan] need clean tmp file.");
      cqb = l;
      return true;
    }
    v.d("MicroMsg.imageloader.ImageTmpFilehUtils", "[cpan] need not clean tmp file.");
    return false;
  }

  public static boolean CQ()
  {
    File localFile = new File(cqa);
    try
    {
      if ((localFile.exists()) && (!localFile.isFile()))
        a(localFile, true);
      return true;
    }
    catch (Exception localException)
    {
      v.e("MicroMsg.imageloader.ImageTmpFilehUtils", "[cpan] clean tmp file path exception.");
    }
    return false;
  }

  private static void a(File paramFile, boolean paramBoolean)
  {
    if ((paramFile != null) && (paramFile.exists()) && (paramFile.isDirectory()))
    {
      File[] arrayOfFile = paramFile.listFiles();
      if ((arrayOfFile != null) && (arrayOfFile.length > 0))
      {
        int k = arrayOfFile.length;
        int i = 0;
        if (i < k)
        {
          File localFile = arrayOfFile[i];
          if ((localFile != null) && (localFile.exists()))
          {
            if (!localFile.isFile())
              break label109;
            if ((localFile != null) && (localFile.isFile()) && (localFile.exists()))
              localFile.delete();
          }
          label182: 
          while (true)
          {
            i += 1;
            break;
            label109: long l1 = localFile.lastModified();
            long l2 = System.currentTimeMillis();
            v.d("MicroMsg.imageloader.ImageTmpFilehUtils", "[cpan] can delete current time:%d,listModified:%d", new Object[] { Long.valueOf(l2), Long.valueOf(l1) });
            if (l2 - l1 >= 259200000L);
            for (int j = 1; ; j = 0)
            {
              if ((j == 0) || (!paramBoolean))
                break label182;
              a(localFile, false);
              break;
            }
          }
        }
      }
      paramFile.delete();
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.g.b
 * JD-Core Version:    0.6.2
 */