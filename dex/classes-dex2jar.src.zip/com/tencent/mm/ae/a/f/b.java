package com.tencent.mm.ae.a.f;

import android.graphics.Bitmap;
import com.tencent.mm.ae.a.c.a;
import com.tencent.mm.ae.a.c.d;
import com.tencent.mm.ae.a.c.e;
import com.tencent.mm.ae.a.c.f;
import com.tencent.mm.ae.a.c.g;
import com.tencent.mm.ae.a.c.i;
import com.tencent.mm.ae.a.c.j;
import com.tencent.mm.ae.a.c.k;
import com.tencent.mm.ae.a.c.l;
import com.tencent.mm.sdk.platformtools.ac;
import com.tencent.mm.sdk.platformtools.be;
import com.tencent.mm.sdk.platformtools.v;

public final class b
  implements Runnable
{
  private final com.tencent.mm.ae.a.a.b coH;
  private final com.tencent.mm.ae.a.b cpS;
  public final com.tencent.mm.ae.a.c cpU;
  private final ac cpV;
  private final i cpW;
  private final g cpX;
  private final k cpY;
  private final d cpZ;
  public final com.tencent.mm.ae.a.a.c cpa;
  private final l cpb;
  private final a cpc;
  private final com.tencent.mm.ae.a.c.b cpd;
  private final f cpe;
  private final j cpf;
  private final e cph;
  public final String url;

  public b(String paramString, com.tencent.mm.ae.a.c paramc, ac paramac, com.tencent.mm.ae.a.a.c paramc1, i parami, j paramj, com.tencent.mm.ae.a.b paramb, g paramg, e parame, d paramd)
  {
    this.url = paramString;
    this.cpU = paramc;
    this.cpV = paramac;
    this.cpS = paramb;
    this.cpX = paramg;
    this.coH = this.cpS.coH;
    if (paramc1 == null)
    {
      this.cpa = this.coH.cpa;
      this.cpW = parami;
      if (paramj != null)
        break label177;
      this.cpf = this.coH.cpf;
      label80: if (this.cpa.cpd == null)
        break label186;
      this.cpd = this.cpa.cpd;
      label101: this.cpb = this.coH.cpb;
      this.cpc = this.coH.cpc;
      this.cpe = this.coH.cpe;
      this.cpY = this.coH.cpg;
      if (parame != null)
        break label200;
    }
    label177: label186: label200: for (this.cph = this.coH.cph; ; this.cph = parame)
    {
      this.cpZ = paramd;
      return;
      this.cpa = paramc1;
      break;
      this.cpf = paramj;
      break label80;
      this.cpd = this.coH.cpd;
      break label101;
    }
  }

  private void h(String paramString, Bitmap paramBitmap)
  {
    if (this.cpa.cpl)
    {
      v.d("MicroMsg.imageloader.ImageLoadTask", "[cpan] run. put key %s to memory cache.", new Object[] { this.url });
      this.cpb.g(paramString, paramBitmap);
    }
  }

  public final void an(long paramLong)
  {
    if (this.cpf != null)
      this.cpf.an(paramLong);
  }

  public final String iM(String paramString)
  {
    if ((be.ky(paramString)) || (this.cpa == null))
      return null;
    String str = paramString;
    if (this.cpa.cpI)
      str = paramString + "round" + this.cpa.cpJ;
    return str + "size" + this.cpa.cpt + this.cpa.cpu;
  }

  // ERROR //
  public final void run()
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 12
    //   3: new 171	com/tencent/mm/ae/a/d/b
    //   6: dup
    //   7: invokespecial 172	com/tencent/mm/ae/a/d/b:<init>	()V
    //   10: astore 14
    //   12: aload_0
    //   13: aload_0
    //   14: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   17: invokevirtual 174	com/tencent/mm/ae/a/f/b:iM	(Ljava/lang/String;)Ljava/lang/String;
    //   20: astore 17
    //   22: ldc 102
    //   24: ldc 176
    //   26: iconst_1
    //   27: anewarray 4	java/lang/Object
    //   30: dup
    //   31: iconst_0
    //   32: aload_0
    //   33: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   36: aastore
    //   37: invokestatic 110	com/tencent/mm/sdk/platformtools/v:d	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   40: invokestatic 182	java/lang/System:currentTimeMillis	()J
    //   43: lstore 5
    //   45: aload_0
    //   46: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   49: getfield 185	com/tencent/mm/ae/a/a/c:cps	I
    //   52: istore_3
    //   53: aload_0
    //   54: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   57: getfield 188	com/tencent/mm/ae/a/a/c:cpv	Z
    //   60: istore 9
    //   62: aload_0
    //   63: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   66: getfield 191	com/tencent/mm/ae/a/a/c:aHq	Ljava/lang/String;
    //   69: astore 18
    //   71: ldc 102
    //   73: new 134	java/lang/StringBuilder
    //   76: dup
    //   77: ldc 193
    //   79: invokespecial 196	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   82: iload 9
    //   84: invokevirtual 199	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   87: invokevirtual 152	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   90: invokestatic 202	com/tencent/mm/sdk/platformtools/v:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   93: ldc 102
    //   95: ldc 204
    //   97: iconst_1
    //   98: anewarray 4	java/lang/Object
    //   101: dup
    //   102: iconst_0
    //   103: iload_3
    //   104: invokestatic 210	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   107: aastore
    //   108: invokestatic 110	com/tencent/mm/sdk/platformtools/v:d	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   111: ldc 102
    //   113: ldc 212
    //   115: iconst_2
    //   116: anewarray 4	java/lang/Object
    //   119: dup
    //   120: iconst_0
    //   121: aload_0
    //   122: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   125: getfield 217	com/tencent/mm/ae/a/c:width	I
    //   128: invokestatic 210	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   131: aastore
    //   132: dup
    //   133: iconst_1
    //   134: aload_0
    //   135: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   138: getfield 220	com/tencent/mm/ae/a/c:height	I
    //   141: invokestatic 210	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   144: aastore
    //   145: invokestatic 110	com/tencent/mm/sdk/platformtools/v:d	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   148: iload_3
    //   149: tableswitch	default:+2137 -> 2286, 1:+284->433, 2:+1105->1254, 3:+1135->1284, 4:+1187->1336, 5:+750->899
    //   185: fsub
    //   186: ldc 222
    //   188: iconst_1
    //   189: anewarray 4	java/lang/Object
    //   192: dup
    //   193: iconst_0
    //   194: iload_3
    //   195: invokestatic 210	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   198: aastore
    //   199: invokestatic 225	com/tencent/mm/sdk/platformtools/v:e	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   202: invokestatic 182	java/lang/System:currentTimeMillis	()J
    //   205: lstore 7
    //   207: aload 12
    //   209: ifnull +2080 -> 2289
    //   212: aload 12
    //   214: invokevirtual 231	android/graphics/Bitmap:isRecycled	()Z
    //   217: ifeq +1728 -> 1945
    //   220: goto +2069 -> 2289
    //   223: ldc 102
    //   225: ldc 233
    //   227: invokestatic 236	com/tencent/mm/sdk/platformtools/v:w	(Ljava/lang/String;Ljava/lang/String;)V
    //   230: aload 14
    //   232: astore 13
    //   234: aload 12
    //   236: ifnull +1901 -> 2137
    //   239: aload 12
    //   241: invokevirtual 231	android/graphics/Bitmap:isRecycled	()Z
    //   244: ifne +1893 -> 2137
    //   247: ldc 102
    //   249: ldc 238
    //   251: invokestatic 202	com/tencent/mm/sdk/platformtools/v:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   254: new 240	com/tencent/mm/ae/a/f/c
    //   257: dup
    //   258: aload_0
    //   259: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   262: aload_0
    //   263: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   266: aload 12
    //   268: aload_0
    //   269: getfield 51	com/tencent/mm/ae/a/f/b:cpS	Lcom/tencent/mm/ae/a/b;
    //   272: aload_0
    //   273: aload_0
    //   274: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   277: invokevirtual 174	com/tencent/mm/ae/a/f/b:iM	(Ljava/lang/String;)Ljava/lang/String;
    //   280: invokespecial 243	com/tencent/mm/ae/a/f/c:<init>	(Ljava/lang/String;Lcom/tencent/mm/ae/a/c;Landroid/graphics/Bitmap;Lcom/tencent/mm/ae/a/b;Ljava/lang/String;)V
    //   283: astore 14
    //   285: aload_0
    //   286: getfield 49	com/tencent/mm/ae/a/f/b:cpV	Lcom/tencent/mm/sdk/platformtools/ac;
    //   289: ifnull +13 -> 302
    //   292: aload_0
    //   293: getfield 49	com/tencent/mm/ae/a/f/b:cpV	Lcom/tencent/mm/sdk/platformtools/ac;
    //   296: aload 14
    //   298: invokevirtual 249	com/tencent/mm/sdk/platformtools/ac:post	(Ljava/lang/Runnable;)Z
    //   301: pop
    //   302: aload 13
    //   304: aload 12
    //   306: putfield 253	com/tencent/mm/ae/a/d/b:bitmap	Landroid/graphics/Bitmap;
    //   309: aload_0
    //   310: getfield 53	com/tencent/mm/ae/a/f/b:cpX	Lcom/tencent/mm/ae/a/c/g;
    //   313: ifnull +37 -> 350
    //   316: aload 13
    //   318: ifnull +32 -> 350
    //   321: aload 13
    //   323: aload 12
    //   325: putfield 253	com/tencent/mm/ae/a/d/b:bitmap	Landroid/graphics/Bitmap;
    //   328: aload_0
    //   329: getfield 53	com/tencent/mm/ae/a/f/b:cpX	Lcom/tencent/mm/ae/a/c/g;
    //   332: aload_0
    //   333: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   336: aload_0
    //   337: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   340: invokevirtual 257	com/tencent/mm/ae/a/c:CI	()Landroid/widget/ImageView;
    //   343: aload 13
    //   345: invokeinterface 263 4 0
    //   350: aload_0
    //   351: getfield 65	com/tencent/mm/ae/a/f/b:cpW	Lcom/tencent/mm/ae/a/c/i;
    //   354: astore 13
    //   356: aload_0
    //   357: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   360: astore 14
    //   362: aload_0
    //   363: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   366: invokevirtual 257	com/tencent/mm/ae/a/c:CI	()Landroid/widget/ImageView;
    //   369: pop
    //   370: aload 13
    //   372: aload 14
    //   374: aload 12
    //   376: aload_0
    //   377: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   380: getfield 267	com/tencent/mm/ae/a/a/c:cpM	[Ljava/lang/Object;
    //   383: invokeinterface 272 4 0
    //   388: aload_0
    //   389: getfield 51	com/tencent/mm/ae/a/f/b:cpS	Lcom/tencent/mm/ae/a/b;
    //   392: astore 12
    //   394: aload 12
    //   396: getfield 276	com/tencent/mm/ae/a/b:coL	Ljava/util/HashMap;
    //   399: ifnull +33 -> 432
    //   402: aload_0
    //   403: ifnull +29 -> 432
    //   406: aload_0
    //   407: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   410: ifnull +22 -> 432
    //   413: aload 12
    //   415: getfield 276	com/tencent/mm/ae/a/b:coL	Ljava/util/HashMap;
    //   418: aload_0
    //   419: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   422: invokevirtual 280	com/tencent/mm/ae/a/c:CJ	()I
    //   425: invokestatic 210	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   428: invokevirtual 286	java/util/HashMap:remove	(Ljava/lang/Object;)Ljava/lang/Object;
    //   431: pop
    //   432: return
    //   433: aload_0
    //   434: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   437: getfield 289	com/tencent/mm/ae/a/a/c:aLL	Ljava/lang/String;
    //   440: astore 13
    //   442: aload_0
    //   443: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   446: getfield 292	com/tencent/mm/ae/a/a/c:cpx	Z
    //   449: ifeq +115 -> 564
    //   452: aload 13
    //   454: invokestatic 129	com/tencent/mm/sdk/platformtools/be:ky	(Ljava/lang/String;)Z
    //   457: ifne +107 -> 564
    //   460: aload 13
    //   462: invokestatic 297	com/tencent/mm/a/e:aO	(Ljava/lang/String;)Z
    //   465: ifeq +99 -> 564
    //   468: aload_0
    //   469: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   472: getfield 300	com/tencent/mm/ae/a/a/c:cpK	Z
    //   475: ifeq +61 -> 536
    //   478: aload_0
    //   479: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   482: aload 13
    //   484: aload_0
    //   485: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   488: getfield 158	com/tencent/mm/ae/a/a/c:cpt	I
    //   491: aload_0
    //   492: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   495: getfield 164	com/tencent/mm/ae/a/a/c:cpu	I
    //   498: invokestatic 306	com/tencent/mm/ae/a/g/a:b	(Lcom/tencent/mm/ae/a/c;Ljava/lang/String;II)Landroid/graphics/Bitmap;
    //   501: astore 12
    //   503: aload 12
    //   505: astore 13
    //   507: aload_0
    //   508: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   511: getfield 309	com/tencent/mm/ae/a/a/c:density	I
    //   514: ifle +1769 -> 2283
    //   517: aload 12
    //   519: astore 13
    //   521: aload 12
    //   523: aload_0
    //   524: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   527: getfield 309	com/tencent/mm/ae/a/a/c:density	I
    //   530: invokevirtual 313	android/graphics/Bitmap:setDensity	(I)V
    //   533: goto -331 -> 202
    //   536: aload_0
    //   537: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   540: aload 13
    //   542: aload_0
    //   543: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   546: getfield 158	com/tencent/mm/ae/a/a/c:cpt	I
    //   549: aload_0
    //   550: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   553: getfield 164	com/tencent/mm/ae/a/a/c:cpu	I
    //   556: invokestatic 315	com/tencent/mm/ae/a/g/a:a	(Lcom/tencent/mm/ae/a/c;Ljava/lang/String;II)Landroid/graphics/Bitmap;
    //   559: astore 12
    //   561: goto -58 -> 503
    //   564: aload_0
    //   565: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   568: invokestatic 129	com/tencent/mm/sdk/platformtools/be:ky	(Ljava/lang/String;)Z
    //   571: ifne +317 -> 888
    //   574: aload_0
    //   575: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   578: invokestatic 297	com/tencent/mm/a/e:aO	(Ljava/lang/String;)Z
    //   581: ifeq +222 -> 803
    //   584: iload 9
    //   586: ifeq +21 -> 607
    //   589: aload_0
    //   590: getfield 87	com/tencent/mm/ae/a/f/b:cpY	Lcom/tencent/mm/ae/a/c/k;
    //   593: aload 18
    //   595: aload_0
    //   596: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   599: invokeinterface 321 3 0
    //   604: ifeq +185 -> 789
    //   607: aload_0
    //   608: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   611: getfield 300	com/tencent/mm/ae/a/a/c:cpK	Z
    //   614: ifeq +75 -> 689
    //   617: aload_0
    //   618: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   621: aload_0
    //   622: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   625: aload_0
    //   626: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   629: getfield 158	com/tencent/mm/ae/a/a/c:cpt	I
    //   632: aload_0
    //   633: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   636: getfield 164	com/tencent/mm/ae/a/a/c:cpu	I
    //   639: invokestatic 306	com/tencent/mm/ae/a/g/a:b	(Lcom/tencent/mm/ae/a/c;Ljava/lang/String;II)Landroid/graphics/Bitmap;
    //   642: astore 12
    //   644: aload 12
    //   646: astore 13
    //   648: aload_0
    //   649: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   652: getfield 309	com/tencent/mm/ae/a/a/c:density	I
    //   655: ifle +19 -> 674
    //   658: aload 12
    //   660: astore 13
    //   662: aload 12
    //   664: aload_0
    //   665: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   668: getfield 309	com/tencent/mm/ae/a/a/c:density	I
    //   671: invokevirtual 313	android/graphics/Bitmap:setDensity	(I)V
    //   674: aload 12
    //   676: astore 13
    //   678: ldc 102
    //   680: ldc_w 323
    //   683: invokestatic 202	com/tencent/mm/sdk/platformtools/v:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   686: goto -484 -> 202
    //   689: aload_0
    //   690: getfield 92	com/tencent/mm/ae/a/f/b:cpZ	Lcom/tencent/mm/ae/a/c/d;
    //   693: ifnull +66 -> 759
    //   696: aload_0
    //   697: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   700: aload_0
    //   701: getfield 92	com/tencent/mm/ae/a/f/b:cpZ	Lcom/tencent/mm/ae/a/c/d;
    //   704: aload_0
    //   705: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   708: getfield 267	com/tencent/mm/ae/a/a/c:cpM	[Ljava/lang/Object;
    //   711: invokeinterface 329 2 0
    //   716: aload_0
    //   717: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   720: getfield 158	com/tencent/mm/ae/a/a/c:cpt	I
    //   723: aload_0
    //   724: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   727: getfield 164	com/tencent/mm/ae/a/a/c:cpu	I
    //   730: aload_0
    //   731: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   734: getfield 332	com/tencent/mm/ae/a/a/c:cpz	Z
    //   737: aload_0
    //   738: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   741: getfield 335	com/tencent/mm/ae/a/a/c:alpha	F
    //   744: aload_0
    //   745: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   748: getfield 338	com/tencent/mm/ae/a/a/c:cpw	Z
    //   751: invokestatic 341	com/tencent/mm/ae/a/g/a:a	(Lcom/tencent/mm/ae/a/c;[BIIZFZ)Landroid/graphics/Bitmap;
    //   754: astore 12
    //   756: goto -112 -> 644
    //   759: aload_0
    //   760: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   763: aload_0
    //   764: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   767: aload_0
    //   768: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   771: getfield 158	com/tencent/mm/ae/a/a/c:cpt	I
    //   774: aload_0
    //   775: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   778: getfield 164	com/tencent/mm/ae/a/a/c:cpu	I
    //   781: invokestatic 315	com/tencent/mm/ae/a/g/a:a	(Lcom/tencent/mm/ae/a/c;Ljava/lang/String;II)Landroid/graphics/Bitmap;
    //   784: astore 12
    //   786: goto -142 -> 644
    //   789: ldc 102
    //   791: ldc_w 343
    //   794: invokestatic 236	com/tencent/mm/sdk/platformtools/v:w	(Ljava/lang/String;Ljava/lang/String;)V
    //   797: aconst_null
    //   798: astore 12
    //   800: goto -598 -> 202
    //   803: aload_0
    //   804: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   807: getfield 346	com/tencent/mm/ae/a/a/c:cpy	Z
    //   810: ifeq +19 -> 829
    //   813: aload_0
    //   814: getfield 90	com/tencent/mm/ae/a/f/b:cph	Lcom/tencent/mm/ae/a/c/e;
    //   817: aload_0
    //   818: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   821: getfield 267	com/tencent/mm/ae/a/a/c:cpM	[Ljava/lang/Object;
    //   824: invokeinterface 352 2 0
    //   829: ldc 102
    //   831: ldc_w 354
    //   834: invokestatic 236	com/tencent/mm/sdk/platformtools/v:w	(Ljava/lang/String;Ljava/lang/String;)V
    //   837: goto -635 -> 202
    //   840: astore 15
    //   842: aload 14
    //   844: astore 12
    //   846: aconst_null
    //   847: astore 13
    //   849: aload 15
    //   851: astore 14
    //   853: ldc 102
    //   855: ldc_w 356
    //   858: iconst_1
    //   859: anewarray 4	java/lang/Object
    //   862: dup
    //   863: iconst_0
    //   864: aload 14
    //   866: invokevirtual 357	java/lang/Exception:toString	()Ljava/lang/String;
    //   869: aastore
    //   870: invokestatic 225	com/tencent/mm/sdk/platformtools/v:e	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   873: aload 12
    //   875: astore 14
    //   877: aload 13
    //   879: astore 12
    //   881: aload 14
    //   883: astore 13
    //   885: goto -651 -> 234
    //   888: ldc 102
    //   890: ldc_w 359
    //   893: invokestatic 236	com/tencent/mm/sdk/platformtools/v:w	(Ljava/lang/String;Ljava/lang/String;)V
    //   896: goto -694 -> 202
    //   899: aconst_null
    //   900: astore 15
    //   902: iconst_0
    //   903: istore_2
    //   904: aload_0
    //   905: getfield 79	com/tencent/mm/ae/a/f/b:cpc	Lcom/tencent/mm/ae/a/c/a;
    //   908: aload_0
    //   909: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   912: aload_0
    //   913: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   916: invokeinterface 364 3 0
    //   921: astore 16
    //   923: aload 16
    //   925: ifnull +1352 -> 2277
    //   928: iload 9
    //   930: ifeq +23 -> 953
    //   933: aload 16
    //   935: astore 15
    //   937: aload_0
    //   938: getfield 87	com/tencent/mm/ae/a/f/b:cpY	Lcom/tencent/mm/ae/a/c/k;
    //   941: aload 18
    //   943: aload 16
    //   945: invokeinterface 367 3 0
    //   950: ifeq +281 -> 1231
    //   953: aload 16
    //   955: astore 15
    //   957: aload_0
    //   958: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   961: astore 12
    //   963: aload 16
    //   965: astore 15
    //   967: aload_0
    //   968: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   971: getfield 158	com/tencent/mm/ae/a/a/c:cpt	I
    //   974: istore_2
    //   975: aload 16
    //   977: astore 15
    //   979: aload_0
    //   980: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   983: getfield 164	com/tencent/mm/ae/a/a/c:cpu	I
    //   986: istore 4
    //   988: aload 16
    //   990: astore 15
    //   992: aload_0
    //   993: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   996: getfield 332	com/tencent/mm/ae/a/a/c:cpz	Z
    //   999: istore 10
    //   1001: aload 16
    //   1003: astore 15
    //   1005: aload_0
    //   1006: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1009: getfield 335	com/tencent/mm/ae/a/a/c:alpha	F
    //   1012: fstore_1
    //   1013: aload 16
    //   1015: astore 15
    //   1017: aload_0
    //   1018: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1021: getfield 338	com/tencent/mm/ae/a/a/c:cpw	Z
    //   1024: istore 11
    //   1026: iload_2
    //   1027: ifle +8 -> 1035
    //   1030: iload 4
    //   1032: ifgt +181 -> 1213
    //   1035: aload 12
    //   1037: ifnull +162 -> 1199
    //   1040: aload 16
    //   1042: astore 15
    //   1044: aload 12
    //   1046: getfield 217	com/tencent/mm/ae/a/c:width	I
    //   1049: ifle +150 -> 1199
    //   1052: aload 16
    //   1054: astore 15
    //   1056: aload 12
    //   1058: getfield 217	com/tencent/mm/ae/a/c:width	I
    //   1061: ifle +138 -> 1199
    //   1064: aload 16
    //   1066: astore 15
    //   1068: aload 16
    //   1070: fconst_0
    //   1071: aload 12
    //   1073: getfield 217	com/tencent/mm/ae/a/c:width	I
    //   1076: aload 12
    //   1078: getfield 220	com/tencent/mm/ae/a/c:height	I
    //   1081: invokestatic 372	com/tencent/mm/sdk/platformtools/d:a	(Ljava/io/InputStream;FII)Landroid/graphics/Bitmap;
    //   1084: astore 12
    //   1086: aload 12
    //   1088: astore 13
    //   1090: iload 10
    //   1092: ifeq +19 -> 1111
    //   1095: aload 16
    //   1097: astore 15
    //   1099: aload 12
    //   1101: iload_2
    //   1102: iload 4
    //   1104: iconst_0
    //   1105: iconst_1
    //   1106: invokestatic 375	com/tencent/mm/sdk/platformtools/d:a	(Landroid/graphics/Bitmap;IIZZ)Landroid/graphics/Bitmap;
    //   1109: astore 13
    //   1111: aload 13
    //   1113: astore 12
    //   1115: fload_1
    //   1116: fconst_0
    //   1117: fcmpl
    //   1118: ifle +15 -> 1133
    //   1121: aload 16
    //   1123: astore 15
    //   1125: aload 13
    //   1127: fload_1
    //   1128: invokestatic 379	com/tencent/mm/sdk/platformtools/d:c	(Landroid/graphics/Bitmap;F)Landroid/graphics/Bitmap;
    //   1131: astore 12
    //   1133: aload 12
    //   1135: astore 13
    //   1137: iload 11
    //   1139: ifeq +14 -> 1153
    //   1142: aload 16
    //   1144: astore 15
    //   1146: aload 12
    //   1148: invokestatic 383	com/tencent/mm/sdk/platformtools/d:C	(Landroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    //   1151: astore 13
    //   1153: iconst_1
    //   1154: istore_2
    //   1155: aload 16
    //   1157: ifnull +8 -> 1165
    //   1160: aload 16
    //   1162: invokevirtual 388	java/io/InputStream:close	()V
    //   1165: iload_2
    //   1166: ifeq +1104 -> 2270
    //   1169: aload 13
    //   1171: ifnonnull +1099 -> 2270
    //   1174: aload_0
    //   1175: getfield 79	com/tencent/mm/ae/a/f/b:cpc	Lcom/tencent/mm/ae/a/c/a;
    //   1178: aload_0
    //   1179: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   1182: aload_0
    //   1183: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1186: invokeinterface 391 3 0
    //   1191: pop
    //   1192: aload 13
    //   1194: astore 12
    //   1196: goto -994 -> 202
    //   1199: aload 16
    //   1201: astore 15
    //   1203: aload 16
    //   1205: invokestatic 395	com/tencent/mm/sdk/platformtools/d:decodeStream	(Ljava/io/InputStream;)Landroid/graphics/Bitmap;
    //   1208: astore 12
    //   1210: goto -124 -> 1086
    //   1213: aload 16
    //   1215: astore 15
    //   1217: aload 16
    //   1219: fconst_0
    //   1220: iload_2
    //   1221: iload 4
    //   1223: invokestatic 372	com/tencent/mm/sdk/platformtools/d:a	(Ljava/io/InputStream;FII)Landroid/graphics/Bitmap;
    //   1226: astore 12
    //   1228: goto -142 -> 1086
    //   1231: iconst_1
    //   1232: istore_2
    //   1233: aconst_null
    //   1234: astore 13
    //   1236: goto -81 -> 1155
    //   1239: astore 12
    //   1241: aload 15
    //   1243: ifnull +8 -> 1251
    //   1246: aload 15
    //   1248: invokevirtual 388	java/io/InputStream:close	()V
    //   1251: aload 12
    //   1253: athrow
    //   1254: aload_0
    //   1255: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   1258: aload_0
    //   1259: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   1262: aload_0
    //   1263: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1266: getfield 158	com/tencent/mm/ae/a/a/c:cpt	I
    //   1269: aload_0
    //   1270: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1273: getfield 164	com/tencent/mm/ae/a/a/c:cpu	I
    //   1276: invokestatic 397	com/tencent/mm/ae/a/g/a:c	(Lcom/tencent/mm/ae/a/c;Ljava/lang/String;II)Landroid/graphics/Bitmap;
    //   1279: astore 12
    //   1281: goto -1079 -> 202
    //   1284: aload_0
    //   1285: getfield 58	com/tencent/mm/ae/a/f/b:coH	Lcom/tencent/mm/ae/a/a/b;
    //   1288: getfield 401	com/tencent/mm/ae/a/a/b:coX	Landroid/content/res/Resources;
    //   1291: aload_0
    //   1292: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   1295: ldc_w 403
    //   1298: aload_0
    //   1299: getfield 58	com/tencent/mm/ae/a/f/b:coH	Lcom/tencent/mm/ae/a/a/b;
    //   1302: getfield 406	com/tencent/mm/ae/a/a/b:packageName	Ljava/lang/String;
    //   1305: invokevirtual 412	android/content/res/Resources:getIdentifier	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   1308: istore_2
    //   1309: aload_0
    //   1310: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   1313: iload_2
    //   1314: aload_0
    //   1315: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1318: getfield 158	com/tencent/mm/ae/a/a/c:cpt	I
    //   1321: aload_0
    //   1322: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1325: getfield 164	com/tencent/mm/ae/a/a/c:cpu	I
    //   1328: invokestatic 415	com/tencent/mm/ae/a/g/a:a	(Lcom/tencent/mm/ae/a/c;III)Landroid/graphics/Bitmap;
    //   1331: astore 12
    //   1333: goto -1131 -> 202
    //   1336: aload_0
    //   1337: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   1340: invokestatic 418	java/lang/Integer:valueOf	(Ljava/lang/String;)Ljava/lang/Integer;
    //   1343: invokevirtual 421	java/lang/Integer:intValue	()I
    //   1346: istore_2
    //   1347: aload_0
    //   1348: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   1351: iload_2
    //   1352: aload_0
    //   1353: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1356: getfield 158	com/tencent/mm/ae/a/a/c:cpt	I
    //   1359: aload_0
    //   1360: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1363: getfield 164	com/tencent/mm/ae/a/a/c:cpu	I
    //   1366: invokestatic 415	com/tencent/mm/ae/a/g/a:a	(Lcom/tencent/mm/ae/a/c;III)Landroid/graphics/Bitmap;
    //   1369: astore 12
    //   1371: goto -1169 -> 202
    //   1374: invokestatic 182	java/lang/System:currentTimeMillis	()J
    //   1377: lstore 5
    //   1379: ldc 102
    //   1381: ldc_w 423
    //   1384: invokestatic 202	com/tencent/mm/sdk/platformtools/v:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   1387: aload_0
    //   1388: getfield 53	com/tencent/mm/ae/a/f/b:cpX	Lcom/tencent/mm/ae/a/c/g;
    //   1391: ifnull +32 -> 1423
    //   1394: aload_0
    //   1395: getfield 53	com/tencent/mm/ae/a/f/b:cpX	Lcom/tencent/mm/ae/a/c/g;
    //   1398: astore 13
    //   1400: aload_0
    //   1401: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   1404: astore 15
    //   1406: aload_0
    //   1407: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   1410: invokevirtual 257	com/tencent/mm/ae/a/c:CI	()Landroid/widget/ImageView;
    //   1413: pop
    //   1414: aload 13
    //   1416: aload 15
    //   1418: invokeinterface 426 2 0
    //   1423: aload_0
    //   1424: getfield 73	com/tencent/mm/ae/a/f/b:cpd	Lcom/tencent/mm/ae/a/c/b;
    //   1427: aload_0
    //   1428: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   1431: invokeinterface 432 2 0
    //   1436: astore 13
    //   1438: aload 13
    //   1440: ifnonnull +827 -> 2267
    //   1443: new 171	com/tencent/mm/ae/a/d/b
    //   1446: dup
    //   1447: aconst_null
    //   1448: aconst_null
    //   1449: invokespecial 435	com/tencent/mm/ae/a/d/b:<init>	([BLjava/lang/String;)V
    //   1452: astore 14
    //   1454: aload 14
    //   1456: astore 13
    //   1458: aload 13
    //   1460: getfield 439	com/tencent/mm/ae/a/d/b:data	[B
    //   1463: ifnonnull +12 -> 1475
    //   1466: aload 13
    //   1468: iconst_1
    //   1469: putfield 442	com/tencent/mm/ae/a/d/b:status	I
    //   1472: goto -1238 -> 234
    //   1475: iload 9
    //   1477: ifeq +22 -> 1499
    //   1480: aload_0
    //   1481: getfield 87	com/tencent/mm/ae/a/f/b:cpY	Lcom/tencent/mm/ae/a/c/k;
    //   1484: aload 18
    //   1486: aload 13
    //   1488: getfield 439	com/tencent/mm/ae/a/d/b:data	[B
    //   1491: invokeinterface 445 3 0
    //   1496: ifeq +414 -> 1910
    //   1499: ldc 102
    //   1501: ldc_w 447
    //   1504: invokestatic 202	com/tencent/mm/sdk/platformtools/v:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   1507: invokestatic 182	java/lang/System:currentTimeMillis	()J
    //   1510: lstore 7
    //   1512: aload_0
    //   1513: getfield 47	com/tencent/mm/ae/a/f/b:cpU	Lcom/tencent/mm/ae/a/c;
    //   1516: aload 13
    //   1518: getfield 439	com/tencent/mm/ae/a/d/b:data	[B
    //   1521: aload_0
    //   1522: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1525: getfield 158	com/tencent/mm/ae/a/a/c:cpt	I
    //   1528: aload_0
    //   1529: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1532: getfield 164	com/tencent/mm/ae/a/a/c:cpu	I
    //   1535: aload_0
    //   1536: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1539: getfield 332	com/tencent/mm/ae/a/a/c:cpz	Z
    //   1542: aload_0
    //   1543: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1546: getfield 335	com/tencent/mm/ae/a/a/c:alpha	F
    //   1549: aload_0
    //   1550: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1553: getfield 338	com/tencent/mm/ae/a/a/c:cpw	Z
    //   1556: invokestatic 341	com/tencent/mm/ae/a/g/a:a	(Lcom/tencent/mm/ae/a/c;[BIIZFZ)Landroid/graphics/Bitmap;
    //   1559: astore 15
    //   1561: aload 15
    //   1563: ifnonnull +20 -> 1583
    //   1566: aload 15
    //   1568: astore 14
    //   1570: aload 13
    //   1572: iconst_3
    //   1573: putfield 442	com/tencent/mm/ae/a/d/b:status	I
    //   1576: aload 15
    //   1578: astore 12
    //   1580: goto -1346 -> 234
    //   1583: aload 15
    //   1585: astore 14
    //   1587: aload 13
    //   1589: getfield 439	com/tencent/mm/ae/a/d/b:data	[B
    //   1592: astore 12
    //   1594: aload 15
    //   1596: astore 14
    //   1598: aload_0
    //   1599: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1602: getfield 450	com/tencent/mm/ae/a/a/c:cpn	Z
    //   1605: ifeq +27 -> 1632
    //   1608: aload 15
    //   1610: astore 14
    //   1612: aload_0
    //   1613: getfield 79	com/tencent/mm/ae/a/f/b:cpc	Lcom/tencent/mm/ae/a/c/a;
    //   1616: aload_0
    //   1617: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   1620: aload 12
    //   1622: aload_0
    //   1623: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1626: invokeinterface 453 4 0
    //   1631: pop
    //   1632: aload 15
    //   1634: astore 14
    //   1636: aload_0
    //   1637: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1640: getfield 456	com/tencent/mm/ae/a/a/c:cpm	Z
    //   1643: ifeq +67 -> 1710
    //   1646: aload 15
    //   1648: astore 14
    //   1650: new 134	java/lang/StringBuilder
    //   1653: dup
    //   1654: invokespecial 135	java/lang/StringBuilder:<init>	()V
    //   1657: invokestatic 461	com/tencent/mm/ae/a/g/b:CO	()Ljava/lang/String;
    //   1660: invokevirtual 139	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1663: getstatic 466	java/io/File:separator	Ljava/lang/String;
    //   1666: invokevirtual 139	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1669: aload_0
    //   1670: getfield 82	com/tencent/mm/ae/a/f/b:cpe	Lcom/tencent/mm/ae/a/c/f;
    //   1673: aload_0
    //   1674: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   1677: invokeinterface 471 2 0
    //   1682: invokevirtual 139	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1685: pop
    //   1686: aload 15
    //   1688: astore 14
    //   1690: aload_0
    //   1691: getfield 79	com/tencent/mm/ae/a/f/b:cpc	Lcom/tencent/mm/ae/a/c/a;
    //   1694: aload_0
    //   1695: getfield 45	com/tencent/mm/ae/a/f/b:url	Ljava/lang/String;
    //   1698: aload 12
    //   1700: aload_0
    //   1701: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1704: invokeinterface 453 4 0
    //   1709: pop
    //   1710: aload 15
    //   1712: astore 12
    //   1714: aload 15
    //   1716: astore 14
    //   1718: aload_0
    //   1719: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1722: getfield 132	com/tencent/mm/ae/a/a/c:cpI	Z
    //   1725: ifeq +56 -> 1781
    //   1728: aload 15
    //   1730: astore 14
    //   1732: aload_0
    //   1733: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1736: getfield 145	com/tencent/mm/ae/a/a/c:cpJ	F
    //   1739: fconst_0
    //   1740: fcmpl
    //   1741: ifne +147 -> 1888
    //   1744: aload 15
    //   1746: astore 14
    //   1748: aload 15
    //   1750: invokevirtual 474	android/graphics/Bitmap:getWidth	()I
    //   1753: aload 15
    //   1755: invokevirtual 477	android/graphics/Bitmap:getHeight	()I
    //   1758: if_icmpne +51 -> 1809
    //   1761: aload 15
    //   1763: astore 14
    //   1765: aload 15
    //   1767: iconst_0
    //   1768: aload 15
    //   1770: invokevirtual 474	android/graphics/Bitmap:getWidth	()I
    //   1773: iconst_2
    //   1774: idiv
    //   1775: i2f
    //   1776: invokestatic 480	com/tencent/mm/sdk/platformtools/d:a	(Landroid/graphics/Bitmap;ZF)Landroid/graphics/Bitmap;
    //   1779: astore 12
    //   1781: aload 12
    //   1783: astore 14
    //   1785: aload_0
    //   1786: aload 17
    //   1788: aload 12
    //   1790: invokespecial 482	com/tencent/mm/ae/a/f/b:h	(Ljava/lang/String;Landroid/graphics/Bitmap;)V
    //   1793: aload 12
    //   1795: astore 14
    //   1797: aload_0
    //   1798: lload 7
    //   1800: lload 5
    //   1802: lsub
    //   1803: invokevirtual 483	com/tencent/mm/ae/a/f/b:an	(J)V
    //   1806: goto -1572 -> 234
    //   1809: aload 15
    //   1811: astore 14
    //   1813: aload 15
    //   1815: invokevirtual 474	android/graphics/Bitmap:getWidth	()I
    //   1818: aload 15
    //   1820: invokevirtual 477	android/graphics/Bitmap:getHeight	()I
    //   1823: invokestatic 489	java/lang/Math:min	(II)I
    //   1826: istore_3
    //   1827: iload_3
    //   1828: istore_2
    //   1829: iload_3
    //   1830: ifgt +21 -> 1851
    //   1833: aload 15
    //   1835: astore 14
    //   1837: aload 15
    //   1839: invokevirtual 474	android/graphics/Bitmap:getWidth	()I
    //   1842: aload 15
    //   1844: invokevirtual 477	android/graphics/Bitmap:getHeight	()I
    //   1847: invokestatic 492	java/lang/Math:max	(II)I
    //   1850: istore_2
    //   1851: aload 15
    //   1853: astore 14
    //   1855: aload 15
    //   1857: iload_2
    //   1858: iload_2
    //   1859: iconst_1
    //   1860: invokestatic 495	com/tencent/mm/sdk/platformtools/d:a	(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;
    //   1863: astore 12
    //   1865: aload 12
    //   1867: astore 14
    //   1869: aload 12
    //   1871: iconst_0
    //   1872: aload 12
    //   1874: invokevirtual 474	android/graphics/Bitmap:getWidth	()I
    //   1877: iconst_2
    //   1878: idiv
    //   1879: i2f
    //   1880: invokestatic 480	com/tencent/mm/sdk/platformtools/d:a	(Landroid/graphics/Bitmap;ZF)Landroid/graphics/Bitmap;
    //   1883: astore 12
    //   1885: goto -104 -> 1781
    //   1888: aload 15
    //   1890: astore 14
    //   1892: aload 15
    //   1894: iconst_0
    //   1895: aload_0
    //   1896: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1899: getfield 145	com/tencent/mm/ae/a/a/c:cpJ	F
    //   1902: invokestatic 480	com/tencent/mm/sdk/platformtools/d:a	(Landroid/graphics/Bitmap;ZF)Landroid/graphics/Bitmap;
    //   1905: astore 12
    //   1907: goto -126 -> 1781
    //   1910: aload 13
    //   1912: iconst_2
    //   1913: putfield 442	com/tencent/mm/ae/a/d/b:status	I
    //   1916: ldc 102
    //   1918: ldc_w 497
    //   1921: invokestatic 236	com/tencent/mm/sdk/platformtools/v:w	(Ljava/lang/String;Ljava/lang/String;)V
    //   1924: aconst_null
    //   1925: astore 12
    //   1927: goto -1693 -> 234
    //   1930: ldc 102
    //   1932: ldc_w 499
    //   1935: invokestatic 236	com/tencent/mm/sdk/platformtools/v:w	(Ljava/lang/String;Ljava/lang/String;)V
    //   1938: aload 14
    //   1940: astore 13
    //   1942: goto -1708 -> 234
    //   1945: aload_0
    //   1946: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1949: getfield 132	com/tencent/mm/ae/a/a/c:cpI	Z
    //   1952: ifeq +312 -> 2264
    //   1955: aload_0
    //   1956: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   1959: getfield 145	com/tencent/mm/ae/a/a/c:cpJ	F
    //   1962: fconst_0
    //   1963: fcmpl
    //   1964: ifne +151 -> 2115
    //   1967: aload 12
    //   1969: invokevirtual 474	android/graphics/Bitmap:getWidth	()I
    //   1972: aload 12
    //   1974: invokevirtual 477	android/graphics/Bitmap:getHeight	()I
    //   1977: if_icmpne +67 -> 2044
    //   1980: aload 12
    //   1982: iconst_0
    //   1983: aload 12
    //   1985: invokevirtual 474	android/graphics/Bitmap:getWidth	()I
    //   1988: iconst_2
    //   1989: idiv
    //   1990: i2f
    //   1991: invokestatic 480	com/tencent/mm/sdk/platformtools/d:a	(Landroid/graphics/Bitmap;ZF)Landroid/graphics/Bitmap;
    //   1994: astore 13
    //   1996: aload 13
    //   1998: astore 12
    //   2000: aload 12
    //   2002: astore 13
    //   2004: aload_0
    //   2005: aload 17
    //   2007: aload 12
    //   2009: invokespecial 482	com/tencent/mm/ae/a/f/b:h	(Ljava/lang/String;Landroid/graphics/Bitmap;)V
    //   2012: aload 12
    //   2014: astore 13
    //   2016: aload_0
    //   2017: lload 7
    //   2019: lload 5
    //   2021: lsub
    //   2022: invokevirtual 483	com/tencent/mm/ae/a/f/b:an	(J)V
    //   2025: aload 12
    //   2027: astore 13
    //   2029: ldc 102
    //   2031: ldc_w 501
    //   2034: invokestatic 202	com/tencent/mm/sdk/platformtools/v:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   2037: aload 14
    //   2039: astore 13
    //   2041: goto -1807 -> 234
    //   2044: aload 12
    //   2046: invokevirtual 474	android/graphics/Bitmap:getWidth	()I
    //   2049: aload 12
    //   2051: invokevirtual 477	android/graphics/Bitmap:getHeight	()I
    //   2054: invokestatic 489	java/lang/Math:min	(II)I
    //   2057: istore_3
    //   2058: iload_3
    //   2059: istore_2
    //   2060: iload_3
    //   2061: ifgt +17 -> 2078
    //   2064: aload 12
    //   2066: invokevirtual 474	android/graphics/Bitmap:getWidth	()I
    //   2069: aload 12
    //   2071: invokevirtual 477	android/graphics/Bitmap:getHeight	()I
    //   2074: invokestatic 492	java/lang/Math:max	(II)I
    //   2077: istore_2
    //   2078: aload 12
    //   2080: iload_2
    //   2081: iload_2
    //   2082: iconst_1
    //   2083: invokestatic 495	com/tencent/mm/sdk/platformtools/d:a	(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;
    //   2086: astore 13
    //   2088: aload 13
    //   2090: astore 12
    //   2092: aload 12
    //   2094: astore 13
    //   2096: aload 12
    //   2098: iconst_0
    //   2099: aload 12
    //   2101: invokevirtual 474	android/graphics/Bitmap:getWidth	()I
    //   2104: iconst_2
    //   2105: idiv
    //   2106: i2f
    //   2107: invokestatic 480	com/tencent/mm/sdk/platformtools/d:a	(Landroid/graphics/Bitmap;ZF)Landroid/graphics/Bitmap;
    //   2110: astore 12
    //   2112: goto -112 -> 2000
    //   2115: aload 12
    //   2117: iconst_0
    //   2118: aload_0
    //   2119: getfield 63	com/tencent/mm/ae/a/f/b:cpa	Lcom/tencent/mm/ae/a/a/c;
    //   2122: getfield 145	com/tencent/mm/ae/a/a/c:cpJ	F
    //   2125: invokestatic 480	com/tencent/mm/sdk/platformtools/d:a	(Landroid/graphics/Bitmap;ZF)Landroid/graphics/Bitmap;
    //   2128: astore 13
    //   2130: aload 13
    //   2132: astore 12
    //   2134: goto -134 -> 2000
    //   2137: ldc 102
    //   2139: ldc_w 503
    //   2142: invokestatic 236	com/tencent/mm/sdk/platformtools/v:w	(Ljava/lang/String;Ljava/lang/String;)V
    //   2145: goto -1836 -> 309
    //   2148: astore 12
    //   2150: goto -985 -> 1165
    //   2153: astore 13
    //   2155: goto -904 -> 1251
    //   2158: astore 15
    //   2160: aload 14
    //   2162: astore 12
    //   2164: aload 15
    //   2166: astore 14
    //   2168: goto -1315 -> 853
    //   2171: astore 15
    //   2173: aload 14
    //   2175: astore 12
    //   2177: aload 15
    //   2179: astore 14
    //   2181: goto -1328 -> 853
    //   2184: astore 16
    //   2186: aload 14
    //   2188: astore 13
    //   2190: aload 12
    //   2192: astore 15
    //   2194: aload 16
    //   2196: astore 14
    //   2198: aload 13
    //   2200: astore 12
    //   2202: aload 15
    //   2204: astore 13
    //   2206: goto -1353 -> 853
    //   2209: astore 14
    //   2211: aload 12
    //   2213: astore 15
    //   2215: aload 13
    //   2217: astore 12
    //   2219: aload 15
    //   2221: astore 13
    //   2223: goto -1370 -> 853
    //   2226: astore 14
    //   2228: aload 12
    //   2230: astore 15
    //   2232: aload 13
    //   2234: astore 12
    //   2236: aload 15
    //   2238: astore 13
    //   2240: goto -1387 -> 853
    //   2243: astore 16
    //   2245: aload 14
    //   2247: astore 15
    //   2249: aload 13
    //   2251: astore 12
    //   2253: aload 16
    //   2255: astore 14
    //   2257: aload 15
    //   2259: astore 13
    //   2261: goto -1408 -> 853
    //   2264: goto -264 -> 2000
    //   2267: goto -809 -> 1458
    //   2270: aload 13
    //   2272: astore 12
    //   2274: goto -2072 -> 202
    //   2277: aconst_null
    //   2278: astore 13
    //   2280: goto -1125 -> 1155
    //   2283: goto -2081 -> 202
    //   2286: goto -2102 -> 184
    //   2289: iload_3
    //   2290: tableswitch	default:+34 -> 2324, 1:+-360->1930, 2:+-360->1930, 3:+-360->1930, 4:+-360->1930, 5:+-916->1374
    //   2325: <illegal opcode>
    //   2326: <illegal opcode>
    //
    // Exception table:
    //   from	to	target	type
    //   12	148	840	java/lang/Exception
    //   184	202	840	java/lang/Exception
    //   433	503	840	java/lang/Exception
    //   536	561	840	java/lang/Exception
    //   564	584	840	java/lang/Exception
    //   589	607	840	java/lang/Exception
    //   607	644	840	java/lang/Exception
    //   689	756	840	java/lang/Exception
    //   759	786	840	java/lang/Exception
    //   789	797	840	java/lang/Exception
    //   803	829	840	java/lang/Exception
    //   829	837	840	java/lang/Exception
    //   888	896	840	java/lang/Exception
    //   1246	1251	840	java/lang/Exception
    //   1251	1254	840	java/lang/Exception
    //   1254	1281	840	java/lang/Exception
    //   1284	1333	840	java/lang/Exception
    //   1336	1371	840	java/lang/Exception
    //   904	923	1239	finally
    //   937	953	1239	finally
    //   957	963	1239	finally
    //   967	975	1239	finally
    //   979	988	1239	finally
    //   992	1001	1239	finally
    //   1005	1013	1239	finally
    //   1017	1026	1239	finally
    //   1044	1052	1239	finally
    //   1056	1064	1239	finally
    //   1068	1086	1239	finally
    //   1099	1111	1239	finally
    //   1125	1133	1239	finally
    //   1146	1153	1239	finally
    //   1203	1210	1239	finally
    //   1217	1228	1239	finally
    //   1160	1165	2148	java/io/IOException
    //   1246	1251	2153	java/io/IOException
    //   507	517	2158	java/lang/Exception
    //   521	533	2158	java/lang/Exception
    //   648	658	2158	java/lang/Exception
    //   662	674	2158	java/lang/Exception
    //   678	686	2158	java/lang/Exception
    //   2004	2012	2158	java/lang/Exception
    //   2016	2025	2158	java/lang/Exception
    //   2029	2037	2158	java/lang/Exception
    //   2096	2112	2158	java/lang/Exception
    //   1160	1165	2171	java/lang/Exception
    //   1174	1192	2171	java/lang/Exception
    //   202	207	2184	java/lang/Exception
    //   212	220	2184	java/lang/Exception
    //   223	230	2184	java/lang/Exception
    //   1374	1423	2184	java/lang/Exception
    //   1423	1438	2184	java/lang/Exception
    //   1930	1938	2184	java/lang/Exception
    //   1945	1996	2184	java/lang/Exception
    //   2044	2058	2184	java/lang/Exception
    //   2064	2078	2184	java/lang/Exception
    //   2078	2088	2184	java/lang/Exception
    //   2115	2130	2184	java/lang/Exception
    //   1443	1454	2209	java/lang/Exception
    //   1458	1472	2226	java/lang/Exception
    //   1480	1499	2226	java/lang/Exception
    //   1499	1561	2226	java/lang/Exception
    //   1910	1924	2226	java/lang/Exception
    //   1570	1576	2243	java/lang/Exception
    //   1587	1594	2243	java/lang/Exception
    //   1598	1608	2243	java/lang/Exception
    //   1612	1632	2243	java/lang/Exception
    //   1636	1646	2243	java/lang/Exception
    //   1650	1686	2243	java/lang/Exception
    //   1690	1710	2243	java/lang/Exception
    //   1718	1728	2243	java/lang/Exception
    //   1732	1744	2243	java/lang/Exception
    //   1748	1761	2243	java/lang/Exception
    //   1765	1781	2243	java/lang/Exception
    //   1785	1793	2243	java/lang/Exception
    //   1797	1806	2243	java/lang/Exception
    //   1813	1827	2243	java/lang/Exception
    //   1837	1851	2243	java/lang/Exception
    //   1855	1865	2243	java/lang/Exception
    //   1869	1885	2243	java/lang/Exception
    //   1892	1907	2243	java/lang/Exception
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.f.b
 * JD-Core Version:    0.6.2
 */