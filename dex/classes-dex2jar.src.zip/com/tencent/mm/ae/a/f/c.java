package com.tencent.mm.ae.a.f;

import android.graphics.Bitmap;
import android.os.Looper;
import android.widget.ImageView;
import com.tencent.mm.ae.a.b;
import com.tencent.mm.sdk.platformtools.be;
import com.tencent.mm.sdk.platformtools.v;
import java.lang.ref.WeakReference;
import java.util.Map;

public final class c
  implements Runnable
{
  private String YJ;
  private Bitmap bitmap;
  private b cpS;
  private com.tencent.mm.ae.a.c cpU;
  private String url;

  public c(String paramString1, com.tencent.mm.ae.a.c paramc, Bitmap paramBitmap, b paramb, String paramString2)
  {
    this.url = paramString1;
    this.cpU = paramc;
    this.bitmap = paramBitmap;
    this.cpS = paramb;
    this.YJ = paramString2;
  }

  public final void run()
  {
    if ((!be.ky(this.url)) && (this.cpU != null) && (this.bitmap != null) && (!this.bitmap.isRecycled()) && (this.cpS != null))
    {
      Object localObject1 = this.cpS;
      Object localObject2 = this.cpU;
      localObject1 = (String)((b)localObject1).coK.get(Integer.valueOf(((com.tencent.mm.ae.a.c)localObject2).CJ()));
      if (this.url.equals(localObject1))
      {
        localObject2 = this.cpU;
        localObject1 = this.bitmap;
        if ((Looper.myLooper() == Looper.getMainLooper()) && (((com.tencent.mm.ae.a.c)localObject2).coM != null))
        {
          localObject2 = (ImageView)((com.tencent.mm.ae.a.c)localObject2).coM.get();
          if (localObject2 != null)
            ((ImageView)localObject2).setImageBitmap((Bitmap)localObject1);
        }
        this.cpS.a(this.cpU);
        return;
      }
      v.w("MicroMsg.imageloader.ImageShowTask", "[cpan] url is not equals view url.");
      return;
    }
    v.w("MicroMsg.imageloader.ImageShowTask", "[cpan] run something is null.");
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.f.c
 * JD-Core Version:    0.6.2
 */