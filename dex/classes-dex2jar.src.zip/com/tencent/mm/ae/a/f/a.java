package com.tencent.mm.ae.a.f;

import com.tencent.mm.sdk.platformtools.d;

public final class a
  implements Runnable
{
  private final com.tencent.mm.ae.a.a.b coH;
  private final com.tencent.mm.ae.a.b cpS;
  private final com.tencent.mm.ae.a.c.c cpT;
  private final com.tencent.mm.ae.a.a.c cpa;
  private final com.tencent.mm.ae.a.c.a cpc;
  private final com.tencent.mm.ae.a.c.b cpd;
  private final String url;

  public a(String paramString, com.tencent.mm.ae.a.a.c paramc, com.tencent.mm.ae.a.b paramb, com.tencent.mm.ae.a.c.c paramc1)
  {
    this.url = paramString;
    this.cpS = paramb;
    this.coH = this.cpS.coH;
    if (paramc == null)
    {
      this.cpa = this.coH.cpa;
      this.cpT = paramc1;
      if (this.cpa.cpd == null)
        break label87;
    }
    label87: for (this.cpd = this.cpa.cpd; ; this.cpd = this.coH.cpd)
    {
      this.cpc = this.coH.cpc;
      return;
      this.cpa = paramc;
      break;
    }
  }

  public final void run()
  {
    new com.tencent.mm.ae.a.d.b();
    com.tencent.mm.ae.a.d.b localb = this.cpd.iJ(this.url);
    if (localb == null)
      this.cpT.a(false, this.cpa.cpM);
    do
    {
      do
      {
        return;
        if (((d.decodeByteArray(localb.data, 10, 10) == null) && (this.cpa.cpL)) || (!this.cpc.a(this.url, localb.data, this.cpa)))
          break;
      }
      while (this.cpT == null);
      this.cpT.a(true, this.cpa.cpM);
      return;
    }
    while (this.cpT == null);
    this.cpT.a(false, this.cpa.cpM);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.f.a
 * JD-Core Version:    0.6.2
 */