package com.tencent.mm.ae.a.f;

import com.tencent.mm.ae.a.g.b;

public final class d
  implements Runnable
{
  public final void run()
  {
    b.CQ();
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.f.d
 * JD-Core Version:    0.6.2
 */