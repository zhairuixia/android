package com.tencent.mm.ae.a.c;

import java.util.concurrent.Executor;

public abstract interface h extends Executor
{
  public abstract boolean lU();

  public abstract void pause();

  public abstract void remove(Object paramObject);

  public abstract void resume();
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.c.h
 * JD-Core Version:    0.6.2
 */