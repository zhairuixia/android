package com.tencent.mm.ae.a.c;

public abstract interface j
{
  public abstract void an(long paramLong);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.c.j
 * JD-Core Version:    0.6.2
 */