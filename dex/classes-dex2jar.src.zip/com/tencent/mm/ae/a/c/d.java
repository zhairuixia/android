package com.tencent.mm.ae.a.c;

public abstract interface d
{
  public abstract byte[] j(Object[] paramArrayOfObject);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.c.d
 * JD-Core Version:    0.6.2
 */