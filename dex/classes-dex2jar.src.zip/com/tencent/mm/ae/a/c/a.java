package com.tencent.mm.ae.a.c;

import com.tencent.mm.ae.a.a.c;
import java.io.InputStream;

public abstract interface a
{
  public abstract void CN();

  public abstract void a(f paramf);

  public abstract boolean a(String paramString, byte[] paramArrayOfByte, c paramc);

  public abstract boolean c(String paramString, c paramc);

  public abstract InputStream d(String paramString, c paramc);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.c.a
 * JD-Core Version:    0.6.2
 */