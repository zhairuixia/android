package com.tencent.mm.ae.a.c;

import java.io.InputStream;

public abstract interface k
{
  public abstract boolean U(String paramString1, String paramString2);

  public abstract boolean a(String paramString, InputStream paramInputStream);

  public abstract boolean i(String paramString, byte[] paramArrayOfByte);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.c.k
 * JD-Core Version:    0.6.2
 */