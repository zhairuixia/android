package com.tencent.mm.ae.a.c;

public abstract interface b
{
  public abstract com.tencent.mm.ae.a.d.b iJ(String paramString);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.c.b
 * JD-Core Version:    0.6.2
 */