package com.tencent.mm.ae.a.c;

public abstract interface c
{
  public abstract void a(boolean paramBoolean, Object[] paramArrayOfObject);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.c.c
 * JD-Core Version:    0.6.2
 */