package com.tencent.mm.ae.a.c;

import android.graphics.Bitmap;

public abstract interface i
{
  public abstract void a(String paramString, Bitmap paramBitmap, Object[] paramArrayOfObject);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.c.i
 * JD-Core Version:    0.6.2
 */