package com.tencent.mm.ae.a.c;

import android.graphics.Bitmap;

public abstract interface l
{
  public abstract void clear();

  public abstract void g(String paramString, Bitmap paramBitmap);

  public abstract Bitmap im(String paramString);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.c.l
 * JD-Core Version:    0.6.2
 */