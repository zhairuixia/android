package com.tencent.mm.ae.a.c;

public abstract interface f
{
  public abstract String iK(String paramString);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.c.f
 * JD-Core Version:    0.6.2
 */