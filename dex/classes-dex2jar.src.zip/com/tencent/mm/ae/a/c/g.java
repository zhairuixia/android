package com.tencent.mm.ae.a.c;

import android.view.View;
import com.tencent.mm.ae.a.d.b;

public abstract interface g
{
  public abstract void a(String paramString, View paramView, b paramb);

  public abstract void iL(String paramString);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.c.g
 * JD-Core Version:    0.6.2
 */