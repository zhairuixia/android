package com.tencent.mm.ae.a.c;

public abstract interface e
{
  public abstract void i(Object[] paramArrayOfObject);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.a.c.e
 * JD-Core Version:    0.6.2
 */