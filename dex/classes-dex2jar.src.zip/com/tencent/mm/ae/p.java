package com.tencent.mm.ae;

import android.content.Context;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Build.VERSION;
import com.tencent.mm.compatible.d.j;
import com.tencent.mm.h.e;
import com.tencent.mm.h.h;
import com.tencent.mm.sdk.platformtools.aa;
import com.tencent.mm.sdk.platformtools.ak;
import com.tencent.mm.sdk.platformtools.be;
import com.tencent.mm.sdk.platformtools.v;

public final class p
{
  private static String[] coD = null;

  public static boolean CF()
  {
    if (coD == null)
      CG();
    if ((Build.VERSION.SDK_INT >= 14) && (coD != null) && (coD.length > 0) && (com.tencent.mm.compatible.d.p.bIZ.bIA == 1));
    for (boolean bool = true; ; bool = false)
    {
      v.d("MicroMsg.WebpUtil", "isSupportWebp: %b", new Object[] { Boolean.valueOf(bool) });
      return bool;
    }
  }

  private static void CG()
  {
    String str = h.qr().getValue("BizEnableWebpUrl");
    v.d("MicroMsg.WebpUtil", "initCdnUrlList, urllist: %s", new Object[] { str });
    if (!be.ky(str));
    try
    {
      coD = str.split(";");
      v.d("MicroMsg.WebpUtil", "initCdnUrlList, CDN_URL_LIST.length: %d", new Object[] { Integer.valueOf(coD.length) });
      return;
    }
    catch (Exception localException)
    {
      v.d("MicroMsg.WebpUtil", "initCdnUrlList error: %s", new Object[] { localException.getMessage() });
    }
  }

  private static int CH()
  {
    Context localContext = aa.getContext();
    if (ak.dJ(localContext))
      return 1;
    if (ak.dG(localContext))
      return 4;
    if (ak.dI(localContext))
      return 3;
    if (ak.dF(localContext))
      return 2;
    return 0;
  }

  public static String eA(int paramInt)
  {
    return String.format("System=android-%d,ClientVersion=%d,NetworkType=%d,Scene=%d", new Object[] { Integer.valueOf(Build.VERSION.SDK_INT), Integer.valueOf(paramInt), Integer.valueOf(CH()), Integer.valueOf(2) });
  }

  public static String eB(int paramInt)
  {
    return String.format("System=android-%d,ClientVersion=%d,NetworkType=%d,Scene=%d", new Object[] { Integer.valueOf(Build.VERSION.SDK_INT), Integer.valueOf(paramInt), Integer.valueOf(CH()), Integer.valueOf(1) });
  }

  private static boolean iC(String paramString)
  {
    boolean bool2 = false;
    boolean bool1 = bool2;
    String[] arrayOfString;
    int j;
    int i;
    if (coD != null)
    {
      bool1 = bool2;
      if (coD.length > 0)
      {
        bool1 = bool2;
        if (!be.ky(paramString))
        {
          arrayOfString = coD;
          j = arrayOfString.length;
          i = 0;
        }
      }
    }
    while (true)
    {
      bool1 = bool2;
      if (i < j)
      {
        if (paramString.startsWith(arrayOfString[i]))
          bool1 = true;
      }
      else
        return bool1;
      i += 1;
    }
  }

  public static String iD(String paramString)
  {
    if ((coD == null) || (coD.length == 0))
    {
      v.d("MicroMsg.WebpUtil", "addWebpURLIfNecessary, cdn url is null");
      CG();
    }
    if (!iC(paramString))
      v.d("MicroMsg.WebpUtil", "addWebpURLIfNecessary, is not cdn url");
    while (true)
    {
      return paramString;
      try
      {
        Object localObject = Uri.parse(paramString);
        String str1 = ((Uri)localObject).getQueryParameter("wxtype");
        if (!be.ky(str1))
        {
          str1 = str1.toLowerCase();
          v.d("MicroMsg.WebpUtil", "addWebpURLIfNecessary, wxtype:%s", new Object[] { str1 });
          if ((!str1.equals("gif")) && (!str1.contains("gif")))
          {
            String str2 = ((Uri)localObject).getQueryParameter("tp");
            if (((be.ky(str2)) || (!str2.equals("webp"))) && (!be.ky(str1)))
            {
              localObject = ((Uri)localObject).buildUpon().appendQueryParameter("tp", "webp").build().toString();
              v.d("MicroMsg.WebpUtil", "webpURL: %s", new Object[] { localObject });
              return localObject;
            }
          }
        }
      }
      catch (Exception localException)
      {
      }
    }
    return paramString;
  }

  public static boolean iE(String paramString)
  {
    try
    {
      if (be.ky(paramString))
        return false;
      if (iC(paramString))
      {
        paramString = Uri.parse(paramString).getQueryParameter("tp");
        if (!be.ky(paramString))
        {
          boolean bool = paramString.equals("webp");
          if (bool)
            return true;
        }
      }
    }
    catch (Exception paramString)
    {
    }
    return false;
  }

  public static String iF(String paramString)
  {
    try
    {
      if (!iC(paramString))
        return null;
      paramString = Uri.parse(paramString).getQueryParameter("wxtype").toLowerCase();
      if (!be.ky(paramString))
      {
        paramString = paramString.toLowerCase();
        return paramString;
      }
    }
    catch (Exception paramString)
    {
    }
    return null;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.p
 * JD-Core Version:    0.6.2
 */