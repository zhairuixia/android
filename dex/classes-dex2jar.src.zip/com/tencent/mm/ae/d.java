package com.tencent.mm.ae;

import android.content.ContentValues;
import android.database.Cursor;
import com.tencent.mm.sdk.platformtools.v;

public final class d
{
  int aJJ;
  public int aSa = -2;
  public int bZw;
  int brZ = 0;
  public long clA;
  public long clB;
  public String clC = "";
  String clD = "";
  public String clE = "";
  int clF;
  private String clG = "";
  int clH;
  public long clI;
  int clJ;
  public int clK = 0;
  public String clL = "";
  int clM = 1;
  private boolean clN;
  private boolean clO;
  private boolean clP;
  private boolean clQ;
  private boolean clR;
  private boolean clS;
  private boolean clT;
  private boolean clU;
  private boolean clV;
  private boolean clW;
  private boolean clX;
  private boolean clY;
  boolean clZ;
  private boolean cma;
  boolean cmb;
  private boolean cmc;
  private boolean cmd;
  private boolean cme;
  public int offset;
  public int status;

  public final long Cc()
  {
    return this.clI;
  }

  public final long Cd()
  {
    return this.clA;
  }

  public final String Ce()
  {
    return this.clC;
  }

  public final boolean Cf()
  {
    return (this.bZw != 0) && (this.bZw == this.offset);
  }

  public final boolean Cg()
  {
    return this.clK > 0;
  }

  public final void Ch()
  {
    this.clN = false;
    this.clO = false;
    this.clP = false;
    this.clQ = false;
    this.clR = false;
    this.clS = false;
    this.clT = false;
    this.clU = false;
    this.clV = false;
    this.clW = false;
    this.clX = false;
    this.clY = false;
    this.clZ = false;
    this.cma = false;
    this.cmb = false;
    this.cmc = false;
    this.cmd = false;
    this.cme = false;
  }

  public final void ag(long paramLong)
  {
    this.clI = paramLong;
    this.clV = true;
  }

  public final void ah(long paramLong)
  {
    this.clA = paramLong;
    this.clN = true;
  }

  public final void b(Cursor paramCursor)
  {
    this.clA = paramCursor.getInt(0);
    this.clB = paramCursor.getLong(1);
    this.offset = paramCursor.getInt(2);
    this.bZw = paramCursor.getInt(3);
    this.clC = paramCursor.getString(4);
    this.clE = paramCursor.getString(5);
    this.clH = paramCursor.getInt(6);
    this.clI = paramCursor.getInt(7);
    this.status = paramCursor.getInt(8);
    this.clJ = paramCursor.getInt(9);
    this.clK = paramCursor.getInt(10);
    this.aJJ = paramCursor.getInt(11);
    this.clL = paramCursor.getString(12);
    this.brZ = paramCursor.getInt(14);
    this.clM = paramCursor.getInt(15);
    this.clG = paramCursor.getString(16);
    this.clF = paramCursor.getInt(17);
    this.clD = paramCursor.getString(18);
  }

  public final void bV(int paramInt)
  {
    this.status = paramInt;
    this.clW = true;
  }

  public final void em(int paramInt)
  {
    this.clJ = paramInt;
    this.clX = true;
  }

  public final void en(int paramInt)
  {
    this.clH = paramInt;
    this.clU = true;
  }

  public final void eo(int paramInt)
  {
    this.bZw = paramInt;
    this.clQ = true;
  }

  public final void ep(int paramInt)
  {
    this.clK = paramInt;
    this.clY = true;
  }

  public final void eq(int paramInt)
  {
    if (this.clM != paramInt)
      this.cmc = true;
    this.clM = paramInt;
  }

  public final void er(int paramInt)
  {
    this.clF = paramInt;
    this.cme = true;
  }

  public final void io(String paramString)
  {
    this.clG = paramString;
    this.cmd = true;
  }

  public final void ip(String paramString)
  {
    this.clC = paramString;
    this.clR = true;
  }

  public final void iq(String paramString)
  {
    this.clD = paramString;
    this.clS = true;
  }

  public final void ir(String paramString)
  {
    this.clE = paramString;
    this.clT = true;
  }

  public final void is(String paramString)
  {
    if (((this.clL == null) && (paramString != null)) || ((this.clL != null) && (!this.clL.equals(paramString))))
      this.cma = true;
    this.clL = paramString;
  }

  public final long mC()
  {
    return this.clB;
  }

  public final ContentValues ms()
  {
    ContentValues localContentValues = new ContentValues();
    if (this.clN)
      localContentValues.put("id", Long.valueOf(this.clA));
    if (this.clO)
      localContentValues.put("msgSvrId", Long.valueOf(this.clB));
    if (this.clP)
      localContentValues.put("offset", Integer.valueOf(this.offset));
    if (this.clQ)
      localContentValues.put("totalLen", Integer.valueOf(this.bZw));
    if (this.clR)
      localContentValues.put("bigImgPath", this.clC);
    if (this.clS)
      localContentValues.put("midImgPath", this.clD);
    if (this.clT)
      localContentValues.put("thumbImgPath", this.clE);
    if (this.clU)
      localContentValues.put("createtime", Integer.valueOf(this.clH));
    if (this.clV)
      localContentValues.put("msglocalid", Long.valueOf(this.clI));
    if (this.clW)
      localContentValues.put("status", Integer.valueOf(this.status));
    if (this.clX)
      localContentValues.put("nettimes", Integer.valueOf(this.clJ));
    if (this.clY)
      localContentValues.put("reserved1", Integer.valueOf(this.clK));
    if (this.clZ)
      localContentValues.put("reserved2", Integer.valueOf(this.aJJ));
    if (this.cma)
      localContentValues.put("reserved3", this.clL);
    if (this.cmb)
      localContentValues.put("hashdthumb", Integer.valueOf(this.brZ));
    if (this.cmc)
      if (this.offset >= this.bZw)
        break label365;
    label365: for (int i = 0; ; i = 1)
    {
      localContentValues.put("iscomplete", Integer.valueOf(i));
      if (this.cmd)
        localContentValues.put("origImgMD5", this.clG);
      if (this.cme)
        localContentValues.put("compressType", Integer.valueOf(this.clF));
      return localContentValues;
    }
  }

  public final void setOffset(int paramInt)
  {
    int i = 0;
    if (this.offset != paramInt)
      this.clP = true;
    this.offset = paramInt;
    v.e("MicroMsg.Imgfo", "set offset : %d  id:%d total:%d", new Object[] { Integer.valueOf(paramInt), Long.valueOf(this.clI), Integer.valueOf(this.bZw) });
    if (paramInt < this.bZw);
    for (paramInt = i; ; paramInt = 1)
    {
      eq(paramInt);
      return;
    }
  }

  public final void y(long paramLong)
  {
    if (this.clB != paramLong)
      this.clO = true;
    this.clB = paramLong;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.d
 * JD-Core Version:    0.6.2
 */