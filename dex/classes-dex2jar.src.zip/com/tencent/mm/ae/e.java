package com.tencent.mm.ae;

public final class e
{
  public static d a(d paramd)
  {
    d locald1;
    if (paramd == null)
      locald1 = null;
    d locald2;
    do
    {
      do
      {
        return locald1;
        locald1 = paramd;
      }
      while (!paramd.Cg());
      locald2 = n.Cx().es(paramd.clK);
      locald1 = paramd;
    }
    while (locald2 == null);
    return locald2;
  }

  public static boolean b(d paramd)
  {
    if (paramd == null);
    int j;
    int i;
    long l;
    do
    {
      return false;
      j = paramd.offset;
      i = paramd.bZw;
      l = paramd.clB;
      if (paramd.Cg())
      {
        paramd = n.Cx().es(paramd.clK);
        j = paramd.offset;
        i = paramd.bZw;
        l = paramd.clB;
      }
      if (i == 0)
        return true;
    }
    while (((j != i) || (i == 0)) && (l == 0L));
    return true;
  }

  public static String c(d paramd)
  {
    if (paramd == null)
      return "";
    if (paramd.Cg())
    {
      paramd = n.Cx().es(paramd.clK);
      if (paramd == null)
        return "";
      return paramd.clC;
    }
    return paramd.clC;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ae.e
 * JD-Core Version:    0.6.2
 */