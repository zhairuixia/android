package com.tencent.mm.ai;

public final class d
{
  public int csJ = -1;
  public int csK = -1;
  public boolean csL = false;
  public int csM = -1;

  public d(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3)
  {
    this.csJ = paramInt1;
    this.csK = paramInt2;
    this.csL = paramBoolean;
    this.csM = paramInt3;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ai.d
 * JD-Core Version:    0.6.2
 */