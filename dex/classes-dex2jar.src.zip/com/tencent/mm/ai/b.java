package com.tencent.mm.ai;

import android.content.Context;
import com.tencent.mm.e.a.he;
import com.tencent.mm.e.a.he.b;
import com.tencent.mm.protocal.b.ael;
import com.tencent.mm.protocal.b.afy;
import com.tencent.mm.protocal.b.avh;
import com.tencent.mm.protocal.b.be;
import com.tencent.mm.protocal.b.jk;
import com.tencent.mm.sdk.c.a;
import com.tencent.mm.ui.base.h;
import com.tencent.mm.ui.base.h.a;
import java.util.LinkedList;

public final class b
{
  public static final void Ds()
  {
    he localhe = new he();
    localhe.aPo.action = 1;
    a.lfk.y(localhe);
  }

  public static final void Dt()
  {
    he localhe = new he();
    localhe.aPo.action = 2;
    a.lfk.y(localhe);
  }

  public static final void Du()
  {
    he localhe = new he();
    localhe.aPo.action = -1;
    a.lfk.y(localhe);
  }

  public static boolean Dv()
  {
    he localhe = new he();
    localhe.aPo.action = -3;
    a.lfk.y(localhe);
    return localhe.aPp.aFY;
  }

  public static boolean Dw()
  {
    he localhe = new he();
    localhe.aPo.action = 9;
    a.lfk.y(localhe);
    return localhe.aPp.aFY;
  }

  public static afy a(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10)
  {
    afy localafy = new afy();
    localafy.kJS = paramInt;
    localafy.kJY = paramString1;
    localafy.kJV = paramString2;
    localafy.kJW = paramString3;
    localafy.kKb = paramString4;
    localafy.kKa = paramString5;
    localafy.kJZ = paramString6;
    localafy.kKe = paramString8;
    localafy.kcQ = paramString10;
    localafy.kKd = paramString9;
    localafy.kJT = paramString7;
    localafy.kJU = 0.0F;
    localafy.kJX = "";
    localafy.khd = 1;
    localafy.kKc = null;
    localafy.khj = paramString7;
    return localafy;
  }

  public static afy a(String paramString, avh paramavh)
  {
    String str = null;
    if ((paramavh == null) || (paramavh.kVF == null) || (paramavh.kVF.koX == null) || (paramavh.kVF.koX.size() <= 0));
    ael localael;
    do
    {
      return null;
      localael = (ael)paramavh.kVF.koX.get(0);
    }
    while (localael == null);
    afy localafy = new afy();
    localafy.kJS = 1;
    localafy.kJT = paramavh.keK;
    localafy.kJU = 0.0F;
    localafy.kJX = "";
    localafy.kJY = localael.kHP;
    localafy.kKd = null;
    localafy.khd = 1;
    localafy.kKc = null;
    localafy.kJV = localael.aFG;
    localafy.kJW = localael.ePy;
    if (paramavh.kVF != null)
      str = paramavh.kVF.ePX;
    localafy.kKb = str;
    localafy.kKa = localael.kHT;
    localafy.kJZ = localael.ePX;
    localafy.kKf = localael.kHQ;
    localafy.khj = localael.keK;
    localafy.kKe = paramString;
    localafy.kcQ = paramavh.kVE.keK;
    localafy.kKk = paramavh.eQf;
    return localafy;
  }

  public static final void a(afy paramafy)
  {
    he localhe = new he();
    localhe.aPo.action = 6;
    localhe.aPo.aPq = paramafy;
    a.lfk.y(localhe);
  }

  public static void b(afy paramafy)
  {
    he localhe = new he();
    localhe.aPo.action = 0;
    localhe.aPo.aPq = paramafy;
    a.lfk.y(localhe);
  }

  public static boolean c(afy paramafy)
  {
    if (paramafy == null)
      return false;
    switch (paramafy.kJS)
    {
    default:
      return false;
    case 1:
    case 8:
    case 9:
    }
    return true;
  }

  public static afy mX()
  {
    he localhe = new he();
    localhe.aPo.action = -2;
    a.lfk.y(localhe);
    return localhe.aPp.aPq;
  }

  public static h p(Context paramContext, int paramInt)
  {
    paramContext = new h.a(paramContext);
    paramContext.tc(2131231056);
    paramContext.te(paramInt);
    paramContext.c(2131233983, null);
    paramContext.ie(true);
    paramContext = paramContext.bkL();
    paramContext.show();
    return paramContext;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ai.b
 * JD-Core Version:    0.6.2
 */