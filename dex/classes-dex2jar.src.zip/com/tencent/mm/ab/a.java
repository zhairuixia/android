package com.tencent.mm.ab;

public final class a
{
  int aSa = -1;
  int bXt = 0;
  String bXv = "";
  String bXw = "";
  int cib = 0;
  long cke = 0L;
  int ckf = 0;
  int type = 0;
  String username = "";

  public final String getUsername()
  {
    if (this.username == null)
      return "";
    return this.username;
  }

  public final String wC()
  {
    if (this.bXv == null)
      return "";
    return this.bXv;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ab.a
 * JD-Core Version:    0.6.2
 */