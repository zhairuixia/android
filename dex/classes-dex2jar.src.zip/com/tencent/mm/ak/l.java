package com.tencent.mm.ak;

import com.tencent.mm.a.e;
import com.tencent.mm.e.a.bc;
import com.tencent.mm.e.a.oc;
import com.tencent.mm.model.ah;
import com.tencent.mm.sdk.platformtools.v;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class l
{
  Map<Integer, a<?>> ctO = new ConcurrentHashMap();
  public com.tencent.mm.sdk.c.c ctP;
  public com.tencent.mm.sdk.c.c ctQ;

  public l()
  {
    this.ctO.put(Integer.valueOf(6), new b((byte)0));
    this.ctP = new com.tencent.mm.sdk.c.c()
    {
    };
    this.ctQ = new com.tencent.mm.sdk.c.c()
    {
    };
  }

  public static abstract interface a<T>
  {
    public abstract void delete();

    public abstract T getData();

    public abstract void update();
  }

  private static final class b
    implements l.a<f>
  {
    private f ctS = null;

    private b()
    {
      init();
    }

    private static void Dz()
    {
      try
      {
        e.deleteFile(ah.vE().cachePath + "eggingfo.ini");
        t.DF().eI(6);
        return;
      }
      catch (Exception localException)
      {
        v.w("MicroMsg.UpdatePackageListener", "init crash cannot delete file: %s", new Object[] { localException.getLocalizedMessage() });
      }
    }

    private void init()
    {
      try
      {
        if (this.ctS == null)
        {
          byte[] arrayOfByte = e.d(ah.vE().cachePath + "eggingfo.ini", 0, -1);
          if (arrayOfByte == null)
          {
            v.d("MicroMsg.UpdatePackageListener", "data is null, parse EggList from config file fail");
            return;
          }
          this.ctS = ((f)new f().aw(arrayOfByte));
          return;
        }
      }
      catch (Exception localException)
      {
        v.w("MicroMsg.UpdatePackageListener", "init crash : %s, try delete egg file", new Object[] { localException.getLocalizedMessage() });
        Dz();
      }
    }

    public final void delete()
    {
      this.ctS = null;
      Dz();
    }

    public final void update()
    {
      this.ctS = null;
      init();
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ak.l
 * JD-Core Version:    0.6.2
 */