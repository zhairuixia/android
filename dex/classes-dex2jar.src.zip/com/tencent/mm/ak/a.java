package com.tencent.mm.ak;

import android.content.ContentValues;
import android.database.Cursor;

public final class a
{
  int aSa = -1;
  private String bZA = "";
  private int bZB = 0;
  private int bZC = 0;
  private String bZz = "";
  public int ctu = 0;
  private String path = "";
  public String username = "";

  public final void b(Cursor paramCursor)
  {
    this.username = paramCursor.getString(0);
    this.ctu = paramCursor.getInt(1);
    this.path = paramCursor.getString(2);
    this.bZz = paramCursor.getString(3);
    this.bZA = paramCursor.getString(4);
    this.bZB = paramCursor.getInt(5);
    this.bZC = paramCursor.getInt(6);
  }

  public final String getUsername()
  {
    if (this.username == null)
      return "";
    return this.username;
  }

  public final ContentValues ms()
  {
    ContentValues localContentValues = new ContentValues();
    if ((this.aSa & 0x1) != 0)
      localContentValues.put("username", getUsername());
    if ((this.aSa & 0x2) != 0)
      localContentValues.put("bgflag", Integer.valueOf(this.ctu));
    if ((this.aSa & 0x4) != 0)
    {
      if (this.path == null)
      {
        str = "";
        localContentValues.put("path", str);
      }
    }
    else
    {
      if ((this.aSa & 0x8) != 0)
      {
        if (this.bZz != null)
          break label185;
        str = "";
        label95: localContentValues.put("reserved1", str);
      }
      if ((this.aSa & 0x10) != 0)
        if (this.bZA != null)
          break label193;
    }
    label185: label193: for (String str = ""; ; str = this.bZA)
    {
      localContentValues.put("reserved2", str);
      if ((this.aSa & 0x20) != 0)
        localContentValues.put("reserved3", Integer.valueOf(this.bZB));
      if ((this.aSa & 0x40) != 0)
        localContentValues.put("reserved4", Integer.valueOf(this.bZC));
      return localContentValues;
      str = this.path;
      break;
      str = this.bZz;
      break label95;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ak.a
 * JD-Core Version:    0.6.2
 */