package com.tencent.mm.ak;

import android.content.ContentValues;
import android.database.Cursor;

public final class m
{
  private String aKT = this.id + "_" + this.ctU;
  int aSa = -1;
  private String bZA = "";
  private int bZB = 0;
  private int bZC = 0;
  private String bZz = "";
  String ctT = "";
  public int ctU = 0;
  public int id = 0;
  String name = "";
  int size = 0;
  public int status = 0;
  public int version = 0;

  public final String DA()
  {
    if (this.ctT == null)
      return "";
    return this.ctT;
  }

  public final void b(Cursor paramCursor)
  {
    this.version = paramCursor.getInt(2);
    this.name = paramCursor.getString(3);
    this.size = paramCursor.getInt(4);
    this.ctT = paramCursor.getString(5);
    this.status = paramCursor.getInt(6);
    this.bZz = paramCursor.getString(8);
    this.bZA = paramCursor.getString(9);
    this.ctU = paramCursor.getInt(7);
    this.bZC = paramCursor.getInt(11);
    this.id = paramCursor.getInt(1);
    this.bZB = paramCursor.getInt(10);
    this.aKT = paramCursor.getString(0);
  }

  public final ContentValues ms()
  {
    ContentValues localContentValues = new ContentValues();
    if ((this.aSa & 0x2) != 0)
      localContentValues.put("id", Integer.valueOf(this.id));
    if ((this.aSa & 0x4) != 0)
      localContentValues.put("version", Integer.valueOf(this.version));
    if ((this.aSa & 0x8) != 0)
    {
      if (this.name == null)
      {
        str = "";
        localContentValues.put("name", str);
      }
    }
    else
    {
      if ((this.aSa & 0x10) != 0)
        localContentValues.put("size", Integer.valueOf(this.size));
      if ((this.aSa & 0x20) != 0)
        localContentValues.put("packname", DA());
      if ((this.aSa & 0x40) != 0)
        localContentValues.put("status", Integer.valueOf(this.status));
      if ((this.aSa & 0x80) != 0)
        localContentValues.put("type", Integer.valueOf(this.ctU));
      if ((this.aSa & 0x100) != 0)
      {
        if (this.bZz != null)
          break label327;
        str = "";
        label190: localContentValues.put("reserved1", str);
      }
      if ((this.aSa & 0x200) != 0)
        if (this.bZA != null)
          break label335;
    }
    label327: label335: for (String str = ""; ; str = this.bZA)
    {
      localContentValues.put("reserved2", str);
      if ((this.aSa & 0x400) != 0)
        localContentValues.put("reserved3", Integer.valueOf(this.bZB));
      if ((this.aSa & 0x800) != 0)
        localContentValues.put("reserved4", Integer.valueOf(this.bZC));
      if ((this.aSa & 0x1) != 0)
        localContentValues.put("localId", this.id + "_" + this.ctU);
      return localContentValues;
      str = this.name;
      break;
      str = this.bZz;
      break label190;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ak.m
 * JD-Core Version:    0.6.2
 */