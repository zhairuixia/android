package com.tencent.mm.af;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.telephony.TelephonyManager;
import com.tencent.mm.model.h;
import com.tencent.mm.sdk.platformtools.aa;
import com.tencent.mm.sdk.platformtools.be;
import com.tencent.mm.sdk.platformtools.u;
import com.tencent.mm.sdk.platformtools.v;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

public final class b
{
  private static Map<String, a> cqc = null;
  private static String cqd = null;

  public static boolean CR()
  {
    return (be.CX()) || (!u.bcy().equals("zh_CN"));
  }

  public static boolean CS()
  {
    return be.CX();
  }

  public static boolean CT()
  {
    return (h.ud() != 0) || (!be.CX());
  }

  public static boolean CU()
  {
    return be.CX();
  }

  public static boolean CV()
  {
    if (!u.bcy().equals("zh_CN"));
    TimeZone localTimeZone1;
    TimeZone localTimeZone2;
    do
    {
      return true;
      localTimeZone1 = TimeZone.getDefault();
      localTimeZone2 = TimeZone.getTimeZone("GMT+08:00");
    }
    while (localTimeZone1.getRawOffset() != localTimeZone2.getRawOffset());
    return false;
  }

  public static boolean CW()
  {
    if (!u.bcy().equals("zh_CN"))
      return true;
    Object localObject = TimeZone.getDefault();
    TimeZone localTimeZone = TimeZone.getTimeZone("GMT+08:00");
    if (((TimeZone)localObject).getRawOffset() != localTimeZone.getRawOffset())
      return true;
    localObject = (TelephonyManager)aa.getContext().getSystemService("phone");
    if (localObject != null)
    {
      localObject = ((TelephonyManager)localObject).getNetworkCountryIso();
      if ((!be.ky((String)localObject)) && (!((String)localObject).equalsIgnoreCase("cn")))
        return true;
    }
    return false;
  }

  public static boolean CX()
  {
    return be.CX();
  }

  public static a h(Context paramContext, String paramString1, String paramString2)
  {
    Object localObject1 = null;
    try
    {
      Object localObject2 = paramContext.getResources().getConfiguration().locale.getLanguage();
      if (localObject2 != null)
      {
        localObject3 = localObject2;
        localObject1 = localObject2;
        if (((String)localObject2).equals(cqd));
      }
      else
      {
        localObject1 = localObject2;
        cqc = null;
        localObject3 = localObject2;
      }
      if (cqc == null)
      {
        cqc = new HashMap();
        cqd = (String)localObject3;
        localObject2 = null;
        localObject1 = null;
        try
        {
          localObject3 = paramContext.getAssets().open("country_code.txt");
          localObject1 = localObject3;
          localObject2 = localObject3;
          paramContext = new byte[((InputStream)localObject3).available()];
          localObject1 = localObject3;
          localObject2 = localObject3;
          ((InputStream)localObject3).read(paramContext);
          localObject1 = localObject3;
          localObject2 = localObject3;
          str = new String(paramContext);
          paramContext = str;
          if (localObject3 != null);
          try
          {
            ((InputStream)localObject3).close();
            paramContext = str;
            paramContext = paramContext.trim().split("\n");
            paramString2 = be.lC(paramString2).trim().split(",");
            int i = 0;
            while (true)
            {
              if (i >= paramContext.length)
                break label493;
              localObject1 = paramContext[i].trim().split(" ");
              if (localObject1.length >= 2)
                break;
              v.e("MicroMsg.InternationaPluginlLogic", "this country item has problem %s", new Object[] { paramContext[i] });
              i += 1;
            }
          }
          catch (IOException paramContext)
          {
            while (true)
            {
              v.e("MicroMsg.InternationaPluginlLogic", "exception:%s", new Object[] { be.f(paramContext) });
              paramContext = str;
            }
          }
        }
        catch (IOException paramContext)
        {
          while (true)
          {
            localObject2 = localObject1;
            v.e("MicroMsg.InternationaPluginlLogic", "exception:%s", new Object[] { be.f(paramContext) });
            if (localObject1 == null)
              break;
            try
            {
              ((InputStream)localObject1).close();
              paramContext = "";
            }
            catch (IOException paramContext)
            {
              v.e("MicroMsg.InternationaPluginlLogic", "exception:%s", new Object[] { be.f(paramContext) });
              paramContext = "";
            }
          }
        }
        finally
        {
          while (true)
          {
            String str;
            if (localObject2 != null);
            try
            {
              ((InputStream)localObject2).close();
              throw paramContext;
            }
            catch (IOException paramString1)
            {
              while (true)
                v.e("MicroMsg.InternationaPluginlLogic", "exception:%s", new Object[] { be.f(paramString1) });
            }
            localObject2 = new a();
            ((a)localObject2).cqe = localObject1[0];
            ((a)localObject2).cqf = localObject1[1];
            int k = paramString2.length;
            int j = 0;
            if (j < k)
            {
              str = paramString2[j];
              localObject3 = str.trim().split(":");
              if (localObject3.length < 2)
                v.e("MicroMsg.InternationaPluginlLogic", "this country item has problem %s", new Object[] { str });
              do
              {
                j += 1;
                break;
                str = localObject3[0];
              }
              while (!localObject1[1].equals(str));
              ((a)localObject2).cqg = localObject3[1];
            }
            cqc.put(((a)localObject2).cqe, localObject2);
          }
        }
      }
      else
      {
        label493: return (a)cqc.get(paramString1.toUpperCase());
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        Object localObject3 = localObject1;
        continue;
        paramContext = "";
      }
    }
  }

  public static boolean iO(String paramString)
  {
    return (paramString != null) && (paramString.length() > 1) && (paramString.startsWith("+")) && (!paramString.startsWith("+86"));
  }

  public static String iP(String paramString)
  {
    if ((paramString.startsWith("+886")) || (paramString.startsWith("+86")))
      return "zh-TW";
    if ((paramString.startsWith("+852")) || (paramString.startsWith("+853")))
      return "zh-HK";
    if (paramString.startsWith("+81"))
      return "ja";
    if (paramString.startsWith("+82"))
      return "ko";
    if (paramString.startsWith("+66"))
      return "th";
    if (paramString.startsWith("+84"))
      return "vi";
    if (paramString.startsWith("+62"))
      return "id";
    if (paramString.startsWith("+55"))
      return "pt";
    if (paramString.startsWith("+34"))
      return "es-419";
    return "en";
  }

  public static final class a
  {
    public String cqe;
    public String cqf;
    public String cqg;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.af.b
 * JD-Core Version:    0.6.2
 */