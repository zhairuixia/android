package com.tencent.mm.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import com.tencent.mm.booter.CoreService;
import com.tencent.mm.booter.b;
import com.tencent.mm.model.ah;
import com.tencent.mm.model.w;
import com.tencent.mm.network.g.a;
import com.tencent.mm.network.q.a;
import com.tencent.mm.sdk.platformtools.aa;
import com.tencent.mm.sdk.platformtools.ad;
import com.tencent.mm.sdk.platformtools.v;
import com.tencent.mm.t.m;

final class c
  implements ServiceConnection
{
  private static boolean azf = false;
  private Runnable azg = new Runnable()
  {
    private int azk = 0;

    // ERROR //
    public final void run()
    {
      // Byte code:
      //   0: ldc 27
      //   2: ldc 29
      //   4: iconst_1
      //   5: anewarray 4	java/lang/Object
      //   8: dup
      //   9: iconst_0
      //   10: aload_0
      //   11: getfield 21	com/tencent/mm/app/c$3:azk	I
      //   14: invokestatic 35	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
      //   17: aastore
      //   18: invokestatic 41	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
      //   21: invokestatic 47	com/tencent/mm/sdk/platformtools/v:e	(Ljava/lang/String;Ljava/lang/String;)V
      //   24: aload_0
      //   25: getfield 21	com/tencent/mm/app/c$3:azk	I
      //   28: iconst_1
      //   29: if_icmpne +39 -> 68
      //   32: ldc 49
      //   34: invokestatic 53	com/tencent/mm/app/c:bg	(Ljava/lang/String;)I
      //   37: istore_1
      //   38: iload_1
      //   39: iconst_m1
      //   40: if_icmpeq +126 -> 166
      //   43: iload_1
      //   44: invokestatic 59	android/os/Process:killProcess	(I)V
      //   47: ldc 27
      //   49: ldc 61
      //   51: iconst_1
      //   52: anewarray 4	java/lang/Object
      //   55: dup
      //   56: iconst_0
      //   57: iload_1
      //   58: invokestatic 35	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
      //   61: aastore
      //   62: invokestatic 41	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
      //   65: invokestatic 64	com/tencent/mm/sdk/platformtools/v:d	(Ljava/lang/String;Ljava/lang/String;)V
      //   68: invokestatic 70	com/tencent/mm/sdk/platformtools/aa:getContext	()Landroid/content/Context;
      //   71: astore_2
      //   72: new 72	android/content/Intent
      //   75: dup
      //   76: aload_2
      //   77: ldc 74
      //   79: invokespecial 77	android/content/Intent:<init>	(Landroid/content/Context;Ljava/lang/Class;)V
      //   82: astore_3
      //   83: ldc 27
      //   85: ldc 79
      //   87: invokestatic 82	com/tencent/mm/sdk/platformtools/v:i	(Ljava/lang/String;Ljava/lang/String;)V
      //   90: aload_2
      //   91: aload_0
      //   92: getfield 16	com/tencent/mm/app/c$3:azh	Lcom/tencent/mm/app/c;
      //   95: invokevirtual 88	android/content/Context:unbindService	(Landroid/content/ServiceConnection;)V
      //   98: aload_2
      //   99: aload_3
      //   100: invokevirtual 92	android/content/Context:stopService	(Landroid/content/Intent;)Z
      //   103: pop
      //   104: aload_2
      //   105: aload_3
      //   106: aload_0
      //   107: getfield 16	com/tencent/mm/app/c$3:azh	Lcom/tencent/mm/app/c;
      //   110: iconst_1
      //   111: invokevirtual 96	android/content/Context:bindService	(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
      //   114: pop
      //   115: aload_2
      //   116: aload_3
      //   117: invokevirtual 100	android/content/Context:startService	(Landroid/content/Intent;)Landroid/content/ComponentName;
      //   120: pop
      //   121: aload_0
      //   122: getfield 21	com/tencent/mm/app/c$3:azk	I
      //   125: iconst_1
      //   126: if_icmpne +106 -> 232
      //   129: aload_0
      //   130: iconst_0
      //   131: putfield 21	com/tencent/mm/app/c$3:azk	I
      //   134: aload_0
      //   135: ldc2_w 101
      //   138: invokestatic 107	com/tencent/mm/sdk/platformtools/ad:e	(Ljava/lang/Runnable;J)V
      //   141: ldc 27
      //   143: ldc 109
      //   145: iconst_1
      //   146: anewarray 4	java/lang/Object
      //   149: dup
      //   150: iconst_0
      //   151: aload_0
      //   152: getfield 21	com/tencent/mm/app/c$3:azk	I
      //   155: invokestatic 35	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
      //   158: aastore
      //   159: invokestatic 41	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
      //   162: invokestatic 64	com/tencent/mm/sdk/platformtools/v:d	(Ljava/lang/String;Ljava/lang/String;)V
      //   165: return
      //   166: ldc 27
      //   168: ldc 111
      //   170: invokestatic 64	com/tencent/mm/sdk/platformtools/v:d	(Ljava/lang/String;Ljava/lang/String;)V
      //   173: goto -105 -> 68
      //   176: astore 4
      //   178: aload_2
      //   179: aload_3
      //   180: invokevirtual 92	android/content/Context:stopService	(Landroid/content/Intent;)Z
      //   183: pop
      //   184: aload_2
      //   185: aload_3
      //   186: aload_0
      //   187: getfield 16	com/tencent/mm/app/c$3:azh	Lcom/tencent/mm/app/c;
      //   190: iconst_1
      //   191: invokevirtual 96	android/content/Context:bindService	(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
      //   194: pop
      //   195: aload_2
      //   196: aload_3
      //   197: invokevirtual 100	android/content/Context:startService	(Landroid/content/Intent;)Landroid/content/ComponentName;
      //   200: pop
      //   201: goto -80 -> 121
      //   204: astore 4
      //   206: aload_2
      //   207: aload_3
      //   208: invokevirtual 92	android/content/Context:stopService	(Landroid/content/Intent;)Z
      //   211: pop
      //   212: aload_2
      //   213: aload_3
      //   214: aload_0
      //   215: getfield 16	com/tencent/mm/app/c$3:azh	Lcom/tencent/mm/app/c;
      //   218: iconst_1
      //   219: invokevirtual 96	android/content/Context:bindService	(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
      //   222: pop
      //   223: aload_2
      //   224: aload_3
      //   225: invokevirtual 100	android/content/Context:startService	(Landroid/content/Intent;)Landroid/content/ComponentName;
      //   228: pop
      //   229: aload 4
      //   231: athrow
      //   232: aload_0
      //   233: aload_0
      //   234: getfield 21	com/tencent/mm/app/c$3:azk	I
      //   237: iconst_1
      //   238: iadd
      //   239: putfield 21	com/tencent/mm/app/c$3:azk	I
      //   242: goto -108 -> 134
      //
      // Exception table:
      //   from	to	target	type
      //   83	98	176	java/lang/Exception
      //   83	98	204	finally
    }
  };
  private Object lock = new Object();

  // ERROR //
  private static int bf(java.lang.String paramString)
  {
    // Byte code:
    //   0: new 43	java/io/File
    //   3: dup
    //   4: ldc 45
    //   6: invokespecial 48	java/io/File:<init>	(Ljava/lang/String;)V
    //   9: invokevirtual 52	java/io/File:listFiles	()[Ljava/io/File;
    //   12: astore 8
    //   14: aload 8
    //   16: arraylength
    //   17: istore 4
    //   19: iconst_0
    //   20: istore_2
    //   21: iconst_m1
    //   22: istore_1
    //   23: aconst_null
    //   24: astore 6
    //   26: iload_1
    //   27: istore_3
    //   28: iload_2
    //   29: iload 4
    //   31: if_icmpge +71 -> 102
    //   34: aload 8
    //   36: iload_2
    //   37: aaload
    //   38: astore 7
    //   40: aload 7
    //   42: invokevirtual 56	java/io/File:getName	()Ljava/lang/String;
    //   45: invokestatic 61	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   48: istore_3
    //   49: iload_3
    //   50: istore_1
    //   51: new 63	java/util/Scanner
    //   54: dup
    //   55: new 43	java/io/File
    //   58: dup
    //   59: aload 7
    //   61: ldc 65
    //   63: invokespecial 68	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   66: invokespecial 71	java/util/Scanner:<init>	(Ljava/io/File;)V
    //   69: astore 7
    //   71: aload 7
    //   73: invokevirtual 75	java/util/Scanner:hasNext	()Z
    //   76: ifeq +28 -> 104
    //   79: aload 7
    //   81: invokevirtual 78	java/util/Scanner:nextLine	()Ljava/lang/String;
    //   84: aload_0
    //   85: invokevirtual 84	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   88: istore 5
    //   90: iload 5
    //   92: ifeq +12 -> 104
    //   95: aload 7
    //   97: invokevirtual 87	java/util/Scanner:close	()V
    //   100: iload_1
    //   101: istore_3
    //   102: iload_3
    //   103: ireturn
    //   104: aload 7
    //   106: invokevirtual 87	java/util/Scanner:close	()V
    //   109: aconst_null
    //   110: astore 6
    //   112: iload_1
    //   113: istore_3
    //   114: iload_2
    //   115: iconst_1
    //   116: iadd
    //   117: istore_2
    //   118: iload_3
    //   119: istore_1
    //   120: goto -94 -> 26
    //   123: astore 6
    //   125: iload_1
    //   126: istore_3
    //   127: aload 7
    //   129: astore 6
    //   131: aload 7
    //   133: ifnull -19 -> 114
    //   136: aload 7
    //   138: invokevirtual 87	java/util/Scanner:close	()V
    //   141: aconst_null
    //   142: astore 6
    //   144: iload_1
    //   145: istore_3
    //   146: goto -32 -> 114
    //   149: astore_0
    //   150: aload 7
    //   152: astore 6
    //   154: aload 6
    //   156: ifnull +8 -> 164
    //   159: aload 6
    //   161: invokevirtual 87	java/util/Scanner:close	()V
    //   164: aload_0
    //   165: athrow
    //   166: astore_0
    //   167: goto -13 -> 154
    //   170: astore 7
    //   172: aload 6
    //   174: astore 7
    //   176: goto -51 -> 125
    //   179: astore 7
    //   181: iload_1
    //   182: istore_3
    //   183: goto -69 -> 114
    //
    // Exception table:
    //   from	to	target	type
    //   71	90	123	java/io/FileNotFoundException
    //   71	90	149	finally
    //   51	71	166	finally
    //   51	71	170	java/io/FileNotFoundException
    //   40	49	179	java/lang/NumberFormatException
  }

  public final void ad(Context arg1)
  {
    if (!b.s(???, "noop"))
    {
      v.i("MicroMsg.CoreServiceConnection", "ensureServiceInstance return false");
      return;
    }
    Intent localIntent = new Intent(???, CoreService.class);
    v.i("MicroMsg.CoreServiceConnection", "prepare dispatcher / bind core service");
    if (!???.bindService(localIntent, this, 1))
    {
      v.e("MicroMsg.CoreServiceConnection", "bindService failed, may be caused by some crashes");
      return;
    }
    synchronized (this.lock)
    {
      if (!azf)
      {
        azf = true;
        v.d("MicroMsg.CoreServiceConnection", "ZombieWaker posted.");
        ad.e(this.azg, 10000L);
      }
      return;
    }
  }

  // ERROR //
  public final void onServiceConnected(ComponentName paramComponentName, android.os.IBinder paramIBinder)
  {
    // Byte code:
    //   0: ldc 102
    //   2: ldc 150
    //   4: invokestatic 153	com/tencent/mm/sdk/platformtools/v:w	(Ljava/lang/String;Ljava/lang/String;)V
    //   7: aload_0
    //   8: getfield 30	com/tencent/mm/app/c:lock	Ljava/lang/Object;
    //   11: astore_1
    //   12: aload_1
    //   13: monitorenter
    //   14: aload_0
    //   15: getfield 35	com/tencent/mm/app/c:azg	Ljava/lang/Runnable;
    //   18: invokestatic 156	com/tencent/mm/sdk/platformtools/ad:w	(Ljava/lang/Runnable;)V
    //   21: iconst_0
    //   22: putstatic 24	com/tencent/mm/app/c:azf	Z
    //   25: aload_1
    //   26: monitorexit
    //   27: aload_2
    //   28: ifnonnull +16 -> 44
    //   31: ldc 158
    //   33: iconst_0
    //   34: invokestatic 164	junit/framework/Assert:assertTrue	(Ljava/lang/String;Z)V
    //   37: ldc 158
    //   39: ldc 166
    //   41: invokestatic 171	com/tencent/mm/sdk/b/b:q	(Ljava/lang/String;Ljava/lang/String;)V
    //   44: new 173	com/tencent/mm/t/o
    //   47: dup
    //   48: aload_2
    //   49: invokestatic 179	com/tencent/mm/network/f$a:A	(Landroid/os/IBinder;)Lcom/tencent/mm/network/f;
    //   52: invokespecial 182	com/tencent/mm/t/o:<init>	(Lcom/tencent/mm/network/f;)V
    //   55: astore_1
    //   56: new 8	com/tencent/mm/app/c$1
    //   59: dup
    //   60: aload_0
    //   61: invokespecial 183	com/tencent/mm/app/c$1:<init>	(Lcom/tencent/mm/app/c;)V
    //   64: astore_2
    //   65: aload_1
    //   66: getfield 187	com/tencent/mm/t/o:cbl	Lcom/tencent/mm/network/f;
    //   69: aload_2
    //   70: invokeinterface 193 2 0
    //   75: new 10	com/tencent/mm/app/c$2
    //   78: dup
    //   79: aload_0
    //   80: invokespecial 194	com/tencent/mm/app/c$2:<init>	(Lcom/tencent/mm/app/c;)V
    //   83: astore_2
    //   84: aload_1
    //   85: getfield 187	com/tencent/mm/t/o:cbl	Lcom/tencent/mm/network/f;
    //   88: aload_2
    //   89: invokeinterface 197 2 0
    //   94: aload_1
    //   95: invokestatic 203	com/tencent/mm/model/ah:b	(Lcom/tencent/mm/network/e;)V
    //   98: invokestatic 208	com/tencent/mm/model/a:td	()Z
    //   101: ifeq +55 -> 156
    //   104: invokestatic 212	com/tencent/mm/model/ah:vE	()Lcom/tencent/mm/model/c;
    //   107: getfield 218	com/tencent/mm/model/c:bUx	Lcom/tencent/mm/model/a;
    //   110: astore_2
    //   111: invokestatic 222	com/tencent/mm/model/ah:vF	()Lcom/tencent/mm/t/m;
    //   114: getfield 228	com/tencent/mm/t/m:caV	Lcom/tencent/mm/network/e;
    //   117: invokeinterface 234 1 0
    //   122: astore 6
    //   124: invokestatic 240	com/tencent/mm/sdk/platformtools/be:IC	()J
    //   127: lstore 4
    //   129: aload 6
    //   131: ifnonnull +120 -> 251
    //   134: ldc 242
    //   136: ldc 244
    //   138: invokestatic 130	com/tencent/mm/sdk/platformtools/v:e	(Ljava/lang/String;Ljava/lang/String;)V
    //   141: getstatic 250	com/tencent/mm/plugin/report/service/g:gIW	Lcom/tencent/mm/plugin/report/service/g;
    //   144: astore_2
    //   145: ldc2_w 251
    //   148: ldc2_w 253
    //   151: lconst_1
    //   152: iconst_0
    //   153: invokestatic 257	com/tencent/mm/plugin/report/service/g:b	(JJJZ)V
    //   156: invokestatic 260	com/tencent/mm/model/ah:tg	()Z
    //   159: ifeq +30 -> 189
    //   162: invokestatic 222	com/tencent/mm/model/ah:vF	()Lcom/tencent/mm/t/m;
    //   165: ifnull +24 -> 189
    //   168: invokestatic 222	com/tencent/mm/model/ah:vF	()Lcom/tencent/mm/t/m;
    //   171: getfield 228	com/tencent/mm/t/m:caV	Lcom/tencent/mm/network/e;
    //   174: ifnull +15 -> 189
    //   177: invokestatic 222	com/tencent/mm/model/ah:vF	()Lcom/tencent/mm/t/m;
    //   180: getfield 228	com/tencent/mm/t/m:caV	Lcom/tencent/mm/network/e;
    //   183: iconst_1
    //   184: invokeinterface 264 2 0
    //   189: aload_1
    //   190: invokestatic 268	com/tencent/mm/modelstat/m:d	(Lcom/tencent/mm/network/e;)V
    //   193: aload_1
    //   194: invokestatic 270	com/tencent/mm/modelstat/m:e	(Lcom/tencent/mm/network/e;)V
    //   197: return
    //   198: astore_2
    //   199: aload_1
    //   200: monitorexit
    //   201: aload_2
    //   202: athrow
    //   203: astore_2
    //   204: ldc_w 272
    //   207: ldc_w 274
    //   210: iconst_1
    //   211: anewarray 4	java/lang/Object
    //   214: dup
    //   215: iconst_0
    //   216: aload_2
    //   217: invokestatic 278	com/tencent/mm/sdk/platformtools/be:f	(Ljava/lang/Throwable;)Ljava/lang/String;
    //   220: aastore
    //   221: invokestatic 281	com/tencent/mm/sdk/platformtools/v:e	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   224: goto -149 -> 75
    //   227: astore_2
    //   228: ldc_w 272
    //   231: ldc_w 274
    //   234: iconst_1
    //   235: anewarray 4	java/lang/Object
    //   238: dup
    //   239: iconst_0
    //   240: aload_2
    //   241: invokestatic 278	com/tencent/mm/sdk/platformtools/be:f	(Ljava/lang/Throwable;)Ljava/lang/String;
    //   244: aastore
    //   245: invokestatic 281	com/tencent/mm/sdk/platformtools/v:e	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   248: goto -154 -> 94
    //   251: ldc 242
    //   253: ldc_w 283
    //   256: iconst_2
    //   257: anewarray 4	java/lang/Object
    //   260: dup
    //   261: iconst_0
    //   262: aload 6
    //   264: invokeinterface 288 1 0
    //   269: invokestatic 294	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
    //   272: aastore
    //   273: dup
    //   274: iconst_1
    //   275: aload_2
    //   276: invokevirtual 298	com/tencent/mm/model/a:tc	()I
    //   279: invokestatic 301	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   282: aastore
    //   283: invokestatic 303	com/tencent/mm/sdk/platformtools/v:i	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   286: aload 6
    //   288: invokeinterface 288 1 0
    //   293: ifeq +130 -> 423
    //   296: aload_2
    //   297: invokevirtual 298	com/tencent/mm/model/a:tc	()I
    //   300: ifle +96 -> 396
    //   303: getstatic 250	com/tencent/mm/plugin/report/service/g:gIW	Lcom/tencent/mm/plugin/report/service/g;
    //   306: astore 7
    //   308: ldc2_w 251
    //   311: ldc2_w 304
    //   314: lconst_1
    //   315: iconst_0
    //   316: invokestatic 257	com/tencent/mm/plugin/report/service/g:b	(JJJZ)V
    //   319: ldc 242
    //   321: ldc_w 307
    //   324: invokestatic 130	com/tencent/mm/sdk/platformtools/v:e	(Ljava/lang/String;Ljava/lang/String;)V
    //   327: aload_2
    //   328: aconst_null
    //   329: putfield 311	com/tencent/mm/model/a:bTW	[B
    //   332: aload_2
    //   333: aload 6
    //   335: invokeinterface 315 1 0
    //   340: putfield 311	com/tencent/mm/model/a:bTW	[B
    //   343: getstatic 250	com/tencent/mm/plugin/report/service/g:gIW	Lcom/tencent/mm/plugin/report/service/g;
    //   346: astore 6
    //   348: aload_2
    //   349: invokevirtual 298	com/tencent/mm/model/a:tc	()I
    //   352: ifle +224 -> 576
    //   355: ldc2_w 316
    //   358: lstore 4
    //   360: ldc2_w 251
    //   363: lload 4
    //   365: lconst_1
    //   366: iconst_0
    //   367: invokestatic 257	com/tencent/mm/plugin/report/service/g:b	(JJJZ)V
    //   370: goto -214 -> 156
    //   373: astore_2
    //   374: ldc 242
    //   376: ldc_w 319
    //   379: iconst_1
    //   380: anewarray 4	java/lang/Object
    //   383: dup
    //   384: iconst_0
    //   385: aload_2
    //   386: invokestatic 278	com/tencent/mm/sdk/platformtools/be:f	(Ljava/lang/Throwable;)Ljava/lang/String;
    //   389: aastore
    //   390: invokestatic 281	com/tencent/mm/sdk/platformtools/v:e	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   393: goto -237 -> 156
    //   396: ldc 242
    //   398: ldc_w 321
    //   401: invokestatic 153	com/tencent/mm/sdk/platformtools/v:w	(Ljava/lang/String;Ljava/lang/String;)V
    //   404: getstatic 250	com/tencent/mm/plugin/report/service/g:gIW	Lcom/tencent/mm/plugin/report/service/g;
    //   407: astore 7
    //   409: ldc2_w 251
    //   412: ldc2_w 322
    //   415: lconst_1
    //   416: iconst_0
    //   417: invokestatic 257	com/tencent/mm/plugin/report/service/g:b	(JJJZ)V
    //   420: goto -88 -> 332
    //   423: aload_2
    //   424: invokevirtual 298	com/tencent/mm/model/a:tc	()I
    //   427: ifgt +41 -> 468
    //   430: getstatic 250	com/tencent/mm/plugin/report/service/g:gIW	Lcom/tencent/mm/plugin/report/service/g;
    //   433: astore 6
    //   435: ldc2_w 251
    //   438: ldc2_w 324
    //   441: lconst_1
    //   442: iconst_0
    //   443: invokestatic 257	com/tencent/mm/plugin/report/service/g:b	(JJJZ)V
    //   446: ldc 242
    //   448: ldc_w 327
    //   451: iconst_1
    //   452: anewarray 4	java/lang/Object
    //   455: dup
    //   456: iconst_0
    //   457: aload_2
    //   458: invokevirtual 330	java/lang/Object:toString	()Ljava/lang/String;
    //   461: aastore
    //   462: invokestatic 332	com/tencent/mm/sdk/platformtools/v:w	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   465: goto -309 -> 156
    //   468: aload 6
    //   470: aload_2
    //   471: getfield 311	com/tencent/mm/model/a:bTW	[B
    //   474: invokeinterface 336 2 0
    //   479: istore_3
    //   480: ldc 242
    //   482: ldc_w 338
    //   485: iconst_3
    //   486: anewarray 4	java/lang/Object
    //   489: dup
    //   490: iconst_0
    //   491: iload_3
    //   492: invokestatic 301	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   495: aastore
    //   496: dup
    //   497: iconst_1
    //   498: lload 4
    //   500: invokestatic 342	com/tencent/mm/sdk/platformtools/be:az	(J)J
    //   503: invokestatic 347	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   506: aastore
    //   507: dup
    //   508: iconst_2
    //   509: aload_2
    //   510: invokevirtual 298	com/tencent/mm/model/a:tc	()I
    //   513: invokestatic 301	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   516: aastore
    //   517: invokestatic 303	com/tencent/mm/sdk/platformtools/v:i	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   520: iload_3
    //   521: ifeq +47 -> 568
    //   524: ldc 242
    //   526: ldc_w 349
    //   529: iconst_1
    //   530: anewarray 4	java/lang/Object
    //   533: dup
    //   534: iconst_0
    //   535: iload_3
    //   536: invokestatic 301	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   539: aastore
    //   540: invokestatic 281	com/tencent/mm/sdk/platformtools/v:e	(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    //   543: aload_2
    //   544: aconst_null
    //   545: putfield 311	com/tencent/mm/model/a:bTW	[B
    //   548: getstatic 250	com/tencent/mm/plugin/report/service/g:gIW	Lcom/tencent/mm/plugin/report/service/g;
    //   551: astore_2
    //   552: ldc2_w 251
    //   555: iload_3
    //   556: bipush 20
    //   558: iadd
    //   559: i2l
    //   560: lconst_1
    //   561: iconst_0
    //   562: invokestatic 257	com/tencent/mm/plugin/report/service/g:b	(JJJZ)V
    //   565: goto -409 -> 156
    //   568: aload_2
    //   569: lconst_0
    //   570: putfield 353	com/tencent/mm/model/a:bTX	J
    //   573: goto -25 -> 548
    //   576: ldc2_w 354
    //   579: lstore 4
    //   581: goto -221 -> 360
    //
    // Exception table:
    //   from	to	target	type
    //   14	27	198	finally
    //   199	201	198	finally
    //   65	75	203	java/lang/Exception
    //   84	94	227	java/lang/Exception
    //   104	129	373	java/lang/Throwable
    //   134	156	373	java/lang/Throwable
    //   251	332	373	java/lang/Throwable
    //   332	355	373	java/lang/Throwable
    //   360	370	373	java/lang/Throwable
    //   396	420	373	java/lang/Throwable
    //   423	465	373	java/lang/Throwable
    //   468	520	373	java/lang/Throwable
    //   524	548	373	java/lang/Throwable
    //   548	565	373	java/lang/Throwable
    //   568	573	373	java/lang/Throwable
  }

  public final void onServiceDisconnected(ComponentName paramComponentName)
  {
    v.w("MicroMsg.CoreServiceConnection", "onServiceDisconnected ");
    if ((ah.vJ()) && (!ah.vN()))
    {
      ah.vF().xT();
      ad(aa.getContext());
      return;
    }
    ah.vF().xU();
    ah.vF().reset();
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.app.c
 * JD-Core Version:    0.6.2
 */