package com.tencent.mm.an;

import android.os.Handler;
import android.os.HandlerThread;
import android.text.TextUtils;
import android.util.Base64;
import com.tencent.mm.a.o;
import com.tencent.mm.ak.k;
import com.tencent.mm.compatible.d.p;
import com.tencent.mm.h.e;
import com.tencent.mm.platformtools.r;
import com.tencent.mm.sdk.c.a;
import com.tencent.mm.sdk.platformtools.aa;
import com.tencent.mm.sdk.platformtools.ad;
import com.tencent.mm.sdk.platformtools.ah.a;
import com.tencent.mm.sdk.platformtools.be;
import com.tencent.mm.sdk.platformtools.v;
import com.tencent.mm.storage.j;
import com.tencent.mm.storage.l.a;
import com.tencent.mm.t.m;
import java.util.ArrayList;
import java.util.List;

public final class b
{
  private static final byte[] cwf = "@wechat*weixin!!".getBytes();
  private static b cwg;
  private boolean cwh = false;
  private ad cwi;
  int cwj = 5000;
  int cwk = 5000;
  int cwl = 30000;
  private int cwm = 3600;
  private c cwn;
  private List<d> cwo = new ArrayList();
  private List<d> cwp = new ArrayList();
  private com.tencent.mm.sdk.c.c cwq = new com.tencent.mm.sdk.c.c()
  {
  };
  private com.tencent.mm.sdk.platformtools.ah cwr = new com.tencent.mm.sdk.platformtools.ah(com.tencent.mm.model.ah.vw().lgw.getLooper(), new ah.a()
  {
    public final boolean lP()
    {
      v.i("MicroMsg.SenseWhereHelper", "time up, stop sense where sdk.");
      b.Ew();
      b.this.Eq();
      return false;
    }
  }
  , false);
  private com.tencent.map.a.a.b cws = new com.tencent.map.a.a.b()
  {
    public final void a(double paramAnonymousDouble1, double paramAnonymousDouble2, int paramAnonymousInt1, int paramAnonymousInt2, long paramAnonymousLong)
    {
      v.d("MicroMsg.SenseWhereHelper", "onLocationUpdate latitude[%f] longitude[%f] error[%d] floor[%d] buildingId[%d]", new Object[] { Double.valueOf(paramAnonymousDouble1), Double.valueOf(paramAnonymousDouble2), Integer.valueOf(paramAnonymousInt1), Integer.valueOf(paramAnonymousInt2), Long.valueOf(paramAnonymousLong) });
    }
  };
  private int cwt = 0;
  private com.tencent.map.a.a.c cwu = new com.tencent.map.a.a.c()
  {
    public final void g(int paramAnonymousInt, String paramAnonymousString)
    {
      v.d("MicroMsg.SenseWhereHelper", "onMessage code[%d] message[%s]", new Object[] { Integer.valueOf(paramAnonymousInt), paramAnonymousString });
      if ((paramAnonymousInt != 0) && (b.o(b.this) > 3))
      {
        v.i("MicroMsg.SenseWhereHelper", "sense where error time more than %d, stop now.", new Object[] { Integer.valueOf(3) });
        b.Ex();
        b.this.Eq();
      }
    }
  };
  private long startTime = 0L;

  public static b Eo()
  {
    if (cwg == null)
      cwg = new b();
    return cwg;
  }

  private static String Ep()
  {
    String str = p.oS();
    Object localObject = new o(com.tencent.mm.model.ah.vE().uin).toString();
    str = str + "_" + (String)localObject;
    try
    {
      localObject = new r();
      byte[] arrayOfByte1 = str.getBytes("UTF-8");
      byte[] arrayOfByte2 = cwf;
      localObject = new String(Base64.encode(((r)localObject).a(arrayOfByte1, arrayOfByte1.length, arrayOfByte2), 0), "UTF-8");
      v.i("MicroMsg.SenseWhereHelper", "create encrypt imei[%s], original imei[%s]", new Object[] { localObject, be.Gp(str) });
      return localObject;
    }
    catch (Exception localException)
    {
      v.e("MicroMsg.SenseWhereHelper", "create imei error: " + localException.toString());
    }
    return "";
  }

  private boolean Er()
  {
    if (new o(com.tencent.mm.model.ah.vE().uin).longValue() < 1000000L)
    {
      v.i("MicroMsg.SenseWhereHelper", "it boss uin do not start sense where.");
      return false;
    }
    Object localObject = com.tencent.mm.h.h.qr().getValue("AndroidSenseWhereArgs");
    if (be.ky((String)localObject))
    {
      v.i("MicroMsg.SenseWhereHelper", "it has no config do not start sense where.");
      return false;
    }
    try
    {
      v.d("MicroMsg.SenseWhereHelper", "sense where config : " + (String)localObject);
      localObject = ((String)localObject).split(";");
      int i = be.getInt(localObject[0], 0);
      int j = com.tencent.mm.a.h.F(com.tencent.mm.model.ah.vE().uin + 5, 100);
      if (j > i)
      {
        v.d("MicroMsg.SenseWhereHelper", "do not start sense where.uinhash %d, percent %d", new Object[] { Integer.valueOf(j), Integer.valueOf(i) });
        return false;
      }
      this.cwk = be.getInt(localObject[1], 5000);
      this.cwj = be.getInt(localObject[2], 5000);
      this.cwl = be.getInt(localObject[3], 30000);
      this.cwm = be.getInt(localObject[4], 3600);
      v.i("MicroMsg.SenseWhereHelper", "check sense where report args[%d, %d, %d, %d]", new Object[] { Integer.valueOf(this.cwk), Integer.valueOf(this.cwj), Integer.valueOf(this.cwl), Integer.valueOf(this.cwm) });
      long l = com.tencent.mm.platformtools.t.ay(((Long)com.tencent.mm.model.ah.vE().to().a(l.a.lqi, Long.valueOf(0L))).longValue());
      if (l > this.cwm)
        return true;
      v.i("MicroMsg.SenseWhereHelper", "it is not time out. diff[%d], collection interval[%d]", new Object[] { Long.valueOf(l), Integer.valueOf(this.cwm) });
      return false;
    }
    catch (Exception localException)
    {
      v.e("MicroMsg.SenseWhereHelper", "check sense where config error: " + localException.toString());
      v.i("MicroMsg.SenseWhereHelper", "it default do not start sense where.");
    }
    return false;
  }

  public static void Es()
  {
    if (com.tencent.mm.platformtools.t.ay(com.tencent.mm.platformtools.t.e((Long)com.tencent.mm.model.ah.vE().to().a(l.a.lqh, null))) * 1000L > 21600000L)
    {
      v.i("MicroMsg.SenseWhereHelper", "update sense where location package list.");
      k localk = new k(36);
      com.tencent.mm.model.ah.vF().a(localk, 0);
      com.tencent.mm.model.ah.vE().to().b(l.a.lqh, Long.valueOf(com.tencent.mm.platformtools.t.IB()));
    }
  }

  public final void Eq()
  {
    com.tencent.mm.model.ah.vw().u(new Runnable()
    {
      public final void run()
      {
        v.i("MicroMsg.SenseWhereHelper", "it stop sense where sdk.");
        a.lfk.e(b.f(b.this));
        com.c.a.a.t.kq();
        com.c.a.a.t.finish();
        if (b.g(b.this) != null)
        {
          b.g(b.this).finish();
          b.a(b.this, null);
        }
        b.l(b.this);
        b.m(b.this);
        b.n(b.this);
        b.a(b.this, false);
      }
    });
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.an.b
 * JD-Core Version:    0.6.2
 */