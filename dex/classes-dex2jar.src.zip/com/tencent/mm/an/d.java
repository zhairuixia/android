package com.tencent.mm.an;

public final class d
{
  String cwJ;
  double cwK;
  double latitude;
  double longitude;

  public final String toString()
  {
    return "gspType:" + this.cwJ + " longitude: " + this.longitude + " latitude: " + this.latitude + " distance: " + this.cwK;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.an.d
 * JD-Core Version:    0.6.2
 */