package com.tencent.mm.ah;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.widget.Toast;
import com.tencent.mm.e.a.hd;
import com.tencent.mm.e.a.hd.b;
import com.tencent.mm.pluginsdk.i.a;
import com.tencent.mm.pluginsdk.i.aa;
import com.tencent.mm.pluginsdk.i.u;
import com.tencent.mm.ui.base.h;
import com.tencent.mm.ui.base.h.a;

public final class a
{
  public static boolean Dm()
  {
    hd localhd = new hd();
    localhd.aPl.action = 1;
    com.tencent.mm.sdk.c.a.lfk.y(localhd);
    return localhd.aPm.aPn;
  }

  public static boolean Dn()
  {
    return (i.a.jDW != null) && (i.a.jDW.aKI());
  }

  public static boolean Do()
  {
    return (i.a.jEg != null) && (i.a.jEg.akr());
  }

  public static h a(Context paramContext, int paramInt, Runnable paramRunnable)
  {
    paramContext = new h.a(paramContext);
    paramContext.tc(2131231056);
    paramContext.te(paramInt);
    paramContext.c(2131233983, new DialogInterface.OnClickListener()
    {
      public final void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        if (this.csI != null)
          this.csI.run();
      }
    });
    paramContext.ie(true);
    paramContext.c(new DialogInterface.OnCancelListener()
    {
      public final void onCancel(DialogInterface paramAnonymousDialogInterface)
      {
        if (this.csI != null)
          this.csI.run();
      }
    });
    paramContext = paramContext.bkL();
    paramContext.show();
    return paramContext;
  }

  public static boolean aR(Context paramContext)
  {
    boolean bool = false;
    if (Dm())
    {
      Toast.makeText(paramContext, 2131233987, 0).show();
      bool = true;
    }
    return bool;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.ah.a
 * JD-Core Version:    0.6.2
 */