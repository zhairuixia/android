package com.tencent.mm.a;

import android.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public final class d
{
  private Cipher ayA;
  private Cipher ayz;

  public d(String paramString)
  {
    try
    {
      paramString = new DESKeySpec(paramString.getBytes("UTF8"));
      paramString = SecretKeyFactory.getInstance("DES").generateSecret(paramString);
      IvParameterSpec localIvParameterSpec = new IvParameterSpec("manifest".getBytes("UTF8"));
      this.ayz = Cipher.getInstance("DES/CBC/PKCS5Padding");
      this.ayz.init(1, paramString, localIvParameterSpec);
      this.ayA = Cipher.getInstance("DES/CBC/PKCS5Padding");
      this.ayA.init(2, paramString, localIvParameterSpec);
      return;
    }
    catch (Exception paramString)
    {
    }
  }

  public final String aM(String paramString)
  {
    try
    {
      Object localObject = Base64.decode(paramString, 0);
      localObject = new String(this.ayA.doFinal((byte[])localObject), "UTF8");
      return localObject;
    }
    catch (Exception localException)
    {
      return "[des]" + paramString + "|" + localException.toString();
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.a.d
 * JD-Core Version:    0.6.2
 */