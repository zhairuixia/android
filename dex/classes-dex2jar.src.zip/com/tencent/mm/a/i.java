package com.tencent.mm.a;

final class i
{
  public byte[] ayC;
  public int ayD = 0;

  public i()
  {
    this.ayC = new byte[256];
  }

  public i(byte paramByte)
  {
    this.ayC = new byte[] { paramByte };
  }

  public i(byte[] paramArrayOfByte)
  {
    this.ayC = paramArrayOfByte;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.a.i
 * JD-Core Version:    0.6.2
 */