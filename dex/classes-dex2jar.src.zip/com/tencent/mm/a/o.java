package com.tencent.mm.a;

public final class o extends Number
{
  private int uin = 0;

  public o(int paramInt)
  {
    this.uin = paramInt;
  }

  public o(long paramLong)
  {
    this.uin = ((int)(0xFFFFFFFF & paramLong));
  }

  public static int aX(String paramString)
  {
    try
    {
      int i = new o(Long.valueOf(paramString).longValue()).intValue();
      return i;
    }
    catch (Exception paramString)
    {
    }
    return 0;
  }

  public static String getString(int paramInt)
  {
    return new o(paramInt).toString();
  }

  public final double doubleValue()
  {
    return (this.uin | 0L) + 0.0D;
  }

  public final float floatValue()
  {
    return (float)((this.uin | 0L) + 0.0D);
  }

  public final int intValue()
  {
    return this.uin;
  }

  public final long longValue()
  {
    return this.uin & 0xFFFFFFFF;
  }

  public final String toString()
  {
    return String.valueOf(this.uin & 0xFFFFFFFF);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.mm.a.o
 * JD-Core Version:    0.6.2
 */