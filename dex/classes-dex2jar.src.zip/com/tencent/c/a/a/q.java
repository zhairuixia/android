package com.tencent.c.a.a;

import android.content.Context;

public abstract class q
{
  protected Context context = null;

  protected q(Context paramContext)
  {
    this.context = paramContext;
  }

  protected abstract void a(a parama);

  public final void b(a parama)
  {
    if (parama == null);
    while (!kE())
      return;
    a(parama);
  }

  public final void b(g paramg)
  {
    if (paramg == null);
    do
    {
      return;
      paramg = paramg.toString();
    }
    while (!kE());
    write(s.encode(paramg));
  }

  protected abstract boolean kE();

  protected abstract String kF();

  protected abstract a kG();

  public final g kN()
  {
    g localg = null;
    if (kE());
    for (String str = s.decode(kF()); ; str = null)
    {
      if (str != null)
        localg = g.aI(str);
      return localg;
    }
  }

  public final a kO()
  {
    if (kE())
      return kG();
    return null;
  }

  protected abstract void write(String paramString);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.c.a.a.q
 * JD-Core Version:    0.6.2
 */