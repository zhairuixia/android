package com.tencent.c.a.a;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import java.util.ArrayList;
import java.util.Arrays;
import org.json.JSONException;
import org.json.JSONObject;

public final class n
  implements Runnable
{
  public static long axD = -1L;
  private a axB = null;
  int axC = 0;
  private Context mContext = null;
  private int mType = 0;

  public n(Context paramContext, int paramInt)
  {
    this.mContext = paramContext;
    this.mType = paramInt;
  }

  private void a(JSONObject paramJSONObject)
  {
    if ((i.axr == null) || (j.axx == 1))
      return;
    if ((j.axy > 0) && (this.axC > j.axy))
    {
      new StringBuilder("limit dispatch:").append(j.axy);
      return;
    }
    paramJSONObject = new m(this.mContext, paramJSONObject).kL().toString();
    i.axr.aH("[" + paramJSONObject + "]");
    axD = System.currentTimeMillis();
    this.axC += 1;
  }

  private void kM()
  {
    g localg1 = r.S(this.mContext).l(new ArrayList(Arrays.asList(new Integer[] { Integer.valueOf(1) })));
    g localg2 = r.S(this.mContext).l(new ArrayList(Arrays.asList(new Integer[] { Integer.valueOf(2) })));
    g localg3 = r.S(this.mContext).l(new ArrayList(Arrays.asList(new Integer[] { Integer.valueOf(4) })));
    if ((s.b(localg1, localg2)) && (s.b(localg1, localg3)))
      return;
    localg1 = s.a(s.a(localg1, localg2), s.a(localg1, localg3));
    new StringBuilder("local mid check failed, redress with mid:").append(localg1.toString());
    r.S(this.mContext).b(localg1);
  }

  public final void run()
  {
    new StringBuilder("request type:").append(this.mType);
    switch (this.mType)
    {
    default:
      new StringBuilder("wrong type:").append(this.mType);
    case 1:
    case 2:
    }
    while (true)
    {
      return;
      a(null);
      return;
      if (this.axB == null)
        this.axB = r.S(this.mContext).kO();
      long l1 = System.currentTimeMillis();
      if (i.axs <= 0L)
        i.axs = PreferenceManager.getDefaultSharedPreferences(this.mContext).getLong("__MID_LAST_CHECK_TIME__", 0L);
      long l2 = Math.abs(l1 - i.axs);
      new StringBuilder("check entity: ").append(this.axB.toString()).append(",duration:").append(l2);
      if ((this.axB.awS < 0) || (this.axB.awS > 100))
        this.axB.awS = 3;
      long l3 = this.axB.awS * e.axm;
      new StringBuilder("duration:").append(l2).append(",maxCheckDays:").append(l3).append(",mLastCheckTime:").append(i.axs).append(",mCheckEntity:").append(this.axB);
      if (l2 < l3)
      {
        if (l2 <= e.axm)
          continue;
        kM();
        return;
      }
      kM();
      JSONObject localJSONObject = new JSONObject();
      try
      {
        localJSONObject.put("dur", l2);
        localJSONObject.put("md", l3);
        localJSONObject.put("lct", i.axs);
        localJSONObject.put("cur", l1);
        label320: if (axD > 0L)
          continue;
        a(localJSONObject);
        return;
      }
      catch (JSONException localJSONException)
      {
        break label320;
      }
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.c.a.a.n
 * JD-Core Version:    0.6.2
 */