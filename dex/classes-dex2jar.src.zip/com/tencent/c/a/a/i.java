package com.tencent.c.a.a;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.HandlerThread;
import android.preference.PreferenceManager;
import org.json.JSONObject;

public class i
{
  private static i axq = null;
  static f axr = null;
  public static volatile long axs = 0L;
  static h axt = null;
  public static Context mContext = null;
  public static Handler mHandler = null;
  private g axu = null;

  private i(Context paramContext)
  {
    HandlerThread localHandlerThread = new HandlerThread(i.class.getSimpleName());
    localHandlerThread.start();
    mHandler = new Handler(localHandlerThread.getLooper());
    paramContext = paramContext.getApplicationContext();
    mContext = paramContext;
    axs = PreferenceManager.getDefaultSharedPreferences(paramContext).getLong("__MID_LAST_CHECK_TIME__", 0L);
  }

  public static i Q(Context paramContext)
  {
    if (axq == null);
    try
    {
      if (axq == null)
        axq = new i(paramContext);
      return axq;
    }
    finally
    {
    }
    throw paramContext;
  }

  public static void a(f paramf)
  {
    axr = paramf;
  }

  public final String kI()
  {
    if ((this.axu == null) || (!s.aK(this.axu.axo)))
    {
      this.axu = r.S(mContext).kN();
      if (!s.aK(this.axu.axo))
        break label100;
    }
    label100: for (int i = 2; ; i = 1)
    {
      if (mHandler != null)
        mHandler.post(new n(mContext, i));
      new StringBuilder("wx get mid:").append(this.axu.axo);
      return this.axu.axo;
    }
  }

  public final String kJ()
  {
    if ((this.axu == null) || (!s.aK(this.axu.axo)))
      this.axu = r.S(mContext).kN();
    return this.axu.axo;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.c.a.a.i
 * JD-Core Version:    0.6.2
 */