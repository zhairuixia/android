package com.tencent.c.a.a;

import org.json.JSONException;
import org.json.JSONObject;

final class g
{
  String atr = null;
  String axn = null;
  String axo = "0";
  long axp = 0L;

  static g aI(String paramString)
  {
    g localg = new g();
    if (s.aJ(paramString));
    try
    {
      paramString = new JSONObject(paramString);
      if (!paramString.isNull("ui"))
        localg.atr = paramString.getString("ui");
      if (!paramString.isNull("mc"))
        localg.axn = paramString.getString("mc");
      if (!paramString.isNull("mid"))
        localg.axo = paramString.getString("mid");
      if (!paramString.isNull("ts"))
        localg.axp = paramString.getLong("ts");
      return localg;
    }
    catch (JSONException paramString)
    {
    }
    return localg;
  }

  private JSONObject kH()
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      s.b(localJSONObject, "ui", this.atr);
      s.b(localJSONObject, "mc", this.axn);
      s.b(localJSONObject, "mid", this.axo);
      localJSONObject.put("ts", this.axp);
      return localJSONObject;
    }
    catch (JSONException localJSONException)
    {
    }
    return localJSONObject;
  }

  final int a(g paramg)
  {
    if (paramg == null);
    do
    {
      do
      {
        return 1;
        if ((!s.aK(this.axo)) || (!s.aK(paramg.axo)))
          break;
        if (this.axo.equals(paramg.axo))
          return 0;
      }
      while (this.axp >= paramg.axp);
      return -1;
    }
    while (s.aK(this.axo));
    return -1;
  }

  public final String toString()
  {
    return kH().toString();
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.c.a.a.g
 * JD-Core Version:    0.6.2
 */