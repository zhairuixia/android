package com.tencent.c.a.a;

final class e
{
  static long axm = 86400000L;
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.c.a.a.e
 * JD-Core Version:    0.6.2
 */