package com.tencent.c.a.a;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build;
import android.os.Build.VERSION;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import java.util.Locale;
import java.util.TimeZone;

final class b
{
  static a awX;
  Integer awY = null;
  String awZ = null;

  public b(Context paramContext)
  {
    try
    {
      P(paramContext);
      TelephonyManager localTelephonyManager = (TelephonyManager)paramContext.getSystemService("phone");
      if (localTelephonyManager != null)
        this.awY = Integer.valueOf(localTelephonyManager.getNetworkType());
      this.awZ = s.ab(paramContext);
      return;
    }
    catch (Throwable paramContext)
    {
    }
  }

  private static a P(Context paramContext)
  {
    try
    {
      if (awX == null)
        awX = new a(paramContext.getApplicationContext(), (byte)0);
      paramContext = awX;
      return paramContext;
    }
    finally
    {
    }
    throw paramContext;
  }

  static final class a
  {
    String axa;
    String axb = "2.21";
    DisplayMetrics axc;
    int axd = Build.VERSION.SDK_INT;
    String axe = Build.MANUFACTURER;
    String axf = Locale.getDefault().getLanguage();
    String axg = "WX";
    String axh;
    String axi;
    int axj = 0;
    String axk = null;
    String axl = null;
    Context ctx = null;
    String imsi;
    String model = Build.MODEL;
    String packageName = null;
    String timezone;

    private a(Context paramContext)
    {
      this.ctx = paramContext.getApplicationContext();
      try
      {
        this.axa = this.ctx.getPackageManager().getPackageInfo(this.ctx.getPackageName(), 0).versionName;
        label105: this.axc = new DisplayMetrics();
        ((WindowManager)this.ctx.getApplicationContext().getSystemService("window")).getDefaultDisplay().getMetrics(this.axc);
        if (s.l(paramContext, "android.permission.READ_PHONE_STATE"))
        {
          paramContext = (TelephonyManager)paramContext.getSystemService("phone");
          if (paramContext != null)
          {
            this.axh = paramContext.getSimOperator();
            this.imsi = paramContext.getSubscriberId();
          }
        }
        this.timezone = TimeZone.getDefault().getID();
        this.axi = s.aa(this.ctx);
        this.packageName = this.ctx.getPackageName();
        this.axl = s.kP();
        return;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        break label105;
      }
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.c.a.a.b
 * JD-Core Version:    0.6.2
 */