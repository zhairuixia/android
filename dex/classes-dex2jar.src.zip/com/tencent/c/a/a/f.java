package com.tencent.c.a.a;

public abstract interface f
{
  public abstract void aH(String paramString);
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.c.a.a.f
 * JD-Core Version:    0.6.2
 */