package com.tencent.c.a.a;

import android.content.Context;
import org.json.JSONObject;

final class m
{
  private JSONObject axA = null;
  private int axz = 0;
  protected Context context = null;

  m(Context paramContext, JSONObject paramJSONObject)
  {
    this.context = paramContext;
    this.axz = ((int)(System.currentTimeMillis() / 1000L));
    this.axA = paramJSONObject;
  }

  // ERROR //
  final JSONObject kL()
  {
    // Byte code:
    //   0: new 36	org/json/JSONObject
    //   3: dup
    //   4: invokespecial 37	org/json/JSONObject:<init>	()V
    //   7: astore_1
    //   8: aload_1
    //   9: ldc 39
    //   11: ldc 41
    //   13: invokevirtual 45	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   16: pop
    //   17: aload_1
    //   18: ldc 47
    //   20: iconst_2
    //   21: invokevirtual 50	org/json/JSONObject:put	(Ljava/lang/String;I)Lorg/json/JSONObject;
    //   24: pop
    //   25: aload_1
    //   26: ldc 52
    //   28: aload_0
    //   29: getfield 19	com/tencent/c/a/a/m:axz	I
    //   32: invokevirtual 50	org/json/JSONObject:put	(Ljava/lang/String;I)Lorg/json/JSONObject;
    //   35: pop
    //   36: aload_1
    //   37: ldc 54
    //   39: aload_0
    //   40: getfield 19	com/tencent/c/a/a/m:axz	I
    //   43: invokevirtual 50	org/json/JSONObject:put	(Ljava/lang/String;I)Lorg/json/JSONObject;
    //   46: pop
    //   47: aload_1
    //   48: ldc 56
    //   50: aload_0
    //   51: getfield 17	com/tencent/c/a/a/m:context	Landroid/content/Context;
    //   54: invokestatic 62	com/tencent/c/a/a/s:U	(Landroid/content/Context;)Ljava/lang/String;
    //   57: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   60: aload_1
    //   61: ldc 68
    //   63: aload_0
    //   64: getfield 17	com/tencent/c/a/a/m:context	Landroid/content/Context;
    //   67: invokestatic 71	com/tencent/c/a/a/s:V	(Landroid/content/Context;)Ljava/lang/String;
    //   70: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   73: aload_0
    //   74: getfield 17	com/tencent/c/a/a/m:context	Landroid/content/Context;
    //   77: invokestatic 77	com/tencent/c/a/a/i:Q	(Landroid/content/Context;)Lcom/tencent/c/a/a/i;
    //   80: invokevirtual 81	com/tencent/c/a/a/i:kJ	()Ljava/lang/String;
    //   83: astore_2
    //   84: aload_2
    //   85: invokestatic 85	com/tencent/c/a/a/s:aK	(Ljava/lang/String;)Z
    //   88: ifeq +433 -> 521
    //   91: aload_1
    //   92: ldc 87
    //   94: aload_2
    //   95: invokevirtual 45	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   98: pop
    //   99: new 89	com/tencent/c/a/a/b
    //   102: dup
    //   103: aload_0
    //   104: getfield 17	com/tencent/c/a/a/m:context	Landroid/content/Context;
    //   107: invokespecial 92	com/tencent/c/a/a/b:<init>	(Landroid/content/Context;)V
    //   110: astore_2
    //   111: new 36	org/json/JSONObject
    //   114: dup
    //   115: invokespecial 37	org/json/JSONObject:<init>	()V
    //   118: astore_3
    //   119: getstatic 96	com/tencent/c/a/a/b:awX	Lcom/tencent/c/a/a/b$a;
    //   122: ifnull +340 -> 462
    //   125: getstatic 96	com/tencent/c/a/a/b:awX	Lcom/tencent/c/a/a/b$a;
    //   128: astore 4
    //   130: aload_3
    //   131: ldc 98
    //   133: new 100	java/lang/StringBuilder
    //   136: dup
    //   137: aload 4
    //   139: getfield 106	com/tencent/c/a/a/b$a:axc	Landroid/util/DisplayMetrics;
    //   142: getfield 111	android/util/DisplayMetrics:widthPixels	I
    //   145: invokestatic 117	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   148: invokespecial 120	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   151: ldc 122
    //   153: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: aload 4
    //   158: getfield 106	com/tencent/c/a/a/b$a:axc	Landroid/util/DisplayMetrics;
    //   161: getfield 129	android/util/DisplayMetrics:heightPixels	I
    //   164: invokevirtual 132	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   167: invokevirtual 135	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   170: invokevirtual 45	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   173: pop
    //   174: aload_3
    //   175: ldc 137
    //   177: aload 4
    //   179: getfield 141	com/tencent/c/a/a/b$a:axa	Ljava/lang/String;
    //   182: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   185: aload_3
    //   186: ldc 143
    //   188: aload 4
    //   190: getfield 146	com/tencent/c/a/a/b$a:axg	Ljava/lang/String;
    //   193: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   196: aload_3
    //   197: ldc 148
    //   199: aload 4
    //   201: getfield 151	com/tencent/c/a/a/b$a:axe	Ljava/lang/String;
    //   204: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   207: aload_3
    //   208: ldc 153
    //   210: aload 4
    //   212: getfield 156	com/tencent/c/a/a/b$a:axb	Ljava/lang/String;
    //   215: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   218: aload_3
    //   219: ldc 158
    //   221: aload 4
    //   223: getfield 161	com/tencent/c/a/a/b$a:axd	I
    //   226: invokestatic 165	java/lang/Integer:toString	(I)Ljava/lang/String;
    //   229: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   232: aload_3
    //   233: ldc 167
    //   235: iconst_1
    //   236: invokevirtual 50	org/json/JSONObject:put	(Ljava/lang/String;I)Lorg/json/JSONObject;
    //   239: pop
    //   240: aload_3
    //   241: ldc 169
    //   243: aload 4
    //   245: getfield 172	com/tencent/c/a/a/b$a:axh	Ljava/lang/String;
    //   248: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   251: aload_3
    //   252: ldc 174
    //   254: aload 4
    //   256: getfield 177	com/tencent/c/a/a/b$a:axf	Ljava/lang/String;
    //   259: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   262: aload_3
    //   263: ldc 179
    //   265: aload 4
    //   267: getfield 182	com/tencent/c/a/a/b$a:model	Ljava/lang/String;
    //   270: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   273: aload_3
    //   274: ldc 184
    //   276: aload 4
    //   278: getfield 187	com/tencent/c/a/a/b$a:timezone	Ljava/lang/String;
    //   281: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   284: aload 4
    //   286: getfield 190	com/tencent/c/a/a/b$a:axj	I
    //   289: ifeq +15 -> 304
    //   292: aload_3
    //   293: ldc 192
    //   295: aload 4
    //   297: getfield 190	com/tencent/c/a/a/b$a:axj	I
    //   300: invokevirtual 50	org/json/JSONObject:put	(Ljava/lang/String;I)Lorg/json/JSONObject;
    //   303: pop
    //   304: aload_3
    //   305: ldc 194
    //   307: aload 4
    //   309: getfield 197	com/tencent/c/a/a/b$a:axi	Ljava/lang/String;
    //   312: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   315: aload_3
    //   316: ldc 199
    //   318: aload 4
    //   320: getfield 202	com/tencent/c/a/a/b$a:packageName	Ljava/lang/String;
    //   323: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   326: aload 4
    //   328: getfield 205	com/tencent/c/a/a/b$a:ctx	Landroid/content/Context;
    //   331: invokestatic 209	com/tencent/c/a/a/s:T	(Landroid/content/Context;)Z
    //   334: ifeq +61 -> 395
    //   337: new 36	org/json/JSONObject
    //   340: dup
    //   341: invokespecial 37	org/json/JSONObject:<init>	()V
    //   344: astore 5
    //   346: aload 5
    //   348: ldc 211
    //   350: aload 4
    //   352: getfield 205	com/tencent/c/a/a/b$a:ctx	Landroid/content/Context;
    //   355: invokestatic 214	com/tencent/c/a/a/s:X	(Landroid/content/Context;)Ljava/lang/String;
    //   358: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   361: aload 5
    //   363: ldc 216
    //   365: aload 4
    //   367: getfield 205	com/tencent/c/a/a/b$a:ctx	Landroid/content/Context;
    //   370: invokestatic 219	com/tencent/c/a/a/s:Y	(Landroid/content/Context;)Ljava/lang/String;
    //   373: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   376: aload 5
    //   378: invokevirtual 223	org/json/JSONObject:length	()I
    //   381: ifle +14 -> 395
    //   384: aload_3
    //   385: ldc 225
    //   387: aload 5
    //   389: invokevirtual 226	org/json/JSONObject:toString	()Ljava/lang/String;
    //   392: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   395: aload 4
    //   397: getfield 205	com/tencent/c/a/a/b$a:ctx	Landroid/content/Context;
    //   400: invokestatic 230	com/tencent/c/a/a/s:Z	(Landroid/content/Context;)Lorg/json/JSONArray;
    //   403: astore 5
    //   405: aload 5
    //   407: ifnull +22 -> 429
    //   410: aload 5
    //   412: invokevirtual 233	org/json/JSONArray:length	()I
    //   415: ifle +14 -> 429
    //   418: aload_3
    //   419: ldc 235
    //   421: aload 5
    //   423: invokevirtual 236	org/json/JSONArray:toString	()Ljava/lang/String;
    //   426: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   429: aload_3
    //   430: ldc 238
    //   432: aload 4
    //   434: getfield 241	com/tencent/c/a/a/b$a:axk	Ljava/lang/String;
    //   437: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   440: aload_3
    //   441: ldc 243
    //   443: aload 4
    //   445: getfield 246	com/tencent/c/a/a/b$a:axl	Ljava/lang/String;
    //   448: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   451: aload_3
    //   452: ldc 248
    //   454: aload 4
    //   456: getfield 251	com/tencent/c/a/a/b$a:imsi	Ljava/lang/String;
    //   459: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   462: aload_3
    //   463: ldc 253
    //   465: aload_2
    //   466: getfield 256	com/tencent/c/a/a/b:awZ	Ljava/lang/String;
    //   469: invokestatic 66	com/tencent/c/a/a/s:b	(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    //   472: aload_2
    //   473: getfield 260	com/tencent/c/a/a/b:awY	Ljava/lang/Integer;
    //   476: ifnull +15 -> 491
    //   479: aload_3
    //   480: ldc_w 262
    //   483: aload_2
    //   484: getfield 260	com/tencent/c/a/a/b:awY	Ljava/lang/Integer;
    //   487: invokevirtual 45	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   490: pop
    //   491: aload_1
    //   492: ldc_w 264
    //   495: aload_3
    //   496: invokevirtual 45	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   499: pop
    //   500: aload_0
    //   501: getfield 21	com/tencent/c/a/a/m:axA	Lorg/json/JSONObject;
    //   504: ifnull +37 -> 541
    //   507: aload_1
    //   508: ldc_w 266
    //   511: aload_0
    //   512: getfield 21	com/tencent/c/a/a/m:axA	Lorg/json/JSONObject;
    //   515: invokevirtual 45	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   518: pop
    //   519: aload_1
    //   520: areturn
    //   521: aload_1
    //   522: ldc 87
    //   524: ldc_w 268
    //   527: invokevirtual 45	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   530: pop
    //   531: goto -432 -> 99
    //   534: astore_2
    //   535: aload_1
    //   536: areturn
    //   537: astore_2
    //   538: goto -38 -> 500
    //   541: aload_1
    //   542: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   8	99	534	java/lang/Throwable
    //   99	119	534	java/lang/Throwable
    //   500	519	534	java/lang/Throwable
    //   521	531	534	java/lang/Throwable
    //   119	304	537	java/lang/Throwable
    //   304	395	537	java/lang/Throwable
    //   395	405	537	java/lang/Throwable
    //   410	429	537	java/lang/Throwable
    //   429	462	537	java/lang/Throwable
    //   462	491	537	java/lang/Throwable
    //   491	500	537	java/lang/Throwable
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.c.a.a.m
 * JD-Core Version:    0.6.2
 */