package com.tencent.c.a.a;

public final class j
{
  public static int axx = 0;
  public static int axy = 0;
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.c.a.a.j
 * JD-Core Version:    0.6.2
 */