package com.tencent.c.a.a;

public abstract interface h
{
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.c.a.a.h
 * JD-Core Version:    0.6.2
 */