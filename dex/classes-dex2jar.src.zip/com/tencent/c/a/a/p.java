package com.tencent.c.a.a;

import android.content.Context;
import android.os.Build.VERSION;
import android.provider.Settings.System;
import java.lang.reflect.Method;

public class p
{
  private static volatile p axE = null;
  private boolean axF = false;
  private Context context = null;

  private p(Context paramContext)
  {
    this.context = paramContext.getApplicationContext();
    this.axF = s.l(this.context, "android.permission.WRITE_SETTINGS");
    if (Build.VERSION.SDK_INT >= 23);
    try
    {
      paramContext = Settings.System.class.getDeclaredMethod("canWrite", new Class[] { Context.class });
      paramContext.setAccessible(true);
      this.axF = ((Boolean)paramContext.invoke(null, new Object[] { this.context })).booleanValue();
      return;
    }
    catch (Exception paramContext)
    {
    }
  }

  public static p R(Context paramContext)
  {
    if (axE == null);
    try
    {
      if (axE == null)
        axE = new p(paramContext);
      return axE;
    }
    finally
    {
    }
    throw paramContext;
  }

  public final boolean m(String paramString1, String paramString2)
  {
    if (this.axF)
      try
      {
        boolean bool = Settings.System.putString(this.context.getContentResolver(), paramString1, paramString2);
        return bool;
      }
      catch (Exception paramString1)
      {
      }
    return false;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.c.a.a.p
 * JD-Core Version:    0.6.2
 */