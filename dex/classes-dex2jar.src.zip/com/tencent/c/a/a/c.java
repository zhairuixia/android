package com.tencent.c.a.a;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

final class c
{
  static File aG(String paramString)
  {
    paramString = new File(paramString);
    if (paramString.exists())
      return paramString;
    if (!paramString.getParentFile().exists())
      aG(paramString.getParentFile().getAbsolutePath());
    paramString.mkdir();
    return paramString;
  }

  static List<String> d(File paramFile)
  {
    paramFile = new FileReader(paramFile);
    BufferedReader localBufferedReader = new BufferedReader(paramFile);
    ArrayList localArrayList = new ArrayList();
    while (true)
    {
      String str = localBufferedReader.readLine();
      if (str == null)
        break;
      localArrayList.add(str.trim());
    }
    paramFile.close();
    localBufferedReader.close();
    return localArrayList;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.c.a.a.c
 * JD-Core Version:    0.6.2
 */