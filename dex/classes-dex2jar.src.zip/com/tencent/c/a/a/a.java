package com.tencent.c.a.a;

import org.json.JSONException;
import org.json.JSONObject;

final class a
{
  public static String awT = "ts";
  public static String awU = "times";
  public static String awV = "mfreq";
  public static String awW = "mdays";
  long awP = 0L;
  int awQ = 0;
  int awR = 100;
  int awS = 3;

  a()
  {
  }

  a(String paramString)
  {
    if (!s.aJ(paramString));
    while (true)
    {
      return;
      try
      {
        paramString = new JSONObject(paramString);
        if (!paramString.isNull(awT))
          this.awP = paramString.getLong(awT);
        if (!paramString.isNull(awV))
          this.awR = paramString.getInt(awV);
        if (!paramString.isNull(awU))
          this.awQ = paramString.getInt(awU);
        if (!paramString.isNull(awW))
        {
          this.awS = paramString.getInt(awW);
          return;
        }
      }
      catch (JSONException paramString)
      {
      }
    }
  }

  public final String toString()
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put(awT, this.awP);
      localJSONObject.put(awU, this.awQ);
      localJSONObject.put(awV, this.awR);
      localJSONObject.put(awW, this.awS);
      label56: return localJSONObject.toString();
    }
    catch (JSONException localJSONException)
    {
      break label56;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.c.a.a.a
 * JD-Core Version:    0.6.2
 */