package com.tencent.c.a.a;

import android.content.Context;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public final class r
{
  private static r axI = null;
  private Map<Integer, q> axG = null;
  private int axH = 0;

  private r(Context paramContext)
  {
    this.axG.put(Integer.valueOf(1), new o(paramContext));
    this.axG.put(Integer.valueOf(2), new d(paramContext));
    this.axG.put(Integer.valueOf(4), new k(paramContext));
  }

  static r S(Context paramContext)
  {
    try
    {
      if (axI == null)
        axI = new r(paramContext);
      paramContext = axI;
      return paramContext;
    }
    finally
    {
    }
    throw paramContext;
  }

  private a m(List<Integer> paramList)
  {
    if (paramList.size() > 0)
      paramList = paramList.iterator();
    Object localObject;
    do
    {
      do
      {
        if (!paramList.hasNext())
          return new a();
        localObject = (Integer)paramList.next();
        localObject = (q)this.axG.get(localObject);
      }
      while (localObject == null);
      localObject = ((q)localObject).kO();
    }
    while (localObject == null);
    return localObject;
  }

  final void b(a parama)
  {
    Iterator localIterator = this.axG.entrySet().iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return;
      ((q)((Map.Entry)localIterator.next()).getValue()).b(parama);
    }
  }

  final void b(g paramg)
  {
    Iterator localIterator = this.axG.entrySet().iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return;
      ((q)((Map.Entry)localIterator.next()).getValue()).b(paramg);
    }
  }

  final g kN()
  {
    return l(new ArrayList(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(4) })));
  }

  final a kO()
  {
    return m(new ArrayList(Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(4) })));
  }

  final g l(List<Integer> paramList)
  {
    if (paramList.size() >= 0)
      paramList = paramList.iterator();
    Object localObject;
    do
    {
      do
      {
        if (!paramList.hasNext())
          return new g();
        localObject = (Integer)paramList.next();
        localObject = (q)this.axG.get(localObject);
      }
      while (localObject == null);
      localObject = ((q)localObject).kN();
    }
    while ((localObject == null) || (!s.aK(((g)localObject).axo)));
    return localObject;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.c.a.a.r
 * JD-Core Version:    0.6.2
 */