package com.tencent.kingkong;

public abstract class DataSetObserver extends android.database.DataSetObserver
{
  public void onChanged()
  {
  }

  public void onInvalidated()
  {
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.kingkong.DataSetObserver
 * JD-Core Version:    0.6.2
 */