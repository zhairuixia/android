package com.tencent.kingkong;

public class CursorWindowAllocationException extends RuntimeException
{
  public CursorWindowAllocationException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.kingkong.CursorWindowAllocationException
 * JD-Core Version:    0.6.2
 */