package com.tencent.kingkong.database;

import java.io.Closeable;

public abstract class SQLiteClosable
  implements Closeable
{
  private int mReferenceCount = 1;

  public void acquireReference()
  {
    try
    {
      if (this.mReferenceCount <= 0)
        throw new IllegalStateException("attempt to re-open an already-closed object: " + this);
    }
    finally
    {
    }
    this.mReferenceCount += 1;
  }

  public void close()
  {
    releaseReference();
  }

  public abstract void onAllReferencesReleased();

  @Deprecated
  protected void onAllReferencesReleasedFromContainer()
  {
    onAllReferencesReleased();
  }

  public void releaseReference()
  {
    try
    {
      int i = this.mReferenceCount - 1;
      this.mReferenceCount = i;
      if (i == 0);
      for (i = 1; ; i = 0)
      {
        if (i != 0)
          onAllReferencesReleased();
        return;
      }
    }
    finally
    {
    }
  }

  @Deprecated
  public void releaseReferenceFromContainer()
  {
    try
    {
      int i = this.mReferenceCount - 1;
      this.mReferenceCount = i;
      if (i == 0);
      for (i = 1; ; i = 0)
      {
        if (i != 0)
          onAllReferencesReleasedFromContainer();
        return;
      }
    }
    finally
    {
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.kingkong.database.SQLiteClosable
 * JD-Core Version:    0.6.2
 */