package com.tencent.kingkong.database;

public final class SQLiteStatementInfo
{
  public String[] columnNames;
  public int numParameters;
  public boolean readOnly;
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.kingkong.database.SQLiteStatementInfo
 * JD-Core Version:    0.6.2
 */