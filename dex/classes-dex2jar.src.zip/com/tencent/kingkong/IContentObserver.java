package com.tencent.kingkong;

import android.net.Uri;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;

public abstract interface IContentObserver extends IInterface
{
  public abstract void onChange(boolean paramBoolean, Uri paramUri);

  public static abstract class Stub extends Binder
    implements IContentObserver
  {
    private static final String DESCRIPTOR = "com.tencent.kingkong.IContentObserver";
    static final int TRANSACTION_onChange = 1;

    public Stub()
    {
      attachInterface(this, "com.tencent.kingkong.IContentObserver");
    }

    public static IContentObserver asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null)
        return null;
      IInterface localIInterface = paramIBinder.queryLocalInterface("com.tencent.kingkong.IContentObserver");
      if ((localIInterface != null) && ((localIInterface instanceof IContentObserver)))
        return (IContentObserver)localIInterface;
      return new Proxy(paramIBinder);
    }

    public IBinder asBinder()
    {
      return this;
    }

    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
    {
      switch (paramInt1)
      {
      default:
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902:
        paramParcel2.writeString("com.tencent.kingkong.IContentObserver");
        return true;
      case 1:
      }
      paramParcel1.enforceInterface("com.tencent.kingkong.IContentObserver");
      boolean bool;
      if (paramParcel1.readInt() != 0)
      {
        bool = true;
        if (paramParcel1.readInt() == 0)
          break label97;
      }
      label97: for (paramParcel1 = (Uri)Uri.CREATOR.createFromParcel(paramParcel1); ; paramParcel1 = null)
      {
        onChange(bool, paramParcel1);
        return true;
        bool = false;
        break;
      }
    }

    private static class Proxy
      implements IContentObserver
    {
      private IBinder mRemote;

      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }

      public IBinder asBinder()
      {
        return this.mRemote;
      }

      public String getInterfaceDescriptor()
      {
        return "com.tencent.kingkong.IContentObserver";
      }

      public void onChange(boolean paramBoolean, Uri paramUri)
      {
        int i = 1;
        Parcel localParcel = Parcel.obtain();
        try
        {
          localParcel.writeInterfaceToken("com.tencent.kingkong.IContentObserver");
          if (paramBoolean)
          {
            localParcel.writeInt(i);
            if (paramUri == null)
              break label67;
            localParcel.writeInt(1);
            paramUri.writeToParcel(localParcel, 0);
          }
          while (true)
          {
            this.mRemote.transact(1, localParcel, null, 1);
            return;
            i = 0;
            break;
            label67: localParcel.writeInt(0);
          }
        }
        finally
        {
          localParcel.recycle();
        }
        throw paramUri;
      }
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.kingkong.IContentObserver
 * JD-Core Version:    0.6.2
 */