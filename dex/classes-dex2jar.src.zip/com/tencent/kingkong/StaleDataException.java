package com.tencent.kingkong;

public class StaleDataException extends RuntimeException
{
  public StaleDataException()
  {
  }

  public StaleDataException(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.kingkong.StaleDataException
 * JD-Core Version:    0.6.2
 */