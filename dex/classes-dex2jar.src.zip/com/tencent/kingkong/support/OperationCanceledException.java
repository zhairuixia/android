package com.tencent.kingkong.support;

public class OperationCanceledException extends RuntimeException
{
  public OperationCanceledException()
  {
    this(null);
  }

  public OperationCanceledException(String paramString)
  {
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     com.tencent.kingkong.support.OperationCanceledException
 * JD-Core Version:    0.6.2
 */