package a.a.a;

public final class b extends RuntimeException
{
  public b(String paramString)
  {
    super(paramString);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     a.a.a.b
 * JD-Core Version:    0.6.2
 */