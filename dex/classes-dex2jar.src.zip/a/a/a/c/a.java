package a.a.a.c;

import com.tencent.mm.ay.b;
import java.io.OutputStream;
import java.util.LinkedList;

public final class a
{
  public final OutputStream bZM;
  public final byte[] nAY;
  private final a.a.a.b.b.a nAZ;

  public a(byte[] paramArrayOfByte)
  {
    this.nAY = paramArrayOfByte;
    this.bZM = null;
    this.nAZ = new a.a.a.b.b.a(paramArrayOfByte, 0, paramArrayOfByte.length);
  }

  public final void A(int paramInt, long paramLong)
  {
    a.a.a.b.b.a locala = this.nAZ;
    locala.C(paramInt, 0);
    locala.n(paramLong);
  }

  public final void T(int paramInt, boolean paramBoolean)
  {
    int i = 0;
    a.a.a.b.b.a locala = this.nAZ;
    locala.C(paramInt, 0);
    paramInt = i;
    if (paramBoolean)
      paramInt = 1;
    locala.bj(paramInt);
  }

  public final void a(int paramInt, double paramDouble)
  {
    a.a.a.b.b.a locala = this.nAZ;
    locala.C(paramInt, 1);
    long l = Double.doubleToLongBits(paramDouble);
    locala.bj((int)l & 0xFF);
    locala.bj((int)(l >> 8) & 0xFF);
    locala.bj((int)(l >> 16) & 0xFF);
    locala.bj((int)(l >> 24) & 0xFF);
    locala.bj((int)(l >> 32) & 0xFF);
    locala.bj((int)(l >> 40) & 0xFF);
    locala.bj((int)(l >> 48) & 0xFF);
    locala.bj((int)(l >> 56) & 0xFF);
  }

  public final void b(int paramInt, b paramb)
  {
    a.a.a.b.b.a locala = this.nAZ;
    if (paramb != null)
    {
      locala.C(paramInt, 2);
      paramb = paramb.toByteArray();
      locala.bl(paramb.length);
      locala.i(paramb);
    }
  }

  public final void c(int paramInt, LinkedList<?> paramLinkedList)
  {
    int j = 0;
    a.a.a.b.b.a locala;
    int i;
    if ((paramLinkedList != null) && (paramLinkedList.size() > 0))
    {
      this.nAZ.C(paramInt, 2);
      locala = this.nAZ;
      if ((paramLinkedList == null) || (paramLinkedList.size() <= 0))
        break label123;
      paramInt = 0;
      i = 0;
      if (i < paramLinkedList.size())
        break label70;
    }
    while (true)
    {
      locala.bl(paramInt);
      paramInt = j;
      while (true)
      {
        if (paramInt >= paramLinkedList.size())
        {
          return;
          label70: int k = a.a.a.b.b.a.bm(((Integer)paramLinkedList.get(i)).intValue());
          i += 1;
          paramInt = k + paramInt;
          break;
        }
        this.nAZ.bl(((Integer)paramLinkedList.get(paramInt)).intValue());
        paramInt += 1;
      }
      label123: paramInt = 0;
    }
  }

  public final void cH(int paramInt1, int paramInt2)
  {
    a.a.a.b.b.a locala = this.nAZ;
    locala.C(paramInt1, 0);
    if (paramInt2 >= 0)
    {
      locala.bl(paramInt2);
      return;
    }
    locala.n(paramInt2);
  }

  public final void cI(int paramInt1, int paramInt2)
  {
    cH(paramInt1, paramInt2);
  }

  public final void cJ(int paramInt1, int paramInt2)
  {
    a.a.a.b.b.a locala = this.nAZ;
    locala.C(paramInt1, 2);
    locala.bl(paramInt2);
  }

  public final void d(int paramInt1, int paramInt2, LinkedList<?> paramLinkedList)
  {
    if (paramLinkedList != null)
      switch (paramInt2)
      {
      default:
        throw new IllegalArgumentException("The data type was not found, the id used was " + paramInt2);
      case 6:
        paramInt2 = 0;
        if (paramInt2 < paramLinkedList.size())
          break;
      case 4:
      case 5:
      case 2:
      case 3:
      case 1:
      case 7:
      case 8:
      }
    while (true)
    {
      return;
      b(paramInt1, (b)paramLinkedList.get(paramInt2));
      paramInt2 += 1;
      break;
      paramInt2 = 0;
      while (paramInt2 < paramLinkedList.size())
      {
        a(paramInt1, ((Double)paramLinkedList.get(paramInt2)).doubleValue());
        paramInt2 += 1;
      }
      continue;
      paramInt2 = 0;
      while (paramInt2 < paramLinkedList.size())
      {
        f(paramInt1, ((Float)paramLinkedList.get(paramInt2)).floatValue());
        paramInt2 += 1;
      }
      continue;
      paramInt2 = 0;
      while (paramInt2 < paramLinkedList.size())
      {
        cH(paramInt1, ((Integer)paramLinkedList.get(paramInt2)).intValue());
        paramInt2 += 1;
      }
      continue;
      paramInt2 = 0;
      while (paramInt2 < paramLinkedList.size())
      {
        A(paramInt1, ((Long)paramLinkedList.get(paramInt2)).longValue());
        paramInt2 += 1;
      }
      continue;
      paramInt2 = 0;
      while (paramInt2 < paramLinkedList.size())
      {
        e(paramInt1, (String)paramLinkedList.get(paramInt2));
        paramInt2 += 1;
      }
      continue;
      paramInt2 = 0;
      while (paramInt2 < paramLinkedList.size())
      {
        T(paramInt1, ((Boolean)paramLinkedList.get(paramInt2)).booleanValue());
        paramInt2 += 1;
      }
      continue;
      paramInt2 = 0;
      while (paramInt2 < paramLinkedList.size())
      {
        com.tencent.mm.ay.a locala = (com.tencent.mm.ay.a)paramLinkedList.get(paramInt2);
        cJ(paramInt1, locala.atk());
        locala.a(this);
        paramInt2 += 1;
      }
    }
  }

  public final void e(int paramInt, String paramString)
  {
    a.a.a.b.b.a locala = this.nAZ;
    if (paramString != null)
    {
      locala.C(paramInt, 2);
      paramString = paramString.getBytes("UTF-8");
      locala.bl(paramString.length);
      locala.i(paramString);
    }
  }

  public final void f(int paramInt, float paramFloat)
  {
    a.a.a.b.b.a locala = this.nAZ;
    locala.C(paramInt, 5);
    paramInt = Float.floatToIntBits(paramFloat);
    locala.bj(paramInt & 0xFF);
    locala.bj(paramInt >> 8 & 0xFF);
    locala.bj(paramInt >> 16 & 0xFF);
    locala.bj(paramInt >> 24 & 0xFF);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     a.a.a.c.a
 * JD-Core Version:    0.6.2
 */