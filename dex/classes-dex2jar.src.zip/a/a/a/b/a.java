package a.a.a.b;

public final class a
{
  static final int nAU = 16;
  static final int nAV = 26;

  public static int D(int paramInt1, int paramInt2)
  {
    return paramInt1 << 3 | paramInt2;
  }

  public static int bn(int paramInt)
  {
    return paramInt & 0x7;
  }

  public static int bo(int paramInt)
  {
    return paramInt >>> 3;
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     a.a.a.b.a
 * JD-Core Version:    0.6.2
 */