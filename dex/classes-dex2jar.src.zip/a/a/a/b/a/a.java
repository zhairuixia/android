package a.a.a.b.a;

import java.io.InputStream;
import java.util.LinkedList;

public final class a
{
  public int ape;
  private int apf = 0;
  public int apg;
  public int aph = 0;
  private int api = 2147483647;
  private int apl = 67108864;
  public byte[] buffer;
  private InputStream nAW;
  private int nAX = 0;

  public a(byte[] paramArrayOfByte, int paramInt)
  {
    this.buffer = paramArrayOfByte;
    this.ape = (paramInt + 0);
    this.apg = 0;
    this.nAW = null;
  }

  private void bh(int paramInt)
  {
    if (paramInt < 0)
      throw b.byL();
    if (this.nAX + this.apg + paramInt > this.api)
    {
      bh(this.api - this.nAX - this.apg);
      throw b.byK();
    }
    if (paramInt < this.ape - this.apg)
      this.apg += paramInt;
    while (true)
    {
      return;
      int i = this.ape - this.apg;
      this.nAX += i;
      this.apg = 0;
      this.ape = 0;
      while (i < paramInt)
      {
        if (this.nAW == null);
        for (int j = -1; j <= 0; j = (int)this.nAW.skip(paramInt - i))
          throw b.byK();
        i += j;
        this.nAX = (j + this.nAX);
      }
    }
  }

  private byte jD()
  {
    if (this.apg == this.ape)
      jy(true);
    byte[] arrayOfByte = this.buffer;
    int i = this.apg;
    this.apg = (i + 1);
    return arrayOfByte[i];
  }

  private int[] wu(int paramInt)
  {
    int j = this.buffer[paramInt];
    int i = paramInt + 1;
    if (j >= 0)
      return new int[] { j, i };
    paramInt = j & 0x7F;
    j = this.buffer[i];
    if (j >= 0)
    {
      i += 1;
      paramInt |= j << 7;
    }
    int k;
    do
    {
      while (true)
      {
        return new int[] { paramInt, i };
        paramInt |= (j & 0x7F) << 7;
        j = this.buffer[i];
        if (j >= 0)
        {
          i += 1;
          paramInt |= j << 14;
        }
        else
        {
          paramInt |= (j & 0x7F) << 14;
          j = this.buffer[i];
          if (j < 0)
            break;
          i += 1;
          paramInt |= j << 21;
        }
      }
      k = this.buffer[i];
      paramInt = paramInt | (j & 0x7F) << 21 | k << 28;
      j = i + 1;
      i = j;
    }
    while (k >= 0);
    paramInt = 0;
    while (true)
    {
      if (paramInt >= 5)
        throw b.byM();
      if (this.buffer[j] >= 0)
        return new int[] { k, j + 1 };
      paramInt += 1;
    }
  }

  public final byte[] bg(int paramInt)
  {
    if (paramInt < 0)
      throw b.byL();
    if (this.nAX + this.apg + paramInt > this.api)
    {
      bh(this.api - this.nAX - this.apg);
      throw b.byK();
    }
    if (paramInt <= this.ape - this.apg)
    {
      localObject = new byte[paramInt];
      System.arraycopy(this.buffer, this.apg, localObject, 0, paramInt);
      this.apg += paramInt;
      return localObject;
    }
    if (paramInt < 2048)
    {
      localObject = new byte[paramInt];
      i = this.ape - this.apg;
      System.arraycopy(this.buffer, this.apg, localObject, 0, i);
      this.apg = this.ape;
      jy(true);
      while (true)
      {
        if (paramInt - i <= this.ape)
        {
          System.arraycopy(this.buffer, 0, localObject, i, paramInt - i);
          this.apg = (paramInt - i);
          return localObject;
        }
        System.arraycopy(this.buffer, 0, localObject, i, this.ape);
        i += this.ape;
        this.apg = this.ape;
        jy(true);
      }
    }
    int m = this.apg;
    int n = this.ape;
    this.nAX += this.ape;
    this.apg = 0;
    this.ape = 0;
    Object localObject = new LinkedList();
    int i = paramInt - (n - m);
    byte[] arrayOfByte1;
    if (i <= 0)
    {
      arrayOfByte1 = new byte[paramInt];
      i = n - m;
      System.arraycopy(this.buffer, m, arrayOfByte1, 0, i);
      paramInt = 0;
    }
    while (true)
    {
      if (paramInt >= ((LinkedList)localObject).size())
      {
        return arrayOfByte1;
        arrayOfByte1 = new byte[Math.min(i, 2048)];
        int j = 0;
        while (true)
        {
          if (j >= arrayOfByte1.length)
          {
            j = arrayOfByte1.length;
            ((LinkedList)localObject).add(arrayOfByte1);
            i -= j;
            break;
          }
          if (this.nAW == null);
          for (int k = -1; k == -1; k = this.nAW.read(arrayOfByte1, j, arrayOfByte1.length - j))
            throw b.byK();
          this.nAX += k;
          j += k;
        }
      }
      byte[] arrayOfByte2 = (byte[])((LinkedList)localObject).get(paramInt);
      System.arraycopy(arrayOfByte2, 0, arrayOfByte1, i, arrayOfByte2.length);
      i += arrayOfByte2.length;
      paramInt += 1;
    }
  }

  public final long jA()
  {
    int i = 0;
    long l = 0L;
    while (true)
    {
      if (i >= 64)
        throw b.byM();
      int j = jD();
      l |= (j & 0x7F) << i;
      if ((j & 0x80) == 0)
        return l;
      i += 7;
    }
  }

  public final boolean jy(boolean paramBoolean)
  {
    if (this.apg < this.ape)
      throw new IllegalStateException("refillBuffer() called when buffer wasn't empty.");
    if (this.nAX + this.ape == this.api)
    {
      if (paramBoolean)
        throw b.byK();
      return false;
    }
    this.nAX += this.ape;
    this.apg = 0;
    if (this.nAW == null);
    for (int i = -1; ; i = this.nAW.read(this.buffer))
    {
      this.ape = i;
      if (this.ape != -1)
        break label117;
      this.ape = 0;
      if (!paramBoolean)
        break;
      throw b.byK();
    }
    return false;
    label117: this.ape += this.apf;
    i = this.nAX + this.ape;
    if (i > this.api)
    {
      this.apf = (i - this.api);
      this.ape -= this.apf;
    }
    while (true)
    {
      i = this.nAX + this.ape + this.apf;
      if ((i <= this.apl) && (i >= 0))
        break;
      throw b.byO();
      this.apf = 0;
    }
    return true;
  }

  public final int jz()
  {
    int i = jD();
    if (i >= 0);
    int k;
    do
    {
      return i;
      i &= 127;
      j = jD();
      if (j >= 0)
        return i | j << 7;
      i |= (j & 0x7F) << 7;
      j = jD();
      if (j >= 0)
        return i | j << 14;
      i |= (j & 0x7F) << 14;
      k = jD();
      if (k >= 0)
        return i | k << 21;
      j = jD();
      k = i | (k & 0x7F) << 21 | j << 28;
      i = k;
    }
    while (j >= 0);
    int j = 0;
    while (true)
    {
      if (j >= 5)
        throw b.byM();
      i = k;
      if (jD() >= 0)
        break;
      j += 1;
    }
  }

  public final double readDouble()
  {
    int i = jD();
    int j = jD();
    int k = jD();
    int m = jD();
    int n = jD();
    int i1 = jD();
    int i2 = jD();
    int i3 = jD();
    long l = i;
    return Double.longBitsToDouble((j & 0xFF) << 8 | l & 0xFF | (k & 0xFF) << 16 | (m & 0xFF) << 24 | (n & 0xFF) << 32 | (i1 & 0xFF) << 40 | (i2 & 0xFF) << 48 | (i3 & 0xFF) << 56);
  }

  public final float readFloat()
  {
    return Float.intBitsToFloat(jD() & 0xFF | (jD() & 0xFF) << 8 | (jD() & 0xFF) << 16 | (jD() & 0xFF) << 24);
  }

  public final String readString()
  {
    int i = jz();
    if ((i < this.ape - this.apg) && (i > 0))
    {
      String str = new String(this.buffer, this.apg, i, "UTF-8");
      this.apg = (i + this.apg);
      return str;
    }
    return new String(bg(i), "UTF-8");
  }

  public final LinkedList<byte[]> wt(int paramInt)
  {
    LinkedList localLinkedList = new LinkedList();
    int i = jz();
    try
    {
      byte[] arrayOfByte = new byte[i];
      System.arraycopy(this.buffer, this.apg, arrayOfByte, 0, i);
      localLinkedList.add(arrayOfByte);
      this.apg = (i + this.apg);
      i = this.apg;
      if (this.apg == this.ape)
        return localLinkedList;
    }
    catch (OutOfMemoryError localOutOfMemoryError)
    {
      throw new OutOfMemoryError("alloc bytes:" + i);
    }
    Object localObject = wu(i);
    for (i = localObject[0]; ; i = localObject[0])
    {
      if (a.a.a.b.a.bo(i) != paramInt);
      do
      {
        return localLinkedList;
        this.apg = localObject[1];
        i = jz();
        localObject = new byte[i];
        System.arraycopy(this.buffer, this.apg, localObject, 0, i);
        localLinkedList.add(localObject);
        this.apg = (i + this.apg);
      }
      while (this.apg == this.ape);
      localObject = wu(this.apg);
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     a.a.a.b.a.a
 * JD-Core Version:    0.6.2
 */