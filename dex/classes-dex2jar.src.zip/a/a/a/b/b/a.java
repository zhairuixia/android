package a.a.a.b.b;

import java.io.UnsupportedEncodingException;

public final class a
{
  private final int apm;
  private final byte[] buffer;
  private int position;

  public a(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    this.buffer = paramArrayOfByte;
    this.position = 0;
    this.apm = (paramInt2 + 0);
  }

  public static int bk(int paramInt)
  {
    return bm(a.a.a.b.a.D(paramInt, 0));
  }

  public static int bm(int paramInt)
  {
    if ((paramInt & 0xFFFFFF80) == 0)
      return 1;
    if ((paramInt & 0xFFFFC000) == 0)
      return 2;
    if ((0xFFE00000 & paramInt) == 0)
      return 3;
    if ((0xF0000000 & paramInt) == 0)
      return 4;
    return 5;
  }

  public static int f(int paramInt, String paramString)
  {
    if (paramString == null)
      return 0;
    try
    {
      paramString = paramString.getBytes("UTF-8");
      paramInt = bk(paramInt);
      int i = bm(paramString.length);
      int j = paramString.length;
      return j + (paramInt + i);
    }
    catch (UnsupportedEncodingException paramString)
    {
    }
    throw new IllegalStateException("UTF-8 not supported.");
  }

  public final void C(int paramInt1, int paramInt2)
  {
    bl(a.a.a.b.a.D(paramInt1, paramInt2));
  }

  public final void bj(int paramInt)
  {
    int i = (byte)paramInt;
    byte[] arrayOfByte = this.buffer;
    paramInt = this.position;
    this.position = (paramInt + 1);
    arrayOfByte[paramInt] = i;
  }

  public final void bl(int paramInt)
  {
    while (true)
    {
      if ((paramInt & 0xFFFFFF80) == 0)
      {
        bj(paramInt);
        return;
      }
      bj(paramInt & 0x7F | 0x80);
      paramInt >>>= 7;
    }
  }

  public final void i(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null);
    int j;
    int i;
    do
    {
      do
      {
        return;
        j = paramArrayOfByte.length;
      }
      while (paramArrayOfByte == null);
      if (this.apm - this.position >= j)
      {
        System.arraycopy(paramArrayOfByte, 0, this.buffer, this.position, j);
        this.position = (j + this.position);
        return;
      }
      i = this.apm - this.position;
      System.arraycopy(paramArrayOfByte, 0, this.buffer, this.position, i);
      j -= i;
      this.position = this.apm;
    }
    while (j > this.apm);
    System.arraycopy(paramArrayOfByte, i + 0, this.buffer, 0, j);
    this.position = j;
  }

  public final void n(long paramLong)
  {
    while (true)
    {
      if ((0xFFFFFF80 & paramLong) == 0L)
      {
        bj((int)paramLong);
        return;
      }
      bj((int)paramLong & 0x7F | 0x80);
      paramLong >>>= 7;
    }
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     a.a.a.b.b.a
 * JD-Core Version:    0.6.2
 */