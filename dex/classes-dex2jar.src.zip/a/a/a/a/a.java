package a.a.a.a;

import java.util.LinkedList;

public final class a
{
  private final a.a.a.a.a.b kaq;
  public final a.a.a.b.a.a nAS;
  public int nAT = 0;

  public a(byte[] paramArrayOfByte, a.a.a.a.a.b paramb)
  {
    this.nAS = new a.a.a.b.a.a(paramArrayOfByte, paramArrayOfByte.length);
    this.kaq = paramb;
  }

  public final int byE()
  {
    return this.nAS.jz();
  }

  public final LinkedList<Integer> byF()
  {
    a.a.a.b.a.a locala = this.nAS;
    LinkedList localLinkedList = new LinkedList();
    while (true)
    {
      if (locala.apg >= locala.ape)
        return localLinkedList;
      localLinkedList.add(Integer.valueOf(locala.jz()));
    }
  }

  public final String byG()
  {
    return this.nAS.readString();
  }

  public final boolean byH()
  {
    return this.nAS.jz() != 0;
  }

  public final com.tencent.mm.ay.b byI()
  {
    a.a.a.b.a.a locala = this.nAS;
    int i = locala.jz();
    if ((i < locala.ape - locala.apg) && (i > 0))
    {
      com.tencent.mm.ay.b localb = com.tencent.mm.ay.b.g(locala.buffer, locala.apg, i);
      locala.apg = (i + locala.apg);
      return localb;
    }
    return com.tencent.mm.ay.b.aR(locala.bg(i));
  }

  public final void byJ()
  {
    int i = a.a.a.b.a.bn(this.nAT);
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("FieldNumber: ").append(a.a.a.b.a.bo(this.nAT)).append(" - ");
    switch (i)
    {
    case 3:
    case 4:
    default:
      return;
    case 5:
      localStringBuffer.append("float value: ").append(Float.toString(this.nAS.readFloat()));
      return;
    case 1:
      localStringBuffer.append("double value: ").append(Double.toString(this.nAS.readDouble()));
      return;
    case 2:
      localStringBuffer.append("Length delimited (String or ByteString) value: ").append(this.nAS.readString());
      return;
    case 0:
    }
    localStringBuffer.append("varint (long, int or boolean) value: ").append(this.nAS.jA());
  }

  public final LinkedList<byte[]> wt(int paramInt)
  {
    return this.nAS.wt(paramInt);
  }
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     a.a.a.a.a
 * JD-Core Version:    0.6.2
 */