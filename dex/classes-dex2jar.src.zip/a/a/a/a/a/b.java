package a.a.a.a.a;

public abstract interface b
{
}

/* Location:           /home/zz/zrx/dex/classes-dex2jar.jar
 * Qualified Name:     a.a.a.a.a.b
 * JD-Core Version:    0.6.2
 */